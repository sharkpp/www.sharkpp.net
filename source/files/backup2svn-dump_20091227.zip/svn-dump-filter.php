<?php

/*******************************************************************************
  The MIT License

  Copyright (c) 2009 Shark++ Software/sharkpp.

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

 ==============================================================================
  参考として The MIT License の日本語訳を下記に併記しますが、頒布条件としては、
  上記原文に従ってください。
 ==============================================================================

  The MIT License

  Copyright (c) 2009 Shark++ Software/sharkpp.

  以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル
  （以下「ソフトウェア」）の複製を取得するすべての人に対し、ソフトウェアを
  無制限に扱うことを無償で許可します。これには、ソフトウェアの複製を使用、
  複写、変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、
  およびソフトウェアを提供する相手に同じことを許可する権利も無制限に含まれ
  ます。

  上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要
  な部分に記載するものとします。

  ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの
  保証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、
  および権利非侵害についての保証も含みますが、それに限定されるものではあり
  ません。作者または著作権者は、契約行為、不法行為、またはそれ以外であろう
  と、ソフトウェアに起因または関連し、あるいはソフトウェアの使用またはその
  他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も
  負わないものとします。 
 *******************************************************************************/

include dirname(__FILE__) . '/get_option.php';

class svn_dump
{
	const FILE_SIGNATURE = "SVN-fs-dump-format-version: 2";
	const FIELD_REVISION_NUMBER		= "Revision-number";
	const FIELD_PROP_CONTENT_LENGTH	= "Prop-content-length";
	const FIELD_TEXT_CONTENT_LENGTH	= "Text-content-length";
	const FIELD_CONTENT_LENGTH		= "Content-length";
	const TERM_PROPS_END			= "PROPS-END";

	// ファイルシグネチャをチェック
	public static function check_signature($fp, &$uuid)
	{
		if( self::FILE_SIGNATURE != stream_get_line($fp, 1024, "\n\n") )
			return false;

		// UUID
		list(, $uuid) = explode(': ', stream_get_line($fp, 1024, "\n\n"));

		return true;
	}

	// ファイルシグネチャを書込み
	public static function write_signature($fp, $uuid)
	{
		fprintf($fp, "%s\n\n", self::FILE_SIGNATURE);
		fprintf($fp, "UUID: %s\n\n", $uuid);
	}

	// propからArray()への変換
	private static function prop_to_array($text)
	{
		$r = array();
		$pos = 0;
		$pos_last = strlen($text) - strlen(self::TERM_PROPS_END) - 1;
		while( $pos < $pos_last )
		{
			// K ?
			$new_pos = strpos($text, "\n", $pos);
			$tmp = explode(' ', substr($text, $pos, $new_pos - $pos));
			$pos = $new_pos + 1;
			$new_pos = $pos + intval($tmp[1]);
			// key
			$key = substr($text, $pos, $new_pos - $pos);
			$pos = $new_pos + 1;
			// V ?
			$new_pos = strpos($text, "\n", $pos);
			$tmp = explode(' ', substr($text, $pos, $new_pos - $pos));
			$pos = $new_pos + 1;
			$new_pos = $pos + intval($tmp[1]);
			// value
			$r[$key] = substr($text, $pos, $new_pos - $pos);
			$pos = $new_pos + 1;
		}
		return $r;
	}

	// Array()からpropへの変換
	private static function array_to_prop($props)
	{
		$r = '';
		foreach($props as $props_key => $props_value)
		{
			$r .= sprintf("K %d\n%s\nV %d\n%s\n",
						strlen($props_key),   $props_key,
						strlen($props_value), $props_value
					);
		}
		$r .= self::TERM_PROPS_END . "\n";
		return $r;
	}

	// １ブロックを読み込み
	private static function read_node($fp)
	{
		$r = array();

		while( !feof($fp) &&
		       '' == ($line = stream_get_line($fp, 1024*1024, "\n")) );
		while( !feof($fp) &&
		       '' != $line )
		{
			list($field_name, $field_value) = explode(': ', $line);

			$r[$field_name] = $field_value;

			$line = stream_get_line($fp, 1024*1024, "\n");
		}

		$prop_content_length = isset($r[self::FIELD_PROP_CONTENT_LENGTH])
		                            ? intval($r[self::FIELD_PROP_CONTENT_LENGTH])
		                            : -1;
		$text_content_length = isset($r[self::FIELD_TEXT_CONTENT_LENGTH])
		                            ? intval($r[self::FIELD_TEXT_CONTENT_LENGTH])
		                            : -1;

		if( 0 <= $prop_content_length )
		{
			$r['props']
				= self::prop_to_array(
					fread($fp, $prop_content_length));
		}
		if( 0 <= $text_content_length )
		{
			$r['text_content'] = fread($fp, $text_content_length);
		}

		return $r;
	}

	// 最後のブロック
	private static $last_node = array();

	// １リビジョン分を読み込み
	public static function read($fp)
	{
		$r = empty(self::$last_node)
					? self::read_node($fp)
					: self::$last_node;
		$r['nodes'] = array();

		$tmp = self::read_node($fp);

		if( empty($tmp) &&
			empty(self::$last_node) )
		{
			return false;
		}

		while( !empty($tmp) &&
		       !isset($tmp[self::FIELD_REVISION_NUMBER]) )
		{
			$r['nodes'][] = $tmp;

			$tmp = self::read_node($fp);
		}

		self::$last_node = empty($tmp) ? array() : $tmp;

		return $r;
	}

	// １ブロック分を書込み
	public static function write_node($fp, $node)
	{
	//	fwrite($fp, "\n");
		$tmp = '';
		foreach( $node as $field_name => $field_value )
		{
			if( 'nodes' != $field_name &&
			    'props' != $field_name &&
			    'text_content' != $field_name )
			{
				$tmp .= sprintf("%s: %s\n", $field_name, $field_value);
			}
		}
		$tmp .= "\n";
		fwrite($fp, $tmp);
		//
		if( isset($node['props']) )
		{
			fwrite($fp, self::array_to_prop($node['props']));
		//	fwrite($fp, "\n");
		}
		//
		if( isset($node['text_content']) )
		{
			fwrite($fp, $node['text_content']);
			fwrite($fp, "\n");
		}
		if( isset($node['Node-kind']) &&
		    'dir' == $node['Node-kind'] )
		{
			fwrite($fp, "\n");
		}
		if( !(isset($node['Node-action']) &&
		      'delete' == $node['Node-action']) )
		{
			fwrite($fp, "\n");
		}
	}

	// １リビジョンを書込み
	public static function write($fp, $revision)
	{
		self::write_node($fp, $revision);
		foreach( $revision['nodes'] as $node )
		{
			self::write_node($fp, $node);
		}
//		fwrite($fp, "\n");
	}
};

function string_calc(& $text, $val)
{
	$text = strval(intval($text) + $val);
}

//-----------------------------------------------------------------------------
// プログラムメイン
//-----------------------------------------------------------------------------

date_default_timezone_set('UTC');

// Windowsなら取り敢えずSJISにしておき、
// その他ならUTF-8
mb_http_output(isset($_SERVER['windir']) ? 'SJIS' : 'UTF-8');
ob_start("mb_output_handler");

// 引数解析
$args = get_option($argc, $argv,
				array(
					'target' =>
						array(
							'default'     => '',
							'description' => 'ターゲットのファイルを指定。',
						),
					'dest' =>
						array(
							'default'     => '',
							'description' => '出力先のファイルを指定。',
						),
				));
if( false === $args )
{
	exit(1);
}

ob_end_flush();
mb_http_output('pass');

// メイン処理

$revision_shift = 0;

$in  = @fopen(empty($args['target']) ? 'php://stdin'  : $args['target'], 'rb') or die("file not found.\n");
$out = @fopen(empty($args['dest'])   ? 'php://stdout' : $args['dest'],   'wb') or die("file not found.\n");

$repos_snapshot = array();

if( svn_dump::check_signature($in, $uuid) )
{
	svn_dump::write_signature($out, $uuid);
	$action = array('add' => '+', 'delete' => '-', 'change' => '*');
	while( false !== ($revision = svn_dump::read($in)) )
	{
		foreach($revision['nodes'] as & $node)
		{
			if( isset($node['Node-copyfrom-rev']) ) {
				string_calc($node['Node-copyfrom-rev'], -$revision_shift);
			}
			//
			switch( $node['Node-action'] )
			{
			case 'add':
				if( !isset($repos_snapshot[$node['Node-path']]) ) {
					$repos_snapshot[$node['Node-path']] = 1;
				} else {
					fprintf(STDERR, "Revision: %-5d add    error! %s\n", $revision[svn_dump::FIELD_REVISION_NUMBER], $node['Node-path']);
					$node = Array();
				}
				break;
			case 'delete':
				if( isset($repos_snapshot[$node['Node-path']]) ) {
					unset( $repos_snapshot[$node['Node-path']] );
				} else {
					fprintf(STDERR, "Revision: %-5d delete error! %s\n", $revision[svn_dump::FIELD_REVISION_NUMBER], $node['Node-path']);
					$node = Array();
				}
				break;
			case 'change':
				if( !isset($repos_snapshot[$node['Node-path']]) ) {
					fprintf(STDERR, "Revision: %-5d change error! %s\n", $revision[svn_dump::FIELD_REVISION_NUMBER], $node['Node-path']);
					$node = Array();
				}
				break;
			}
		}
		$revision['nodes'] = array_filter($revision['nodes'], create_function('$v', 'return !empty($v);'));
		if( 0 < intval($revision[svn_dump::FIELD_REVISION_NUMBER]) &&
		    empty($revision['nodes']) )
		{
			$revision_shift++;
			continue;
		}
		string_calc($revision[svn_dump::FIELD_REVISION_NUMBER], -$revision_shift);
		// コミット
		svn_dump::write($out, $revision);
	}
}

?>