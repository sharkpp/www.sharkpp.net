// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.


#include "common.h"


// WinSock������������Ă��邩�����t���O�B
BOOL bInit = FALSE;

// �C���X�^���X�n���h��
HINSTANCE g_hInstance = NULL;

// UDP�p�P�b�g�ő咷
unsigned int iMaxUdpDg = 0;

// TCP�p�P�b�g�T�C�Yx2
int iTCPSendBuf = 4096;
int iTCPRecvBuf = 16*1024;

// �ő�o�b�t�@�T�C�Y
int iMaxBuffer = 64*1024*1024;

// bind����C���^�[�t�F�[�X�A�h���X
unsigned long gBindAddress = htonl(INADDR_ANY);


////////////////////////////////////////////////////////////////



THREADINFO::THREADINFO() {
	InitializeCriticalSection(&crit);
	hInst = NULL;
	type = ST_UNDEFINED;
	soc = NULL;
	hWnd = NULL;
	err = 0;
	hAsync = NULL;
	ent = NULL;
	dwUser = 0;
}
THREADINFO::~THREADINFO() {
	DeleteCriticalSection(&crit);
}
void THREADINFO::Lock() {
	EnterCriticalSection(&crit);
}
void THREADINFO::Unlock() {
	LeaveCriticalSection(&crit);
}


////////////////////////////////////////////////////////////////


// WinSock������������B
// �߂�l�FFALSE   �������ɐ�������
//         TRUE    �������Ɏ��s����
BOOL InitWSA()
{
	WORD wVersionRequested;
	WSADATA wsaData;
	int nErrorCode;

	if (bInit) return FALSE;
#ifdef RAW_SUPPORT
	wVersionRequested = MAKEWORD(2, 2);
#else
	wVersionRequested = MAKEWORD(1, 1);
#endif
	nErrorCode = WSAStartup(wVersionRequested, &wsaData);
	iMaxUdpDg = wsaData.iMaxUdpDg;
	if (atexit((void (*)(void))WSACleanup))
		return TRUE;
	if (nErrorCode != 0)
		return TRUE;
	return FALSE;
}


HINSTANCE GetInstance() { return g_hInstance; }
unsigned int GetMaxUdpDg() { return iMaxUdpDg; }


////////////////////////////////////////////////////////////////


extern THREADLIST *pFirstThread;
LRESULT TCPProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, THREADINFO *ti);
LRESULT DNSProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, THREADINFO *ti);
LRESULT CALLBACK NetProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);


HWND SocketWindow(THREADINFO *ti)
{
	WNDCLASSEX wcl;

	memset(&wcl, 0, sizeof(wcl));
	wcl.cbSize = sizeof(wcl);
	wcl.lpfnWndProc = NetProc;
	wcl.hInstance = ti->hInst;
	wcl.lpszClassName = PCBNET_WNDCLASS;
	RegisterClassEx(&wcl);

	return CreateWindow(PCBNET_WNDCLASS, //"{6a01df94-d364-4dba-b80f-ec8e59f0c8fc}",
						"pcbnetASyncSocketWindow",
						0,
						CW_USEDEFAULT, CW_USEDEFAULT,
						CW_USEDEFAULT, CW_USEDEFAULT,
						NULL, NULL,
						ti->hInst,
						(LPVOID)ti);
}

DWORD WINAPI SocketThreadProc(LPVOID lpvParam)
{
	HWND hWnd;
	THREADINFO *ti = (LPTHREADINFO)lpvParam;
	MSG msg;

	hWnd = SocketWindow(ti);
	if (hWnd == NULL)
		return 1;

	while(GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 0;
}

void AddThreadList(THREADLIST *tl)
{
	THREADLIST **p = &pFirstThread;
	while(*p != NULL)
		p = &((*p)->next);
	tl->next = NULL;
	*p = tl;
}

BOOL CALLBACK GetThreadWindowProc(HWND hWnd, LPARAM lParam)
{
	char s[64+1];
	GetClassName(hWnd, s, 64);
	if (strcmp(s, PCBNET_WNDCLASS) != 0)
		return TRUE;
	*(HWND *)lParam = hWnd;
	return FALSE;
}

HWND GetThreadWindow(DWORD threadID)
{
	HWND hWnd = NULL;
	EnumThreadWindows(threadID, GetThreadWindowProc, (LPARAM)&hWnd);
	return hWnd;
}

LPTHREADLIST CreateSocketThread(int socktype)
{
	DWORD threadID, dwStat;
	HANDLE hThread;
	HWND hWnd;
	THREADINFO *ti = new THREADINFO;
	THREADLIST *tl;
	ti->type = socktype;
	ti->hInst = g_hInstance;
	hThread = CreateThread(NULL, 0, SocketThreadProc,
				(LPVOID)ti, 0, &threadID);

	dwStat = STILL_ACTIVE;
	while( dwStat == STILL_ACTIVE && (hWnd = GetThreadWindow(threadID)) == NULL ) {
		GetExitCodeThread(hThread, &dwStat);
		Sleep(1);
	}
	if (dwStat != STILL_ACTIVE) {
		CloseHandle(hThread);
		delete ti;
		return NULL;
	}

	tl = new THREADLIST;
	tl->hWnd = hWnd;
	tl->ti = ti;
	tl->threadID = threadID;
	tl->hThread = hThread;
	tl->next = NULL;
	AddThreadList(tl);
	return tl;
}

BOOL IsSocketThread(THREADLIST *pc)
{
	THREADLIST *p = pFirstThread;
	while(p != NULL) {
		if (p == pc) return TRUE;
		p = p->next;
	}
	return FALSE;
}

BOOL IsSocketHandle(THREADLIST *pc, int type)
{
	int ctype;
	if (! IsSocketThread(pc)) return FALSE;
	ctype = pc->ti->type;
	if ( (ctype & type) == 0 ) return FALSE;
	return TRUE;
}

BOOL DeleteThread(THREADLIST *pdel)
{
	THREADLIST **p = &pFirstThread;
	if (pdel == NULL) return FALSE;

	while(*p != NULL) {
		if (*p == pdel) {
			*p = pdel->next;
			PostMessage(pdel->hWnd, WM_SOCKDESTROY, 0, 0);
			WaitForSingleObject(pdel->hThread, INFINITE);
			CloseHandle(pdel->hThread);
			delete pdel->ti;
			delete pdel;
			return TRUE;
		}
		p = &((*p)->next);
	}
	return FALSE;
}

void DestroyThread()
{
	while(DeleteThread(pFirstThread));
}

/*
unsigned short CheckSum(char *buf, int len)
{
	unsigned short *buffer = (unsigned short *)buf;
    unsigned long cksum=0;
    while(len >1) {
	    cksum+=*buffer++;
    	len -= sizeof(unsigned short);
    }

    if(len) {
	    cksum += *(unsigned char *)buffer;
    }
    cksum = (cksum >> 16) + (cksum & 0xffff);
    cksum += (cksum >>16);
    return (unsigned short)(~cksum);
}
*/

unsigned short CheckSum(char *buf, int len)
{
	unsigned long t = 0;
	int i;

	for(i=0; i<len/2; i++)
		t += ((unsigned short *)buf)[i];
	if (len&1)
		t += ((unsigned char *)buf)[len-1];

	t = (t >> 16) + (t & 0xffff);
	return (unsigned short)(~( (t >> 16) + (t & 0xffff) ));
}


BOOL isWildcardHost(unsigned long addr)
{
	if (addr == inet_addr("64.55.105.9") ||
		addr == inet_addr("64.94.110.11") ||
		addr == inet_addr("194.205.62.62") ||
		addr == inet_addr("194.205.62.122") ||
		addr == inet_addr("195.7.77.20") ||
		addr == inet_addr("203.119.4.6") ||
		addr == inet_addr("206.253.214.102") ||
		addr == inet_addr("212.181.91.6") ||
		addr == inet_addr("216.35.187.246") ||
		addr == inet_addr("219.88.106.80")) {
		return TRUE;
	}
	return FALSE;
}

