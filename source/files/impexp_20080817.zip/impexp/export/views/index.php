<h1><?php echo __('Export'); ?></h1>

<form action="<?php echo get_url('plugin/export/fxr'); ?>" method="post">
<!--
	<table class="fieldset" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td class="label"><label for="setting_admin_title">a</label></td>
			<td class="field">b</td>
			<td class="help">c</td>
		</tr>
	</table>
-->
	<p class="buttons">
		<input class="button" name="commit" type="submit" accesskey="s" value="<?php echo __('Download export file'); ?>" />
	</p>
</form>

<?php
//echo Flash::get('log');
?>
