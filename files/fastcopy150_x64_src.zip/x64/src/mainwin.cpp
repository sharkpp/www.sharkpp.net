static char *mainwin_id = 
	"@(#)Copyright (C) H.Shirouzu 2004-2006   maindlg.cpp	ver1.50";
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2004-09-15(Wed)
	Update					: 2006-08-27(Sun)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "mainwin.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>

/*=========================================================================
  �N���X �F TFastCopyApp
  �T  �v �F �A�v���P�[�V�����N���X
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
TFastCopyApp::TFastCopyApp(HINSTANCE _hI, LPSTR _cmdLine, int _nCmdShow) : TApp(_hI, _cmdLine, _nCmdShow)
{
	LoadLibrary("RICHED20.DLL");
}

TFastCopyApp::~TFastCopyApp()
{
}

void TFastCopyApp::InitWindow(void)
{
	TRegisterClass(FASTCOPY_CLASS);

	TDlg *mainDlg = new TMainDlg();
	mainWnd = mainDlg;
	mainDlg->Create();
}

int WINAPI WinMain(HINSTANCE _hI, HINSTANCE, LPSTR arg, int show)
{
	return	TFastCopyApp(_hI, arg, show).Run();
}


/*=========================================================================
  �N���X �F TMainDlg
  �T  �v �F ���C���_�C�A���O
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
TMainDlg::TMainDlg() : TDlg(MAIN_DIALOG), aboutDlg(this), setupDlg(&cfg, this), shellExtDlg(&cfg, this), jobDlg(&cfg, this)
{
	cfg.ReadIni();

	if (cfg.lcid > 0)
		TSetDefaultLCID(cfg.lcid);

	isShellExt = FALSE;
	isErrLog = cfg.isErrLog;
	forceStart = cfg.forceStart;
	isTaskTray = noConfirmDel = FALSE;
	isNetPlaceSrc = FALSE;
	skipEmptyDir = cfg.skipEmptyDir;
	diskMode = cfg.diskMode;
//	isRegExp = FALSE;
//	isFilter = FALSE;
	autoCloseLevel = NO_CLOSE;
	curIconIndex = 0;
	pathLogBuf = NULL;
	isDelay = FALSE;
	endTick = 0;
	hErrLogFile = INVALID_HANDLE_VALUE;
	memset(&ti, 0, sizeof(ti));
}

TMainDlg::~TMainDlg()
{
}

struct CopyInfo COPYINFO_LIST [] = {
	{ IDS_ALLSKIP,		NULL,	IDS_CMD_NOEXIST_ONLY, NULL,	FastCopy::DIFFCP_MODE,	FastCopy::BY_NAME },
	{ IDS_ATTRCMP,		NULL,	IDS_CMD_DIFF,		NULL,	FastCopy::DIFFCP_MODE,	FastCopy::BY_ATTR },
	{ IDS_UPDATECOPY,	NULL,	IDS_CMD_UPDATE,		NULL,	FastCopy::DIFFCP_MODE,	FastCopy::BY_LASTEST },
	{ IDS_FORCECOPY,	NULL,	IDS_CMD_FORCE_COPY,	NULL,	FastCopy::DIFFCP_MODE,	FastCopy::BY_ALWAYS },
	{ IDS_SYNCCOPY,		NULL,	IDS_CMD_SYNC,		NULL,	FastCopy::SYNCCP_MODE,	FastCopy::BY_ATTR },
//	{ IDS_MOVEATTR,		NULL,	IDS_CMD_MOVE,		NULL,	FastCopy::MOVE_MODE,	FastCopy::BY_ATTR },
	{ IDS_MOVEFORCE,	NULL,	IDS_CMD_MOVE,		NULL,	FastCopy::MOVE_MODE,	FastCopy::BY_ALWAYS },
	{ IDS_DELETE,		NULL,	IDS_CMD_DELETE,		NULL,	FastCopy::DELETE_MODE,	FastCopy::BY_ALWAYS },
	{ 0,				NULL,	0,					NULL,	(FastCopy::Mode)0,		(FastCopy::OverWrite)0 }
};

void TMainDlg::SetPathHistory(void)
{
	int		item[] = { SRC_COMBO, DST_COMBO, 0 };
	void	**history[] = { cfg.srcPathHistory, cfg.dstPathHistory, NULL };

	SetHistory(item, history);
}

void TMainDlg::SetFilterHistory(void)
{
	int		item[] = { INCLUDE_COMBO, EXCLUDE_COMBO, 0 };
	void	**history[] = { cfg.includeHistory, cfg.excludeHistory, NULL };

	SetHistory(item, history);
}

void TMainDlg::SetHistory(int *item, void ***history)
{
	for (int i=0; item[i]; i++) {
		SendDlgItemMessage(item[i], CB_RESETCONTENT, 0, 0);
		for (int j=0; j < cfg.maxHistory; j++) {
			if (GetChar(history[i][j], 0))
				SendDlgItemMessageV(item[i], CB_INSERTSTRING, j, (LPARAM)history[i][j]);
		}
		if (cfg.maxHistory > 0 && ::IsWindowEnabled(GetDlgItem(item[i])))
			SetDlgItemTextV(item[i], history[i][0]);
	}
}

BOOL TMainDlg::SetMiniWindow(void)
{
	GetWindowRect(&rect);
	int height = rect.bottom - rect.top - (isErrEditHide ? 0 : normalHeight - miniHeight);
	isErrEditHide = TRUE;
	MoveWindow(rect.left, rect.top, rect.right - rect.left, height, ::IsWindowVisible(hWnd));
	return	TRUE;
}

BOOL TMainDlg::SetNormalWindow(void)
{
	if (::IsWindowVisible(hWnd)) {
		GetWindowRect(&rect);
		int height = rect.bottom - rect.top + (isErrEditHide ? normalHeight - miniHeight : 0);
		isErrEditHide = FALSE;
		MoveWindow(rect.left, rect.top, rect.right - rect.left, height, TRUE);
	}
	return	TRUE;
}

BOOL TMainDlg::EvCreate(LPARAM lParam)
{
	char	buf[100];
	int		i;

	hAccel = LoadAccelerators(TApp::GetInstance(), (LPCSTR)IDR_ACCEL);

	for (i=0; i < MAX_FASTCOPY_ICON; i++)
		hMainIcon[i] = ::LoadIcon(TApp::GetInstance(), (LPCSTR)(FASTCOPY_ICON + i));
	::SetClassLongPtr(hWnd, GCLP_HICON, (LONG_PTR)hMainIcon[FCNORMAL_ICON_INDEX]);

	SetSize();

	isErrEditHide = FALSE;
	// ��O�t�B���^�̐ݒ�
	SetWindowTitle("FastCopy %s", GetVersionStr());
	GetWindowText(buf, sizeof(buf));
	InstallExceptionFilter(buf);

	TaskBarCreateMsg = ::RegisterWindowMessage("TaskbarCreated");

	// �����Z�b�g
	SetPathHistory();
	SetFilterHistory();

	// ���b�Z�[�W�Z�b�g
	SetDlgItemText(STATUS_EDIT, GetLoadStr(IDS_BEHAVIOR));
	SetDlgItemInt(BUFSIZE_EDIT, cfg.bufSize);

	// �R�s�[���[�h���X�g�쐬
	for (i=0; COPYINFO_LIST[i].resId; i++) {
		COPYINFO_LIST[i].list_str = GetLoadStr(COPYINFO_LIST[i].resId);
		SendDlgItemMessage(MODE_COMBO, CB_ADDSTRING, 0, (LPARAM)COPYINFO_LIST[i].list_str);
		COPYINFO_LIST[i].cmdline_name = GetLoadStrV(COPYINFO_LIST[i].cmdline_resId);
	}
	UpdateMenu();

	// �R�s�[���[�h���X�g�̃f�t�H���g�I��
	SendDlgItemMessage(MODE_COMBO, CB_SETCURSEL, cfg.copyMode, 0);

	::CheckDlgButton(hWnd, IGNORE_CHECK, cfg.ignoreErr);
	::CheckDlgButton(hWnd, ESTIMATE_CHECK, cfg.estimateMode);
	::CheckDlgButton(hWnd, TOPLEVEL_CHECK, cfg.isTopLevel);
	SetForegroundWindow();
	if (cfg.isTopLevel)
		SetWindowPos(HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOMOVE);

	SendDlgItemMessage(STATUS_EDIT, EM_SETWORDBREAKPROC, 0, (LPARAM)EditWordBreakProc);
//	SendDlgItemMessage(ERR_EDIT, EM_SETWORDBREAKPROC, 0, (LPARAM)EditWordBreakProc);
	SendDlgItemMessage(ERR_EDIT, EM_SETTARGETDEVICE, 0, 0);		// �܂�Ԃ�
	SendDlgItemMessage(ERR_EDIT, EM_LIMITTEXT, 0, 0);
	SendDlgItemMessage(PATH_EDIT, EM_LIMITTEXT, 0, 0);

	GetWindowRect(&rect);

	int	offset_x = (GetSystemMetrics(SM_CXFULLSCREEN) - (rect.right - rect.left)) / 2;
	int	offset_y = (GetSystemMetrics(SM_CYFULLSCREEN) - (rect.bottom - rect.top)) / 2;

	SetWindowPos(NULL, offset_x, offset_y, 0, 0, SWP_NOSIZE|SWP_NOZORDER);

	RECT	path_rect, err_rect;
	GetWindowRect(&rect);
	::GetWindowRect(GetDlgItem(PATH_EDIT), &path_rect);
	::GetWindowRect(GetDlgItem(ERR_EDIT), &err_rect);
	SendDlgItemMessage(PATH_EDIT, EM_SETBKGNDCOLOR, 0, ::GetSysColor(COLOR_3DFACE));
	SendDlgItemMessage(ERR_EDIT, EM_SETBKGNDCOLOR, 0, ::GetSysColor(COLOR_3DFACE));
	normalHeight	= rect.bottom - rect.top;
	miniHeight		= normalHeight - (err_rect.bottom - path_rect.bottom);
	SetMiniWindow();

	int		argc;
	void	**argv;

	argv = CommandLineToArgvV(::GetCommandLineV(), &argc);

	// command line mode
	if (argc > 1) {
		if (!CommandLineExecV(argc, argv) && (!isShellExt || autoCloseLevel >= NOERR_CLOSE)) {
			if (::GetAsyncKeyState(VK_SHIFT) & 0x8000)
				autoCloseLevel = NO_CLOSE;
			else
				PostMessage(WM_CLOSE, 0, 0);
		}
	}
	else
		Show();
	return	TRUE;
}

BOOL TMainDlg::EvNcDestroy(void)
{
	TaskTray(NIM_DELETE);
	PostQuitMessage(0);
	return	TRUE;
}

BOOL TMainDlg::CancelCopy()
{
	if (!isDelay)
		fastCopy.Suspend();

	::KillTimer(hWnd, FASTCOPY_TIMER);
	int	ret = TMsgBox(this).Exec(GetLoadStr(IsListing() ? IDS_LISTCONFIRM : info.mode == FastCopy::DELETE_MODE ? IDS_DELSTOPCONFIRM : IDS_STOPCONFIRM), FASTCOPY, MB_OKCANCEL);

	if (isDelay) {
		isDelay = FALSE;
		EndCopy();
	}
	else {
		fastCopy.Resume();

		if (ret == IDOK)
			fastCopy.Aborting();
		else
			::SetTimer(hWnd, FASTCOPY_TIMER, 1000, NULL);
	}

	return	ret == IDOK ? TRUE : FALSE;
}

BOOL TMainDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID) {
	case IDOK: case LIST_BUTTON:
		if (!fastCopy.IsStarting() && !isDelay) {
			if ((::GetTickCount() - endTick) > 1000)
				ExecCopy(wID == LIST_BUTTON ? LISTING_EXEC : NORMAL_EXEC);
		}
		else if (CancelCopy()) {
			autoCloseLevel = NO_CLOSE;
		}
		return	TRUE;

	case IDCANCEL: case CLOSE_MENUITEM:
		if (!fastCopy.IsStarting()) {
			EndDialog(wID);
		}
		else if (fastCopy.IsAborting()) {
			if (TMsgBox(this).Exec(GetLoadStr(IDS_CONFIRMFORCEEND), FASTCOPY, MB_OKCANCEL) == IDOK)
				EndDialog(wID);
		}
		else {
			CancelCopy();
			autoCloseLevel = NOERR_CLOSE;
		}
		return	TRUE;

	case ATONCE_BUTTON:
		isDelay = FALSE;
		::KillTimer(hWnd, FASTCOPY_TIMER);
		ExecCopyCore();
		return	TRUE;

	case SRC_FILE_BUTTON:
		BrowseDirDlgV(this, SRC_COMBO, GetLoadStrV(IDS_SRC_SELECT), BRDIR_VQUOTE|BRDIR_FILESELECT);
		return	TRUE;

	case DST_FILE_BUTTON:
		BrowseDirDlgV(this, DST_COMBO, GetLoadStrV(IDS_DST_SELECT), BRDIR_BACKSLASH);
		return	TRUE;

	case TOPLEVEL_CHECK:
		cfg.isTopLevel = IsDlgButtonChecked(TOPLEVEL_CHECK);
		SetWindowPos(cfg.isTopLevel ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOMOVE);
		cfg.WriteIni();
		break;

	case MODE_COMBO:
		if (wNotifyCode == CBN_SELCHANGE) {
			BOOL	is_delete = GetCopyMode() == FastCopy::DELETE_MODE;
			if (is_delete && isNetPlaceSrc) {
				SetDlgItemTextV(SRC_COMBO, EMPTY_STR_V);
				isNetPlaceSrc = FALSE;
			}
			SetItemEnable(is_delete);
		}
		return	TRUE;

	case FILTER_CHECK:
		ReflectFilterCheck();
		return	TRUE;

	case OPENDIR_MENUITEM:
		::ShellExecute(NULL, NULL, cfg.execDir, 0, 0, SW_SHOW);
		return	TRUE;

	case SETUP_MENUITEM:
		if (setupDlg.Exec() == IDOK) {
			SetDlgItemInt(BUFSIZE_EDIT, cfg.bufSize);
			CheckDlgButton(IGNORE_CHECK, cfg.ignoreErr);
			CheckDlgButton(ESTIMATE_CHECK, cfg.estimateMode);
			isErrLog = cfg.isErrLog;
			skipEmptyDir = cfg.skipEmptyDir;
			forceStart = cfg.forceStart;
		}
		return	TRUE;

	case SHELLEXT_MENUITEM:
		shellExtDlg.Exec();
		return	TRUE;

	case ABOUT_MENUITEM:
		aboutDlg.Exec();
		return	TRUE;

	case FASTCOPYURL_MENUITEM:
		::ShellExecute(NULL, NULL, GetLoadStr(IDS_FASTCOPYURL), NULL, NULL, SW_SHOW);
		return	TRUE;

	case AUTODISK_MENUITEM: case SAMEDISK_MENUITEM: case DIFFDISK_MENUITEM:
		diskMode = wID - AUTODISK_MENUITEM;
		UpdateMenu();
		break;

	case IDR_DISKMODE:
		diskMode = (diskMode + 1) % 3;
		UpdateMenu();
		break;

	case JOB_MENUITEM:
		jobDlg.Exec();
		UpdateMenu();
		return	TRUE;

	case HELP_BUTTON: case HELP_MENUITEM:
		ShowHelp(hWnd, cfg.execDir, GetLoadStr(IDS_FASTCOPYHELP), wID == HELP_BUTTON ? "#usage" : NULL);
		return	TRUE;

	default:
		if (wID >= JOBOBJ_MENUITEM_START && wID <= JOBOBJ_MENUITEM_END) {
			int idx = wID - JOBOBJ_MENUITEM_START;
			if (idx < cfg.jobMax) {
				SetJob(idx);
			}
			return TRUE;
		}
		break;
	}
	return	FALSE;
}

BOOL TMainDlg::EvSysCommand(WPARAM uCmdType, POINTS pos)
{
	switch (uCmdType)
	{
	case SC_RESTORE: case SC_MAXIMIZE:
		return	TRUE;

	case SC_MINIMIZE:
		PostMessage(WM_FASTCOPY_HIDDEN, 0, 0);
		return	TRUE;
	}
	return	FALSE;
}

BOOL TMainDlg::EvSize(UINT fwSizeType, WORD nWidth, WORD nHeight)
{
	if (fwSizeType != SIZE_RESTORED && fwSizeType != SIZE_MAXIMIZED)
		return	FALSE;

	RefreshWindow();
	return	TRUE;
}

void TMainDlg::RefreshWindow(void)
{
	GetWindowRect(&rect);
	int	xdiff = (rect.right - rect.left) - (orgRect.right - orgRect.left);
	int ydiff = (rect.bottom - rect.top) - (orgRect.bottom - orgRect.top) + (isErrEditHide ? normalHeight - miniHeight : 0);

	HDWP	hdwp = ::BeginDeferWindowPos(max_dlgitem);	// MAX item number
	UINT	dwFlg		= SWP_SHOWWINDOW | SWP_NOZORDER;
	UINT	dwHideFlg	= SWP_HIDEWINDOW | SWP_NOZORDER;
	DlgItem	*item;
	int		*target;
	BOOL	is_delete = GetCopyMode() == FastCopy::DELETE_MODE;

	int	slide_y[] = { errstatus_item, errstatic_item, -1 };
	for (target=slide_y; *target != -1; target++) {
		item = dlgItems + *target;
		hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x, item->wpos.y + ydiff, item->wpos.cx, item->wpos.cy, isErrEditHide ? dwHideFlg : dwFlg);
	}

	item = dlgItems + erredit_item;
	hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x, item->wpos.y + ydiff, item->wpos.cx + xdiff, item->wpos.cy, isErrEditHide ? dwHideFlg : dwFlg);

	item = dlgItems + path_item;
	hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x, item->wpos.y, item->wpos.cx + xdiff, item->wpos.cy + ydiff, dwFlg);

	item = dlgItems + filter_item;
	hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x + xdiff, item->wpos.y, item->wpos.cx, item->wpos.cy, dwFlg);

	int	harf_growslide_x[] = { exccombo_item, excstatic_item, -1 };
	for (target=harf_growslide_x; *target != -1; target++) {
		item = dlgItems + *target;
		hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x + xdiff/2, item->wpos.y, item->wpos.cx + xdiff/2, item->wpos.cy, dwFlg);
	}

	int	harf_glow_x[] = { inccombo_item, incstatic_item, -1 };
	for (target=harf_glow_x; *target != -1; target++) {
		item = dlgItems + *target;
		hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x, item->wpos.y, item->wpos.cx + xdiff/2, item->wpos.cy, dwFlg);
	}

	BOOL	is_exec = fastCopy.IsStarting() || isDelay;

	int	slide_x[] = { samedrv_item, ok_item, list_item, top_item, estimate_item, ignore_item, bufedit_item, bufstatic_item, help_item, mode_item, -1 };
	for (target=slide_x; *target != -1; target++) {
		item = dlgItems + *target;
		hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x + xdiff, item->wpos.y, item->wpos.cx, item->wpos.cy,
			is_exec && (*target == list_item && !IsListing() || *target == ok_item && IsListing()) ||
			is_delete && *target == estimate_item ? dwHideFlg : dwFlg);
	}

	int	grow_x[] = { srccombo_item, dstcombo_item, -1 };
	for (target=grow_x; *target != -1; target++) {
		item = dlgItems + *target;
		hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x, item->wpos.y, item->wpos.cx + xdiff, item->wpos.cy, dwFlg);
	}

	item = dlgItems + atonce_item;
	hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x, item->wpos.y, item->wpos.cx + xdiff, item->wpos.cy, !isDelay ? dwHideFlg : dwFlg);

	item = dlgItems + status_item;
	hdwp = ::DeferWindowPos(hdwp, item->hWnd, 0, item->wpos.x, item->wpos.y, item->wpos.cx + xdiff, (!isDelay ? dlgItems[atonce_item].wpos.y + dlgItems[atonce_item].wpos.cy - item->wpos.y : item->wpos.cy), dwFlg);

	EndDeferWindowPos(hdwp);
}

void TMainDlg::SetDlgItem(UINT ctl_id, DlgItem *item)
{
	WINDOWPLACEMENT wp;
	wp.length = sizeof(wp);

	item->hWnd = GetDlgItem(ctl_id);
	::GetWindowPlacement(item->hWnd, &wp);
	item->wpos.x = wp.rcNormalPosition.left;
	item->wpos.y = wp.rcNormalPosition.top;
	item->wpos.cx = wp.rcNormalPosition.right - wp.rcNormalPosition.left;
	item->wpos.cy = wp.rcNormalPosition.bottom - wp.rcNormalPosition.top;
}

void TMainDlg::SetSize(void)
{
	SetDlgItem(SRC_FILE_BUTTON,	&dlgItems[srcbutton_item]);
	SetDlgItem(DST_FILE_BUTTON,	&dlgItems[dstbutton_item]);
	SetDlgItem(SRC_COMBO,		&dlgItems[srccombo_item]);
	SetDlgItem(DST_COMBO,		&dlgItems[dstcombo_item]);
	SetDlgItem(STATUS_EDIT,		&dlgItems[status_item]);
	SetDlgItem(MODE_COMBO,		&dlgItems[mode_item]);
	SetDlgItem(BUF_STATIC,		&dlgItems[bufstatic_item]);
	SetDlgItem(BUFSIZE_EDIT,	&dlgItems[bufedit_item]);
	SetDlgItem(HELP_BUTTON,		&dlgItems[help_item]);
	SetDlgItem(IGNORE_CHECK,	&dlgItems[ignore_item]);
	SetDlgItem(ESTIMATE_CHECK,	&dlgItems[estimate_item]);
	SetDlgItem(TOPLEVEL_CHECK,	&dlgItems[top_item]);
	SetDlgItem(LIST_BUTTON,		&dlgItems[list_item]);
	SetDlgItem(IDOK,			&dlgItems[ok_item]);
	SetDlgItem(ATONCE_BUTTON,	&dlgItems[atonce_item]);
	SetDlgItem(SAMEDRV_STATIC,	&dlgItems[samedrv_item]);
	SetDlgItem(INC_STATIC,		&dlgItems[incstatic_item]);
	SetDlgItem(EXC_STATIC,		&dlgItems[excstatic_item]);
	SetDlgItem(INCLUDE_COMBO,	&dlgItems[inccombo_item]);
	SetDlgItem(EXCLUDE_COMBO,	&dlgItems[exccombo_item]);
	SetDlgItem(FILTER_CHECK,	&dlgItems[filter_item]);
	SetDlgItem(PATH_EDIT,		&dlgItems[path_item]);
	SetDlgItem(ERR_STATIC,		&dlgItems[errstatic_item]);
	SetDlgItem(ERRSTATUS_STATIC,&dlgItems[errstatus_item]);
	SetDlgItem(ERR_EDIT,		&dlgItems[erredit_item]);

	GetWindowRect(&rect);
	orgRect = rect;
}

/*
	DropFiles Event CallBack
*/
BOOL TMainDlg::EvDropFiles(HDROP hDrop)
{
	PathArray	pathArray;
	WCHAR	path[MAX_PATH_EX];
	BOOL	isDstDrop = IsDestDropFiles(hDrop);
	BOOL	isDeleteMode = GetCopyMode() == FastCopy::DELETE_MODE;
	int		max = isDstDrop ? 1 : ::DragQueryFileV(hDrop, 0xffffffff, 0, 0), max_len = 0;

	// CTL ��������Ă���ꍇ�A���݂̓��e�����Z
	if (!isDstDrop) {
		if (::GetAsyncKeyState(VK_CONTROL) & 0x8000) {
			max_len = ::GetWindowTextLengthV(GetDlgItem(SRC_COMBO)) + 1;
			WCHAR	*buf = new WCHAR [max_len];
			GetDlgItemTextV(SRC_COMBO, buf, max_len);
			pathArray.RegistMultiPath(buf);
			delete [] buf;
		}
		else
			isNetPlaceSrc = FALSE;
	}

	for (int i=0; i < max; i++) {
		if (::DragQueryFileV(hDrop, i, path, sizeof(path) / CHAR_LEN_V) <= 0)
			break;

		if (isDstDrop || !isDeleteMode) {
			if (NetPlaceConvertV(path, path) && !isDstDrop)
				isNetPlaceSrc = TRUE;
		}
		max_len += strlenV(path) + 3;
		pathArray.RegistPath(path);
	}
	::DragFinish(hDrop);

	if (max_len > 0) {
		WCHAR	*buf = new WCHAR [max_len += pathArray.Num() * 2];	// ������A���p�̈�

		if (isDstDrop) {
			DWORD	attr = ::GetFileAttributesV(pathArray.Path(0));
			if (attr & FILE_ATTRIBUTE_DIRECTORY) {	// 0xffffffff ���F�߂�(for 95�nOS��root�΍�)
				MakePathV(path, pathArray.Path(0), EMPTY_STR_V);
				SetDlgItemTextV(DST_COMBO, path);
			}
		}
		else {
			if (pathArray.GetMultiPath(buf, max_len))
				SetDlgItemTextV(SRC_COMBO, buf);
		}
		delete [] buf;
	}
	return	TRUE;
}

FastCopy::Mode TMainDlg::GetCopyMode(void)
{
	return	COPYINFO_LIST[SendDlgItemMessage(MODE_COMBO, CB_GETCURSEL, 0, 0)].mode;
}

void TMainDlg::ReflectFilterCheck(BOOL is_invert)
{
	BOOL	is_show_filter = GetCopyMode() != FastCopy::MOVE_MODE;
	BOOL	is_checked = IsDlgButtonChecked(FILTER_CHECK);
	BOOL	new_status = (is_invert ? !is_checked : is_checked) && is_show_filter;

//	::ShowWindow(GetDlgItem(FILTER_CHECK), is_show_filter ? SW_SHOW : SW_HIDE);
//	::ShowWindow(GetDlgItem(INCLUDE_COMBO), is_show_filter ? SW_SHOW : SW_HIDE);
//	::ShowWindow(GetDlgItem(EXCLUDE_COMBO), is_show_filter ? SW_SHOW : SW_HIDE);
//	if (is_show_filter)
		::CheckDlgButton(hWnd, FILTER_CHECK, new_status);
	::EnableWindow(GetDlgItem(FILTER_CHECK), is_show_filter);
	::EnableWindow(GetDlgItem(INCLUDE_COMBO), new_status);
	::EnableWindow(GetDlgItem(EXCLUDE_COMBO), new_status);
}

BOOL TMainDlg::IsDestDropFiles(HDROP hDrop)
{
	POINT	pt;
	RECT	dst_rect;

	if (::DragQueryPoint(hDrop, &pt) == FALSE || ::ClientToScreen(hWnd, &pt) == FALSE)
		return	FALSE;

	if (::GetWindowRect(GetDlgItem(DST_COMBO), &dst_rect) == FALSE || PtInRect(&dst_rect, pt) == FALSE)
		return	FALSE;

	return	TRUE;
}


BOOL TMainDlg::ExecCopy(DWORD exec_flags)
{
	int		idx = SendDlgItemMessage(MODE_COMBO, CB_GETCURSEL, 0, 0);
	BOOL	is_delete_mode = COPYINFO_LIST[idx].mode == FastCopy::DELETE_MODE;
	BOOL	is_filter = IsDlgButtonChecked(FILTER_CHECK);
	BOOL	is_listing = (exec_flags & LISTING_EXEC) ? TRUE : FALSE;

	info.ignoreErr		= IsDlgButtonChecked(IGNORE_CHECK);
	info.mode			= COPYINFO_LIST[idx].mode;
	info.overWrite		= COPYINFO_LIST[idx].overWrite;
	info.isPhysLock		= IS_WINNT_V ? TRUE : FALSE;
	info.lcid			= cfg.lcid > 0 && IsWinNT() ? ::GetThreadLocale() : 0;
	info.flags			= cfg.copyFlags
		| (!is_delete_mode && IsDlgButtonChecked(ESTIMATE_CHECK) && !is_listing ? FastCopy::PRE_SEARCH : 0)
		| (cfg.isSameDirRename ? FastCopy::SAMEDIR_RENAME : 0)
		| (is_listing ? FastCopy::LISTING_ONLY : 0)
		| (skipEmptyDir && is_filter ? FastCopy::SKIP_EMPTYDIR : 0)
		| (diskMode == 0 ? 0 : diskMode == 1 ? FastCopy::FIX_SAMEDISK : FastCopy::FIX_DIFFDISK);
	info.bufSize		= GetDlgItemInt(BUFSIZE_EDIT) * 1024 * 1024;
	info.maxTransSize	= cfg.maxTransSize * 1024 * 1024;
	info.maxOpenFiles	= cfg.maxOpenFiles;
	info.nbMinSizeNtfs	= cfg.nbMinSizeNtfs * 1024;
	info.nbMinSizeFat	= cfg.nbMinSizeFat * 1024;
	info.notifyWnd		= this;
	info.uNotifyMsg		= WM_FASTCOPY_MSG;
	errBufOffset		= 0;
	listBufOffset		= 0;

	memset(&ti, 0, sizeof(ti));

	int		src_len = ::GetWindowTextLengthV(GetDlgItem(SRC_COMBO)) + 1;
	int		dst_len = ::GetWindowTextLengthV(GetDlgItem(DST_COMBO)) + 1;
	if (src_len <= 1 || !is_delete_mode && dst_len <= 1)
		return	FALSE;

	WCHAR	*src = new WCHAR [src_len], dst[MAX_PATH_EX] = L"";
	BOOL	ret = TRUE;
	BOOL	exec_confirm = cfg.execConfirm || (::GetAsyncKeyState(VK_CONTROL) & 0x8000);

	if (!exec_confirm) {
		if (isShellExt && (exec_flags & CMDLINE_EXEC))
			exec_confirm = is_delete_mode ? !cfg.shextRNoConfirm : !cfg.shextDdNoConfirm;
		else
			exec_confirm = is_delete_mode ? !noConfirmDel : cfg.execConfirm;
	}

	if (GetDlgItemTextV(SRC_COMBO, src, src_len) == 0 || !is_delete_mode && GetDlgItemTextV(DST_COMBO, dst, MAX_PATH_EX) == 0) {
		TMsgBox(this).Exec("Can't get src or dst field");
		ret = FALSE;
	}
	SendDlgItemMessage(PATH_EDIT, WM_SETTEXT, 0, (LPARAM)"");
	SendDlgItemMessage(STATUS_EDIT, WM_SETTEXT, 0, (LPARAM)"");

	PathArray	srcArray, dstArray, incArray, excArray;
	srcArray.RegistMultiPath(src);
	if (!is_delete_mode)
		dstArray.RegistPath(dst);

	// �t�B���^
	WCHAR	inc[MAX_PATH] = L"", exc[MAX_PATH] = L"";
	if (is_filter) {
		GetDlgItemTextV(INCLUDE_COMBO, inc, MAX_PATH);
		GetDlgItemTextV(EXCLUDE_COMBO, exc, MAX_PATH);
		incArray.RegistMultiPath(inc);
		excArray.RegistMultiPath(exc);
	}

	// �m�F�p�t�@�C���ꗗ
	if (ret && (ret = fastCopy.RegistInfo(&srcArray, &dstArray, &info, &incArray, &excArray))) {
		if (!is_delete_mode && cfg.EntryPathHistory(src, dst))
			SetPathHistory();
		if (is_filter && cfg.EntryFilterHistory(inc, exc))
			SetFilterHistory();
		cfg.WriteIni();
	}
	else
		SetDlgItemText(STATUS_EDIT, "Error");

	int	src_list_len = src_len + srcArray.Num() * 4;
	void *src_list = new WCHAR [src_list_len];

	if (ret && exec_confirm && (exec_flags & LISTING_EXEC) == 0) {
		srcArray.GetMultiPath(src_list, src_list_len, NEWLINE_STR_V, EMPTY_STR_V);
		void	*title = info.mode == FastCopy::MOVE_MODE ? GetLoadStrV(IDS_MOVECONFIRM) : info.isRenameMode ? GetLoadStrV(IDS_DUPCONFIRM): NULL;
		if (TExecConfirmDlg(info.mode, &cfg, this, title).Exec(src_list, is_delete_mode ? NULL : dst) != IDOK) {
			ret = FALSE;
			if (isShellExt && !is_delete_mode)
				autoCloseLevel = NO_CLOSE;
		}
	}

	int		pathLogMax = src_len * CHAR_LEN_V + sizeof(dst);

	if (ret && (pathLogBuf = new char [pathLogMax])) {
		if (IS_WINNT_V) {
			srcArray.GetMultiPath(src_list, src_list_len);
			::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)src_list, -1, (char *)src, src_len * CHAR_LEN_V, 0, 0);
			if (!is_delete_mode)
				::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)dstArray.Path(0), -1, (char *)dst, sizeof(dst), 0, 0);
		}
		int len = sprintf(pathLogBuf, "<Source>  %s", src);
		if (!is_delete_mode) {
			len += sprintf(pathLogBuf + len, "\r\n<DestDir> %s", dst);
		}
		if (GetChar(inc, 0)) {
			len += sprintf(pathLogBuf + len, "\r\n<Include> ");
			len += GetDlgItemText(INCLUDE_COMBO, pathLogBuf + len, MAX_PATH);
		}
		if (GetChar(exc, 0)) {
			len += sprintf(pathLogBuf + len, "\r\n<Exclude> ");
			len += GetDlgItemText(EXCLUDE_COMBO, pathLogBuf + len, MAX_PATH);
		}
		len += sprintf(pathLogBuf + len, "\r\n<Command> %s\r\n\r\n", COPYINFO_LIST[idx].list_str);
	}

	delete [] src_list;
	delete [] src;

	if (ret) {
		SendDlgItemMessage(PATH_EDIT, EM_SETTARGETDEVICE, 0, IsListing() ? 1 : 0);	// �܂�Ԃ�
		SetMiniWindow();
		SetDlgItemText(ERR_EDIT, "");

		if (forceStart == 1 || forceStart == 0 && is_delete_mode || fastCopy.TakeExclusivePriv()) {
			if (forceStart == 1 && !is_delete_mode)
				fastCopy.TakeExclusivePriv();
			ret = ExecCopyCore();
		}
		else {
			isDelay = TRUE;
			::SetTimer(hWnd, FASTCOPY_TIMER, 300, NULL);
			if (isTaskTray)
				TaskTray(NIM_MODIFY, hMainIcon[FCWAIT_ICON_INDEX], FASTCOPY);
		}

		if (ret) {
			SetDlgItemText(IsListing() ? LIST_BUTTON : IDOK, GetLoadStr(IDS_CANCEL));
			RefreshWindow();
		}
	}
	if (!ret && pathLogBuf) {
		delete [] pathLogBuf;
		pathLogBuf = NULL;
	}
	return	ret;
}

BOOL TMainDlg::ExecCopyCore(void)
{
	::GetLocalTime(&startTm);
	BOOL ret = fastCopy.Start();
	RefreshWindow();
	::SetTimer(hWnd, FASTCOPY_TIMER, 1000, NULL);
	return	ret;
}

BOOL TMainDlg::EndCopy(void)
{
	char	buf[1024];

	::KillTimer(hWnd, FASTCOPY_TIMER);

	BOOL	is_starting = fastCopy.IsStarting();

	if (is_starting) {
		SetInfo(FALSE, TRUE);

		if (isErrLog && !IsListing()) {
			EnableLogFile(isErrLog);
			::SetFilePointer(hErrLogFile, 0, 0, FILE_END);

			DWORD len = sprintf(buf, "-------------------------------------------------\r\n"
				"FastCopy start at %d/%02d/%02d %02d:%02d:%02d\r\n\r\n",
				startTm.wYear, startTm.wMonth, startTm.wDay,
				startTm.wHour, startTm.wMinute, startTm.wSecond);
			::WriteFile(hErrLogFile, buf, len, &len, 0);
			::WriteFile(hErrLogFile, pathLogBuf, strlen(pathLogBuf), &len, 0);

			if (errBufOffset) {
				::WriteFile(hErrLogFile, ti.errBuf->Buf(), errBufOffset, &len, 0);
				len = sprintf(buf, "%s", "\r\n\r\n");
				::WriteFile(hErrLogFile, buf, len, &len, 0);
			}
			else {
				char	msg[] = " No Errors\r\n\r\n";
				::WriteFile(hErrLogFile, msg, sizeof(msg) -1, &len, 0);
			}

			len = GetDlgItemText(STATUS_EDIT, buf, sizeof(buf));
			len += sprintf(buf + len, "%s", "\r\n\r\nResult : ");
			len += GetDlgItemText(ERRSTATUS_STATIC, buf + len, sizeof(buf) - len);
			len += sprintf(buf + len, "%s", "\r\n\r\n");
			::WriteFile(hErrLogFile, buf, len, &len, 0);
			EnableLogFile(FALSE);
		}
		::EnableWindow(GetDlgItem(IsListing() ? LIST_BUTTON : IDOK), FALSE);
		fastCopy.End();
		::EnableWindow(GetDlgItem(IsListing() ? LIST_BUTTON : IDOK), TRUE);
	}
	else
		SendDlgItemMessage(STATUS_EDIT, WM_SETTEXT, 0, (LPARAM)" ---- Canceled. ----");

	delete [] pathLogBuf;
	pathLogBuf = NULL;
	endTick = ::GetTickCount();

	SetDlgItemText(IsListing() ? LIST_BUTTON : IDOK, GetLoadStr(IsListing() ? IDS_LISTING : IDS_EXECUTE));
	SetDlgItemText(SAMEDRV_STATIC, "");
	if (autoCloseLevel == FORCE_CLOSE || autoCloseLevel == NOERR_CLOSE && (!is_starting || (ti.total.errFiles == 0 && ti.total.errDirs == 0)))
		PostMessage(WM_CLOSE, 0, 0);
	autoCloseLevel = NO_CLOSE;
	RefreshWindow();
	UpdateMenu();

	if (isTaskTray)
		TaskTray(NIM_MODIFY, hMainIcon[curIconIndex = FCNORMAL_ICON_INDEX], FASTCOPY);

	return	TRUE;
}

BOOL TMainDlg::EventUser(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
	case WM_FASTCOPY_MSG:
		if (wParam == FastCopy::END_NOTIFY) {
			EndCopy();
		}
		else if (wParam == FastCopy::CONFIRM_NOTIFY) {
			FastCopy::Confirm	*confirm = (FastCopy::Confirm *)lParam;
			switch (TConfirmDlg().Exec(confirm->message, confirm->allow_continue, this)) {
			case IDIGNORE:	confirm->result = FastCopy::Confirm::IGNORE_RESULT;		break;
			case IDCANCEL:	confirm->result = FastCopy::Confirm::CANCEL_RESULT;		break;
			default:		confirm->result = FastCopy::Confirm::CONTINUE_RESULT;	break;
			}
		}
		return	TRUE;

	case WM_FASTCOPY_NOTIFY:
		switch (lParam) {
		case WM_LBUTTONDOWN: case WM_RBUTTONDOWN:
			SetForceForegroundWindow();
			Show();
			break;

		case WM_LBUTTONUP: case WM_RBUTTONUP:
			Show();
			if (isErrEditHide && ti.errBuf && ti.errBuf->UsedSize())
				SetNormalWindow();
			TaskTray(NIM_DELETE);
			break;
		}
		return	TRUE;

	case WM_FASTCOPY_HIDDEN:
		Show(SW_HIDE);
		TaskTray(NIM_ADD, hMainIcon[isDelay ? FCWAIT_ICON_INDEX : FCNORMAL_ICON_INDEX], FASTCOPY);
		return	TRUE;

	default:
		if (uMsg == TaskBarCreateMsg)
		{
			if (isTaskTray)
				TaskTray(NIM_ADD, hMainIcon[isDelay ? FCWAIT_ICON_INDEX : FCNORMAL_ICON_INDEX], FASTCOPY);
			return	TRUE;
		}
	}
	return	FALSE;
}


BOOL TMainDlg::EvTimer(WPARAM timerID, TIMERPROC proc)
{
	if (isDelay) {
		if (fastCopy.TakeExclusivePriv()) {
			::KillTimer(hWnd, FASTCOPY_TIMER);
			isDelay = FALSE;
			ExecCopyCore();
		}
	}
	else
		SetInfo(isTaskTray ? TRUE : FALSE);

	return	TRUE;
}

BOOL TMainDlg::EnableLogFile(BOOL on)
{
	if (on && hErrLogFile == INVALID_HANDLE_VALUE) {
		char	path[MAX_PATH];
		MakePath(path, cfg.execDir, "fastcopy.log");
		hErrLogFile = ::CreateFile(path, GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_ALWAYS, 0, 0);
	}
	else if (!on && hErrLogFile != INVALID_HANDLE_VALUE) {
		::CloseHandle(hErrLogFile);
		hErrLogFile = INVALID_HANDLE_VALUE;
	}
	return	TRUE;
}

int GetArgOpt(void *arg, int default_value)
{
	if (GetChar(arg, 0) == 0 || GetChar(arg, 1) != '=')
		return	default_value;

	arg = MakeAddr(arg, 2);

	if (lstrcmpiV(arg, "true"))
		return	TRUE;

	if (lstrcmpiV(arg, "false"))
		return	FALSE;

	if (GetChar(arg, 0) >= '0' && GetChar(arg, 0) <= '9')
		return	GetChar(arg, 0) - '0';

	return	default_value;
}

int CmdNameToComboIndex(void *cmd_name)
{
	for (int i=0; COPYINFO_LIST[i].cmdline_name; i++) {
		if (lstrcmpiV(cmd_name, COPYINFO_LIST[i].cmdline_name) == 0)
			return	i;
	}
	return	-1;
}

BOOL TMainDlg::CommandLineExecV(int argc, void **argv)
{
	VBuf	shellExtBuf;
	int		len;
	int		job_idx = -1;

	BOOL	is_openwin			= FALSE;
	BOOL	is_noexec			= FALSE;
	BOOL	is_delete			= FALSE;
	BOOL	is_estimate			= FALSE;
	BOOL	is_filter			= FALSE;
	BOOL	is_job_filter		= FALSE;

	void	*CMD_STR			= GetLoadStrV(IDS_CMD_OPT);
	void	*BUSIZE_STR			= GetLoadStrV(IDS_BUFSIZE_OPT);
	void	*LOG_STR			= GetLoadStrV(IDS_LOG_OPT);
	void	*FORCESTART_STR		= GetLoadStrV(IDS_FORCESTART_OPT);
	void	*SKIPEMPTYDIR_STR	= GetLoadStrV(IDS_SKIPEMPTYDIR_OPT);
	void	*ERRSTOP_STR		= GetLoadStrV(IDS_ERRSTOP_OPT);
	void	*ESTIMATE_STR		= GetLoadStrV(IDS_ESTIMATE_OPT);
	void	*DISKMODE_STR		= GetLoadStrV(IDS_DISKMODE_OPT);
	void	*DISKMODE_SAME_STR	= GetLoadStrV(IDS_DISKMODE_SAME);
	void	*DISKMODE_DIFF_STR	= GetLoadStrV(IDS_DISKMODE_DIFF);
	void	*DISKMODE_AUTO_STR	= GetLoadStrV(IDS_DISKMODE_AUTO);
	void	*OPENWIN_STR		= GetLoadStrV(IDS_OPENWIN_OPT);
	void	*AUTOCLOSE_STR		= GetLoadStrV(IDS_AUTOCLOSE_OPT);
	void	*FORCECLOSE_STR		= GetLoadStrV(IDS_FORCECLOSE_OPT);
	void	*NOEXEC_STR			= GetLoadStrV(IDS_NOEXEC_OPT);
	void	*SHELLEXT1_STR		= GetLoadStrV(IDS_SHEXT1_OPT);
	void	*SHELLEXT2_STR		= GetLoadStrV(IDS_SHEXT2_OPT);
	void	*SHELLEXT4_STR		= GetLoadStrV(IDS_SHEXT4_OPT);
	void	*FCSHEXT1_STR		= GetLoadStrV(IDS_FCSHEXT1_OPT);
	void	*NOCONFIRMDEL_STR	= GetLoadStrV(IDS_NOCONFIRMDEL_OPT);
	void	*INCLUDE_STR		= GetLoadStrV(IDS_INCLUDE_OPT);
	void	*EXCLUDE_STR		= GetLoadStrV(IDS_EXCLUDE_OPT);
	void	*REGEXP_STR			= GetLoadStrV(IDS_REGEXP_OPT);
	void	*JOB_STR			= GetLoadStrV(IDS_JOB_OPT);
	void	*TO_STR				= GetLoadStrV(IDS_TO_OPT);
	void	*p;

	argc--, argv++;		// ���s�t�@�C������ skip

	while (*argv && GetChar(*argv, 0) == '/') {
		if (strnicmpV(*argv, CMD_STR, len = strlenV(CMD_STR)) == 0) {
			int idx = CmdNameToComboIndex(MakeAddr(*argv, len));
			if (idx == -1)
				return	MessageBox(GetLoadStr(IDS_USAGE), "Illegal Command"), FALSE;

			// �R�}���h���[�h��I��
			SendDlgItemMessage(MODE_COMBO, CB_SETCURSEL, idx, 0);
		}
		else if (strnicmpV(*argv, JOB_STR, len = strlenV(JOB_STR)) == 0) {
			if ((job_idx = cfg.SearchJobV(MakeAddr(*argv, len))) == -1)
				return	MessageBox(GetLoadStr(IDS_JOBNOTFOUND), "Illegal Command"), FALSE;
			SetJob(job_idx);
			if (GetChar(cfg.jobArray[job_idx]->includeFilter, 0) || GetChar(cfg.jobArray[job_idx]->excludeFilter, 0))
				is_job_filter = TRUE;
		}
		else if (strnicmpV(*argv, BUSIZE_STR, len = strlenV(BUSIZE_STR)) == 0) {
			SetDlgItemTextV(BUFSIZE_EDIT, MakeAddr(*argv, len));
		}
		else if (strnicmpV(*argv, LOG_STR, len = strlenV(LOG_STR)) == 0) {
			isErrLog = GetArgOpt(MakeAddr(*argv, len), TRUE);
		}
		else if (strnicmpV(*argv, FORCESTART_STR, len = strlenV(FORCESTART_STR)) == 0) {
			forceStart = GetArgOpt(MakeAddr(*argv, len), 1);
		}
		else if (strnicmpV(*argv, SKIPEMPTYDIR_STR, len = strlenV(SKIPEMPTYDIR_STR)) == 0) {
			skipEmptyDir = GetArgOpt(MakeAddr(*argv, len), 1);
		}
		else if (strnicmpV(*argv, ERRSTOP_STR, len = strlenV(ERRSTOP_STR)) == 0) {
			::CheckDlgButton(hWnd, IGNORE_CHECK, GetArgOpt(MakeAddr(*argv, len), FALSE) ? TRUE : FALSE);
		}
		else if (strnicmpV(*argv, ESTIMATE_STR, len = strlenV(ESTIMATE_STR)) == 0) {
			is_estimate = GetArgOpt(MakeAddr(*argv, len), TRUE);
		}
		else if (strnicmpV(*argv, OPENWIN_STR, len = strlenV(OPENWIN_STR)) == 0) {
			is_openwin = GetArgOpt(MakeAddr(*argv, len), TRUE);
		}
		else if (strnicmpV(*argv, AUTOCLOSE_STR, len = strlenV(AUTOCLOSE_STR)) == 0) {
			autoCloseLevel = (AutoCloseLevel)GetArgOpt(MakeAddr(*argv, len), NOERR_CLOSE);
		}
		else if (strnicmpV(*argv, FORCECLOSE_STR, strlenV(FORCECLOSE_STR)) == 0) {
			autoCloseLevel = FORCE_CLOSE;
		}
		else if (strnicmpV(*argv, NOEXEC_STR, strlenV(NOEXEC_STR)) == 0) {
			is_noexec = TRUE;
		}
		else if (strnicmpV(*argv, DISKMODE_STR, len = strlenV(DISKMODE_STR)) == 0) {
			if (lstrcmpiV(MakeAddr(*argv, len), DISKMODE_SAME_STR) == 0)
				diskMode = 1;
			else if (lstrcmpiV(MakeAddr(*argv, len), DISKMODE_DIFF_STR) == 0)
				diskMode = 2;
			else
				diskMode = 0;
		}
		else if (strnicmpV(*argv, INCLUDE_STR, len = strlenV(INCLUDE_STR)) == 0) {
			is_filter = TRUE;
			SetDlgItemTextV(INCLUDE_COMBO, strtok_pathV(MakeAddr(*argv, len), EMPTY_STR_V, &p));
		}
		else if (strnicmpV(*argv, EXCLUDE_STR, len = strlenV(EXCLUDE_STR)) == 0) {
			is_filter = TRUE;
			SetDlgItemTextV(EXCLUDE_COMBO, strtok_pathV(MakeAddr(*argv, len), EMPTY_STR_V, &p));
		}
		else if (strnicmpV(*argv, REGEXP_STR, strlenV(REGEXP_STR)) == 0) {
			isRegExp = TRUE;
		}
		else if (strnicmpV(*argv, SHELLEXT1_STR, strlenV(SHELLEXT1_STR)) == 0
			|| strnicmpV(*argv, SHELLEXT2_STR, strlenV(SHELLEXT2_STR)) == 0
			|| strnicmpV(*argv, SHELLEXT4_STR, strlenV(SHELLEXT4_STR)) == 0) {
			if (TMsgBox(this).Exec(GetLoadStr(IDS_UPDATE), FASTCOPY, MB_OKCANCEL) == IDOK)
				UpdateShellExt(&cfg);
			return	FALSE;
		}
		else if (strnicmpV(*argv, FCSHEXT1_STR, strlenV(FCSHEXT1_STR)) == 0) {
			isShellExt = TRUE;
			is_openwin = !cfg.shextTaskTray;
			autoCloseLevel = cfg.shextAutoClose ? NOERR_CLOSE : NO_CLOSE;
			HANDLE	hStdInput = ::GetStdHandle(STD_INPUT_HANDLE);
			DWORD	read_size;
			BOOL	convertErr = FALSE;

			shellExtBuf.AllocBuf(SHELLEXT_MIN_ALLOC, SHELLEXT_MAX_ALLOC);
			while (::ReadFile(hStdInput, shellExtBuf.Buf() + shellExtBuf.UsedSize(), shellExtBuf.RemainSize(), &read_size, 0) && read_size > 0) {
				if (shellExtBuf.AddUsedSize(read_size) == shellExtBuf.Size())
					shellExtBuf.Grow(SHELLEXT_MIN_ALLOC);
			}
			shellExtBuf.Buf()[shellExtBuf.UsedSize()] = 0;

			if (convertErr)
				return	FALSE;
			if ((argv = CommandLineToArgvV(shellExtBuf.Buf(), &argc)) == NULL)
				break;
			continue;	// �� parse
		}
		else if (strnicmpV(*argv, NOCONFIRMDEL_STR, strlenV(NOCONFIRMDEL_STR)) == 0) {
			noConfirmDel = TRUE;
		}
		else
			return	MessageBoxV(GetLoadStrV(IDS_USAGE), *argv), FALSE;
		argc--, argv++;
	}

	is_delete = GetCopyMode() == FastCopy::DELETE_MODE;

	if (job_idx == -1) {
		SetDlgItemText(SRC_COMBO, "");
		SetDlgItemText(DST_COMBO, "");
	}
	PathArray	pathArray;

	int		path_len = 0;
	WCHAR	wBuf[MAX_PATH_EX];

	while (*argv && GetChar(*argv, 0) != '/') {
		void	*path = *argv;
		if (isShellExt && !is_delete) {
			if (NetPlaceConvertV(path, wBuf)) {
				path = wBuf;
				isNetPlaceSrc = TRUE;
			}
		}
		pathArray.RegistPath(path);
		path_len += strlenV(path) + 3;
		argc--, argv++;
	}

	void	*path = new WCHAR [path_len];
	if (pathArray.GetMultiPath(path, path_len))
		SetDlgItemTextV(SRC_COMBO, path);
	delete [] path;

	void	*dst_path	= NULL;
	if (argc == 1 && strnicmpV(*argv, TO_STR, strlenV(TO_STR)) == 0) {
		dst_path = MakeAddr(*argv, strlenV(TO_STR));
		if (isShellExt && NetPlaceConvertV(dst_path, wBuf))
			dst_path = wBuf;
		SetDlgItemTextV(DST_COMBO, dst_path);
	}
	else if (argc >= 1)
		return	MessageBox(GetLoadStr(IDS_USAGE), "Too few/many argument"), FALSE;

	if ((is_filter || is_job_filter) && (GetCopyMode() == FastCopy::MOVE_MODE))
		return	MessageBox(GetLoadStr(IDS_NOFILTER_USAGE), FASTCOPY), FALSE;

	if (::GetWindowTextLengthV(GetDlgItem(SRC_COMBO)) == 0 || (!is_delete && ::GetWindowTextLengthV(GetDlgItem(DST_COMBO)) == 0)) {
		is_noexec = TRUE;
		if (isShellExt)			// �R�s�[��̖��� shell�N�����́Aautoclose �𖳎�����
			autoCloseLevel = NO_CLOSE;
	}

	if (is_filter && !is_job_filter)
		ReflectFilterCheck(TRUE);

	SetItemEnable(is_delete);
	if (diskMode)
		UpdateMenu();

	if (!is_delete && (is_estimate || !isShellExt && !is_noexec && cfg.estimateMode && !is_estimate))
		::CheckDlgButton(hWnd, ESTIMATE_CHECK, is_estimate);

	if (is_openwin || is_noexec)
		Show();
	else
		TaskTray(NIM_ADD, hMainIcon[FCNORMAL_ICON_INDEX], FASTCOPY);

	return	is_noexec ? TRUE : ExecCopy(CMDLINE_EXEC);
}

BOOL TMainDlg::TaskTray(int nimMode, HICON hSetIcon, LPCSTR tip)
{
	NOTIFYICONDATA	tn;

	isTaskTray = nimMode == NIM_DELETE ? FALSE : TRUE;

	memset(&tn, 0, sizeof(tn));
	tn.cbSize = sizeof(tn);
	tn.hWnd = hWnd;
	tn.uID = FASTCOPY_NIM_ID;		// test
	tn.uFlags = NIF_MESSAGE|(hSetIcon ? NIF_ICON : 0)|(tip ? NIF_TIP : 0);
	tn.uCallbackMessage = WM_FASTCOPY_NOTIFY;
	tn.hIcon = hSetIcon;
	if (tip)
		sprintf(tn.szTip, "%.63s", tip);

	return	::Shell_NotifyIcon(nimMode, &tn);
}

BOOL TMainDlg::SetInfo(BOOL is_task_tray, BOOL is_finish_status)
{
	char	buf[512];
	int		len = 0;
	double	doneRate;
	int		done_rate_i;
	int		remain_sec, total_sec, remain_h, remain_m, remain_s;

	fastCopy.GetTransInfo(&ti, is_task_tray ? FALSE : TRUE);
	if (ti.tickCount == 0)
		ti.tickCount++;

	if (IsListing() && ti.listBuf->UsedSize() > listBufOffset) {
		::EnterCriticalSection(ti.listCs);
		int offset_v = listBufOffset / CHAR_LEN_V;
		SendDlgItemMessageV(PATH_EDIT, EM_SETSEL, offset_v, offset_v);
		SendDlgItemMessageV(PATH_EDIT, EM_REPLACESEL, 0, (LPARAM)(ti.listBuf->Buf() + listBufOffset));
		listBufOffset = ti.listBuf->UsedSize();
		::LeaveCriticalSection(ti.listCs);
	}

#define FILERATE_WARTERMARK	5

	if ((info.flags & FastCopy::PRE_SEARCH) && !ti.total.isPreSearch) {
		double	preFiles, preTrans, doneFiles, doneTrans, fileRate;
		int		misc_files = ti.total.skipFiles + ti.total.skipDirs + ti.total.errFiles + ti.total.errDirs;
		if (info.mode == FastCopy::DELETE_MODE) {
			preFiles = ti.total.preFiles + ti.total.preDirs + 0.01;
			doneFiles = ti.total.deleteFiles + ti.total.deleteDirs + misc_files + 0.01;
			doneRate = doneFiles / preFiles;
		}
		else {
			preFiles = (ti.total.preFiles + ti.total.preDirs) * 2 + 0.01;
			preTrans = (double)(ti.total.preTrans * 2 + 0.01);
			doneFiles = (ti.total.writeFiles + ti.total.writeDirs + ti.total.readFiles + ti.total.readDirs + (misc_files) * 2) + 0.01;
			doneTrans = (double)(ti.total.writeTrans + ti.total.readTrans + (ti.total.skipTrans + ti.total.errTrans) * 2 + 0.01);
			doneRate = ((doneFiles / preFiles) + (doneTrans / preTrans)) / 2;
			if ((fileRate = doneFiles / (ti.tickCount / 1000)) < FILERATE_WARTERMARK) {
				if (((preTrans - doneTrans) / (preFiles - doneFiles + 1)) > (doneTrans / doneFiles) / (FILERATE_WARTERMARK / fileRate))
					doneRate = (doneTrans / preTrans);
			}
		}
		remain_sec = (int)((ti.tickCount / doneRate - ti.tickCount) / 1000);
		total_sec = (int)(ti.tickCount / doneRate / 1000);
		remain_h = remain_sec / 3600, remain_m = (remain_sec % 3600) / 60, remain_s = remain_sec % 60;
		done_rate_i = (int)(doneRate * 100);
		SetWindowTitle("(%d%%) FastCopy %s", done_rate_i, GetVersionStr());
	}

	if (is_task_tray) {
		if (info.mode == FastCopy::DELETE_MODE) {
			len += sprintf(buf + len, IsListing() ?
				"FastCopy (%.1fMB %dfiles %dsec)" :
				"FastCopy (%.1fMB %dfiles %dsec %.2fMB/s)",
				(double)ti.total.deleteTrans / (1024 * 1024),
				ti.total.deleteFiles,
				ti.tickCount / 1000,
				(double)ti.total.deleteFiles * 1000 / ti.tickCount);
		}
		else if (ti.total.isPreSearch) {
			len += sprintf(buf + len, " Estimating (Total %.1f MB/%d files/%d sec)",
				(double)ti.total.preTrans / (1024 * 1024),
				ti.total.preFiles,
				(int)(ti.tickCount / 1000));
		}
		else {
			if ((info.flags & FastCopy::PRE_SEARCH) && !ti.total.isPreSearch && !is_finish_status && doneRate >= 0.0001) {
				len += sprintf(buf + len, "%d%% (Remain %02d:%02d:%02d) ",
					done_rate_i, remain_h, remain_m, remain_s);
			}
			len += sprintf(buf + len, IsListing() ?
				"FastCopy (%.1fMB %dfiles %dsec)" :
				"FastCopy (%.1fMB %dfiles %dsec %.2fMB/s)",
				(double)ti.total.writeTrans / (1024 * 1024),
				ti.total.writeFiles,
				ti.tickCount / 1000,
				(double)ti.total.writeTrans / ti.tickCount / 1024 * 1000 / 1024
				);
		}
		TaskTray(NIM_MODIFY, hMainIcon[curIconIndex = (curIconIndex+1) % MAX_NORMAL_FASTCOPY_ICON], buf);
		return	TRUE;
	}

	if (ti.total.isPreSearch) {
		len += sprintf(buf + len,
			" ---- Estimating ... ----\r\n"
			"PreTrans = %.1f MB\r\n"
			"PreFiles = %d (%d)\r\n"
			"PreTime  = %.2f sec\r\n"
			"PreRate  = %.2f files/s",
			(double)ti.total.preTrans / (1024 * 1024),
			ti.total.preFiles, ti.total.preDirs,
			(double)ti.tickCount / 1000,
			(double)ti.total.preFiles * 1000 / ti.tickCount);
	}
	else if (info.mode == FastCopy::DELETE_MODE) {
		len += sprintf(buf + len, IsListing() ?
			"TotalDel  = %.1f MB\r\n"
			"DelFiles  = %d (%d)\r\n"
			"TotalTime = %.2f sec\r\n" :
			"TotalDel  = %.1f MB\r\n"
			"DelFiles  = %d (%d)\r\n"
			"TotalTime = %.2f sec\r\n"
			"FileRate   = %.2f files/s",
			(double)ti.total.deleteTrans / (1024 * 1024),
			ti.total.deleteFiles, ti.total.deleteDirs,
			(double)ti.tickCount / 1000,
			(double)ti.total.deleteFiles * 1000 / ti.tickCount);
	}
	else {
		if (IsListing()) {
			len = sprintf(buf + len,
				"TotalSize = %.1f MB\r\n"
				"TotalFiles = %d (%d)\r\n"
				, (double)ti.total.writeTrans / (1024 * 1024)
				, ti.total.writeFiles, ti.total.writeDirs);
		}
		else {
			len = sprintf(buf + len,
				"TotalRead = %.1f MB\r\n"
				"TotalWrite = %.1f MB\r\n"
				"TotalFiles = %d (%d)\r\n"
				, (double)ti.total.readTrans / (1024 * 1024)
				, (double)ti.total.writeTrans / (1024 * 1024)
				, ti.total.writeFiles, ti.total.writeDirs);
		}

		if (ti.total.skipFiles || ti.total.skipDirs) {
			len += sprintf(buf + len,
				"TotalSkip = %.1f MB\r\n"
				"SkipFiles = %d (%d)\r\n"
				, (double)ti.total.skipTrans / (1024 * 1024)
				, ti.total.skipFiles, ti.total.skipDirs);
		}
		if (ti.total.deleteFiles || ti.total.deleteDirs) {
			len += sprintf(buf + len,
				"TotalDel  = %.1f MB\r\n"
				"DelFiles  = %d (%d)\r\n"
				, (double)ti.total.deleteTrans / (1024 * 1024)
				, ti.total.deleteFiles, ti.total.deleteDirs);
		}
		len += sprintf(buf + len, IsListing() ?
			"TotalTime = %.2f sec\r\n" :
			"TotalTime = %.2f sec\r\n"
			"TransRate = %.2f MB/s\r\n"
			"FileRate   = %.2f files/s"
			, (double)ti.tickCount / 1000
			, (double)ti.total.writeTrans / ti.tickCount / 1024 * 1000 / 1024
			, (double)ti.total.writeFiles * 1000 / ti.tickCount);
	}

	if ((info.flags & FastCopy::PRE_SEARCH) && !ti.total.isPreSearch && !is_finish_status && doneRate >= 0.0001) {
		len += sprintf(buf + len, "\r\n -- Remain %02d:%02d:%02d (%d%%) --", remain_h, remain_m, remain_s, done_rate_i);
	}
	else if (IsListing() && is_finish_status) {
		len += sprintf(buf + len, "\r\n -- Listing Done --");
	}
	SetDlgItemText(STATUS_EDIT, buf);

	if (IsListing()) {
		if (is_finish_status) {
			int offset_v = listBufOffset / CHAR_LEN_V;
			sprintf(buf, "\r\nFinished. (ErrorFiles : %d  ErrorDirs : %d)", ti.total.errFiles, ti.total.errDirs);
			SendDlgItemMessageV(PATH_EDIT, EM_SETSEL, offset_v, offset_v);
			SendDlgItemMessage(PATH_EDIT, EM_REPLACESEL, 0, (LPARAM)buf);
//			int line = SendDlgItemMessage(PATH_EDIT, EM_GETLINECOUNT, 0, 0);
//			SendDlgItemMessage(PATH_EDIT, EM_LINESCROLL, 0, line > 2 ? line -2 : 0);
		}
	}
	else if (is_finish_status) {
		sprintf(buf, ti.total.errFiles || ti.total.errDirs ? "Finished. (ErrorFiles : %d  ErrorDirs : %d)" : "Finished.", ti.total.errFiles, ti.total.errDirs);
		SetDlgItemText(PATH_EDIT, buf);
		SetWindowTitle("FastCopy %s", GetVersionStr());
	}
	else
		SetDlgItemTextV(PATH_EDIT, ti.total.isPreSearch ? EMPTY_STR_V : ti.curPath);

	SetDlgItemText(SAMEDRV_STATIC, ti.isSameDrv ? GetLoadStr(IDS_SAMEDISK) : GetLoadStr(IDS_DIFFDISK));
	if (info.ignoreErr != ti.ignoreErr)
		::CheckDlgButton(hWnd, IGNORE_CHECK, info.ignoreErr = ti.ignoreErr);

	if (isErrEditHide && ti.errBuf->UsedSize() > 0) {
		SetNormalWindow();
	}
	if (ti.errBuf->UsedSize() > errBufOffset || errBufOffset == MAX_ERR_BUF) {
		if (errBufOffset != MAX_ERR_BUF) {
			::EnterCriticalSection(ti.errCs);
			SendDlgItemMessage(ERR_EDIT, EM_SETSEL, errBufOffset, errBufOffset);
			SendDlgItemMessage(ERR_EDIT, EM_REPLACESEL, 0, (LPARAM)(ti.errBuf->Buf() + errBufOffset));
			errBufOffset = ti.errBuf->UsedSize();
			::LeaveCriticalSection(ti.errCs);
		}
		sprintf(buf, "(ErrFiles : %d / ErrDirs : %d)", ti.total.errFiles, ti.total.errDirs);
		SetDlgItemText(ERRSTATUS_STATIC, buf);
	}
	return	TRUE;
}

BOOL TMainDlg::SetWindowTitle(char *fmt,...)
{
	char	buf[1024];

	va_list	va;
	va_start(va, fmt);
	DWORD	len = wvsprintf(buf, fmt, va);
	va_end(va);

	return	SetWindowText(buf);
}

void TMainDlg::SetItemEnable(BOOL is_delete)
{
	::EnableWindow(GetDlgItem(DST_FILE_BUTTON), !is_delete);
	::EnableWindow(GetDlgItem(DST_COMBO), !is_delete);
	::ShowWindow(GetDlgItem(ESTIMATE_CHECK), is_delete ? SW_HIDE : SW_SHOW);
	ReflectFilterCheck();
}

const char *GetVersionStr(void)
{
	static char *version_str;

	if (version_str == NULL)
		version_str = strstr(mainwin_id, "ver");

	return	version_str;
}

void TMainDlg::UpdateMenu(void)
{
	HMENU	hMenu;
	int		i;

	hMenu = ::GetSubMenu(::GetMenu(hWnd), 1);
	while (::GetMenuItemCount(hMenu) > 2 && ::DeleteMenu(hMenu, 2, MF_BYPOSITION))
		;

	for (i=0; i < cfg.jobMax; i++) {
		InsertMenuV(hMenu, i + 2, MF_STRING|MF_BYPOSITION, JOBOBJ_MENUITEM_START + i, cfg.jobArray[i]->title);
	}

	hMenu = ::GetSubMenu(::GetMenu(hWnd), 2);
	::CheckMenuItem(hMenu, AUTODISK_MENUITEM, MF_BYCOMMAND|((diskMode == 0) ? MF_CHECKED : MF_UNCHECKED));
	::CheckMenuItem(hMenu, SAMEDISK_MENUITEM, MF_BYCOMMAND|((diskMode == 1) ? MF_CHECKED : MF_UNCHECKED));
	::CheckMenuItem(hMenu, DIFFDISK_MENUITEM, MF_BYCOMMAND|((diskMode == 2) ? MF_CHECKED : MF_UNCHECKED));

	if (!fastCopy.IsStarting() && !isDelay) {
		SetDlgItemText(SAMEDRV_STATIC, diskMode == 0 ? "" : diskMode == 1 ? GetLoadStr(IDS_FIX_SAMEDISK) : GetLoadStr(IDS_FIX_DIFFDISK));
	}
}

void TMainDlg::SetJob(int idx)
{
	Job	*job = cfg.jobArray[idx];
	idx = CmdNameToComboIndex(job->cmd);

	if (idx == -1)
		return;

	SetDlgItemTextV(JOBTITLE_STATIC, job->title);
	SendDlgItemMessage(MODE_COMBO, CB_SETCURSEL, idx, 0);
	SetDlgItemInt(BUFSIZE_EDIT, job->bufSize);
	::CheckDlgButton(hWnd, ESTIMATE_CHECK, job->estimateMode);
	::CheckDlgButton(hWnd, IGNORE_CHECK, job->ignoreErr);
	::CheckDlgButton(hWnd, FILTER_CHECK, job->isFilter);
	SetDlgItemTextV(SRC_COMBO, job->src);
	SetDlgItemTextV(DST_COMBO, job->dst);
	SetDlgItemTextV(INCLUDE_COMBO, job->includeFilter);
	SetDlgItemTextV(EXCLUDE_COMBO, job->excludeFilter);
	SetItemEnable(COPYINFO_LIST[idx].mode == FastCopy::DELETE_MODE);
	SetDlgItemText(PATH_EDIT, "");
	SetDlgItemText(ERR_EDIT, "");
	diskMode = job->diskMode;
	UpdateMenu();
	SetMiniWindow();
}

#if 0
void DBGWrite(char *fmt,...)
{
	static HANDLE	hDbgFile = INVALID_HANDLE_VALUE;

	if (hDbgFile == INVALID_HANDLE_VALUE)
		hDbgFile = ::CreateFile("c:\\fastcopy_dbg.txt", GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_ALWAYS, 0, 0);

	char	buf[1024];
	va_list	va;
	va_start(va, fmt);
	DWORD	len = wvsprintf(buf, fmt, va);
	va_end(va);
	::WriteFile(hDbgFile, buf, len, &len, 0);
}
#endif


 