<?php

Plugin::setInfos(array(
	'id'          => 'trackback',
	'title'       => 'Trackback',
	'description' => 'Provides interface to add page trackbacks.',
	'version'     => '1.0',
	'license'     => 'MIT',
	'author'      => 'Shark++',
	'website'     => 'http://www.sharkpp.net/',
	'require_frog_version' => '0.9.3'
));

// AutoLoader�N���X�����݂���̂̓o�b�N�G���h����
if (class_exists('AutoLoader'))
{
	require_once dirname(__FILE__).'/Services/Trackback.php';
	require_once dirname(__FILE__).'/frontend.php';

	// �V�������f��Trackback��AutoLoader�ɒǉ����܂�
	AutoLoader::addFile('Trackback', CORE_ROOT.'/plugins/trackback/Trackback.php');

	Plugin::addController('trackback', 'Trackbacks');

	Observer::observe('view_page_edit_plugins', 'trackback_display_dropdown');
	Observer::observe('page_add_after_save', 'trackback_send_trackback_ping');
	Observer::observe('page_edit_after_save', 'trackback_send_trackback_ping');

	function trackback_display_dropdown(&$page)
	{
		if( !isset($page->trackback_status) ) {
			$page->trackback_status = Trackback::NONE;
		}
		// �g���b�N�o�b�N�X�e�[�^�X
	//	echo get_url();
		echo '
		<p><label for="page_trackback_status">'.__('Trackbacks').'</label>
		   <select id="page_trackback_status" name="page[trackback_status]">
		     <option value="'.Trackback::NONE.'"'.($page->trackback_status == Trackback::NONE ? ' selected="selected"': '').'>&#8212; '.__('none').' &#8212;</option>
		     <option value="'.Trackback::OPEN.'"'.($page->trackback_status == Trackback::OPEN ? ' selected="selected"': '').'>'.__('Open').'</option>
		     <option value="'.Trackback::CLOSED.'"'.($page->trackback_status == Trackback::CLOSED ? ' selected="selected"': '').'>'.__('Closed').'</option>
		   </select>
		</p>';
		// �g���b�N�o�b�N�s���O
		echo '
		<script type="text/javascript">
		  Event.observe(window, "load", function()
		    {
		      var elmLabel = document.createElement("label");
		        elmLabel.htmlFor = "trackback_ping_url";
		        elmLabel.appendChild(document.createTextNode("'.__('Trackbacks').'"));
		      var elmText = document.createElement("textarea");
		        elmText.id = "trackback_ping_url";
		        elmText.name = "trackback_ping_url";
		        elmText.cols = "40";
		        elmText.rows = "3";
		        elmText.style.cssText = "width: 100%; height: 3em";
		      var elmBase = document.createElement("p");
		        elmBase.style.cssText = "width: 100%; margin-right: 0";
		        elmBase.appendChild(elmLabel);
		        elmBase.appendChild(elmText);
		      var elmRow = document.createElement("div");
		        elmRow.className = "row";
		        elmRow.appendChild(elmBase);
		        elmRow.style.cssText = "width: 100%;";
		      var elmPrevRow = document.getElementById("page_trackback_status").parentNode.parentNode;
		      var elmForm = elmPrevRow.parentNode;
		      // Insert after
		      elmForm.insertBefore(elmRow, elmPrevRow.nextSibling);
		    }, false);
		</script>
		';
	}

	function trackback_send_trackback_ping(&$page)
	{
		$url = get_frontend_page_url($page);

		// Part['body'] ���擾
		$part_body = PagePart::findOneFrom('PagePart', 'page_id=? and name=?', array($page->id, 'body'));

		// PING�𑗐M
		if( isset($_POST['trackback_ping_url']) )
		{
			$error = '';

			// PING�̑����̈ꗗ���擾
			$ping_list = array_filter(
							array_unique(
								explode("\n", 
									str_replace("\r", "\n", str_replace("\r\n", "\n", 
										$_POST['trackback_ping_url']
								))))
							, create_function('$v', 'return preg_match("|^http://.+|", $v);'));

			// Services_Trackback�I�u�W�F�N�g�̐���
			$trackback = new Services_Trackback();

			// �e���M�g���b�N�o�b�N����ݒ�
			$trackback->set('title',			$page->title);
			$trackback->set('url',				$url);
			$trackback->set('excerpt',			empty($part_body->content_html) ? ' ' : $part_body->content_html);
			$trackback->set('blog_name',		Setting::get('admin_title'));
		//	$trackback->set('trackback_url',	$ping);
			$trackback->set('host',				$_SERVER['SERVER_ADDR']);

			// �S�Ă̑��M��̑��M
			foreach($ping_list as $ping)
			{
				$result = $trackback->send(array('trackback_url' => $ping));
				if (PEAR::isError($result)) {
					$error .= (empty($error) ? '' : '<br>') . 'PING:&lt;' . $ping . '&gt; ' . $result->getMessage();
				}
			}

			// �G���[������Ε\�����Ē��f
			if( !empty($error) )
			{
				Flash::set('error', $error);
				redirect(get_url('page/edit/'.$page->id));
			}
		}
	}
}
else // �t�����g�G���h�Ŏg�p�����֐��A�N���X�̈ꗗ
{
	require_once dirname(__FILE__).'/Services/Trackback.php';

	define('MAX_EXCERPT_LENGTH', 100);
	define('SPAM_BLOCK_SIGNATURE', '');

	Observer::observe('page_requested', 'trackback_ping');

	// �g���b�N�o�b�N���擾
	function trackbacks(&$page)
	{
		global $__FROG_CONN__;

		$trackbacks = array();
		$sql = 'SELECT * FROM '.TABLE_PREFIX.'trackback WHERE is_approved=1 AND page_id=?';

		$stmt = $__FROG_CONN__->prepare($sql);
		$stmt->execute(array($page->id));

		while ($trackback = $stmt->fetchObject('Trackback'))
			$trackbacks[] = $trackback;

		return $trackbacks;
	}

	// �g���b�N�o�b�N�̐�
	function trackbacks_count(&$page)
	{
		global $__FROG_CONN__;

		$sql = 'SELECT COUNT(id) AS num FROM '.TABLE_PREFIX.'trackback WHERE is_approved=1 AND page_id=?';

		$stmt = $__FROG_CONN__->prepare($sql);
		$stmt->execute(array($page->id));
		$obj = $stmt->fetchObject();

		return (int) $obj->num;
	}

	function get_trackback_page_id($query)
	{
		if( preg_match('/^(.+)\.trackback(.*)$/', $query, $m) )
		{
			if( empty($_POST) )
			{
				exit();
			}

			if( SPAM_BLOCK_SIGNATURE != $m[2] )
			{
				exit();
			}

			$m[1] = preg_replace('/(.+)'.URL_SUFFIX.'/', '\1', $m[1]);

			$page = find_page_by_uri($m[1]);

			if( $page->trackback_status != Trackback::OPEN )
			{
				exit();
			}

			if( false !== $page )
			{
				return $page->id;
			}
		//	echo '<pre>'.htmlspecialchars(print_r($page, true)).'</pre>';
		}
		return false;
	}

	// �g���b�N�o�b�N�s���O��M
	function trackback_ping($query)
	{
		global $__FROG_CONN__;

		$page_id = get_trackback_page_id($query);

		if( false === $page_id )
		{
			return;
		}

		// Services_Trackback�I�u�W�F�N�g�̐���
		$trackback = new Services_Trackback();

		// �g���b�N�o�b�N���
		$trackbackData = array( 'id' => $page_id );

		// Services_Trackback�I�u�W�F�N�g�̍쐬
		$trackback = Services_Trackback::create($trackbackData);

		// ���M���ꂽ�g���b�N�o�b�N������M
		$result = $trackback->receive();

		if( PEAR::isError($result) ) {
			echo $trackback->getResponseError($result->getMessage(), 1);
		} else {

			$auto_approve_trackback = 1;

			// �f�[�^�[�x�[�X�ւ̑}���pSQL�𐶐�
			//  �S�Ă̓��͂̃^�O���Ȃ�
			$sql = 'INSERT INTO '.TABLE_PREFIX.'trackback (page_id, title, excerpt, url, blog_name, host, is_approved, created_on) VALUES ('.
					'\''.$page_id.'\', '.
					$__FROG_CONN__->quote(strip_tags($trackback->get('title'))).', '.
					$__FROG_CONN__->quote(strip_tags($trackback->get('excerpt'))).', '.
					$__FROG_CONN__->quote(strip_tags($trackback->get('url'))).', '.
					$__FROG_CONN__->quote(strip_tags($trackback->get('blog_name'))).', '.
					$__FROG_CONN__->quote(strip_tags($trackback->get('host'))).', '.
					$__FROG_CONN__->quote($auto_approve_trackback).', '.
					$__FROG_CONN__->quote(date('Y-m-d H:i:s')).')';

			// �f�[�^�[�x�[�X�֑}��
			$__FROG_CONN__->exec($sql);

			// ���M���ꂽ�e�����擾����
			$values = array(
				'host'		=> $trackback->get('host'),
				'title'		=> $trackback->get('title'),
				'excerpt'	=> $trackback->get('excerpt'),
				'url'		=> $trackback->get('url'),
				'blog_name' => $trackback->get('blog_name'),
			);

			echo $trackback->getResponseSuccess();
		}

		exit();
	}

	class Trackback
	{
		const NONE = 0;
		const OPEN = 1;
		const CLOSED = 2;

		function name($class='')
		{
			if ($this->author_link != '')
			{
				return sprintf(
					'<a class="%s" href="%s" title="%s">%s</a>',
					$class,
					$this->author_link,
					$this->author_name,
					$this->author_name
				);
			}
			else return $this->author_name;
		}

		function title()     { return $this->title; }
		function excerpt()   { return mb_strimwidth($this->excerpt, 0, MAX_EXCERPT_LENGTH, '...', 'UTF-8'); }
		function url()       { return $this->url; }
		function blog_name() { return $this->blog_name; }
		function link($title = '')
		{
			if( empty($title) )
			{
				$title = $this->blog_name;
			}
			return '<a href="'.$this->url.'" title="'.$title.'">'.$title.'</a>';
		}

		function date($format='%a, %e %b %Y')
		{
			return strftime($format, strtotime($this->created_on));
		}

	} // Trackback class
}
