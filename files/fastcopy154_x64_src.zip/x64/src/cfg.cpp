static char *cfg_id = 
	"@(#)Copyright (C) H.Shirouzu 2004-2007   cfg.cpp	Ver1.52";
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2004-09-15(Wed)
	Update					: 2007-02-06(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "mainwin.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>

#define FASTCOPY_INI			"fastcopy.ini"
#define MAIN_SECTION			"main"
#define SRC_HISTORY				"src_history"
#define DST_HISTORY				"dst_history"
#define INC_HISTORY				"include_history"
#define EXC_HISTORY				"exclude_history"
#
#define MAX_HISTORY_KEY			"max_history"
#define COPYMODE_KEY			"default_copy_mode"
#define COPYFLAGS_KEY			"default_copy_flags"
#define SKIPEMPTYDIR_KEY		"skip_empty_dir"
#define FORCESTART_KEY			"force_start"
#define IGNORE_ERR_KEY			"ignore_error"
#define ESTIMATE_KEY			"estimate_mode"
#define DISKMODE_KEY			"disk_mode"
#define ISTOPLEVEL_KEY			"is_toplevel"
#define ISERRLOG_KEY			"is_errlog"
#define ISSAMEDIRRENAME_KEY		"is_samedir_rename"
#define BUFSIZE_KEY				"bufsize"
#define MAXTRANSSIZE_KEY		"max_transize"
#define MAXOPENFILES_KEY		"max_openfiles"
#define MAXATTRSIZE_KEY			"max_attrsize"
#define MAXDIRSIZE_KEY			"max_dirsize"
#define SHEXTAUTOCLOSE_KEY		"shext_autoclose"
#define SHEXTTASKTRAY_KEY		"shext_tasktray"
#define SHEXTDDNOCONFIRM_KEY	"shext_dd_noconfirm"
#define SHEXTRNOCONFIRM_KEY		"shext_right_noconfirm"
#define EXECCONRIM_KEY			"exec_confirm"
#define FORCESTART_KEY			"force_start"
#define LCID_KEY				"lcid"
#define LOGFILE_KEY				"logfile"
#define AUTOSLOW_KEY			"autoslow"
#define ISAUTOSLOW_KEY			"is_autoslow"
#define ISAUTOSLOWIO_KEY		"is_autoslow_io"

#define NONBUFMINSIZENTFS_KEY	"nonbuf_minsize_ntfs2"
#define NONBUFMINSIZEFAT_KEY	"nonbuf_minsize_fat"

#define FMT_JOB_KEY				"job_%d"
#define TITLE_KEY				"title"
#define CMD_KEY					"cmd"
#define SRC_KEY					"src"
#define DST_KEY					"dst"
#define FILTER_KEY				"filter"
#define INCLUDE_KEY				"include_filter"
#define EXCLUDE_KEY				"exclude_filter"

#define DEFAULT_MAX_HISTORY		10
#define DEFAULT_COPYMODE		1
#define DEFAULT_COPYFLAGS		0
#define DEFAULT_EMPTYDIR		1
#define DEFAULT_FORCESTART		0
#define DEFAULT_BUFSIZE			32
#define DEFAULT_MAXTRANSSIZE	8
#define DEFAULT_MAXATTRSIZE		(128 * 1024 * 1024)
#define DEFAULT_MAXDIRSIZE		(128 * 1024 * 1024)
#define DEFAULT_MAXOPENFILES	256
#define DEFAULT_NBMINSIZE_NTFS	64		// nbMinSize �Q��
#define DEFAULT_NBMINSIZE_FAT	128		// nbMinSize �Q��
#define DEFAULT_AUTOSLOW		30
#define JOB_MAX					1000
#define DEFAULT_FASTCOPYLOG		"fastcopy.log"

/*=========================================================================
  �N���X �F Cfg
  �T  �v �F �R���t�B�O�N���X
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
Cfg::Cfg()
{
	char	buf[MAX_PATH], path[MAX_PATH], *fname = NULL;

	::GetModuleFileName(NULL, buf, sizeof(buf));
	::GetFullPathName(buf, sizeof(path), path, &fname);

	execPath = strdup(path);
	if (fname) {
		*fname = 0;
		execDir = strdup(path);
	}
	else {
		execDir = strdup(".\\");
	}

	MakePath(path, execDir, FASTCOPY_INI);
	ini.Init(path);
}

Cfg::~Cfg()
{
	free(execPath);
	free(execDir);
}

BOOL Cfg::ReadIni(void)
{
	char	key[100];
	char	*buf = new char [MAX_HISTORY_CHAR_BUF];
	WCHAR	*wbuf = new WCHAR [MAX_HISTORY_BUF];
	char	*section_array[] = { SRC_HISTORY, DST_HISTORY, INC_HISTORY, EXC_HISTORY };
	void	***history_array[] = { &srcPathHistory, &dstPathHistory, &includeHistory, &excludeHistory };

	srcPathHistory	= NULL;
	dstPathHistory	= NULL;
	includeHistory	= NULL;
	excludeHistory	= NULL;

	jobArray = NULL;
	jobMax = 0;

	ini.SetSection(MAIN_SECTION);
	bufSize			= ini.GetInt(BUFSIZE_KEY, DEFAULT_BUFSIZE);
	maxTransSize	= ini.GetInt(MAXTRANSSIZE_KEY, DEFAULT_MAXTRANSSIZE);
	maxOpenFiles	= ini.GetInt(MAXOPENFILES_KEY, DEFAULT_MAXOPENFILES);
	maxAttrSize		= ini.GetInt(MAXATTRSIZE_KEY, DEFAULT_MAXATTRSIZE);
	maxDirSize		= ini.GetInt(MAXDIRSIZE_KEY, DEFAULT_MAXDIRSIZE);
	nbMinSizeNtfs	= ini.GetInt(NONBUFMINSIZENTFS_KEY, DEFAULT_NBMINSIZE_NTFS);
	nbMinSizeFat	= ini.GetInt(NONBUFMINSIZEFAT_KEY, DEFAULT_NBMINSIZE_FAT);
	maxHistoryNext	= maxHistory = ini.GetInt(MAX_HISTORY_KEY, DEFAULT_MAX_HISTORY);
	copyMode		= ini.GetInt(COPYMODE_KEY, DEFAULT_COPYMODE);
	copyFlags		= ini.GetInt(COPYFLAGS_KEY, DEFAULT_COPYFLAGS);
	skipEmptyDir	= ini.GetInt(SKIPEMPTYDIR_KEY, DEFAULT_EMPTYDIR);
	forceStart		= ini.GetInt(FORCESTART_KEY, DEFAULT_FORCESTART);
	ignoreErr		= ini.GetInt(IGNORE_ERR_KEY, TRUE);
	estimateMode	= ini.GetInt(ESTIMATE_KEY, 0);
	diskMode		= ini.GetInt(DISKMODE_KEY, 0);
	isTopLevel		= ini.GetInt(ISTOPLEVEL_KEY, FALSE);
	isErrLog		= ini.GetInt(ISERRLOG_KEY, TRUE);
	isSameDirRename	= ini.GetInt(ISSAMEDIRRENAME_KEY, TRUE);
	shextAutoClose	= ini.GetInt(SHEXTAUTOCLOSE_KEY, TRUE);
	shextTaskTray	= ini.GetInt(SHEXTTASKTRAY_KEY, FALSE);
	shextDdNoConfirm = ini.GetInt(SHEXTDDNOCONFIRM_KEY, FALSE);
	shextRNoConfirm	= ini.GetInt(SHEXTRNOCONFIRM_KEY, FALSE);
	execConfirm		= ini.GetInt(EXECCONRIM_KEY, FALSE);
	lcid			= ini.GetInt(LCID_KEY, -1);
	autoSlow		= ini.GetInt(AUTOSLOW_KEY, DEFAULT_AUTOSLOW);
	isAutoSlow		= ini.GetInt(ISAUTOSLOW_KEY, FALSE);
	isAutoSlowIo	= ini.GetInt(ISAUTOSLOWIO_KEY, TRUE);

/* logfile */
	ini.GetStr(LOGFILE_KEY, buf, MAX_PATH, DEFAULT_FASTCOPYLOG);
	IniStrToV(buf, wbuf);
	if (lstrchrV(wbuf, '\\') == NULL) {
		MakePathV(buf, IS_WINNT_V ? (void *)AtoW(execDir) : (void *)execDir, wbuf);
		logPath = strdupV(buf);
	}
	else {
		logPath = strdupV(wbuf);
	}

/* History */
	int	i, j;
	for (i=0; i < sizeof(section_array) / sizeof(char *); i++) {
		char	*&section = section_array[i];
		void	**&history = *history_array[i];

		ini.SetSection(section);
		history = (void **)calloc(maxHistory, sizeof(WCHAR *));
		for (j=0; j < maxHistory + 30; j++) {
			wsprintf(key, "%d", j);
			if (j < maxHistory) {
				ini.GetStr(key, buf, MAX_HISTORY_CHAR_BUF, "");
				IniStrToV(buf, wbuf);
				history[j] = strdupV(wbuf);
			}
			else if (!ini.DelKey(key))
				break;
		}
	}

/* Job */
	for (i=0; i < JOB_MAX; i++) {
		wsprintf(buf, FMT_JOB_KEY, i);
		Job	job;

		ini.SetSection(buf);
		if (ini.GetStr(TITLE_KEY, buf, MAX_HISTORY_CHAR_BUF) <= 0)
			break;
		IniStrToV(buf, wbuf);
		job.title = strdupV(wbuf);

		ini.GetStr(SRC_KEY, buf, MAX_HISTORY_CHAR_BUF);
		IniStrToV(buf, wbuf);
		job.src = strdupV(wbuf);

		ini.GetStr(DST_KEY, buf, MAX_HISTORY_CHAR_BUF);
		IniStrToV(buf, wbuf);
		job.dst = strdupV(wbuf);

		ini.GetStr(CMD_KEY, buf, MAX_HISTORY_CHAR_BUF);
		IniStrToV(buf, wbuf);
		job.cmd = strdupV(wbuf);

		ini.GetStr(INCLUDE_KEY, buf, MAX_HISTORY_CHAR_BUF);
		IniStrToV(buf, wbuf);
		job.includeFilter = strdupV(wbuf);

		ini.GetStr(EXCLUDE_KEY, buf, MAX_HISTORY_CHAR_BUF);
		IniStrToV(buf, wbuf);
		job.excludeFilter = strdupV(wbuf);

		job.estimateMode = ini.GetInt(ESTIMATE_KEY, 0);
		job.diskMode = ini.GetInt(DISKMODE_KEY, 0);
		job.ignoreErr = ini.GetInt(IGNORE_ERR_KEY, TRUE);
		job.isFilter = ini.GetInt(FILTER_KEY, FALSE);
		job.bufSize = ini.GetInt(BUFSIZE_KEY, DEFAULT_BUFSIZE);

		AddJob(&job);
	}

	if (::GetFileAttributes(ini.GetIniFileName()) == 0xffffffff) {
		WriteIni();
	}
	delete [] wbuf;
	delete [] buf;

	return	TRUE;
}

BOOL Cfg::WriteIni(void)
{
	ini.SetSection(MAIN_SECTION);
	ini.SetInt(BUFSIZE_KEY, bufSize);
	ini.SetInt(MAXTRANSSIZE_KEY, maxTransSize);
//	ini.SetInt(MAXOPENFILES_KEY, maxOpenFiles);
	ini.SetInt(NONBUFMINSIZENTFS_KEY, nbMinSizeNtfs);
	ini.SetInt(NONBUFMINSIZEFAT_KEY, nbMinSizeFat);
	ini.SetInt(MAX_HISTORY_KEY, maxHistoryNext);
	ini.SetInt(COPYMODE_KEY, copyMode);
//	ini.SetInt(COPYFLAGS_KEY, copyFlags);
	ini.SetInt(SKIPEMPTYDIR_KEY, skipEmptyDir);
	ini.SetInt(IGNORE_ERR_KEY, ignoreErr);
	ini.SetInt(ESTIMATE_KEY, estimateMode);
	ini.SetInt(DISKMODE_KEY, diskMode);
	ini.SetInt(ISTOPLEVEL_KEY, isTopLevel);
	ini.SetInt(ISERRLOG_KEY, isErrLog);
	ini.SetInt(ISSAMEDIRRENAME_KEY, isSameDirRename);
	ini.SetInt(SHEXTAUTOCLOSE_KEY, shextAutoClose);
	ini.SetInt(SHEXTTASKTRAY_KEY, shextTaskTray);
	ini.SetInt(SHEXTDDNOCONFIRM_KEY, shextDdNoConfirm);
	ini.SetInt(SHEXTRNOCONFIRM_KEY, shextRNoConfirm);
	ini.SetInt(EXECCONRIM_KEY, execConfirm);
	ini.SetInt(FORCESTART_KEY, forceStart);
//	ini.SetInt(LCID_KEY, lcid);
//	ini.SetInt(AUTOSLOW_KEY, autoSlow);
	ini.SetInt(ISAUTOSLOW_KEY, isAutoSlow);
	ini.SetInt(ISAUTOSLOWIO_KEY, isAutoSlowIo);

	char	*section_array[] = { SRC_HISTORY, DST_HISTORY, INC_HISTORY, EXC_HISTORY };
	void	***history_array[] = { &srcPathHistory, &dstPathHistory, &includeHistory, &excludeHistory };
	int		i, j;
	char	key[100];
	char	*buf = new char [MAX_HISTORY_CHAR_BUF];

	for (i=0; i < sizeof(section_array) / sizeof(char *); i++) {
		char	*&section = section_array[i];
		void	**&history = *history_array[i];

		ini.SetSection(section);
		for (j=0; j < maxHistory; j++) {
			wsprintf(key, "%d", j);
			VtoIniStr(history[j], buf);
			if (j < maxHistoryNext)
				ini.SetStr(key, buf);
			else
				ini.DelKey(key);
		}
	}

	for (i=0; i < jobMax; i++) {
		wsprintf(buf, FMT_JOB_KEY, i);
		Job *job = jobArray[i];

		ini.SetSection(buf);

		VtoIniStr(job->title, buf);
		ini.SetStr(TITLE_KEY,		buf);

		VtoIniStr(job->src, buf);
		ini.SetStr(SRC_KEY,			buf);

		VtoIniStr(job->dst, buf);
		ini.SetStr(DST_KEY,			buf);

		VtoIniStr(job->cmd, buf);
		ini.SetStr(CMD_KEY,			buf);

		VtoIniStr(job->includeFilter, buf);
		ini.SetStr(INCLUDE_KEY,		buf);

		VtoIniStr(job->excludeFilter, buf);
		ini.SetStr(EXCLUDE_KEY,		buf);

		ini.SetInt(ESTIMATE_KEY,	job->estimateMode);
		ini.SetInt(DISKMODE_KEY,	job->diskMode);
		ini.SetInt(IGNORE_ERR_KEY,	job->ignoreErr);
		ini.SetInt(FILTER_KEY,		job->isFilter);
		ini.SetInt(BUFSIZE_KEY,		job->bufSize);
	}
	wsprintf(buf, FMT_JOB_KEY, i);
	ini.DelSection(buf);

	delete [] buf;

	return	TRUE;
}

BOOL Cfg::EntryPathHistory(void *src, void *dst)
{
	void	*path_array[] = { src, dst };
	void	***history_array[] = { &srcPathHistory, &dstPathHistory };

	return	EntryHistory(path_array, history_array, 2);
}

BOOL Cfg::EntryFilterHistory(void *inc, void *exc)
{
	void	*path_array[] = { inc, exc };
	void	***history_array[] = { &includeHistory, &excludeHistory };

	return	EntryHistory(path_array, history_array, 2);
}

BOOL Cfg::EntryHistory(void **path_array, void ****history_array, int max)
{
	BOOL	ret = TRUE;
	void	*target_path;

	for (int i=0; i < max; i++) {
		int		idx;
		void	*&path = path_array[i];
		void	**&history = *history_array[i];

		if (strlenV(path) >= MAX_HISTORY_BUF || GetChar(path, 0) == 0) {
			ret = FALSE;
			continue;
		}
		for (idx=0; idx < maxHistory; idx++) {
			if (lstrcmpiV(path, history[idx]) == 0)
				break;
		}
		if (idx) {
			if (idx == maxHistory) {
				target_path = strdupV(path);
				free(history[--idx]);
			}
			else {
				target_path = history[idx];
			}
			memmove(history + 1, history, idx * sizeof(void *));
			history[0] = target_path;
		}
	}
	return	ret;
}

BOOL Cfg::IniStrToV(char *inipath, void *path)
{
	if (IS_WINNT_V) {
		int		len = strlen(inipath) + 1;
		if (*inipath == '|') {
			hexstr2bin(inipath + 1, (BYTE *)path, len, &len);
		}
		else
			::MultiByteToWideChar(CP_ACP, 0, (char *)inipath, -1, (WCHAR *)path, len);
	}
	else
		strcpyV(path, inipath);

	return	TRUE;
}

BOOL Cfg::VtoIniStr(void *path, char *inipath)
{
	if (IS_WINNT_V) {
		int		len = (strlenV(path) + 1) * CHAR_LEN_V;
		int		err_cnt = 0;

		*inipath = 0;
		if (!::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)path, -1, inipath, len, 0, &err_cnt))
			return	FALSE;

		if (err_cnt) {
			*inipath = '|';
			bin2hexstr((BYTE *)path, len, inipath + 1);
		}
	}
	else
		strcpyV(inipath, path);

	return	TRUE;
}

int Cfg::SearchJobV(void *title)
{
	for (int i=0; i < jobMax; i++) {
		if (lstrcmpiV(jobArray[i]->title, title) == 0)
			return	i;
	}
	return	-1;
}

BOOL Cfg::AddJob(const Job *job)
{
	if (GetChar(job->title, 0) == 0 || strlenV(job->src) >= MAX_HISTORY_BUF || GetChar(job->src, 0) == 0)
		return	FALSE;

	int idx = SearchJobV(job->title);

	if (idx >= 0) {
		delete jobArray[idx];
		jobArray[idx] = new Job(*job);
		return TRUE;
	}

#define ALLOC_JOB	100
	if ((jobMax % ALLOC_JOB) == 0)
		jobArray = (Job **)realloc(jobArray, sizeof(Job *) * (jobMax + ALLOC_JOB));

	for (idx=0; idx < jobMax; idx++) {
		if (lstrcmpiV(jobArray[idx]->title, job->title) > 0)
			break;
	}
	memmove(jobArray + idx + 1, jobArray + idx, sizeof(Job *) * (jobMax++ - idx));
	jobArray[idx] = new Job(*job);
	return	TRUE;
}

BOOL Cfg::DelJobV(void *title)
{
	int idx = SearchJobV(title);
	if (idx == -1)
		return	FALSE;

	delete jobArray[idx];
	memmove(jobArray + idx, jobArray + idx + 1, sizeof(Job *) * (--jobMax - idx));
	return	TRUE;
}

