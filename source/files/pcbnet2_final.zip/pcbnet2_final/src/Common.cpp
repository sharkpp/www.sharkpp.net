// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"

/*
	�O���[�o���ϐ���`
*/
BOOL bInit = FALSE;
HINSTANCE ghInstance = NULL;
int iTCPSendBuf = 4*1024;
int iTCPRecvBuf = 64*1024;
int iMaxBuffer = 4*1024*1024;
BOOL bStrict = TRUE;
WSADATA wsaData;

SOCKETSET ss;		// �g�p�\�\�P�b�g�Z�b�g
SOCKETSET ssx;		// �x���N���[�Y���\�P�b�g�Z�b�g



////////////////////////////////////////////////////////////////

/*
	SOCKETINFO�N���X ���\�b�h��`
*/

SOCKETINFO::SOCKETINFO() {
	InitializeCriticalSection(&crit);
	bInit = FALSE;
	type = ST_UNDEFINED;
	hWnd = NULL;
	threadID = 0;
	hThread = NULL;
	err = 0;
	dwUser = 0;
	fAsyncTask = 0;
	bClosing = FALSE;
	map.bAvailable = FALSE;
	memset(soc, 0, sizeof(soc));
	socs = 0;
	memset(family, 0, sizeof(family));
	memset(&addr, 0, sizeof(addr));
	addrlen = 0;
	memset(&map, 0, sizeof(map));
}
SOCKETINFO::~SOCKETINFO() {
	DeleteCriticalSection(&crit);
}
void SOCKETINFO::Lock() {
	EnterCriticalSection(&crit);
}
void SOCKETINFO::Unlock() {
	LeaveCriticalSection(&crit);
}




////////////////////////////////////////////////////////////////


BOOL Initialize()
{
	if (bInit) return FALSE;

	memset(&wsaData, 0, sizeof(wsaData));
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
		return TRUE;
	InitSocketManager();
	bInit = TRUE;
	return FALSE;
}


BOOL Cleanup()
{
	if (! bInit) return FALSE;
	CleanupSocketManager();
	WSACleanup();
	bInit = FALSE;
	return FALSE;
}


unsigned short CheckSum(char *buf, int len)
{
	unsigned long t = 0;
	int i;

	for(i=0; i<len/2; i++)
		t += ((unsigned short *)buf)[i];
	if (len&1)
		t += ((unsigned char *)buf)[len-1];

	t = (t >> 16) + (t & 0xffff);
	return (unsigned short)(~( (t >> 16) + (t & 0xffff) ));
}





/*
	�����񑀍�p�֐��Q
*/




char * getstr(char *dest, char *src, int destsize, char token)
{
	int i;
	char c;

	for(i=0; i<destsize-1; i++) {
		c = src[i];
		if (c == '\0' || c == '\r' || c == '\n' || c == token) break;
		dest[i] = c;
	}
	dest[i] = '\0';

	while(c = src[i], c != '\0' && c != '\r' && c != '\n' && c != token)
		i++;

	return (c != '\0' && c != '\r' && c != '\n' && c == token) ? src+i+1 : src+i;
}


char * nextline(char *p)
{
	while(*p != '\0') {
		if (*p == '\r') {
			if (*(p+1) == '\n')
				p+=2;
			else
				p++;
			break;
		}
		if (*p == '\n') {
			p++;
			break;
		}
		p++;
	}
	return (*p != '\0') ? p : NULL;
}


char * skipspace(char *p)
{
	while(*p != '\0' && isspace(*p))
		p++;
	return p;
}


char * deletebackspace(char *p)
{
	int i;
	for(i=strlen(p)-1; i>=0 && isspace(p[i]); i--)
		p[i] = '\0';
	return p;
}





/*
	HTTP�p�֐��Q
*/




int ParseHTTPResponse(HTTPRESPONSE *res, char *in)
{
	int len, headlen, bodylen;
	char *body, *p, *q;
	HTTPHEADER head;
	list<HTTPHEADER>::iterator it;

	strcpy(res->Protocol, "");
	res->Code = 0;
	res->Headers.clear();

	len = strlen(in);
	body = strstr(in, "\r\n\r\n");
	if (body == NULL) return -1;

	headlen = (int)(body-in);
	body += 4;
	bodylen = len-headlen-4;

	// Parse Header
	if (headlen < 16)	// strlen("HTTP/1.0 200\r\n\r\n")
		return -2;
	getstr(res->Protocol, in, sizeof(res->Protocol), ' ');
	res->Code = atoi(in+9);
	res->Headers.clear();

	for(p=nextline(in); p!=NULL; p=nextline(p)) {
		q = getstr(head.Tag, p, sizeof(head.Tag), ':');
		q = skipspace(q);
		getstr(head.Value, q, sizeof(head.Value));
		res->Headers.push_back(head);
	}

	return headlen;
}

void RenewXML(char *xml)
{
	char *p, *q;
	BOOL bSpacing;
	BOOL bNoSpace;
	BOOL bInTag;

	bSpacing = FALSE;
	bNoSpace = TRUE;
	bInTag = FALSE;
	for(p=q=xml; *p!='\0'; p++) {
		if (isspace(*p)) {
			if (bNoSpace || bSpacing)
				continue;
			*q++ = ' ';
			bSpacing = TRUE;
		}
		else {
			if (*p == '<') {
				bInTag = TRUE;
				bNoSpace = TRUE;
			}
			else if (*p == '>') {
				bInTag = FALSE;
				bNoSpace = TRUE;
			}
			else {
				bNoSpace = FALSE;
			}
			if (bInTag && isalpha(*p)) {
				*p = tolower(*p);
			}
			*q++ = *p;
			bSpacing = FALSE;
		}
	}
	*q = '\0';
}


BOOL GetXMLEntry(char *dest, int destsize, char *xml, char *tag)
{
	char *p;
	char tmp[128];

	*dest = '\0';
	tmp[0] = '<';
	getstr(tmp+1, tag, sizeof(tmp)-1);
	if ((p = strstr(xml, tmp)) == NULL) return FALSE;
	p = getstr(dest, p, 0, '>');
	//OutputDebugString(p);
	getstr(dest, p, destsize, '<');
	deletebackspace(dest);

	//OutputDebugString("GetXMLEntry(");
	//OutputDebugString(tag);
	//OutputDebugString(") = ");
	//OutputDebugString(dest);
	//OutputDebugString("\n");
	//OutputDebugString(xml);
	return TRUE;
}


int GetXMLEntryInt(char *xml, char *tag)
{
	char tmp[16];

	GetXMLEntry(tmp, sizeof(tmp), xml, tag);
	return atoi(tmp);
}



