// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"


LRESULT CALLBACK NetProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

HANDLE hManagerThread = NULL;
DWORD dwManagerThreadID = 0;




unsigned int WINAPI SocketManagerProc(void *param)
{
	MSG msg;
	SOCKETINFO *si;
	BOOL bClosing = FALSE;

	while(GetMessage(&msg, NULL, 0, 0)) {
		switch(msg.message) {
			case WM_PCBNET_THREAD_ENDING:
				si = (SOCKETINFO *)msg.lParam;
				if (! IsSocketX(si)) break;
				WaitForSingleObject(si->hThread, INFINITE);
				if (si->hWnd != NULL)
					DestroyWindow(si->hWnd);
				CloseHandle(si->hThread);
				ssx.erase(si);
				delete si;
				break;
			case WM_CLOSE:
				bClosing = TRUE;
				break;
		}
		if (bClosing && ss.empty() && ssx.empty())
			PostQuitMessage(0);
	}

	return msg.wParam;
}

void InitSocketManager()
{
	if (hManagerThread != NULL) return;
	hManagerThread = (HANDLE)_beginthreadex(NULL, 0, SocketManagerProc, NULL, 0, (unsigned int *)&dwManagerThreadID);
	Sleep(100); // �����ƃ_��
}

void CleanupSocketManager()
{
	DestroySocketSet();
	PostThreadMessage(dwManagerThreadID, WM_CLOSE, 0, 0);
	WaitForSingleObject(hManagerThread, INFINITE);
	CloseHandle(hManagerThread);
	hManagerThread = NULL;
	dwManagerThreadID = 0;
}





HWND CreateSocketWindow(SOCKETINFO *si)
{
	WNDCLASSEX wcl;

	memset(&wcl, 0, sizeof(wcl));
	wcl.cbSize = sizeof(wcl);
	wcl.lpfnWndProc = NetProc;
	wcl.hInstance = ghInstance;
	wcl.lpszClassName = PCBNET_WNDCLASS;
	RegisterClassEx(&wcl);

	return CreateWindow(PCBNET_WNDCLASS,
						PCBNET_WNDTITLE,
						0,
						CW_USEDEFAULT, CW_USEDEFAULT,
						CW_USEDEFAULT, CW_USEDEFAULT,
						NULL, NULL,
						ghInstance,
						(LPVOID)si);
}

unsigned int WINAPI SocketThreadProc(LPVOID lpvParam)
{
	HWND hWnd;
	SOCKETINFO *si = (SOCKETINFO *)lpvParam;
	MSG msg;

	hWnd = CreateSocketWindow(si);
	if (hWnd == NULL)
		return 1;

	si->bInit = TRUE;

	while(GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	EndThread(si);

	return 0;
}


SOCKETINFO * CreateSocket(int socktype)
{
	DWORD threadID, dwStat;
	HANDLE hThread;
	SOCKETINFO *si;
	HWND hWnd = NULL;

	si = new SOCKETINFO;
	si->bInit = FALSE;
	si->type = socktype;
	hThread = (HANDLE)_beginthreadex(NULL, 0, SocketThreadProc, (void *)si, 0, (unsigned int *)&threadID);

	dwStat = STILL_ACTIVE;
	while( (! si->bInit) && dwStat == STILL_ACTIVE ) {
		GetExitCodeThread(hThread, &dwStat);
		Sleep(1);
	}
	if (dwStat != STILL_ACTIVE) {
		CloseHandle(hThread);
		delete si;
		return NULL;
	}

	si->threadID = threadID;
	si->hThread = hThread;
	ss.insert(si);
	return si;
}

BOOL IsSocket(SOCKETINFO *si, int type)
{
	if (ss.find(si) != ss.end() && (si->type & type) != 0) return TRUE;
	return FALSE;
}

BOOL IsSocketX(SOCKETINFO *si, int type)
{
	if (ssx.find(si) != ssx.end() && (si->type & type) != 0) return TRUE;
	return FALSE;
}

BOOL DeleteSocket(SOCKETINFO *si)
{
	if (! IsSocket(si)) return TRUE;

	ssx.insert(si);
	ss.erase(si);
	PostMessage(si->hWnd, WM_CLOSE, 0, 0);
	return FALSE;
}

void EndThread(SOCKETINFO *si)
{
	PostThreadMessage(dwManagerThreadID, WM_PCBNET_THREAD_ENDING, 0, (LPARAM)si);
}

void DestroySocketSet()
{
	while(! ss.empty()) {
		DeleteSocket(*ss.begin());
	}
}
