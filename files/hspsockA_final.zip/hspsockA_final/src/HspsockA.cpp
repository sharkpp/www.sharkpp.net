
//
//		Advanced Communications Plugin for HSP
//				onion software/onitama 1998
//
//			Nise Asynchronous version by
//				PCB Software/PCB 2002-2003
//
//					Ver 1.3
//
//


#include <windows.h>
#include <winsock.h>
#include <stdio.h>
#include "hspdll.h"
#include "hspsockA.h"


//#define SOCKDEBUG


/////////////////////////////////////////////////////////////////////////  �錾
//*//////////////////////////////////////////////////////////////////////////////

EXPORT BOOL WINAPI sockinit( BMSCR *bm, int p1, int p2, int p3 );
EXPORT BOOL WINAPI sockbye( int p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockopen( int p1, char *p2, int p3, int p4 );
EXPORT BOOL WINAPI sockmake( int p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockwait( int p1, int p2, int p3, char *p4 );
EXPORT BOOL WINAPI sockshut( int p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockclose( int p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockget( char *p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockput( BMSCR *bm, char *p2, int p3, int p4 );
EXPORT BOOL WINAPI sockputc( int p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockputw( int p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockputd( int p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockgetc( int *p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockgetw( int *p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockgetd( int *p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockputb( char *p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI sockgetb( char *p1, int p2, int p3, int p4 );
EXPORT BOOL WINAPI ipget(int a,int b,int c,char *d);
EXPORT BOOL WINAPI sockcheck(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI sockcount(int *p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI sockerror(int *p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI sockiscon( int p1, int p2, int p3, int p4 );

LRESULT CALLBACK AsyncProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
HWND CreateSocketWindow(HINSTANCE hInstance);
BOOL IsWildcardHost(unsigned long addr);



// �O���[�o���ϐ���`
HINSTANCE g_hInstance;				// DLL�C���X�^���X
BOOL bInit = FALSE;					// �������t���O
HWND hSocketWnd = NULL;				// �\�P�b�g�E�B���h�E�n���h��
SOCKETINFO sockInfo[MAX_SOCKETS];	// �\�P�b�g���








//////////////////////////////////////////////////////////  DLL�G���g���|�C���g
//*//////////////////////////////////////////////////////////////////////////////


int WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, PVOID lpvReserved)
{
	switch(fdwReason) {
	case DLL_PROCESS_ATTACH:
		g_hInstance = hInstance;
		bInit = FALSE;
		break;
	}
	return TRUE;
}







/////////////////////////////////////////////////////////////  �G�N�X�|�[�g����
//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockinit( BMSCR *bm, int p1, int p2, int p3 )
{
	if (bInit)
		sockbye(0, 0, 0, 0);

	WSADATA wsaData;

	// �񓯊��C�x���g�p�E�B���h�E�̍쐬
	hSocketWnd = CreateSocketWindow(g_hInstance);
	if (hSocketWnd == NULL)
		return -1;
	// WinSock�̏�����
	if (WSAStartup(MAKEWORD(1, 1), &wsaData)) {
		DestroyWindow(hSocketWnd);
		return -2;
	}
	// sockInfo������
	memset(sockInfo, 0, sizeof(sockInfo));
	bInit = TRUE;
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockbye( int p1, int p2, int p3, int p4 )
{
	if (! bInit) return 0;

	// �S�Ẵ\�P�b�g���������
	for(int i=0; i<MAX_SOCKETS; i++)
		sockclose(i, 0, 0, 0);
	// �񓯊��C�x���g�p�E�B���h�E�̔j��
	DestroyWindow(hSocketWnd);
	// WinSock�̃��\�[�X�����
	WSACleanup();
	bInit = FALSE;
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockopen( int p1, char *p2, int p3, int p4 )
{
	unsigned long serveraddr;		/* �T�[�o��IP�A�h���X */
	SOCKET soc;
	SOCKETINFO &si = sockInfo[p1];

	if (p1 < 0 || p1 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc != NULL) return HSPEINVALIDSOCKET;		/* ���Ƀ\�P�b�g���g���Ă���ꍇ�̓G���[���o�� */

	soc = socket(AF_INET, SOCK_STREAM, 0);
	if (soc == INVALID_SOCKET)
		return -1;

	// �\�P�b�g���̍\���̂𖄂߂�
	memset(&si, 0, sizeof(SOCKETINFO));
	si.soc = soc;
	si.bListener = FALSE;
	si.addr.sin_family = AF_INET;
	si.addr.sin_addr.s_addr = htonl(INADDR_NONE);		/* �Ƃ肠������ɂ��Ă��� */
	si.addr.sin_port = htons((unsigned short)p3);

	// �񓯊�����̎葱��
	WSAAsyncSelect(soc, hSocketWnd, WM_ASYNC, FD_CONNECT);

	// Name�Ƀh�b�g�ŋ�؂���10�i����IP�A�h���X�������Ă���ꍇ�Aserveraddr��32bit������IP�A�h���X���Ԃ�܂�
	serveraddr = inet_addr(p2);
	if (serveraddr == htonl(INADDR_NONE)) {
		// �T�[�o������T�[�o�̃z�X�g�����擾���܂�(�񓯊�)
		si.pHostent = new char[MAXGETHOSTSTRUCT];
		si.hAsync = WSAAsyncGetHostByName(hSocketWnd, WM_DNSREPLY, p2, si.pHostent, MAXGETHOSTSTRUCT);
	}
	else {
		// �T�[�o�̃A�h���X�̍\���̂ɃT�[�o��IP�A�h���X��ݒ肵�܂�
		sockInfo[p1].addr.sin_addr.s_addr = serveraddr;
		SendMessage(hSocketWnd, WM_CONNECT, p1, 0);		// �ڑ��J�n
	}
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockmake( int p1, int p2, int p3, int p4 )
{
	SOCKET soc;
	SOCKETINFO &si = sockInfo[p1];

	if (p1 < 0 || p1 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc != NULL) return HSPEINVALIDSOCKET;		// ���Ƀ\�P�b�g���g���Ă���ꍇ�̓G���[���o��

	soc = socket(AF_INET, SOCK_STREAM, 0);
	if (soc == INVALID_SOCKET)
		return -2;

	// �\�P�b�g���̍\���̂𖄂߂�
	memset(&si, 0, sizeof(SOCKETINFO));
	si.soc = soc;
	si.bListener = TRUE;
	si.pHostent = new char[MAXGETHOSTSTRUCT];
	si.addr.sin_family = AF_INET;
	si.addr.sin_addr.s_addr = htonl(INADDR_ANY);
	si.addr.sin_port = htons((unsigned short)p2);

	if (bind(soc, (struct sockaddr *)&si.addr, sizeof(si.addr)) == SOCKET_ERROR) {
		sockclose(p1, 0, 0, 0);
		return -1;
	}

	// �񓯊�����̎葱��
	WSAAsyncSelect(soc, hSocketWnd, WM_ASYNC, FD_ACCEPT);

	if (listen(soc, 5) == SOCKET_ERROR) {
		if (WSAGetLastError() != WSAEWOULDBLOCK) {
			sockclose(p1, 0, 0, 0);
			return -3;
		}
	}
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockwait( int p1, int p2, int p3, char *p4 )
{
	char s[16];
	SOCKETINFO &si = sockInfo[p1];

	if (p1 < 0 || p1 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;

	if (si.err)
		return -2;
	if (! si.bConnected)
		return 0;
	if (si.bListener) {
		strcpy(p4, inet_ntoa(si.addr.sin_addr));
		strcat(p4, ":");
		strcat(p4, _itoa(ntohs(si.addr.sin_port), s, 10));
	}
	return -1;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockshut( int p1, int p2, int p3, int p4 )
{
	SOCKETINFO &si = sockInfo[p1];

	if (p1 < 0 || p1 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;
	if (! si.bConnected) return HSPEINVALIDSOCKET;

	if (si.bShutted) return -1;

	// ���M�𖳌��ɂ���
	shutdown(si.soc, 1);
	si.bShutted = TRUE;
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockclose( int p1, int p2, int p3, int p4 )
{
	SOCKETINFO &si = sockInfo[p1];

	if (p1 < 0 || p1 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;

	if (si.hAsync != NULL)
		WSACancelAsyncRequest(si.hAsync);
	if (si.pHostent != NULL)
		delete [] si.pHostent;

	// ���M�𖳌��ɂ���
	shutdown(si.soc, 1);
	// �\�P�b�g��j������
	closesocket(si.soc);

	si.soc = NULL;
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockget( char *p1, int p2, int p3, int p4 )
{
	int ret;
	p1[0] = '\0';

	if (p2 == 0) p2 = 64;

	ret = sockgetb(p1, 0, p2-1, p3);
	if (ret <= 0)
		p1[-ret] = '\0';
	return ret;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockput( BMSCR *bm, char *p2, int p3, int p4 )
{
	int ret;
	ret = sockputb(p2, 0, strlen(p2), p3);
	if (ret > 0) return ret;
	if (ret == 0) return -1;
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockputc( int p1, int p2, int p3, int p4 )
{
	int ret;
	ret = sockputb((char *)&p1, 0, 1, p2);
	if (ret > 0) return ret;		// �G���[
	if (ret == 0) return -1;		// ���M�ł���
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockputw( int p1, int p2, int p3, int p4 )
{
	int ret;
	ret = sockputb((char *)&p1, 0, 2, p2);
	if (ret > 0) return ret;		// �G���[
	if (ret == 0) return -1;		// ���M�ł���
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockputd( int p1, int p2, int p3, int p4 )
{
	int ret;
	ret = sockputb((char *)&p1, 0, 4, p2);
	if (ret > 0) return ret;		// �G���[
	if (ret == 0) return -1;		// ���M�ł���
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockgetc( int *p1, int p2, int p3, int p4 )
{
	int ret;
	*p1 = 0;

	ret = sockgetb((char *)p1, 0, 1, p2);
	if (ret > 0) return ret;
	if (ret == 0) return -1;
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockgetw( int *p1, int p2, int p3, int p4 )
{
	int ret, read=2, len=0;
	*p1 = 0;

	do {
		ret = sockgetb((char *)p1, len, read-len, p2);
		if (ret > 0) return ret;
		if (ret == 0) return -1;
		len += -ret;
	} while(len < read);
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockgetd( int *p1, int p2, int p3, int p4 )
{
	int ret, read=4, len=0;
	*p1 = 0;

	do {
		ret = sockgetb((char *)p1, len, read-len, p2);
		if (ret > 0) return ret;
		if (ret == 0) return -1;
		len += -ret;
	} while(len < read);
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockputb( char *p1, int p2, int p3, int p4 )
{
	SOCKETINFO &si = sockInfo[p4];
	int len;
	
	if (p4 < 0 || p4 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;
	if (! si.bConnected) return HSPENOTCONN;

	if (si.bShutted) return 0;

	// �w��̃\�P�b�g��data�𑗐M���܂�
	// ���M����data�̓T�[�o�ɓ͂��܂�

	if (p3 == 0) p3 = 64;
	len = send(si.soc, p1+p2, p3, 0);
	if (len == SOCKET_ERROR)
		return 0;
	return -len;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockgetb( char *p1, int p2, int p3, int p4 )
{
	SOCKETINFO &si = sockInfo[p4];
	int len;

	if (p4 < 0 || p4 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;
	if (! si.bConnected) return HSPENOTCONN;

	// ��M����data�̓T�[�o�����M�������̂ł�
	len = recv(si.soc, p1+p2, p3, 0);
	if (len == SOCKET_ERROR ){
		return 0;
	}
	return -len;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI ipget(int p1, int p2, int p3, char *refstr)
{
	char myhost[256];
	HOSTENT *phostent;
	IN_ADDR inaddr;

	refstr[0] = '\0';

	if (! bInit) return HSPENOTINIT;

	if(gethostname(myhost, 256) == 0) {
		phostent = gethostbyname(myhost);
		if(WSAGetLastError() == WSANO_DATA) {
			strcpy(refstr, "127.0.0.1");
		}
		else {
			inaddr.s_addr = *((unsigned long *)(phostent->h_addr_list[0]));
			strcpy(refstr, inet_ntoa(inaddr));
		}
	}
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockcheck(int p1, int p2, int p3, int p4)
{
	unsigned long len;
	SOCKETINFO &si = sockInfo[p1];
	FD_SET fds;
	TIMEVAL time = {0, 0};
	int i;

	if (p1 < 0 || p1 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;
	if (! si.bConnected) return HSPENOTCONN;

	if (si.err) return -3;		// socket error occurred
	FD_ZERO(&fds);
	FD_SET(si.soc, &fds);
	i = select(1, &fds, NULL, NULL, &time);
	ioctlsocket(si.soc, FIONREAD, &len);
	if (len == 0 && i == 1) {
		if (recv(si.soc, (char *)&i, 1, 0) == 0)
			return -2;		// indicated graceful shutdown
		si.err = WSAGetLastError();
		return -3;		// socket error occurred
	}
	else if (len == 0) {
		return -1;		// no data available
	}
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockcount(int *p1, int p2, int p3, int p4)
{
	SOCKETINFO &si = sockInfo[p2];
	*p1 = 0;

	if (p2 < 0 || p2 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;
	if (! si.bConnected) return HSPENOTCONN;

	if (si.err) return -1;
	ioctlsocket(si.soc, FIONREAD, (u_long *)p1);
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


EXPORT BOOL WINAPI sockerror(int *p1, int p2, int p3, int p4)
{
	SOCKETINFO &si = sockInfo[p2];
	*p1 = 0;

	if (p2 < 0 || p2 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;

	*p1 = si.err;
	return 0;
}









///////////////////////////////////////////////////  �񓯊����b�Z�[�W�E�B���h�E
//*//////////////////////////////////////////////////////////////////////////////



//		�񓯊��C�x���g(FD_CONNECT,FD_CLOSE,DNS�C�x���g)��
//		��������v���V�[�W���B

LRESULT CALLBACK AsyncProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	SOCKET soc;
	int i, t;

	switch(msg) {

	case WM_ASYNC:		// �񓯊��C�x���g
		// �\�P�b�gID�𒲂ׂ� (by SOCKET)
		for(i=0; i<MAX_SOCKETS; i++) {
			if ( sockInfo[i].soc == (SOCKET)wParam) break;
		}
		if (i == MAX_SOCKETS || wParam == NULL) return 1;		// �U�ҁH
		soc = sockInfo[i].soc;

		if (WSAGETSELECTERROR(lParam) != 0) {
			sockInfo[i].err = WSAGETSELECTERROR(lParam);
			break;
		}

		switch(WSAGETSELECTEVENT(lParam)) {
		case FD_CONNECT:
			sockInfo[i].bConnected = TRUE;
			WSAAsyncSelect(soc, hWnd, 0, 0);
			t = 0;
			ioctlsocket(soc, FIONBIO, (u_long *)&t);
			break;
		case FD_ACCEPT:
			t = sizeof(sockInfo[i].addr);
			sockInfo[i].soc = accept(soc, (sockaddr *)&sockInfo[i].addr, &t);
			closesocket(soc);
			soc = sockInfo[i].soc;
			WSAAsyncSelect(soc, NULL, 0, 0);
			t = 0;
			ioctlsocket(soc, FIONBIO, (u_long *)&t);
			sockInfo[i].bConnected = TRUE;
			break;
		}
		break;

	case WM_DNSREPLY:		// DNS�C�x���g
		// �\�P�b�gID�𒲂ׂ� (by HANDLE)
		for(i=0; i<MAX_SOCKETS; i++) {
			if ( sockInfo[i].hAsync == (HANDLE)wParam) break;
		}
		if (i == MAX_SOCKETS || wParam == NULL) return 1;		// �U�ҁH
		soc = sockInfo[i].soc;
		sockInfo[i].hAsync = NULL;

		if (WSAGETASYNCERROR(lParam) != 0) {
			sockInfo[i].err = WSAGETASYNCERROR(lParam);
			delete [] sockInfo[i].pHostent;
			sockInfo[i].pHostent = NULL;
			break;
		}
		sockInfo[i].addr.sin_addr.s_addr = 
			*(unsigned long *)( ((HOSTENT *)sockInfo[i].pHostent)->h_addr_list[0] );
		delete [] sockInfo[i].pHostent;
		sockInfo[i].pHostent = NULL;
		if (IsWildcardHost(sockInfo[i].addr.sin_addr.s_addr)) {
			sockInfo[i].err = WSAHOST_NOT_FOUND;
			break;
		}
		SendMessage(hWnd, WM_CONNECT, i, 0);
		break;

	case WM_CONNECT:		// �ڑ� wParam:�\�P�b�gID
		soc = sockInfo[wParam].soc;
		if (connect(soc, (struct sockaddr *)&sockInfo[wParam].addr, sizeof(struct sockaddr_in)) == SOCKET_ERROR) {
			if (WSAGetLastError() != WSAEWOULDBLOCK) {
				sockInfo[wParam].err = WSAGetLastError();
			}
		}
		break;

	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}


//*//////////////////////////////////////////////////////////////////////////////


HWND CreateSocketWindow(HINSTANCE hInstance)
{
	WNDCLASSEX wclx;
	char socketClass[] = "hspsockAwnd";

	memset(&wclx, 0, sizeof(wclx));
	wclx.cbSize = sizeof(wclx);
	wclx.lpfnWndProc = AsyncProc;
	wclx.hInstance = hInstance;
	wclx.lpszClassName = socketClass;
	if (! RegisterClassEx(&wclx))
		return NULL;

	return CreateWindowEx(0, socketClass, "", 0, CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
}


BOOL IsWildcardHost(unsigned long addr)
{
	if (addr == inet_addr("64.55.105.9") ||
		addr == inet_addr("64.94.110.11") ||
		addr == inet_addr("194.205.62.62") ||
		addr == inet_addr("194.205.62.122") ||
		addr == inet_addr("195.7.77.20") ||
		addr == inet_addr("203.119.4.6") ||
		addr == inet_addr("206.253.214.102") ||
		addr == inet_addr("212.181.91.6") ||
		addr == inet_addr("216.35.187.246") ||
		addr == inet_addr("219.88.106.80")) {
		return TRUE;
	}
	return FALSE;
}







/////////////////////////////////////////////////////////////  ��������Ȃ�����
//*//////////////////////////////////////////////////////////////////////////////



EXPORT BOOL WINAPI sockiscon( int p1, int p2, int p3, int p4 ) /* deprecated */
{
	SOCKETINFO &si = sockInfo[p1];

	if (p1 < 0 || p1 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;
	if (si.bListener) return HSPEINVALIDSOCKET;

	if (si.err)
		return -2;
	if (! si.bConnected)
		return -1;
	return 0;
}



///////////////////////////////////////////////////////////////////  �f�o�b�O�p
//*//////////////////////////////////////////////////////////////////////////////



#ifdef SOCKDEBUG			// �錾����Ă���Ƃ�����

EXPORT BOOL WINAPI sockdebug(char *p1, int p2, int p3, int p4)
{
	SOCKETINFO &si = sockInfo[p2];
	p1[0] = '\0';

	if (p2 < 0 || p2 >= MAX_SOCKETS) return HSPEINVALIDSOCKET;
	if (! bInit) return HSPENOTINIT;
	if (si.soc == NULL) return HSPEINVALIDSOCKET;

	char boolean[2][6] = {"FALSE", "TRUE"};

	sprintf(p1, "[SOCKETINFO]\nsoc: 0x%x\nerr: %d\nbConnected: %s\nbListener: %s\n\
		addr.sin_addr: %s\naddr.sin_port: %d\npHostent: 0x%x\nhAsync: 0x%x",
		si.soc, si.err, boolean[si.bConnected], boolean[si.bListener],
		inet_ntoa(si.addr.sin_addr), (int)ntohs(si.addr.sin_port), si.pHostent, si.hAsync);
	return 0;
}

#endif //SOCKDEBUG


/////////////////////////////////////////////////////////////////////////////////
//*//////////////////////////////////////////////////////////////////////////////




