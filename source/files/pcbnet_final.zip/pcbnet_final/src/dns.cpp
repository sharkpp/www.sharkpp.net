// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"


EXPORT BOOL WINAPI dnsrequest(int *p1, char *p2, int p3, int p4)
{
	*p1 = 0;
	if ( InitWSA() ) return -1;		// WinSock�������G���[

	THREADLIST *tl;
	tl = CreateSocketThread(ST_DNS);
	if (tl == NULL)
		return -2;			//	Thread�������G���[

	SendMessage(tl->hWnd, WM_DNSREQUEST, 0, (LPARAM)p2);
	*p1 = (int)tl;
	return 0;
}


EXPORT BOOL WINAPI hostbyname(int *p1, char *p2, int p3, int p4)
{
	BOOL ret = dnsrequest(p1, p2, p3, p4);
	if (ret != 0) return ret;
	THREADLIST *tl = (LPTHREADLIST)*p1;
	THREADINFO *ti = tl->ti;
	ti->Lock();
	ti->dns.addr = htonl(INADDR_NONE);
	ti->Unlock();
	return 0;
}


EXPORT BOOL WINAPI hostbyaddr(int *p1, char *p2, int p3, int p4)
{
	BOOL ret = dnsrequest(p1, p2, p3, p4);
	if (ret != 0) return ret;
	THREADLIST *tl = (LPTHREADLIST)*p1;
	THREADINFO *ti = tl->ti;
	ti->Lock();
	ti->dns.addr = htonl(INADDR_ANY);
	ti->Unlock();
	return 0;
}


EXPORT BOOL WINAPI dnscheck(int p1, int p2, int p3, int p4)
{
	THREADLIST *tl = (LPTHREADLIST)p1;
	THREADINFO *ti;
	if (! IsSocketHandle(tl, ST_DNS))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -3;

	BOOL rep;
	int err;
	ti = tl->ti;
	ti->Lock();
	rep = ti->dns.bReply;
	err = ti->err;
	ti->Unlock();
	if (rep && err==0)
		return -1;
	else if (rep && err!=0)
		return -2;
	return 0;
}


EXPORT BOOL WINAPI dnsreply(char *p1, int p2, int p3, int p4)
{
	*p1 = '\0';
	THREADLIST *tl = (LPTHREADLIST)p2;
	THREADINFO *ti;
	if (! IsSocketHandle(tl, ST_DNS))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;

	ti = tl->ti;
	ti->Lock();
	if (! ti->dns.bReply) {
		ti->Unlock();
		return -2;
	}
	else if (ti->err != 0) {
		ti->Unlock();
		return -3;
	}

	if (p3 == 0) {
		if (ti->dns.addr != INADDR_NONE)
			p3 = 1;
		else
			p3 = 2;
	}

	struct in_addr in;
	int n;
	switch(p3) {
		case 1:		// fqdn
			strcpy(p1, ti->ent->h_name);
			break;
		case 2:		// ip
			n=0; while(ti->ent->h_addr_list[n] != NULL) n++;
			if (p4 >= n) {
				ti->Unlock();
				return -4;
			}
			in.s_addr = *(unsigned long *)(ti->ent->h_addr_list[p4]);
			strcpy(p1, inet_ntoa(in));
			break;
		case 3:		// aliases
			n=0; while(ti->ent->h_aliases[n] != NULL) n++;
			if (p4 >= n) return -5;
			strcpy(p1, ti->ent->h_aliases[p4]);
			break;
		default:
			break;
	}
	ti->Unlock();
	return 0;
}


