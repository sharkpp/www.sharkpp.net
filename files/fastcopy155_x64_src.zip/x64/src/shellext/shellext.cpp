static char *shellext_id = 
	"@(#)Copyright (C) H.Shirouzu 2005   shellext.cpp	Ver1.21";
/* ========================================================================
	Project  Name			: Shell Extension for Fast Copy
	Create					: 2005-01-23(Sun)
	Update					: 2005-07-06(Wed)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "..\tlib.h"
#include <olectl.h>
#include "resource.h"

#pragma data_seg(".text")
#define INITGUID
#include <initguid.h>
#include <shlguid.h>
#include "shellext.h"
#pragma data_seg()

ShellExtSystem	*SysObj = NULL;

// ���W�X�g���o�^�L�[�iRef: tortoise subversion�j
char	*DllRegKeys[] = {
	"*\\shellex\\ContextMenuHandlers",
	"*\\shellex\\DragDropHandlers",
	"Folder\\shellex\\ContextMenuHandlers",
	"Folder\\shellex\\DragDropHandlers",
	"Directory\\shellex\\ContextMenuHandlers",
	"Directory\\Background\\shellex\\ContextMenuHandlers",
	"Directory\\shellex\\DragDropHandlers",
	"Drive\\shellex\\ContextMenuHandlers",
	"Drive\\shellex\\DragDropHandlers",
	"InternetShortcut\\shellex\\ContextMenuHandlers",
	"lnkfile\\shellex\\ContextMenuHandlers",
	NULL
};

UINT (WINAPI *DragQueryFileV)(HDROP, UINT, void *, UINT);
BOOL (WINAPI *SHGetPathFromIDListV)(LPCITEMIDLIST, void *);
int (*strlenV)(const void *);
int (WINAPI *wsprintfV)(void *, const void *,...);
int (*MakePathV)(void *, const void *, const void *);
int		CHAR_LEN_V;
BOOL	IS_WINNT_V;
void	*EMPTY_STR_V;
void	*FMT_TOSTR_V;

/*=========================================================================
  �N���X �F ShellExt
  �T  �v �F �V�F���g���N���X
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
ShellExt::ShellExt(void)
{
	cmdFirst = cmdLast = 0;
	refCnt = 0;
	dataObj = NULL;
	if (SysObj)
		SysObj->DllRefCnt++;
}

ShellExt::~ShellExt()
{
	if (dataObj)
		dataObj->Release();
	if (SysObj)
		SysObj->DllRefCnt--;
}

STDMETHODIMP ShellExt::Initialize(LPCITEMIDLIST pIDFolder, IDataObject *pDataObj, HKEY hRegKey)
{
	srcArray.Init();
	dstArray.Init();

	if (dataObj)
		dataObj->Release();

	if (!pDataObj)
		return E_FAIL;

	dataObj = pDataObj;
	pDataObj->AddRef();

	STGMEDIUM	medium;
	FORMATETC	fe = { CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };

	if (pDataObj->GetData(&fe, &medium) < 0)
		return E_INVALIDARG;

	WCHAR	path[MAX_PATH_EX];

	HDROP	hDrop = (HDROP)::GlobalLock(medium.hGlobal);
	int max = DragQueryFileV(hDrop, 0xffffffff, NULL, 0);

	for (int i=0; i < max; i++) {
		DragQueryFileV(hDrop, i, path, sizeof(path) / CHAR_LEN_V);
		srcArray.RegisterPath(path);
	}
	::GlobalUnlock(medium.hGlobal);
	::ReleaseStgMedium(&medium);

	if (pIDFolder && SHGetPathFromIDListV(pIDFolder, path)) {
		dstArray.RegisterPath(path);
	}

	return	NOERROR;
}

STDMETHODIMP ShellExt::QueryInterface(REFIID riid, void **ppv)
{
	*ppv = NULL;

	if (IsEqualIID(riid, IID_IShellExtInit) || IsEqualIID(riid, IID_IUnknown)) {
		*ppv = (IShellExtInit *)this;
	}
	else if (IsEqualIID(riid, IID_IContextMenu)) {
		*ppv = (IContextMenu *)this;
	}

	if (*ppv) {
		AddRef();
		return NOERROR;
	}

	return E_NOINTERFACE;
}

STDMETHODIMP ShellExt::QueryContextMenu(HMENU hMenu, UINT iMenu, UINT _cmdFirst, UINT _cmdLast, UINT flg)
{
	HMENU	hTargetMenu = hMenu;
	BOOL	is_dd = dstArray.Num();
	int		menu_flags = GetMenuFlags();
	int		mask_menu_flags = (menu_flags & (is_dd ? SHEXT_DD_MENUS : SHEXT_RIGHT_MENUS));
	BOOL	is_submenu = (menu_flags & (is_dd ? SHEXT_SUBMENU_DD : SHEXT_SUBMENU_RIGHT));
	BOOL	is_separator = (menu_flags & SHEXT_SUBMENU_NOSEP) ? FALSE : TRUE;

	if (!is_dd && (flg == CMF_NORMAL) || (flg & (CMF_VERBSONLY|CMF_DEFAULTONLY))) {
		return	ResultFromScode(MAKE_SCODE(SEVERITY_SUCCESS, 0, 0));
	}

	cmdFirst = cmdLast = _cmdFirst;
	// ���j���[�A�C�e���̒ǉ�
	if (mask_menu_flags && srcArray.Num() > 0) {
		if (!is_dd && is_separator)
			::InsertMenu(hMenu, iMenu++, MF_SEPARATOR|MF_BYPOSITION, 0, 0);

		if (is_separator)
			::InsertMenu(hMenu, iMenu, MF_SEPARATOR|MF_BYPOSITION, 0, 0);

		if (is_submenu) {
			hTargetMenu = ::CreatePopupMenu();
			::InsertMenu(hMenu, iMenu, MF_POPUP|MF_BYPOSITION, (UINT)hTargetMenu, FASTCOPY);
			iMenu = 0;
		}
		if (mask_menu_flags & (SHEXT_RIGHT_COPY|SHEXT_DD_COPY)) {
			::InsertMenu(hTargetMenu, iMenu++, MF_STRING|MF_BYPOSITION, cmdLast, is_dd ? GetLoadStr(IDS_DDCOPY) : GetLoadStr(IDS_RIGHTCOPY));
		}
		cmdLast++;

		if (mask_menu_flags & (SHEXT_RIGHT_DELETE|SHEXT_DD_MOVE)) {
			::InsertMenu(hTargetMenu, iMenu++, MF_STRING|MF_BYPOSITION, cmdLast, is_dd ? GetLoadStr(IDS_DDMOVE) : GetLoadStr(IDS_RIGHTDEL));
		}
		cmdLast++;
	}

	return	ResultFromScode(MAKE_SCODE(SEVERITY_SUCCESS, 0, cmdLast - cmdFirst));
}

STDMETHODIMP ShellExt::InvokeCommand(CMINVOKECOMMANDINFO *info)
{
	int		cmd = LOWORD(info->lpVerb);

	if (cmd >= 0 && cmd <= 1 && srcArray.Num() > 0) {
		HANDLE	hRead, hWrite;
		SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), 0, TRUE };

		::CreatePipe(&hRead, &hWrite, &sa, 0);
		::DuplicateHandle(::GetCurrentProcess(), hWrite, ::GetCurrentProcess(), &hWrite, 0, FALSE, DUPLICATE_CLOSE_SOURCE|DUPLICATE_SAME_ACCESS);

		STARTUPINFO			st_info;
		memset(&st_info, 0, sizeof(st_info));
		st_info.cb = sizeof(st_info);
		st_info.dwFlags = STARTF_USESTDHANDLES;
		st_info.hStdInput = hRead;
		st_info.hStdOutput = ::GetStdHandle(STD_OUTPUT_HANDLE);
		st_info.hStdError = ::GetStdHandle(STD_ERROR_HANDLE);

		BOOL	is_dd = dstArray.Num();
		char	arg[MAX_PATH_EX];
		PROCESS_INFORMATION	pr_info;

		wsprintf(arg, "\"%s\" %s %s", SysObj->ExeName, cmd == 1 ? is_dd ? "/cmd=move" : "/cmd=delete" : "", SHELLEXT_OPT);
		BOOL ret = ::CreateProcess(SysObj->ExeName, arg, 0, 0, TRUE, CREATE_DEFAULT_ERROR_MODE, 0, 0, &st_info, &pr_info);
		::CloseHandle(hRead);

		if (ret) {
			DWORD	len = srcArray.GetMultiPathLen();
			WCHAR	*buf = new WCHAR[max(len, MAX_PATH_EX)];
			// dstArray �������ꍇ�́A\0 �܂ŏo��
			len = srcArray.GetMultiPath(buf, len) + (!is_dd ? 1 : 0);
			::WriteFile(hWrite, buf, len * CHAR_LEN_V, &len, 0);

			if (is_dd) {
				WCHAR	dir[MAX_PATH_EX];
				MakePathV(dir, dstArray.Path(0), EMPTY_STR_V);	// ������ \\ ��t�^
				len = wsprintfV(buf, FMT_TOSTR_V, dir) + 1;
				::WriteFile(hWrite, buf, len * CHAR_LEN_V, &len, 0);
			}
			delete [] buf;
			::CloseHandle(pr_info.hProcess);
			::CloseHandle(pr_info.hThread);
		}
		::CloseHandle(hWrite);
		return NOERROR;
	}
	return	E_INVALIDARG;
}

STDMETHODIMP ShellExt::GetCommandString(UINT_PTR cmd, UINT flg, UINT *, char *name, UINT cchMax)
{
	BOOL	is_dd = dstArray.Num();

	if (flg == GCS_HELPTEXT) {
		switch (cmd) {
		case 0:
			strncpy(name, is_dd ? GetLoadStr(IDS_DDCOPY) : GetLoadStr(IDS_RIGHTCOPY), cchMax);
			return	S_OK;
		case 1:
			strncpy(name, is_dd ? GetLoadStr(IDS_DDMOVE) : GetLoadStr(IDS_RIGHTDEL), cchMax);
			return	S_OK;
		}
	}
    return E_INVALIDARG;
}

STDMETHODIMP_(ULONG) ShellExt::AddRef()
{
	return ++refCnt;
}

STDMETHODIMP_(ULONG) ShellExt::Release()
{
	if (--refCnt)
		return refCnt;

	delete this;
	return	0;
}


/*=========================================================================
  �N���X �F ShellExtClassFactory
  �T  �v �F �V�F���g���N���X
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
ShellExtClassFactory::ShellExtClassFactory(void)
{
	refCnt = 0;
	if (SysObj)
		SysObj->DllRefCnt++;
}

ShellExtClassFactory::~ShellExtClassFactory()
{
	if (SysObj)
		SysObj->DllRefCnt--;
}

STDMETHODIMP ShellExtClassFactory::CreateInstance(IUnknown *pUnkOuter, REFIID riid, void **ppvObj)
{
	*ppvObj = NULL;

	if (pUnkOuter)
		return CLASS_E_NOAGGREGATION;

	ShellExt *shellExt = new ShellExt;
	if (NULL == shellExt)
		return E_OUTOFMEMORY;

	return shellExt->QueryInterface(riid, ppvObj);
}

STDMETHODIMP ShellExtClassFactory::LockServer(BOOL fLock)
{
	return NOERROR;
}

STDMETHODIMP ShellExtClassFactory::QueryInterface(REFIID riid, void **ppv)
{
	*ppv = NULL;

	if (IsEqualIID(riid, IID_IUnknown) || IsEqualIID(riid, IID_IClassFactory)) {
		*ppv = (IClassFactory *)this;
		AddRef();
		return NOERROR;
	}
	return E_NOINTERFACE;
}

STDMETHODIMP_(ULONG) ShellExtClassFactory::AddRef()
{
	return ++refCnt;
}

STDMETHODIMP_(ULONG) ShellExtClassFactory::Release()
{
	if (--refCnt)
		return refCnt;
	delete this;
	return 0;
}

/*=========================================================================
  ��  �� �F 
  �T  �v �F DLL Export �֐��Q
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
STDAPI DllCanUnloadNow(void)
{
	return SysObj && SysObj->DllRefCnt == 0 ? S_OK : S_FALSE;
}

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID *ppvOut)
{
	*ppvOut = NULL;

	if (IsEqualIID(rclsid, CURRENT_SHEXT_CLSID) || IsEqualIID(rclsid, CURRENT_SHEXTLNK_CLSID)) {
		ShellExtClassFactory	*cf = new ShellExtClassFactory;
		return cf->QueryInterface(riid, ppvOut);
	}
	return CLASS_E_CLASSNOTAVAILABLE;
}

BOOL GetClsId(REFIID cls_name, char *cls_id, int size)
{
	WCHAR		*w_cls_id;
	IMalloc		*im = NULL;

	::StringFromIID(cls_name, &w_cls_id);

	if (w_cls_id)
		::WideCharToMultiByte(CP_ACP, 0, w_cls_id, -1, cls_id, size, NULL, NULL);

	::CoGetMalloc(1, &im);
	im->Free(w_cls_id);
	im->Release();
	return	TRUE;
}

STDAPI DllRegisterServer(void)
{
	if (SHGetPathFromIDListV == NULL)
		return	E_FAIL;

	TShellExtRegistry	reg;

// CLASSKEY �o�^
	if (reg.CreateClsKey()) {
		reg.SetStr(NULL, FASTCOPY);
		if (reg.CreateKey("InProcServer32")) {
			reg.SetStr(NULL, SysObj->DllName);
			reg.SetStr("ThreadingModel", "Apartment");
			reg.CloseKey();
		}
	}

// �֘A�t��
	reg.ChangeTopKey(HKEY_CLASSES_ROOT);
	for (int i=0; DllRegKeys[i]; i++) {
		if (reg.CreateKey(DllRegKeys[i])) {
			if (reg.CreateKey(FASTCOPY)) {
				reg.SetStr(NULL, reg.clsId);
				reg.CloseKey();
			}
			reg.CloseKey();
		}
	}

// NT�n�̒ǉ�
	if (IsWinNT())  {
		reg.ChangeTopKey(HKEY_LOCAL_MACHINE);
		if (reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Shell Extensions\\Approved")) {
			reg.SetStr(reg.clsId, FASTCOPY);
			reg.CloseKey();
		}
	}
	return S_OK;
}

STDAPI DllUnregisterServer(void)
{
	TShellExtRegistry	reg;

// CLASS_KEY �폜
	reg.DeleteChildTree(reg.clsId);

// �֘A�t�� �폜
	reg.ChangeTopKey(HKEY_CLASSES_ROOT);
	for (int i=0; DllRegKeys[i]; i++) {
		if (reg.OpenKey(DllRegKeys[i])) {
			reg.DeleteChildTree(FASTCOPY);
			reg.CloseKey();
		}
	}

// ���o�[�W�����p (.lnk ��p)
	TShellExtRegistry	linkreg(CURRENT_SHEXTLNK_CLSID);
	linkreg.DeleteChildTree(linkreg.clsId);

// NT�n�̒ǉ�
	if (IsWinNT())  {
		reg.ChangeTopKey(HKEY_LOCAL_MACHINE);
		if (reg.OpenKey("Software\\Microsoft\\Windows\\CurrentVersion\\Shell Extensions\\Approved")) {
			reg.DeleteValue(reg.clsId);
			reg.DeleteValue(linkreg.clsId);	// ���o�[�W�����p (.lnk ��p)
			reg.CloseKey();
		}
	}

	return S_OK;
}

/*=========================================================================
  ��  �� �F FastCopy �p export �֐�
  �T  �v �F 
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
BOOL WINAPI SetMenuFlags(int flags)
{
	TRegistry	reg(HKEY_CLASSES_ROOT);

	return	reg.OpenKey(SysObj->MenuFlgRegKey) && reg.SetInt(MENU_FLAGS, flags);
}

int WINAPI GetMenuFlags(void)
{
	TRegistry	reg(HKEY_CLASSES_ROOT);
	int			val = -1;

	if (reg.OpenKey(SysObj->MenuFlgRegKey))
		reg.GetInt(MENU_FLAGS, &val);

	return	val;
}

BOOL WINAPI UpdateDll(void)
{
	int		val = GetMenuFlags();

	const GUID *oldiids[] = {
		&CLSID_ShellExtID1, // ID1 �ɂ� lnkid �͂Ȃ�
		&CLSID_ShellExtID2, &CLSID_ShellExtLinkID2,
		&CLSID_ShellExtID3, &CLSID_ShellExtLinkID3,
		&CLSID_ShellExtID4, &CLSID_ShellExtLinkID4,
		NULL };

	for (int i=0; oldiids[i]; i++) {
		TShellExtRegistry	oldReg(*oldiids[i]);
		oldReg.DeleteChildTree(oldReg.clsId);
	}

	if (val != -1) {
		DllRegisterServer();
		SetMenuFlags(val);
	}
	return	TRUE;
}

BOOL WINAPI IsRegistServer(void)
{
	return	TShellExtRegistry().OpenClsKey();
}

/*=========================================================================
	PathArray
=========================================================================*/
PathArray::PathArray(void)
{
	totalLen = num = 0;
	pathArray = NULL;
}

PathArray::~PathArray()
{
	Init();
}

void PathArray::Init(void)
{
	if (pathArray) {
		while (--num >= 0)
			free(pathArray[num]);
		free(pathArray);
		pathArray = NULL;
		totalLen = num = 0;
	}
}

int PathArray::GetMultiPath(void *multi_path, int max_len)
{
	int		total_len = 0;
	void	*FMT_STR	= IS_WINNT_V ? (void *)L"%s\"%s\"" : (void *)"%s\"%s\"";
	void	*SPACE_STR	= IS_WINNT_V ? (void *)L" " : (void *)" ";

	for (int i=0; i < num; i++) {
		if (total_len + strlenV(pathArray[i]) + 4 >= max_len)
			break;
		total_len += wsprintfV((char *)multi_path + total_len * CHAR_LEN_V, FMT_STR, i ? SPACE_STR : "\0", pathArray[i]);
	}
	return	total_len;
}

int PathArray::GetMultiPathLen(void)
{
	return	totalLen + 3 * num + 10;
}

BOOL PathArray::RegisterPath(const void *path)
{
#define MAX_ALLOC	100
	if ((num % MAX_ALLOC) == 0)
		pathArray = (void **)realloc(pathArray, (num + MAX_ALLOC) * sizeof(void *));

	int		len = strlenV(path) + 1;
	pathArray[num] = malloc(len * CHAR_LEN_V);
	memcpy(pathArray[num++], path, len * CHAR_LEN_V);
	totalLen += len;

	return	TRUE;
}

TShellExtRegistry::TShellExtRegistry(REFIID cls_name) : TRegistry(HKEY_CLASSES_ROOT)
{
	GetClsId(cls_name, clsId, sizeof(clsId));
	OpenKey("CLSID");
}

ShellExtSystem::ShellExtSystem(HINSTANCE hI)
{
	if (IS_WINNT_V = IsWinNT()) {
		DragQueryFileV = (UINT (WINAPI *)(HDROP, UINT, void *, UINT))DragQueryFileW;
		SHGetPathFromIDListV = (BOOL (WINAPI *)(LPCITEMIDLIST, void *))::GetProcAddress(::GetModuleHandle("shell32.dll"), "SHGetPathFromIDListW");
		strlenV = (int (*)(const void *))wcslen;
		wsprintfV = (int (WINAPI *)(void *, const void *,...))wsprintfW;
		MakePathV = (int (*)(void *, const void *, const void *))MakePathW;
		EMPTY_STR_V = L"";
		FMT_TOSTR_V = L" /to=\"%s\"";
		CHAR_LEN_V = sizeof(WCHAR);
	}
	else {
		DragQueryFileV = (UINT (WINAPI *)(HDROP, UINT, void *, UINT))DragQueryFileA;
		SHGetPathFromIDListV = (BOOL (WINAPI *)(LPCITEMIDLIST, void *))SHGetPathFromIDList;
		strlenV = (int (*)(const void *))strlen;
		wsprintfV = (int (WINAPI *)(void *, const void *,...))wsprintfA;
		MakePathV = (int (*)(void *, const void *, const void *))MakePath;
		EMPTY_STR_V = "";
		FMT_TOSTR_V = " /to=\"%s\"";
		CHAR_LEN_V = sizeof(char);
	}

	HInstance = hI;
	DllRefCnt = 0;

// GetSystemDefaultLCID() �Ɋ�Â������\�[�X����������O�Ƀ��[�h���Ă���
	LCID	curLcid = ::GetThreadLocale();
	LCID	newLcid = ::GetSystemDefaultLCID();

	if (curLcid != newLcid)
		::SetThreadLocale(newLcid);

	InitInstanceForLoadStr(hI);
	for (UINT id=IDS_RIGHTCOPY; id <= IDS_DDMOVE; id++)
		GetLoadStr(id);

	if (curLcid != newLcid)
		::SetThreadLocale(curLcid);

	char	path[MAX_PATH], *fname = NULL;
	::GetModuleFileName(hI, path, MAX_PATH);
	DllName = strdup(path);
	::GetFullPathName(DllName, MAX_PATH, path, &fname);
	if (fname)
		strcpy(fname, FASTCOPY_EXE);
	ExeName = strdup(path);

	wsprintf(path, "%s\\" FASTCOPY, DllRegKeys[0]);
	MenuFlgRegKey = strdup(path);
}

/*=========================================================================
  ��  �� �F DllMain
  �T  �v �F 
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
int APIENTRY DllMain(HINSTANCE hI, DWORD reason, PVOID)
{
	switch (reason) {
	case DLL_PROCESS_ATTACH:
		if (SysObj == NULL)
			SysObj = new ShellExtSystem(hI);
		return	TRUE;

	case DLL_THREAD_ATTACH:
		return	TRUE;

	case DLL_THREAD_DETACH:
		return	TRUE;

	case DLL_PROCESS_DETACH:
		if (SysObj) {
			delete [] SysObj->ExeName;
			delete SysObj;
			SysObj = NULL;
		}
		return	TRUE;
	}
	return	TRUE;
}


