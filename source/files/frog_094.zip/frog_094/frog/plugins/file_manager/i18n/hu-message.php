<?php

/**
 * this file has been translated by: H.S.Laszlo http://www.bluedesign.hu
 */

return array(

// files
'File' => 'Fájl',
'Size' => 'Méret',
'Permissions' => 'Attribútumok',
'Change mode' => 'Change mode',
'Remove file' => 'Fájl eltávolítása',
'Create new file' => 'Új fájl létrehozása',
'Create new directory' => 'Új könyvtár létrehozása',
'Upload file' => 'Fájl feltöltése',
'Rename' => 'Átnevezés',
'overwrite it?' => 'felülírod?',

);