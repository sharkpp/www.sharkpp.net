<?php

Plugin::setInfos(array(
    'id'          => 'export',
    'title'       => 'Exporter', 
    'description' => 'Export plugin.', 
    'version'     => '1.0', 
    'website'     => 'http://www.sharkpp.net/')
);

Plugin::addController('export', 'Export');

