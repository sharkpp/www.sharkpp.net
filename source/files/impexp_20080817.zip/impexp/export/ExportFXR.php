<?php

class DOMFrogElement extends DOMElement
{
	const FROG_NAMESPACE_URI = 'http://www.madebyfrog.com/namespace/1.0/';

	function appendElement($name, $text = NULL, $namesapceURI = NULL) { 
		return $this->appendChild(new DOMFrogElement($name, $text, $namesapceURI));
	}
	function appendCDATAElement($name, $cdata, $namesapceURI = NULL) { 
		return $this->appendChild(new DOMFrogElement($name, NULL, $namesapceURI))->appendChild(new DOMCDATASection($cdata));
	}
	function appendFrogElement($name, $text = NULL) { 
	//	$f = $this->ownerDocument->createDocumentFragment();
	//	@$f->appendXML("<frog:{$name}/>");
	//	$r = $this->appendChild($f);
	//	if( null != $text ) {
	//		$r->appendChild(new DOMText($text));
	//	}
	//	return $r;
	//	$r = $this->appendChild(new DOMFrogElement('frog:' . $name, $text, self::FROG_NAMESPACE_URI));
	//	$r->removeAttribute('xmlns:frog');
	//	return $r;
		return $this->appendChild(new DOMFrogElement('frog:' . $name, $text, self::FROG_NAMESPACE_URI));
	}
	function appendFrogCDATAElement($name, $cdata) { 
	//	$r = $this->appendChild(new DOMFrogElement('frog:' . $name, NULL, self::FROG_NAMESPACE_URI));
	//	$r->appendChild(new DOMCDATASection($cdata));
	//	$r->removeAttribute('xmlns:frog');
	//	return $r;
		return $this->appendChild(new DOMFrogElement('frog:' . $name, NULL, self::FROG_NAMESPACE_URI))->appendChild(new DOMCDATASection($cdata));
	}
}

class ExportFXR
{
	static protected $layout_table;
	static protected $snippet_table;
	static protected $page_table;
	static protected $page_part_table;

	static protected $users;

	public function __construct()
	{
		self::$layout_table =
			array(
				'id', 'name', 'content_type', '#content', 'created_on', 'updated_on',
				'created_by_id' => create_function('$val', 'return ExportFXR::get_user_name_from_id($val);'),
				'updated_by_id' => create_function('$val', 'return ExportFXR::get_user_name_from_id($val);'),
				'position',
			);

		self::$snippet_table =
			array(
				'id', 'name', 'filter_id', '#content', 'created_on', 'updated_on',
				'created_by_id' => create_function('$val', 'return ExportFXR::get_user_name_from_id($val);'),
				'updated_by_id' => create_function('$val', 'return ExportFXR::get_user_name_from_id($val);'),
				'position',
			);

		self::$page_table =
			array(
				'id', 'parent_id', 'layout_id', 'slug', 'breadcrumb', 'behavior_id', 'status_id',
				'created_on', 'published_on', 'updated_on',
				'created_by_id' => create_function('$val', 'return ExportFXR::get_user_name_from_id($val);'),
				'updated_by_id' => create_function('$val', 'return ExportFXR::get_user_name_from_id($val);'),
				'position', 'is_protected',
			);

		self::$page_part_table =
			array(
				'id', 'name', 'filter_id', '#content'
			);

		self::$users = array();
		foreach(Record::findAllFrom('User') as $user)
		{
			self::$users[$user->id] = $user->username;
		}
	}

	public function export()
	{
		$doc = new DOMDocument('1.0', 'UTF-8');
		$doc->formatOutput = true;

//		$doc->registerNodeClass('DOMElement', 'DOMFrogElement');

		$page    = Page::findOneFrom('Page', 'id=?', array(1));

		$root = $doc->appendChild(new DOMFrogElement('rss'));
			$root->setAttribute('version', '2.0');
			$root->setAttribute('xmlns:content', 'http://purl.org/rss/1.0/modules/content/');
			$root->setAttribute('xmlns:frog', 'http://www.madebyfrog.com/export/1.0/');

		$channel = $root->appendElement('channel');

		$channel->appendElement('title',			$page->title);
		$channel->appendElement('link',				rtrim(URL_PUBLIC, '/'));
		$channel->appendElement('description',		$page->description);

		$channel->appendFrogElement('base_site_url',	rtrim(URL_PUBLIC, '/'));
		$channel->appendFrogElement('export_version',	'1.0');

		self::export_layout($channel);
		self::export_snippet($channel);
		self::export_page($channel);

		$xml = $doc->saveXML();

		header('Content-Disposition: attachment; filename="frog_'.date('Y-m-d').'.xml"');
		header('Content-Type: application/octet-stream');
		header('Content-Transfer-Encoding: binary');
		header('Content-Length: '.strlen($xml));
		print $xml;
		
		return true;
	}

	static private function get_page_url($find_page)
	{
		$url = '';
		$page = $find_page;

		while( !empty($page) && 0 < $page->parent_id )
		{
			if( false === $page ) {
				break;
			}
			$url = '/' . $page->slug . $url;
			$page = Page::findOneFrom('Page', 'id=?', array($page->parent_id));
		}

		if( '' != $find_page->slug ) {
			$url .= URL_SUFFIX;
		} else {
			$url = rtrim($url, '/') . '/';
		}

		return rtrim(URL_PUBLIC, '/') . $url;
	}

	static public function get_user_name_from_id($id)
	{
		return
			isset(self::$users[$id]) ? self::$users[$id]
			                         : '';
	}

	static private function put_value(& $element, $prefix, $obj, & $table)
	{
		$obj_var = get_object_vars($obj);
		foreach($table as $tag => $func)
		{
			if( is_int($tag) )
			{
				$tag = $func;
				$func= null;
			}
			if( '#' == substr($tag, 0, 1) )
			{
				$tag = ltrim($tag, '#');
				$element->appendFrogCDATAElement(
					  $prefix . '_' . $tag
					, is_null($func) ? $obj_var[$tag]
					                 : $func($obj_var[$tag])
					);
			}
			else
			{
				$element->appendFrogElement(
					  $prefix . '_' . $tag
					, is_null($func) ? $obj_var[$tag]
					                 : $func($obj_var[$tag])
					);
			}
		}
		
		return $element;
	}

	static private function export_layout(& $element)
	{
		$layouts  = Layout::findAllFrom('Layout');

		foreach($layouts as $layout)
		{
			self::put_value($element->appendFrogElement('layout'), 'layout', $layout, self::$layout_table);
		}
	}

	static private function export_snippet(& $element)
	{
		$snippets = Snippet::findAllFrom('Snippet');

		foreach($snippets as $snippet)
		{
			self::put_value($element->appendFrogElement('snippet'), 'snippet', $snippet, self::$snippet_table);
		}
	}

	static private function export_page(& $element)
	{
		$pages    = Page::findAllFrom('Page');

		foreach($pages as $page)
		{
			$item = $element->appendElement('item');

			$item->appendElement('title',				$page->title);
			$item->appendElement('link',				self::get_page_url($page));
			$item->appendElement('description',			$page->description);
			$item->appendElement('pubDate',				date("r", strtotime($page->updated_on)));
			$guid = $item->appendElement('guid',		sprintf('%d', $page->id));
				$guid->setAttribute('isPermaLink', 'false');

			self::put_value($item, 'page', $page, self::$page_table);

			$page_parts = Record::findAllFrom('PagePart', 'page_id=? ORDER BY id', array($page->id));
			foreach($page_parts as $page_part)
			{
				if( 'body' == $page_part->name )
				{
					$item->appendCDATAElement('content:encoded',	$page_part->content,	'http://purl.org/rss/1.0/modules/content/');
				}

				self::put_value($item->appendFrogElement('part'), 'part', $page_part, self::$page_part_table);
			}

		}
	}


}

