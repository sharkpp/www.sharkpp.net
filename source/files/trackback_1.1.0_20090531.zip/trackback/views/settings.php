<?php
/*******************************************************************************
  The MIT License

  Copyright (c) 2008-2009 Shark++ Software.

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

 ==============================================================================
  参考として The MIT License の日本語訳を下記に併記しますが、頒布条件としては、
  上記原文に従ってください。
 ==============================================================================

  The MIT License

  Copyright (c) 2008-2009 Shark++ Software.

  以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル
  （以下「ソフトウェア」）の複製を取得するすべての人に対し、ソフトウェアを
  無制限に扱うことを無償で許可します。これには、ソフトウェアの複製を使用、
  複写、変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、
  およびソフトウェアを提供する相手に同じことを許可する権利も無制限に含まれ
  ます。

  上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要
  な部分に記載するものとします。

  ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの
  保証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、
  および権利非侵害についての保証も含みますが、それに限定されるものではあり
  ません。作者または著作権者は、契約行為、不法行為、またはそれ以外であろう
  と、ソフトウェアに起因または関連し、あるいはソフトウェアの使用またはその
  他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も
  負わないものとします。 
 *******************************************************************************/
?>
<h1><?php echo __('Settings'); ?></h1>

<form method="post" action="">
	<table class="fieldset">
		<tr>
			<td class="label"><?php echo __('Auto approve'); ?>:</td>
			<td>
				<select name="auto_approve">
					<option value="1" <?php if( $auto_approve ) echo 'selected="selected"'; ?>><?php echo __('yes'); ?></option>
					<option value="0" <?php if(!$auto_approve ) echo 'selected="selected"'; ?>><?php echo __('no'); ?></option>
				</select>
			</td>
			<td class="help"><?php echo __('"Yes" to choose the back of the truck and received approval to open automatically.'); ?></td>
		</tr>
		<tr>
			<td class="label"><?php echo __('Ping title'); ?>:</td>
			<td><input type="text" name="ping_title" value="<?php echo $ping_title; ?>" size="30" /></td>
			<td class="help"><?php echo __('Specify use blog title in the trackback ping. In the blank here and use the administration title.'); ?></td>
		</tr>
		<tr>
			<td class="label"><?php echo __('Trackbacks per page'); ?>:</td>
			<td><input type="text" name="rows_per_page" value="<?php echo $rows_per_page; ?>" size="10" /></td>
			<td class="help"><?php echo __('Specify the number of trackbacks per page in the backend.'); ?></td>
		</tr>
		<tr>
			<td class="label"><?php echo __('Default status id'); ?>:</td>
			<td>
				<select name="default_status_id">
					<option value="<?php echo Trackback::NONE;   ?>" <?php if( Trackback::NONE == $default_status_id ) echo 'selected="selected"'; ?>>&#8212; <?php echo __('none'); ?> &#8212;</option>
					<option value="<?php echo Trackback::OPEN;   ?>" <?php if( Trackback::OPEN == $default_status_id ) echo 'selected="selected"'; ?>><?php echo __('Open'); ?></option>
					<option value="<?php echo Trackback::CLOSED; ?>" <?php if( Trackback::CLOSED==$default_status_id ) echo 'selected="selected"'; ?>><?php echo __('Closed'); ?></option>
				</select>
			</td>
			<td class="help"><?php echo __('The trackback status is specified in the early adding the page.'); ?></td>
		</tr>
		<tr>
			<td class="label"><?php echo __('Spam block keyword'); ?>:</td>
			<td><input type="text" name="spam_block_keyword" value="<?php echo $spam_block_keyword; ?>" size="10" /></td>
			<td class="help"><?php echo __('The key word to add to track back URL and to defend from the track back spam simply is specified.'); ?></td>
		</tr>
<?php if( version_compare('0.9.4', FROG_VERSION, '<') ): ?>
		<tr>
			<td class="label"><?php echo __('The state is displayed in the tab'); ?>:</td>
			<td>
				<select name="display_count_in_tab">
					<option value="1" <?php if( $display_count_in_tab ) echo 'selected="selected"'; ?>><?php echo __('yes'); ?></option>
					<option value="0" <?php if(!$display_count_in_tab ) echo 'selected="selected"'; ?>><?php echo __('no'); ?></option>
				</select>
			</td>
			<td class="help"><?php echo __('When "Yes" is chosen, the number of the track back and approval waiting is displayed in the tab.'); ?></td>
		</tr>
<?php endif; ?>
	</table>
	<p class="buttons">
<?php if( version_compare(FROG_VERSION, '0.9.4', '<=') ): ?>
		<input type="hidden" value="<?php echo $display_count_in_tab; ?>" name="display_count_in_tab" />
<?php endif; ?>
		<input class="button" type="submit" value="<?php echo __('Save'); ?>" name="commit" />
	</p>
</form>
