<?php if (Dispatcher::getAction() != 'view'): ?>

<div class="box">
<h2><?php echo __('What is this plugin?'); ?></h2>
<p><?php echo __('Downloaded to the local file from Frog CMS pages.
You can pages backup, import to another weblog.'); ?></p>
</div>

<?php endif; ?>
