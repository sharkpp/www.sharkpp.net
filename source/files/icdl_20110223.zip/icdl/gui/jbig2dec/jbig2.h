//  written by sharkpp.

#include "os_types.h"

typedef void* Jbig2Ctx;
typedef void* Jbig2Segment;
typedef void* Jbig2GenericRegionParams;

typedef struct {
	byte*	data;
	int		stride;
	int		width;
	int		height;
} Jbig2Image;
