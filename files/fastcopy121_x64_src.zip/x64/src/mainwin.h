/* static char *fastcopy_id = 
	"@(#)Copyright (C) H.Shirouzu 2004-2005   mainwin.h	Ver1.10"; */
/* ========================================================================
	Project  Name			: Fast Copy file and directory
	Create					: 2004-09-15(Wed)
	Update					: 2005-05-03(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef FASTCOPY_H
#define FASTCOPY_H

#include "fastcopy.h"
#include "cfg.h"
#include "miscdlg.h"

#define FASTCOPY			"FastCopy"
#define FASTCOPY_CLASS		"fastcopy_class"
#define WM_FASTCOPY_END		(WM_USER + 100)
#define WM_FASTCOPY_NOTIFY	(WM_USER + 101)
#define WM_FASTCOPY_HIDDEN	(WM_USER + 102)
#define FASTCOPY_TIMER		100
#define FASTCOPY_NIM_ID		100
#define MAX_HISTORY_BUF		1024

#define SHELLEXT_MIN_ALLOC		(16 * 1024)
#define SHELLEXT_MAX_ALLOC		(4 * 1024 * 1024)

#define MAX_FASTCOPY_ICON	4
class TMainDlg : public TDlg {
protected:
	FastCopy	fastCopy;
	FastCopy::Info	info;
	Cfg			cfg;
	HICON		hMainIcon[MAX_FASTCOPY_ICON];
	enum AutoCloseLevel { NO_CLOSE, NOERR_CLOSE, FORCE_CLOSE } autoCloseLevel;
	BOOL		isTaskTray;

	int			miniHeight;
	int			normalHeight;
	UINT		timerID;
	BOOL		noConfirmDel;
	UINT		curIconIndex;
	UINT		TaskBarCreateMsg;
	SYSTEMTIME	startTm;
	BOOL		isShellExt;
	BOOL		isNetPlaceSrc;
	BOOL		isErrEditHide;
	int			errBufOffset;
	BOOL		isErrLog;
	char		*pathLogBuf;
	HANDLE		hErrLogFile;
	TransInfo	ti;

	TAboutDlg		aboutDlg;
	TSetupDlg		setupDlg;
	TShellExtDlg	shellExtDlg;

protected:
	BOOL	ExecCopy(BOOL cmdLineExec=FALSE);
	BOOL	EndCopy(void);
	BOOL	CancelCopy(void);
	void	SetItemEnable(BOOL is_delete);

public:
	TMainDlg();
	virtual ~TMainDlg();

	virtual BOOL	EvCreate(LPARAM lParam);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvNcDestroy(void);
	virtual BOOL	EvTimer(WPARAM timerID, TIMERPROC proc);
	virtual BOOL	EvSysCommand(WPARAM uCmdType, POINTS pos);
	virtual BOOL	EvDropFiles(HDROP hDrop);
/*
	virtual BOOL	EvEndSession(BOOL nSession, BOOL nLogOut);
	virtual BOOL	EvQueryOpen(void);
	virtual BOOL	EvHotKey(int hotKey);
	virtual BOOL	EventButton(UINT uMsg, int nHitTest, POINTS pos);
	virtual BOOL	EventInitMenu(UINT uMsg, HMENU hMenu, UINT uPos, BOOL fSystemMenu);
*/
	virtual BOOL	EventUser(UINT uMsg, WPARAM wParam, LPARAM lParam);
	BOOL	EnableLogFile(BOOL on);
	BOOL	CommandLineExecV(int argc, void **argv);
	BOOL	SetMiniWindow(void);
	BOOL	SetNormalWindow(void);
	BOOL	SetWindowTitle(char *fmt,...);
	BOOL	IsDestDropFiles(HDROP hDrop);
	BOOL	SetInfo(BOOL is_task_tray=FALSE, BOOL is_finish_status=FALSE);
	void	SetPathHistory(void);
	BOOL	TaskTray(int nimMode, HICON hSetIcon=NULL, LPCSTR tip=NULL);
};

class TFastCopyApp : public TApp {
public:
	TFastCopyApp(HINSTANCE _hI, LPSTR _cmdLine, int _nCmdShow);
	virtual ~TFastCopyApp();

	virtual void	InitWindow(void);
};

class TBrowseDirDlgV : public TSubClass
{
protected:
	void	*fileBuf;
	BOOL	dirtyFlg;

public:
	TBrowseDirDlgV(void *_fileBuf) { fileBuf = _fileBuf; }
	virtual BOOL	CreateByWnd(HWND _hWnd);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	SetFileBuf(LPARAM list);
	BOOL	IsDirty(void) { return dirtyFlg; };
	BOOL	GetParentDirV(void *srcfile, void *dir);
	static int CALLBACK BrowseDirDlg_Proc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM data);
};

#define BRDIR_QUOTE		0x0001
#define BRDIR_VQUOTE	0x0002
#define BRDIR_BACKSLASH	0x0004
BOOL BrowseDirDlgV(TWin *parentWin, UINT editCtl, void *title, int flg=0);

class TInputDlgV : public TDlg
{
protected:
	void	*dirBuf;

public:
	TInputDlgV(void *_dirBuf, TWin *_win) : TDlg(INPUT_DIALOG, _win) { dirBuf = _dirBuf; }
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
};

const char *GetVersionStr(void);

#endif

