static char *tmisc_id = 
	"@(#)Copyright (C) H.Shirouzu 1996-2005   tmisc.cpp	Ver1.00";
/* ========================================================================
	Project  Name			: Win32 Lightweight  Class Library Test
	Module Name				: Application Frame Class
	Create					: 1996-06-01(Sat)
	Update					: 2005-11-28(Mon)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "tlib.h"

#include <stdio.h>
#include <mbstring.h>
#include <stdlib.h>

struct TResHashObj {
	TResHashObj	*prior;
	TResHashObj	*next;
	UINT		resId;
	void		*val;
	TResHashObj(UINT _resId, void *_val=NULL) { prior = next = NULL; resId = _resId; val = _val; }
};

class TResHash {
protected:
	int			hashNum;
	TResHashObj	**hashTbl;

public:
	TResHash(int _hashNum);
	BOOL		Regist(TResHashObj *);
	TResHashObj	*Search(UINT id);
};

TResHash::TResHash(int _hashNum)
{
	hashNum = _hashNum;
	hashTbl = new TResHashObj *[hashNum];
	memset(hashTbl, 0, sizeof(TResHashObj *) * hashNum);
}

BOOL TResHash::Regist(TResHashObj *target)
{
	TResHashObj **obj;

	for (obj = &hashTbl[target->resId % hashNum]; *obj; obj=&(*obj)->next)
		;
	*obj = target;
	return	TRUE;
}

TResHashObj *TResHash::Search(UINT resId)
{
	for (TResHashObj *obj = hashTbl[resId % hashNum]; obj; obj=obj->next) {
		if (obj->resId == resId)
			return	obj;
	}
	return	NULL;
}

static HINSTANCE defaultInstance;

void InitInstanceForLoadStr(HINSTANCE hI)
{
	defaultInstance = hI;
}

LPSTR GetLoadStrA(UINT resId, HINSTANCE hI)
{
	static TResHash	*hash;

	if (hash == NULL) {
		hash = new TResHash(100);
	}

	char		buf[1024];
	TResHashObj	*obj;

	if ((obj = hash->Search(resId)) == NULL) {
		if (::LoadStringA(hI ? hI : defaultInstance, resId, buf, sizeof(buf)) >= 0) {
			obj = new TResHashObj(resId, strdup(buf));
			hash->Regist(obj);
		}
	}
	return	obj ? (char *)obj->val : NULL;
}

LPWSTR GetLoadStrW(UINT resId, HINSTANCE hI)
{
	static TResHash	*hash;

	if (hash == NULL) {
		hash = new TResHash(100);
	}

	WCHAR		buf[1024];
	TResHashObj	*obj;

	if ((obj = hash->Search(resId)) == NULL) {
		if (::LoadStringW(hI ? hI : defaultInstance, resId, buf, sizeof(buf) / sizeof(WCHAR)) >= 0) {
			obj = new TResHashObj(resId, wcsdup(buf));
			hash->Regist(obj);
		}
	}
	return	obj ? (LPWSTR)obj->val : NULL;
}

static LCID defaultLCID;

void TSetDefaultLCID(LCID lcid)
{
	defaultLCID = lcid ? lcid : ::GetSystemDefaultLCID();
	::SetThreadLocale(defaultLCID);
}

HMODULE TLoadLibrary(LPTSTR dllname)
{
	HMODULE	hModule = ::LoadLibrary(dllname);

	if (defaultLCID)
		::SetThreadLocale(defaultLCID);

	return	hModule;
}

/*=========================================================================
	�p�X�����iANSI �Łj
=========================================================================*/
int MakePath(char *dest, const char *dir, const char *file)
{
	BOOL	separetor = TRUE;
	int		len;

	if ((len = strlen(dir)) == 0)
		return	wsprintf(dest, "%s", file);

	if (dir[len -1] == '\\')	// �\�ȂǁA2byte�ڂ�'\\'�ŏI�镶����΍�
	{
		if (len >= 2 && IsDBCSLeadByte(dir[len -2]) == FALSE)
			separetor = FALSE;
		else {
			for (u_char *p=(u_char *)dir; *p && p[1]; IsDBCSLeadByte(*p) ? p+=2 : p++)
				;
			if (*p == '\\')
				separetor = FALSE;
		}
	}
	return	wsprintf(dest, "%s%s%s", dir, separetor ? "\\" : "", file);
}

/*=========================================================================
	�p�X�����iUNICODE �Łj
=========================================================================*/
int MakePathW(WCHAR *dest, const WCHAR *dir, const WCHAR *file)
{
	int		len;

	if ((len = wcslen(dir)) == 0)
		return	wsprintfW(dest, L"%s", file);

	return	wsprintfW(dest, L"%s%s%s", dir, dir[len -1] == L'\\' ? L"" : L"\\" , file);
}

WCHAR lGetCharIncW(const WCHAR **str)
{
	return	*(*str)++;
}

WCHAR lGetCharIncA(const char **str)
{
	WCHAR	ch = *(*str)++;

	if (IsDBCSLeadByte((BYTE)ch)) {
		ch <<= BITS_OF_BYTE;
		ch |= *(*str)++;	// null ����͎蔲��
	}
	return	ch;
}

WCHAR lGetCharW(const WCHAR *str, int offset)
{
	return	str[offset];
}

WCHAR lGetCharA(const char *str, int offset)
{
	while (offset-- > 0)
		lGetCharIncA(&str);

	return	lGetCharIncA(&str);
}

void lSetCharW(WCHAR *str, int offset, WCHAR ch)
{
	str[offset] = ch;
}

void lSetCharA(char *str, int offset, WCHAR ch)
{
	while (offset-- > 0) {
		if (IsDBCSLeadByte(*str++))
			*str++;
	}

	BYTE	high_ch = ch >> BITS_OF_BYTE;

	if (high_ch)
		*str++ = high_ch;
	*str = (BYTE)ch;
}

