<?php

/*******************************************************************************
  The MIT License

  Copyright (c) 2009 Shark++ Software/sharkpp.

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

 ==============================================================================
  参考として The MIT License の日本語訳を下記に併記しますが、頒布条件としては、
  上記原文に従ってください。
 ==============================================================================

  The MIT License

  Copyright (c) 2009 Shark++ Software/sharkpp.

  以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル
  （以下「ソフトウェア」）の複製を取得するすべての人に対し、ソフトウェアを
  無制限に扱うことを無償で許可します。これには、ソフトウェアの複製を使用、
  複写、変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、
  およびソフトウェアを提供する相手に同じことを許可する権利も無制限に含まれ
  ます。

  上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要
  な部分に記載するものとします。

  ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの
  保証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、
  および権利非侵害についての保証も含みますが、それに限定されるものではあり
  ません。作者または著作権者は、契約行為、不法行為、またはそれ以外であろう
  と、ソフトウェアに起因または関連し、あるいはソフトウェアの使用またはその
  他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も
  負わないものとします。 
 *******************************************************************************/

include 'uuid.php';

class svn_dump
{
	const SVN_DUMP_FILE_SIGNATURE = "SVN-fs-dump-format-version: 2\n";

	const DATE_ISO8601 = 'Y-m-d\TH:i:s.000000\Z';

	// プロパティーを出力
	private static function puts_svn_dump_props($props)
	{
		$r = '';
		foreach($props as $key => $value)
		{
			$r .= sprintf("K %d\n%s\nV %d\n%s\n"
						, strlen($key), $key
						, strlen($value), $value
					);
		}
		return $r . "PROPS-END\n";
	}

	// リビジョン内ノードを出力
	private static function puts_svn_dump_node($node)
	{
		$r  = "\n";
		$r .= sprintf("Node-path: %s\n", $node['node-path']);
		if( 'delete' == $node['node-action'] )
		{
			$r .= sprintf("Node-action: %s\n", $node['node-action']);
		}
		else
		{
			$r .= sprintf("Node-kind: %s\n", $node['node-kind']);
			$r .= sprintf("Node-action: %s\n", $node['node-action']);
			$props        = self::puts_svn_dump_props($node['props']);
			$props_length = 0;
			if( 'change' != $node['node-action'] ||
			    !empty($node['props']) )
			{
				$props_length = strlen($props);
				$r .= sprintf("Prop-content-length: %d\n", $props_length );
			}
			$text_content = '';
			if( 'file' == $node['node-kind'] &&
			    'delete' != $node['node-action'] )
			{
				$text_content = file_get_contents($node['contents_path']);
			}
			$text_content_length = strlen($text_content);
			if( !empty($text_content) ) {
				$r .= sprintf("Text-content-length: %d\n", $text_content_length );
				$r .= sprintf("Text-content-md5: %s\n", md5($text_content) );
			}
			$r .= sprintf("Content-length: %d\n\n", $props_length + $text_content_length );
			if( 'change' != $node['node-action'] ||
			    !empty($node['props']) )
			{
				$r .= $props;
			}
			$r .= $text_content;
		}
		$r .= "\n";

		return $r;
	}

	// リビジョンを出力
	public function puts($dump, & $revision = 0)
	{
		if( 0 == $revision )
		{
			echo self::SVN_DUMP_FILE_SIGNATURE . "\n";
			echo sprintf("UUID: %s\n\n", uuid() );
		}

		if( $revision < 1 )
		{
		//	$tmp = preg_split('/[-T:+]/', $dump[0]['props']['svn:date']);
		//	array_walk($tmp, create_function('&$v,$k', '$v = intval($v);'));
		//	$tmp = date(DATE_ISO8601, mktime($tmp[3],$tmp[4],$tmp[5],$tmp[1],$tmp[2],$tmp[0])-1);
		//	array_unshift($dump, array( 'props' => array( 'svn:date' => $tmp ) ));
			array_unshift($dump, array( 'props' => array( 'svn:date' => $dump[0]['props']['svn:date'] ) ));
		}

		foreach($dump as $revision_data)
		{
			$props = self::puts_svn_dump_props($revision_data['props']);
			echo sprintf("Revision-number: %d\n", $revision );
			echo sprintf("Prop-content-length: %d\n", strlen($props) );
			echo sprintf("Content-length: %d\n\n", strlen($props) );
			echo $props;
			if( array_key_exists('nodes', $revision_data) )
			{
				foreach($revision_data['nodes'] as $node)
				{
					echo self::puts_svn_dump_node($node);
				}
			}
			$revision++;
		}
	}
}

// ディレクトリを再帰的に検索しファイル・ディレクトリをリストアップ
function ls_recursive($dir, $include_mask = '/.*/', $exclude_mask = '/^$/')
{
	$r = array();
	if( is_dir($dir) ) {
		$r[] = $dir;
		if( $dh = opendir($dir) ) {
			while( ($name = readdir($dh)) !== false ) {
				if( '.' != $name && '..' != $name && 
				    preg_match($include_mask, $name) &&
				    !preg_match($exclude_mask, $name) )
				{
					$path = $dir . $name;
					if( is_dir($path) ) {
						$r = array_merge($r, ls_recursive($path . '/', $include_mask, $exclude_mask));
					} else {
						$r[] = $path;
					}
				}
			}
			closedir($dh);
		}
	}
	return $r;
}

// 対象のディレクトリを取得
function get_buckup_dirs($base_dir)
{
	$r = array();
	if( is_dir($base_dir) ) {
		if( $dh = opendir($base_dir) ) {
			while( ($name = readdir($dh)) !== false ) {
				if( '.' != $name && '..' != $name ) {
					$path = $base_dir . $name;
					if( is_dir($path) ) {
						$r[] = $path . '/';
					}
				}
			}
			closedir($dh);
		}
	}
	return $r;
}

// 引数解析
function get_option($argc, $argv, $option)
{
//	$r = array_combine(array_keys($option), array_fill(0, count($option), null));
	$r = array();
	foreach($option as $key => $optinfo)
	{
		$r[$key]
			= array_key_exists('default', $optinfo)
				? $optinfo['default']
				: null;
	}
	//
	array_push($argv, null);
	array_push($argv, null);
	$cmd_name = array_shift($argv);
	while( null !== ($arg = array_shift($argv)) )
	{
		foreach($option as $key => $optinfo)
		{
			if( array_key_exists('argument', $optinfo) )
			{
				foreach($optinfo['argument'] as $opt)
				{
					if( preg_match('/^((-+).+?)(:*)$/', $opt, $m) )
					{
						$long_opt = 1 < strlen($m[2]);
						$arg_opt  = $m[1];
						$arg_req  = strlen($m[3]);
						if( $long_opt )
						{
							$pattern = '(' . $arg_opt . ')';
							switch( $arg_req ) {
								case 0: $pattern .= '()()'; break;
								case 1: $pattern .= '(=)(.+)'; break;
								case 2: $pattern .= '(=?)(.*?)'; break;
							}
							if( preg_match('/^' . $pattern . '$/', $arg, $m) &&
							    (0 == $arg_req ||
							    (1 == $arg_req && '' == $m[2] && '' == $m[3]) ||
							     '=' == $m[2]  && '' != $m[3]) )
							{
								$arg_val = $m[3];
								$r[$key] = 0 < $arg_req ? $arg_val : true;
							}
						}
						else
						{
							$pattern = $arg_opt;
							if( preg_match('/^' . $pattern . '$/', $arg, $m) )
							{
								if( 0 < $arg_req )
								{
									$arg_val = array_shift($argv);
									if( null == $arg_val )
									{
										break 3;
									}
								}
								$r[$key] = 0 < $arg_req ? $arg_val : true;
							}
						}
					}
				}
			}
			else if( '-' != substr($arg, 0, 1) )
			{
				$r[$key] = $arg;
				unset($optinfo, $key);
				break;
			}
		}
	}
	if( false !== array_search(null, $r, true) )
	{
		$options   = '';
		$arguments = '';
		$arguments2= '';
		foreach($option as $key => $optinfo)
		{
			if( array_key_exists('argument', $optinfo) )
			{
				$tmp = '';
				foreach($optinfo['argument'] as $opt)
				{
					if( preg_match('/^((-+).+?)(:*)$/', $opt, $m) )
					{
						$long_opt = 1 < strlen($m[2]);
						$arg_opt  = $m[1];
						$arg_req  = strlen($m[3]);
						$tmp .= (!empty($tmp) ? ', ' : '') . $arg_opt;
						$tmp .= (!$arg_req ? ''
						                   : (($long_opt ? '=' : ' ') .
						                     (array_key_exists('parameter', $optinfo) ? $optinfo['parameter']
						                                                              : 'parameter')));
					}
				}
				$options .= sprintf("  %s\n",   $tmp);
				$options .= sprintf("    %s\n", $optinfo['description']);
			}
			else
			{
				$arguments2.= (!empty($arguments2) ? ' ' : '') . $key;
				$arguments .= sprintf("  %s\n",   $key);
				$arguments .= sprintf("    %s\n", $optinfo['description']);
			}
		}
		$tmp = "usage: " . basename($cmd_name);
		if( !empty($options) )
			$tmp .= " [options]";
		if( !empty($arguments2) )
			$tmp .= " " . $arguments2;
		$tmp .= "\n\n";
		if( !empty($options) )
			$tmp .= "Options:\n" . $options;
		if( !empty($arguments) )
			$tmp .= "Arguments:\n" . $arguments;
		echo $tmp;
		return false;
	}
	return $r;
}

// ディレクトリパスの正規化
function normalize_dir_path($path)
{
	return rtrim(preg_replace('|[/\\\]+|', '/', $path), '/') . '/';
}

//-----------------------------------------------------------------------------
// プログラムメイン
//-----------------------------------------------------------------------------

date_default_timezone_set('UTC');

// Windowsなら取り敢えずSJISにしておき、
// その他ならUTF-8
mb_http_output(isset($_SERVER['windir']) ? 'SJIS' : 'UTF-8');
ob_start("mb_output_handler");

// 引数解析
$args = get_option($argc, $argv,
				array(
					'author' =>
						array(
							'argument'    => array( '--author:', '-a:' ),
							'default'     => 'test',
							'parameter'   => 'AUTHOR_NAME',
							'description' => '作者名。省略時は "test"。',
						),
					'repos_path' =>
						array(
							'argument'    => array( '--repos-path:', '-r:' ),
							'default'     => '',
							'parameter'   => 'REPOS_PATH',
							'description' => '収納先レポジトリパス。',
						),
					'target' =>
						array(
							'description' => 'ターゲットのバックアップフォルダを指定。',
						),
				));
if( false === $args )
{
	exit(1);
}

ob_end_flush();

// メイン処理

$repos_snapshot = array();
$revision = 0;

$base_dir  = normalize_dir_path($args['target']);
$repos_dir = normalize_dir_path('/' . (empty($args['repos_path']) ? basename($base_dir) : $args['repos_path']));
$svn_author= $args['author'];

$invalid_time = date(svn_dump::DATE_ISO8601, 0);
$mtime_last = $invalid_time;

$path = '';
$tmp = explode('/', trim($repos_dir, '/'));
array_pop($tmp);
if( !empty($tmp) )
{
	$predump = array(
			'props' => array(
					'svn:log'    => '',
					'svn:author' => $svn_author,
					'svn:date'   => $mtime_last,
				),
			'nodes' => array(),
		);
	foreach($tmp as $repos_path)
	{
		$path .= $repos_path;
		$predump['nodes'][] = array(
				'node-path'   => $path,
				'node-kind'   => 'dir',
				'node-action' => 'add',
				'props'       => array(),
			);
		$path .= '/';
	}
}

foreach(get_buckup_dirs($base_dir) as $dir)
{
	$r = ls_recursive($dir, '/.*/', '/(\.(exe|obj|res|exp|lib|log)$)|(^@$)/i');
//	print_r($r);
	$snapshot = array();
	$snapshot_as_mtime = array();
	foreach($r as $path)
	{
		$isdir = is_dir($path);
	//	$mtime = $isdir ? $invalid_time : date(svn_dump::DATE_ISO8601, filemtime($path));
		$mtime = date(svn_dump::DATE_ISO8601, filemtime($path));
		$snapshot[$path]
			= array(
				'type' => $isdir ? 'dir' : 'file',
				'_path'=> $path,
				'path' => trim($repos_dir . substr($path, strlen($dir)), '/'),
				'mtime'=> $mtime,
				'md5'  => $isdir ? str_pad('', 32, ' ') : md5_file($path),
			);
		if( !$isdir && $mtime_last < $mtime )
		{
			$mtime_last = $mtime;
		}
	}

	$delete_repos_paths = array_flip(array_keys($repos_snapshot));
	$svn_actions = array();
	ksort($snapshot);
	foreach($snapshot as $path => $snapshot_info)
	{
		$repos_path = $snapshot_info['path'];
		if( array_key_exists($repos_path, $delete_repos_paths) )
		{
			unset($delete_repos_paths[$repos_path]);
		}
		if( !array_key_exists($repos_path, $repos_snapshot) )
		{
			$repos_snapshot[ $repos_path ] = $snapshot_info;
			$svn_actions[]
				= array_merge(array('action' => 'add'), $snapshot_info);
		}
		else
		{
			if( //0 < strcasecmp($mtime, $repos_snapshot[ $repos_path ]['mtime']) &&
				$snapshot_info['md5'] != $repos_snapshot[ $repos_path ]['md5'] &&
				'dir' != $repos_snapshot[ $repos_path ]['type'] )
			{
				$repos_snapshot[ $repos_path ] = $snapshot_info;
				$svn_actions[]
					= array_merge(array('action' => 'change'), $snapshot_info);
			}
		}
	}

	if( !empty($delete_repos_paths) )
	{
		foreach($delete_repos_paths as $repos_path => $tmp)
		{
			$svn_actions[]
				= array_merge(array('action' => 'delete'), $repos_snapshot[ $repos_path ]);
		}
	}

	if( !empty($svn_actions) )
	{
		$dump = array(
				'props' => array(
						'svn:log'    => mb_convert_encoding(file_exists($dir.'/@')?file_get_contents($dir.'/@'):'', 'UTF-8','auto'),
						'svn:author' => $svn_author,
						'svn:date'   => $mtime_last,
					),
				'nodes' => array(),
			);
		foreach($svn_actions as $action)
		{
			$dump['nodes'][] = array(
					'node-path'   => $action['path'],
					'node-kind'   => $action['type'],
					'node-action' => $action['action'],
					'props'       => array(),
					'contents_path'=>$action['_path'],
				);
		}
		if( !empty($predump) ) {
			$predump['props']['svn:date'] = $mtime_last;
			svn_dump::puts(array($predump, $dump), $revision);
			$predump = array();
		} else {
			svn_dump::puts(array($dump), $revision);
		}
	}
}

exit;

?>