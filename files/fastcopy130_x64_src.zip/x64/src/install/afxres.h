#include <windows.h>
#include <winver.h>
#include <mfc/winres.h>
