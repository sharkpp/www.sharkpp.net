<?php

/*******************************************************************************
  The MIT License

  Copyright (c) 2008-2009 Shark++ Software.

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

 ==============================================================================
  参考として The MIT License の日本語訳を下記に併記しますが、頒布条件としては、
  上記原文に従ってください。
 ==============================================================================

  The MIT License

  Copyright (c) 2008-2009 Shark++ Software.

  以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル
  （以下「ソフトウェア」）の複製を取得するすべての人に対し、ソフトウェアを
  無制限に扱うことを無償で許可します。これには、ソフトウェアの複製を使用、
  複写、変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、
  およびソフトウェアを提供する相手に同じことを許可する権利も無制限に含まれ
  ます。

  上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要
  な部分に記載するものとします。

  ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの
  保証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、
  および権利非侵害についての保証も含みますが、それに限定されるものではあり
  ません。作者または著作権者は、契約行為、不法行為、またはそれ以外であろう
  と、ソフトウェアに起因または関連し、あるいはソフトウェアの使用またはその
  他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も
  負わないものとします。 
 *******************************************************************************/

require_once dirname(__FILE__).'/Services/Trackback.php';

//////////////////////////////////////////////////////////////////////
// クラス登録
AutoLoader::addFile('Trackback', CORE_ROOT.'/plugins/trackback/Trackback.php');

//////////////////////////////////////////////////////////////////////
// イベント監視登録

Observer::observe('view_page_edit_plugins',  'trackback_insert_ui');
Observer::observe('page_add_after_save',     'trackback_send_ping');
Observer::observe('page_edit_after_save',    'trackback_send_ping');
Observer::observe('view_backend_list_plugin','trackback_view_backend_list_plugin');

//////////////////////////////////////////////////////////////////////
// バックエンドで使用される関数郡

// フロントエンドで使用されるURLを取得
function get_frontend_page_url(& $page)
{
	// URLを取得
	$url = '';
	$cur_page = $page;
	while( !empty($cur_page) && 0 < $cur_page->parent_id )
	{
		if( false === $cur_page ) {
			break;
		}
	//	$url = '/' . $cur_page->slug . '[' . $cur_page->behavior_id . ']' . $url;
		$slug = $cur_page->slug;
		// フロントエンドのBehaviorをシュミレーション
		// フロントエンドで使用されるURLを
		if( '' != $cur_page->behavior_id )
		{
			switch($cur_page->behavior_id)
			{
			case 'archive':
				// 参考:PageArchive::setUrl() in archive/archive.php
				list(,$child_page_slug,) = explode('/', $url);
				$child_page = Page::findOneFrom('Page', 'parent_id=? AND slug=?', array($cur_page->id, $child_page_slug));
				$slug .= date('/Y/m/d/', strtotime($child_page->created_on));
				break;
			}
		}
		$url = '/' . trim($slug, '/') . $url;
		$cur_page = Page::findOneFrom('Page', 'id=?', array($cur_page->parent_id));
	}
	if( '' != $page->slug ) {
		$url .= URL_SUFFIX;
	} else {
		$url = rtrim($url, '/') . '/';
	}
	$url = rtrim(URL_PUBLIC, '/') . $url;
	
	return $url;
}

// UIを画面に追加
function trackback_insert_ui(& $page)
{
	if( !isset($page->trackback_status) ) {
		$page->trackback_status = PluginTrackback::getSetting('default_status_id');
	}
	// トラックバックステータス

	echo '
	<p><label for="page_trackback_status">'.__('Trackbacks').'</label>
	   <select id="page_trackback_status" name="page[trackback_status]">
	     <option value="'.Trackback::NONE  .'"'.($page->trackback_status == Trackback::NONE   ? ' selected="selected"': '').'>&#8212; '.__('none').' &#8212;</option>
	     <option value="'.Trackback::OPEN  .'"'.($page->trackback_status == Trackback::OPEN   ? ' selected="selected"': '').'>'.__('Open').'</option>
	     <option value="'.Trackback::CLOSED.'"'.($page->trackback_status == Trackback::CLOSED ? ' selected="selected"': '').'>'.__('Closed').'</option>
	   </select>
	</p>';
	// トラックバックピング
	echo '
	<script type="text/javascript">
	  Event.observe(window, "load", function()
	    {
	      var elmLabel = document.createElement("label");
	        elmLabel.htmlFor = "trackback_ping_url";
	        elmLabel.appendChild(document.createTextNode("'.__('Trackbacks').'"));
	      var elmText = document.createElement("textarea");
	        elmText.id = "trackback_ping_url";
	        elmText.name = "trackback_ping_url";
	        elmText.cols = "40";
	        elmText.rows = "3";
	        elmText.style.cssText = "width: 100%; height: 3em";
	      var elmBase = document.createElement("p");
	        elmBase.style.cssText = "width: 100%; margin-right: 0";
	        elmBase.appendChild(elmLabel);
	        elmBase.appendChild(elmText);
	      var elmRow = document.createElement("div");
	        elmRow.className = "row";
	        elmRow.appendChild(elmBase);
	        elmRow.style.cssText = "width: 100%;";
	      var elmPrevRow = document.getElementById("page_trackback_status").parentNode.parentNode;
	      var elmForm = elmPrevRow.parentNode;
	      // Insert after
	      elmForm.insertBefore(elmRow, elmPrevRow.nextSibling);
	    }, false);
	</script>
	';
}

// トラックバックの送信
function trackback_send_ping(& $page)
{
	$url = get_frontend_page_url($page);
//	$url = $page->url();

	// Part['body'] を取得
	$part_body = PagePart::findOneFrom('PagePart', 'page_id=? and name=?', array($page->id, 'body'));

	// PINGを送信
	if( isset($_POST['trackback_ping_url']) )
	{
		$error = '';

		// PINGの送り先の一覧を取得
		$ping_list = array_filter(
						array_unique(
							explode("\n", 
								str_replace("\r", "\n", str_replace("\r\n", "\n", 
									$_POST['trackback_ping_url']
							))))
						, create_function('$v', 'return preg_match("|^http://.+|", $v);'));

		// Services_Trackbackオブジェクトの生成
		$trackback = new Services_Trackback();

		// 各送信トラックバック情報を設定
		$trackback->set('title',			$page->title);
		$trackback->set('url',				$url);
		$trackback->set('excerpt',			empty($part_body->content_html) ? ' ' : $part_body->content_html);
		$trackback->set('blog_name',		PluginTrackback::getSetting('ping_title'));
	//	$trackback->set('trackback_url',	$ping);
		$trackback->set('host',				$_SERVER['SERVER_ADDR']);

		// 全ての送信先の送信
		foreach($ping_list as $ping)
		{
			$result = $trackback->send(array('trackback_url' => $ping));
			if (PEAR::isError($result)) {
				$error .= (empty($error) ? '' : '<br>') . 'PING:&lt;' . $ping . '&gt; ' . $result->getMessage();
			}
		}

		// エラーがあれば表示して中断
		if( !empty($error) )
		{
			Flash::set('error', $error);
			redirect(get_url('page/edit/'.$page->id));
		}
	}
}

// プラグインタブの設定要求
function trackback_view_backend_list_plugin(& $plugin_name, & $plugin)
{
	if( $plugin_name != PluginTrackback::PLUGIN_ID ||
	    !(bool)PluginTrackback::getSetting('display_count_in_tab') ) {
		return;
	}
	$plugin->label = 
		__('Trackbacks')
		. sprintf(" (%d/%d)"
			, Trackback::count('is_approved=?', array(0))
			, Trackback::count('is_approved=?', array(1)) );
}

