<h1><?php echo __('Import'); ?></h1>

<div class="form-area">
<div id="tab-control-import" class="tab_control">
  <div id="tabs-import" class="tabs">
    <div id="tab-import-toolbar" class="tab_toolbar">&nbsp;</div>
  </div>
  <div id="import-pages" class="pages">
    <!-- Frog eXtended RSS pmport tab page -->
    <div id="fxr-page" class="page" title="<?php echo __('Frog eXtended RSS'); ?>">
      <form action="<?php echo get_url('plugin/import/fxr'); ?>" method="post" enctype="multipart/form-data">
        <table class="fieldset" cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td class="label"><label for="import_file"><?php echo __('Import file'); ?></label></td>
            <td class="field">
              <input id="import_path" name="import[path]" type="hidden" value="" />
              <input id="import_file" name="import_file" type="file" />
            </td>
            <td class="help">&nbsp;</td>
          </tr>
        </table>
        <p class="buttons">
          <input class="button" name="commit" type="submit" accesskey="s" value="<?php echo __('Import'); ?>" />
        </p>
      </form>
    </div>
    <!-- YAML pmport tab page -->
    <div id="yaml-page" class="page" title="<?php echo __('YAML'); ?>">
      <form action="<?php echo get_url('plugin/import/yaml'); ?>" method="post" enctype="multipart/form-data">
        <table class="fieldset" cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td class="label"><label for="setting_admin_title"><?php echo __('Import file'); ?></label></td>
            <td class="field">
              <input id="import_path" name="import[path]" type="hidden" value="" />
              <input id="import_file" name="import_file" type="file" />
            </td>
            <td class="help">&nbsp;</td>
          </tr>
        </table>
        <p class="buttons">
          <input class="button" name="commit" type="submit" accesskey="s" value="<?php echo __('Import'); ?>" />
        </p>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
  var tabControlMeta = new TabControl('tab-control-import');
  $('import-pages').childElements().each(function(item) {
        tabControlMeta.addTab('tab-'+item.id, item.title, item.id);
      });
  tabControlMeta.select(tabControlMeta.firstTab());
</script>
</div>

<?php
echo Flash::get('log');
?>
