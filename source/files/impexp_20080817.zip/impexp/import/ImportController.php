<?php

// �g�����U�N�V�����������T�|�[�g����Page�N���X
class TransactionPage extends Page
{
    public static function beginTransaction() { return self::$__CONN__->beginTransaction(); }

    public static function commit() { return self::$__CONN__->commit(); }

    public static function rollBack() { return self::$__CONN__->rollBack(); }
}

function get_declared_classes_puts($class_list, $level = 0)
{
	$r = '';
	foreach($class_list as $class => $child) {
		$r .= str_replace(' ', "\t", str_pad('', $level, ' ')) . $class . "\n";
		$r .= get_declared_classes_puts($child, $level + 1);
	}
	return $r;
}
function get_declared_classes_()
{
	$classes_list = get_declared_classes();
	$result = array();
	foreach($classes_list as $class) {
		$class_tree = array();
		for($parent_class = $class; false !== $parent_class; $parent_class = get_parent_class($parent_class)) {
			array_unshift($class_tree, $parent_class);
		}
		$p = & $result;
		foreach( $class_tree as $class ) {
			if( !isset($p[$class]) ) {
				$p[$class] = array();
			}
			$p = & $p[$class];
		}
	}
	return get_declared_classes_puts($result);
}

// �C���|�[�g�R���g���[���N���X
class ImportController extends PluginController
{
	// Constructer
	public function __construct()
	{
		AuthUser::load();
		if ( ! AuthUser::isLoggedIn())
			redirect(get_url('login'));

		$this->setLayout('backend');
		$this->assignToLayout('sidebar', new View('../../../plugins/import/views/sidebar'));

//file_put_contents(dirname(__FILE__) . '/a.txt', print_r(get_declared_classes_(), true));
	}

	// Plugin view main
	public function index()
	{
	//	  $this->browse();
		$this->display('import/views/index', array());
	}

	// Import core
	private function import_core($controller_class)
	{
		//echo Dispatcher::getAction();

		$data = $_POST['import'];
		$path = str_replace('..', '', $data['path']);
		$local_path = $_FILES['import_file']['tmp_name'];

		if (isset($_FILES))
		{
			$log   = '';
			if( file_exists($local_path) )
			{
				if( UPLOAD_ERR_OK == $_FILES['import_file']['error'] )
				{
					include( dirname(__FILE__) . '/' . $controller_class . '.php' );
					$controller = new $controller_class;

					TransactionPage::beginTransaction();

					if( $controller->import($local_path) )
					{
						Flash::set('success', __('Import successed!'));
						TransactionPage::commit();
					}
					else
					{
						TransactionPage::rollBack();
					}
					$log = $controller->getLog();
				}
				else
				{
					Flash::set('error', __('File has not been imported!'));
				}
				unlink($local_path);
			}
			else
			{
				Flash::set('error', __('File has not been imported!'));
			}
			if( DEBUG ) {
				Flash::set('log', Flash::get('log') . $log);
			}
		}
		redirect(get_url('plugin/import'));
	}

	// Import from yaml
	public function yaml()
	{
		$this->import_core('ImportYAML');
	}

	// Import from Frog eXtended RSS
	public function fxr()
	{
		$this->import_core('ImportFXR');
	}

} // end ConvertController class

