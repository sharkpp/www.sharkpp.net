// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

// Buffer.cpp: CBuffer �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "Buffer.h"

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CBuffer::CBuffer()
{
	m_pFirst = NULL;
	m_ppLast = &m_pFirst;
	m_read = 0;
	m_length = 0;
}

CBuffer::~CBuffer()
{
	Destroy();
}

int CBuffer::Count()
{
	return m_length;
}

BOOL CBuffer::Destroy()
{
	BinData *p = m_pFirst;
	BinData *next;

	while( p != NULL ) {
		next = p->next;
		delete [] p->pt;
		delete p;
		p = next;
	}

	m_pFirst = NULL;
	m_ppLast = &m_pFirst;
	m_read = 0;
	m_length = 0;

	return FALSE;
}

BOOL CBuffer::Write(LPVOID pt, int len)
{
	BinData **pp = m_ppLast;
	BinData *n;

	if (len <= 0) return TRUE;

	n = new BinData;
	n->next = NULL;
	n->len = len;
	n->pt = new char[len];
	memcpy(n->pt, pt, len);
	*pp = n;
	m_ppLast = &n->next;

	m_length+=len;
	return FALSE;
}

int CBuffer::Read(LPVOID buf, int nMax)
{
	BinData *next;
	int read = nMax, left;

	if (nMax <= 0)
		return 0;

	while( read > 0 && m_pFirst != NULL ) {
		left = m_pFirst->len - m_read;
		if ( read < left ) {
			if (buf != NULL)
				memcpy(buf, m_pFirst->pt + m_read, read);
			m_read += read;
			read = 0;
		}
		else {
			if (buf != NULL) {
				memcpy(buf, m_pFirst->pt + m_read, left);
				(char *&)buf += left;
			}
			read -= left;
			next = m_pFirst->next;
			delete [] m_pFirst->pt;
			delete m_pFirst;
			m_pFirst = next;
			m_read = 0;
		}
	}
	if (m_pFirst == NULL)
		m_ppLast = &m_pFirst;

	m_length-=nMax - read;
	return nMax - read;
}

BOOL CBuffer::WriteDirect(LPVOID pt, int len)
{
	BinData **pp = m_ppLast;
	BinData *n;

	if (len == 0) return FALSE;
	if (len < 0) return TRUE;

	n = new BinData;
	n->next = NULL;
	n->len = len;
	n->pt = (char *)pt;
	*pp = n;
	m_ppLast = &n->next;

	m_length+=len;
	return FALSE;
}

int CBuffer::GetNextLength()
{
	if (m_pFirst == NULL) return 0;
	return m_pFirst->len - m_read;
}

int CBuffer::Peek(LPVOID buf, int nMax)
{
	BinData *p = m_pFirst;
	int read = nMax, left, ofs;

	if (nMax <= 0)
		return 0;

	ofs = m_read;
	while( read > 0 && p != NULL ) {
		left = p->len - ofs;
		if ( read <= left ) {
			memcpy(buf, p->pt + ofs, read);
			read = 0;
		}
		else {
			memcpy(buf, p->pt + ofs, left);
			(char *&)buf += left;
			read -= left;
			p = p->next;
			ofs = 0;
		}
	}

	return nMax - read;
}
