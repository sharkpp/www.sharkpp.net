// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include <windows.h>
#include <stdlib.h>
#include "hspdll.h"
#include "common.h"

/*
 *		�O���[�o���ϐ��̃C���X�^���X
 */
HANDLE hMutex = NULL;
HANDLE hMapping = NULL;
DEBUGINFO *debuginfo = NULL;


EXPORT BOOL WINAPI HSPDebugGetVer(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI GenerateChannelName(char *p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI CloseDebugChannel(int p1, int p2, int p3, int p4);



EXPORT BOOL WINAPI HSPDebugGetVer(int p1, int p2, int p3, int p4)
{
	return -VERSION;
}


EXPORT BOOL WINAPI GenerateChannelName(char *p1, int p2, int p3, int p4)
{
	_itoa((int)GetTickCount(), p1, 10);
	return 0;
}


EXPORT BOOL WINAPI CloseDebugChannel(int p1, int p2, int p3, int p4)
{
	if (hMutex == NULL)
		return -1;

	WaitForSingleObject(hMutex, INFINITE);
	debuginfo->bDebugging = FALSE;
	ReleaseMutex(hMutex);

	UnmapViewOfFile(debuginfo);
	CloseHandle(hMapping);
	CloseHandle(hMutex);
	hMutex = NULL;
	return 0;
}

/*
#define COLOR_SCROLLBAR         0
#define COLOR_BACKGROUND        1
#define COLOR_ACTIVECAPTION     2
#define COLOR_INACTIVECAPTION   3
#define COLOR_MENU              4
#define COLOR_WINDOW            5
#define COLOR_WINDOWFRAME       6
#define COLOR_MENUTEXT          7
#define COLOR_WINDOWTEXT        8
#define COLOR_CAPTIONTEXT       9
#define COLOR_ACTIVEBORDER      10
#define COLOR_INACTIVEBORDER    11
#define COLOR_APPWORKSPACE      12
#define COLOR_HIGHLIGHT         13
#define COLOR_HIGHLIGHTTEXT     14
#define COLOR_BTNFACE           15
#define COLOR_BTNSHADOW         16
#define COLOR_GRAYTEXT          17
#define COLOR_BTNTEXT           18
#define COLOR_INACTIVECAPTIONTEXT 19
#define COLOR_BTNHIGHLIGHT      20
*/

EXPORT BOOL WINAPI GetSystemColor(int *p1, int p2, int p3, int p4)
{
	*p1 = (int)GetSysColor(p2);
	return 0;
}




