<h1><?php echo __('Trackbacks'); ?></h1>

<div id="comments-def">
    <div class="comment"><?php echo __('Trackbacks'); ?></div>
    <div class="modify"><?php echo __('Modify'); ?></div>
</div>

<?php if (count($trackbacks)): ?>
<ol id="comments">
<?php foreach($trackbacks as $trackback): ?>

    <li class="<?php echo odd_even(); ?> <?php echo ($trackback->is_approved) ? 'approve': 'reject'; ?>">
          <a href="<?php echo get_url('plugin/trackback/edit/'.$trackback->id); ?>"><b><?php echo $trackback->title; ?></b></a>
          <p><?php echo $trackback->excerpt; ?></p>
          <div class="infos">
              <?php echo date('D, j M Y', strtotime($trackback->created_on)); ?> &#8212; 
              <a href="<?php echo get_url('plugin/trackback/delete/'.$trackback->id); ?>" onclick="return confirm('<?php echo __('Are you sure you wish to delete it?'); ?>');"><?php echo __('Delete'); ?></a> | 
<?php if ($trackback->is_approved): ?>
              <a href="<?php echo get_url('plugin/trackback/unapprove/'.$trackback->id); ?>"><?php echo __('Reject'); ?></a>
<?php else: ?>
              <a href="<?php echo get_url('plugin/trackback/approve/'.$trackback->id); ?>"><?php echo __('Approve'); ?></a>
<?php endif; ?>
          </div>
      </li>
<?php endforeach; ?>
</ol>
<?php else: ?>
<h3><?php echo __('No trackbacks found.'); ?></h3>
<?php endif; ?>
