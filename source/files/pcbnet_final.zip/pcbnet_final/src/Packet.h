// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

// Packet.h: CPacket �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PACKET_H__7B7E4651_8AE1_4068_986F_1176B2375CBA__INCLUDED_)
#define AFX_PACKET_H__7B7E4651_8AE1_4068_986F_1176B2375CBA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>

class CPacket
{
protected:
	typedef struct tagPACKETSTRUCT {
		int len;
		struct sockaddr_in addr;
		char *pt;
		tagPACKETSTRUCT *next;
	} PACKETSTRUCT, *LPPACKETSTRUCT;
public:
	int Count();
	BOOL Destroy();
	int GetNextLength();
	BOOL WriteDirect(LPVOID pt, struct sockaddr_in *addr, int len);
	BOOL Write(LPVOID pt, struct sockaddr_in *addr, int len);
	int CountPacket();
	int Read(LPVOID buf, struct sockaddr_in *addr, int nMax);
	int Peek(LPVOID buf, struct sockaddr_in *addr, int nMax);
	CPacket();
	virtual ~CPacket();

protected:
	PACKETSTRUCT *m_pFirst;
	PACKETSTRUCT **m_ppLast;
	int m_length;
	int m_packets;
};

#endif // !defined(AFX_PACKET_H__7B7E4651_8AE1_4068_986F_1176B2375CBA__INCLUDED_)
