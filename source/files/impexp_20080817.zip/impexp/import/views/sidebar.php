<?php if (Dispatcher::getAction() != 'view'): ?>

<div class="box">
<h2><?php echo __('What is this plugin?'); ?></h2>
<p><?php echo __('Import to Frog CMS from local files.'); ?></p>
</div>

<?php endif; ?>
