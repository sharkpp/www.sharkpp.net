// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#ifdef RAW_SUPPORT
#include <winsock2.h>
#include <ws2tcpip.h>
#include <mstcpip.h>
#else
#include <winsock.h>
#endif

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include <rasdlg.h>
#include <ras.h>
#include <raserror.h>

#include <assert.h>
#include "Buffer.h"
#include "Packet.h"
#include "hspdll.h"
#include "hspparam.h"

#ifdef HRT
#undef EXPORT
#define EXPORT extern "C"
#endif // HRT

#pragma function(memset, memcpy, strcmp, strcpy, strlen, strcat)

#define INADDR_ERROR	INADDR_ANY
#define MAX_PACKET		1500

#define ST_UNDEFINED	0
#define ST_TCP			1
#define ST_TCPLISTEN	2
#define ST_UDP			4
#define ST_DNS			8
#define ST_PING			16
#define ST_RAW			1024
#define ST_TCPALL		(ST_TCP|ST_TCPLISTEN)
#define ST_UDPALL		(ST_UDP)
#define ST_ICMPALL		(ST_PING)
#define ST_ALL			(~0)

#define ICMP_ECHO		8
#define ICMP_REPLY		0
#define ICMP_UNREACHED	3
#define ICMP_TTL		11

#define WM_ASYNC			(WM_USER+100)
#define WM_INITIALIZE		(WM_USER+101)
#define WM_DNSREQUEST		(WM_USER+102)
#define WM_DNSREPLY			(WM_USER+103)
#define WM_ATTACH			(WM_USER+104)
#define WM_SENDING			(WM_USER+105)
#define WM_CONNECT			(WM_USER+106)
#define WM_BIND				(WM_USER+107)
#define WM_ACCEPT			(WM_USER+108)
#define WM_SOCKATTACH		(WM_USER+109)
#define WM_SOCKDESTROY		(WM_USER+110)
#define WM_GRACEFUL_DISCON	(WM_USER+111)
#define WM_SENDPING			(WM_USER+112)
#define WM_ICMPREPLY		(WM_USER+113)
#define WM_TIMEOUT_CHECK	(WM_USER+114)
#define WM_FATAL_CLOSE		(WM_USER+115)
#define WM_SENDTO			(WM_USER+116)
#define WM_PINGTARGET		(WM_USER+117)

#ifndef SD_RECEIVE

#define SD_RECEIVE 0			// ���̂���`����ĂȂ��c
#define SD_SEND 1
#define SD_BOTH 2

#endif	//SD_RECEIVE

#define PCBNET_WNDCLASS		"PCBNET_AsyncSocketWindow"

	//	THREADINFO�N���X
class THREADINFO {
private:
	CRITICAL_SECTION crit;
public:
	HINSTANCE hInst;
	int type;
	SOCKET soc;
	HWND hWnd;
	int err;
	HANDLE hAsync;
	HOSTENT *ent;
	DWORD dwUser;
	union {
		struct {
			unsigned long addr;
			unsigned short port;
			BOOL bAvailable;
			BOOL bBlocking;
			BOOL bShutting;
			CBuffer *r;
			CBuffer *s;
			BOOL incoming;
		} tcp;
		struct {
			unsigned long addr;
			unsigned short port;
			BOOL bBlocking;
			BOOL bBroadCast;
			CPacket *r;
			CPacket *s;
			unsigned long fromaddr;
			unsigned short fromport;
		} udp;
		struct {
			BOOL bReply;
			unsigned long addr;
		} dns;
		struct {
			int datasize;
			unsigned long dwTimeOut;
			BOOL bReply;
			unsigned long addr;
			unsigned long dwSendTime;
			unsigned long dwReplyTime;
			unsigned char replycode;
			unsigned long replyfrom;
			unsigned char ttl;
			unsigned long dwUid;
		} icmp;
		struct {
			BOOL bBlocking;
			CPacket *r;
			CPacket *s;
		} raw;
	};
	THREADINFO();
	~THREADINFO();
	void Lock();
	void Unlock();
};
typedef THREADINFO *LPTHREADINFO;

typedef struct THREADLIST {
	THREADINFO *ti;
	HWND hWnd;
	DWORD threadID;
	HANDLE hThread;
	THREADLIST *next;
} *LPTHREADLIST;

typedef struct {
	SOCKET soc;
	struct sockaddr_in from;
} ACCEPTSTRUCT, *LPACCEPTSTRUCT;

typedef struct {
	unsigned char Type;
	unsigned char SubCode;
	unsigned short CheckSum;
	union {
		unsigned long reserved;
		struct {
			union {
				struct {
					unsigned short Id;
					unsigned short Seq;
				};
				struct {
					unsigned long dwId;
				};
			};
		} ping;
	};
} ICMPHEADER, *LPICMPHEADER;

#pragma pack(4)

typedef struct {
	unsigned char headerlen:4;
	unsigned char ipver:4;
	unsigned char tos;
	unsigned short len;
	unsigned short id;
	unsigned short fr;
	unsigned char ttl;
	unsigned char proto;
	unsigned short checksum;
	unsigned long srcip;
	unsigned long destip;
} IPHEADER, *LPIPHEADER;

#pragma pack()

BOOL InitWSA();
HINSTANCE GetInstance();
unsigned int GetMaxUdpDg();

LPTHREADLIST CreateSocketThread(int socktype);
BOOL IsSocketHandle(THREADLIST *pc, int type);
BOOL DeleteThread(THREADLIST *pdel);
void DestroyThread();
unsigned short CheckSum(char *buf, int len);
BOOL isWildcardHost(unsigned long addr);

extern HINSTANCE g_hInstance;
extern int iTCPSendBuf;
extern int iTCPRecvBuf;
extern BOOL bStrict;
extern int iMaxBuffer;
extern unsigned long gBindAddress;
#define HSPERROR_INVALID_SOCKET		3

#ifdef _DEBUG
#include <crtdbg.h>


void memLeakCheck();

#define new new(_NORMAL_BLOCK,__FILE__,__LINE__)
#define malloc(p1) _malloc_dbg(p1,_NORMAL_BLOCK,__FILE__,__LINE__)
#define MEMLEAK_CHECK() memLeakCheck()

#else

#define MEMLEAK_CHECK()

#endif	// _DEBUG
