static char *fastcopy_id = 
	"@(#)Copyright (C) H.Shirouzu 2004-2005   fastcopy.cpp	Ver1.30";
/* ========================================================================
	Project  Name			: Fast Copy file and directory
	Create					: 2004-09-15(Wed)
	Update					: 2005-12-14(Wed)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "fastcopy.h"
#include <stdarg.h>
#include <stddef.h>
#include <process.h>
#include <stdio.h>

void *NTFS_STR_V;		// "NTFS"
void *FMT_RENAME_V;		// ".%03d"

/*=========================================================================
  �N���X �F FastCopy
  �T  �v �F �}���`�X���b�h�ȃt�@�C���R�s�[�Ǘ��N���X
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
FastCopy::FastCopy()
{
	hReadThread = hWriteThread = NULL;
	::InitializeCriticalSection(&errCs);
	errBuf.AllocBuf(MIN_ERR_BUF, MAX_ERR_BUF);	// �G���[�L�^�p�o�b�t�@

	if (IS_WINNT_V) {
		src = new WCHAR [MAX_PATHLEN_V + MAX_PATH];
		dst = new WCHAR [MAX_PATHLEN_V + MAX_PATH];
		confirmDst = new WCHAR [MAX_PATHLEN_V + MAX_PATH];
		FMT_INT_STR_V = L"%d";
		FMT_RENAME_V = L"%.*s(%d)%s";
	}
	else {
		src = new char [MAX_PATHLEN_V + MAX_PATH_EX];
		dst = new char [MAX_PATHLEN_V + MAX_PATH_EX];
		confirmDst = new char [MAX_PATHLEN_V + MAX_PATH_EX];
		FMT_INT_STR_V = "%d";
		FMT_RENAME_V = "%.*s(%d)%s";
	}
	maxStatSize = (MAX_PATH * CHAR_LEN_V) * 2 + offsetof(FileStat, cFileName) + 8;
	hashVal.Init(MAX_PATH * CHAR_LEN_V);
}

FastCopy::~FastCopy()
{
	delete [] confirmDst;
	delete [] dst;
	delete [] src;
	errBuf.FreeBuf();
	::DeleteCriticalSection(&errCs);
}

BOOL FastCopy::GetRootDir(const void *path, void *root_dir)
{
	if (GetChar(path, 0) == '\\') {	// "\\server\volname\" 4�ڂ� \ ��������
		DWORD	ch;
		int		backslash_cnt = 0, offset;

		for (offset=0; (ch = GetChar(path, offset)) != 0 && backslash_cnt < 4; offset++) {
			if (ch == '\\')
				backslash_cnt++;
		}
		memcpy(root_dir, path, offset * CHAR_LEN_V);
		if (backslash_cnt < 4)					// 4�� \ ���Ȃ��ꍇ�́A������ \ ��t�^
			SetChar(root_dir, offset++, '\\');	// �i\\server\volume �Ȃǁj
		SetChar(root_dir, offset, 0);	// NULL terminate
	}
	else {	// "C:\" ��
		memcpy(root_dir, path, 3 * CHAR_LEN_V);
		SetChar(root_dir, 3, 0);	// NULL terminate
	}
	return	TRUE;
}

FastCopy::FsType FastCopy::GetFsType(const void *root_dir)
{
	if (GetDriveTypeV(root_dir) == DRIVE_REMOTE)
		return	FSTYPE_NETWORK;

	DWORD	serial, max_fname, fs_flags;
	WCHAR	vol[MAX_PATH], fs[MAX_PATH];

	if (GetVolumeInformationV(root_dir, vol, sizeof(vol) / CHAR_LEN_V, &serial, &max_fname, &fs_flags, fs, sizeof(fs) / CHAR_LEN_V) == FALSE)
		return	ConfirmErr("GetVolumeInformation", root_dir, FALSE), FSTYPE_NONE;

	return	lstrcmpiV(fs, NTFS_STR_V) == 0 ? FSTYPE_NTFS : FSTYPE_FAT;
}

int FastCopy::GetSectorSize(const void *root_dir)
{
	DWORD	spc, bps, fc, cl;

	if (GetDiskFreeSpaceV(root_dir, &spc, &bps, &fc, &cl) == FALSE) {
		if (IS_WINNT_V)
			ConfirmErr("GetDiskFreeSpace", root_dir, FALSE);
		return	OPT_SECTOR_SIZE;
	}
	return	bps;
}

BOOL FastCopy::IsSameDrive(const void *root1, const void *root2)
{
	if (GetChar(root1, 1) == ':' && GetChar(root2, 1) == ':')
		return	driveMng.IsSameDrive(GetChar(root1, 0), GetChar(root2, 0));

	if (GetChar(root1, 1) != GetChar(root2, 1) || GetDriveTypeV(root1) != GetDriveTypeV(root2))
		return	FALSE;

	return	lstrcmpiV(root1, root2) == 0 ? TRUE : FALSE;
}

int FastCopy::MakeUnlimitedPath(WCHAR *buf)
{
	int		prefix_len;
	WCHAR	*prefix;
	BOOL	isUNC = (*buf == '\\') ? TRUE : FALSE;

	prefix		= isUNC ? PATH_UNC_PREFIX : PATH_LOCAL_PREFIX;
	prefix_len	= isUNC ? PATH_UNC_PREFIX_LEN : PATH_LOCAL_PREFIX_LEN;

	// (isUNC ? 1 : 0) ... PATH_UNC_PREFIX �̏ꍇ�A\\server -> \\?\UNC\server 
	//  �ɂ��邽�߁A\\server �̓��� \ ����ׂ��B
	memmove(buf + prefix_len - (isUNC ? 1 : 0), buf, (strlenV(buf) + 1) * CHAR_LEN_V);
	memcpy(buf, prefix, prefix_len * CHAR_LEN_V);
	return	prefix_len;
}

BOOL FastCopy::InitDstPath(void)
{
	DWORD	attr;
	WCHAR	wbuf[MAX_PATH_EX];
	void	*buf = wbuf, *fname = NULL;
	const void	*org_path = dstArray.Path(0), *dst_root;

	// dst �̊m�F/���H
	if (GetChar(org_path, strlenV(org_path) -1) == ':' ||
		GetFullPathNameV(org_path, MAX_PATHLEN_V, dst, &fname) == 0)
		return	ConfirmErr("GetFullPathName", org_path, FALSE), FALSE;

	GetRootDir(dst, buf);
	dstArray.RegistPath(buf);
	dst_root = dstArray.Path(dstArray.Num() -1);

	if ((attr = GetFileAttributesV(dst)) == 0xffffffff) {
		CreateDirectoryV(dst, NULL);
		if ((attr = GetFileAttributesV(dst)) == 0xffffffff)
			return	ConfirmErr("CreateDirectory", dst, FALSE), FALSE;
	}
	if ((attr & FILE_ATTRIBUTE_DIRECTORY) == 0)
		return	ConfirmErr("Not a directory", dst, FALSE), FALSE;

	strcpyV(buf, dst);
	MakePathV(dst, buf, EMPTY_STR_V);
	// src���̂��R�s�[���邩�idst������ \ �����Ă��� or �����w��j
	isExtendDir = strcmpV(buf, dst) == 0 || srcArray.Num() > 1 ? TRUE : FALSE;
	dstPrefixLen = IS_WINNT_V ? MakeUnlimitedPath((WCHAR *)dst) : 0;
	dstBaseLen = strlenV(dst);

	// dst �t�@�C���V�X�e�����擾
	dstSectorSize = GetSectorSize(dst_root);
	dstFsType = GetFsType(dst_root);
	nbMinSize = dstFsType == FSTYPE_NTFS ? info.nbMinSizeNtfs : info.nbMinSizeFat;

	// �ő�]���T�C�Y
	maxTransSize = isSameDrv ? info.bufSize : info.bufSize / 2;
	maxTransSize = min(info.maxTransSize, maxTransSize);

	// �����R�s�[�pdst��t�@�C���m�F
	strcpyV(confirmDst, dst);

	return	TRUE;
}

BOOL FastCopy::InitSrcPath(int idx)
{
	DWORD		attr;
	BYTE		src_root_cur[MAX_PATH];
	WCHAR		wbuf[MAX_PATH_EX];
	void		*buf = wbuf, *fname = NULL;
	const void	*dst_root = dstArray.Path(dstArray.Num() -1);
	const void	*org_path = srcArray.Path(idx);

	// src �̊m�F/���H
	if (GetChar(org_path, strlenV(org_path) -1) == ':' ||
		GetFullPathNameV(org_path, MAX_PATHLEN_V, src, &fname) == 0)
		return	ConfirmErr("GetFullPathName", org_path), FALSE;
	GetRootDir(src, src_root_cur);

	if ((attr = GetFileAttributesV(src)) == 0xffffffff) {
		isMetaSrc = TRUE;
	}
	else if (attr & FILE_ATTRIBUTE_DIRECTORY) {
		isMetaSrc = FALSE;
		// �e�f�B���N�g�����̂��R�s�[���Ȃ��ꍇ�A\* ��t�^
		strcpyV(buf, src);
		MakePathV(src, buf, ASTERISK_V);
		if (strcmpV(buf, src_root_cur) == 0 || !isExtendDir)
			isMetaSrc = TRUE;
		else
			SetChar(src, strlenV(src) - 2, 0);	// ������ \* ��t���Ȃ�
	}
	srcPrefixLen = IS_WINNT_V ? MakeUnlimitedPath((WCHAR *)src) : 0;

	if (GetFullPathNameV(src, MAX_PATH_EX, buf, &fname) == 0 || fname == NULL)
		return	ConfirmErr("GetFullPathName2", MakeAddr(src, srcPrefixLen)), FALSE;

	// �m�F�pdst����
	strcpyV(MakeAddr(confirmDst, dstBaseLen), fname);

	// ����p�X�łȂ����Ƃ̊m�F
	if (lstrcmpiV(buf, confirmDst) == 0) {
		if (info.mode != DIFFCP_MODE || (info.flags & SAMEDIR_RENAME) == 0)
			return	ConfirmErr(GetLoadStr(IDS_SAMEPATHERR), MakeAddr(confirmDst, dstBaseLen), FALSE), FALSE;
		strcpyV(MakeAddr(confirmDst, dstBaseLen), ASTERISK_V);
		isRename = TRUE;
	}
	else
		isRename = FALSE;

	if (info.mode == MOVE_MODE && (attr & FILE_ATTRIBUTE_DIRECTORY)) {	// �e����q�ւ̈ړ��͔F�߂Ȃ�
		if (GetChar(fname, 0) == '*' || attr == 0xffffffff)
			SetChar(fname, 0, 0);
		int	len = IS_WINNT_V ? strlenV(buf) : ::lstrlenA((char *)buf);
		if (srcBaseLen <= dstBaseLen && strnicmpV(buf, confirmDst, len) == 0)
			return	ConfirmErr(GetLoadStr(IDS_PARENTPATHERR), MakeAddr(buf, srcPrefixLen), FALSE), FALSE;
	}

	SetChar(fname, 0, 0);
	srcBaseLen = strlenV(buf);

	// src �t�@�C���V�X�e�����擾
	if (lstrcmpiV(src_root_cur, src_root)) {
		srcSectorSize = GetSectorSize(src_root_cur);
		srcFsType = GetFsType(src_root_cur);

		sectorSize = max(srcSectorSize, dstSectorSize);		// �傫���ق��ɍ��킹��
		sectorSize = max(sectorSize, MIN_SECTOR_SIZE);

		// ���ꕨ���h���C�u���ǂ����̒���
		isSameDrv = IsSameDrive(src_root_cur, dst_root);
		if (info.mode == MOVE_MODE)
			isSameVol = strcmpV(src_root_cur, dst_root);
	}

	strcpyV(src_root, src_root_cur);

	return	TRUE;
}

BOOL FastCopy::InitDeletePath(int idx)
{
	DWORD		attr;
	WCHAR		wbuf[MAX_PATH_EX];
	void		*buf = wbuf, *fname = NULL;
	const void	*org_path = srcArray.Path(idx);
	BYTE		dst_root[MAX_PATH];

	// delete �p path �̊m�F/���H
	if (GetChar(org_path, strlenV(org_path) -1) == ':' ||
		GetFullPathNameV(org_path, MAX_PATHLEN_V, dst, &fname) == 0)
		return	ConfirmErr("GetFullPathName", org_path), FALSE;

	if ((attr = GetFileAttributesV(dst)) == 0xffffffff) {
		isMetaSrc = TRUE;
	}
	else if (attr & FILE_ATTRIBUTE_DIRECTORY) {
		isMetaSrc = FALSE;
		GetRootDir(dst, dst_root);
		strcpyV(buf, dst);
		// root_dir �͖����� "\*" ��t�^�A����ȊO�͖����� "\"���폜
		MakePathV(dst, buf, ASTERISK_V);
		if (lstrcmpiV(buf, dst_root) == 0)
			isMetaSrc = TRUE;
		else
			SetChar(dst, strlenV(dst) - 2, 0);
	}
	dstPrefixLen = IS_WINNT_V ? MakeUnlimitedPath((WCHAR *)dst) : 0;

	if (GetFullPathNameV(dst, MAX_PATH_EX, buf, &fname) == 0 || fname == NULL)
		return	ConfirmErr("GetFullPathName2", MakeAddr(dst, dstPrefixLen)), FALSE;
	SetChar(fname, 0, 0);
	dstBaseLen = strlenV(buf);

	return	TRUE;
}

BOOL FastCopy::RegistInfo(const PathArray *_srcArray, const PathArray *_dstArray, Info *_info, const PathArray *_includeArray, const PathArray *_excludeArray)
{
	isAbort = FALSE;
	isRename = FALSE;
	isFilter = FALSE;

	info = *_info;
	SetChar(src_root, 0, 0);

	// filter
	PathArray	pathArray[] = { *_includeArray, *_excludeArray };
	void		*path = NULL;

	for (int kind=0; kind < MAX_KIND_EXP; kind++) {
		for (int ftype=0; ftype < MAX_FTYPE_EXP; ftype++)
			regExp[kind][ftype].Init();

		for (int idx=0; idx < pathArray[kind].Num(); idx++) {
			int		len = lstrlenV(path = pathArray[kind].Path(idx)), targ = FILE_EXP;

			if (lGetCharV(path, len -1) == '\\') {
				lSetCharV(path, len -1, 0);
				targ = DIR_EXP;
			}
			if (!regExp[kind][targ].RegistWildCard(path, RegExp::CASE_INSENSE))
				return	ConfirmErr("Bad or Too long windcard string", path, FALSE), FALSE;
		}
	}
	if (path)
		isFilter = TRUE;

	// command
	if (info.mode == DELETE_MODE) {
		srcArray = *_srcArray;
		if (InitDeletePath(0) == FALSE)
			return	FALSE;
	}
	else {
		srcArray = *_srcArray;
		dstArray = *_dstArray;

		if (info.bufSize > MAX_BUF || info.bufSize < MIN_BUF * 2)
			return	FALSE;
		if (InitDstPath() == FALSE)
			return	FALSE;
		if (InitSrcPath(0) == FALSE)
			return	FALSE;
	}
	_info->isRenameMode = isRename;

	return	!isAbort;
}

BOOL FastCopy::Start(void)
{
	u_int	id;
	int		allocSize = info.bufSize + 4096;
	memset(&total, 0, sizeof(total));
	if (info.flags & PRE_SEARCH)
		total.isPreSearch = TRUE;

	isAbort = FALSE;
	writeReq = NULL;
	isSuspend = FALSE;
	readDestStatQueue = FALSE;
	nextFileID = 1;
	errFileID = 0;

	cv.Initialize(2);
	readReqList.Init();
	writeReqList.Init();
	errBuf.SetUsedSize(0);

	if (info.mode == DELETE_MODE) {
		startTick = ::GetTickCount();
		if (!(hReadThread = (HANDLE)_beginthreadex(0, 0, FastCopy::DeleteThread, this, 0, &id)))
			goto ERR;
		return	TRUE;
	}

	openFiles = new FileStat *[info.maxOpenFiles];
	openFilesCnt = 0;

	// src/dst dir-entry/attr �p�o�b�t�@�m��
	fileStatBuf.AllocBuf(MIN_ATTR_BUF, MAX_ATTR_BUF);
	dirStatBuf.AllocBuf(MIN_ATTR_BUF, MAX_ATTR_BUF);
	dstStatBuf.AllocBuf(MIN_ATTR_BUF, MAX_ATTR_BUF);
	dstStatIdxBuf.AllocBuf(MIN_ATTRIDX_BUF, MAX_ATTRIDX_BUF);

	// ���C�������O�o�b�t�@�m��
	if (mainBuf.AllocBuf(allocSize) == FALSE) {
		ConfirmErr("Can't alloc main buf", NULL, FALSE);
		goto ERR;
	}

	// �����O�o�b�t�@�p�I�t�Z�b�g������
	usedOffset = freeOffset = mainBuf.Buf();

	if (IS_WINNT_V && info.isPhysLock) {
		::SetProcessWorkingSetSize(::GetCurrentProcess(), mainBuf.Size() + APP_MEMSIZE, mainBuf.Size() + APP_MEMSIZE);
		mainBuf.LockBuf();
		fileStatBuf.LockBuf();
		dirStatBuf.LockBuf();
		dstStatBuf.LockBuf();
		dstStatIdxBuf.LockBuf();
	}

	startTick = ::GetTickCount();

	if (!(hReadThread = (HANDLE)_beginthreadex(0, 0, FastCopy::ReadThread, this, 0, &id))
	|| !(hWriteThread = (HANDLE)_beginthreadex(0, 0, FastCopy::WriteThread, this, 0, &id)))
		goto ERR;
	return	TRUE;

ERR:
	End();
	return	FALSE;
}

/*=========================================================================
  ��  �� �F ReadThread
  �T  �v �F Read ����
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
unsigned WINAPI FastCopy::ReadThread(void *fastCopyObj)
{
	return	((FastCopy *)fastCopyObj)->ReadThreadCore();
}

BOOL FastCopy::ReadThreadCore(void)
{
	BOOL	isSameDrvOld;
	int		done_cnt = 0;

	if (info.flags & PRE_SEARCH)
		PreSearch();

	for (int i=0; i < srcArray.Num(); i++) {
		if (InitSrcPath(i)) {
			if (done_cnt >= 1 && isSameDrvOld != isSameDrv)
				ChangeToWriteMode();
			ReadProc(srcBaseLen, info.overWrite == BY_ALWAYS ? FALSE : TRUE);
			isSameDrvOld = isSameDrv;
			done_cnt++;
		}
		if (isAbort)
			break;
	}
	SendRequest(REQ_EOF);
	ChangeToWriteMode();
	return	TRUE;
}


BOOL FastCopy::PreSearch(void)
{
	BOOL	is_delete = info.mode == DELETE_MODE;
	BOOL	(FastCopy::*InitPath)(int) = is_delete ? InitDeletePath : InitSrcPath;
	void	*path = is_delete ? dst : src;
	int		prefix_len = is_delete ? dstPrefixLen : srcPrefixLen;
	int		base_len = is_delete ? dstBaseLen : srcBaseLen;
	BOOL	ret = TRUE;

	for (int i=0; i < srcArray.Num(); i++) {
		if ((this->*InitPath)(i)) {
			if (!PreSearchProc(path, prefix_len, base_len))
				ret = FALSE;
		}
		if (isAbort)
			break;
	}
	total.isPreSearch = FALSE;
	startTick = ::GetTickCount();

	return	ret && !isAbort;
}

BOOL FastCopy::FilterCheck(const void *path, const WIN32_FIND_DATAW *fdat)
{
	int	targ = (fdat->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ? DIR_EXP : FILE_EXP;

	if (regExp[EXC_EXP][targ].IsMatch(fdat->cFileName))
		return	FALSE;

	if (!regExp[INC_EXP][targ].IsRegistered())
		return	TRUE;

	if (regExp[INC_EXP][targ].IsMatch(fdat->cFileName))
		return	TRUE;

	return	FALSE;
}

BOOL FastCopy::PreSearchProc(void *path, int prefix_len, int dir_len)
{
	HANDLE		hDir;
	BOOL		ret = TRUE;
	WIN32_FIND_DATAW fdat;

	if ((hDir = FindFirstFileV(path, &fdat)) == INVALID_HANDLE_VALUE) {
		return	ConfirmErr("FindFirstFile(pre)", MakeAddr(path, prefix_len)), FALSE;
	}

	do {
		if (IsParentOrSelfDirs(fdat.cFileName))
			continue;

		// src �f�B���N�g�����̂ɑ΂��ẮA�t�B���^�Ώۂɂ��Ȃ�
		if (isFilter && (dir_len != srcBaseLen || isMetaSrc) && !FilterCheck(path, &fdat))
			continue;

		if (fdat.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
			total.preDirs++;
			int len = sprintfV(MakeAddr(path, dir_len), FMT_CAT_ASTER_V, fdat.cFileName) -1;
			ret = PreSearchProc(path, prefix_len, dir_len + len);
		}
		else {
			total.preFiles++;
			total.preTrans += (((_int64)fdat.nFileSizeHigh << 32) + fdat.nFileSizeLow);
		}
	}
	while (!isAbort && FindNextFileV(hDir, &fdat));

	if (!isAbort && ret && ::GetLastError() != ERROR_NO_MORE_FILES) {
		ret = FALSE;
		ConfirmErr("FindNextFile(pre)", MakeAddr(path, prefix_len));
	}

	::FindClose(hDir);

	return	ret && !isAbort;
}

BOOL FastCopy::ReadProc(int dir_len, BOOL confirm_dir)
{
	BOOL		ret = TRUE;
	FileStat	*srcStat, *statEnd;
	FileStat	*dstStat = NULL;
	int			new_dir_len, curDirStatSize, confirm_len;
	BOOL		is_rename_local = isRename;
	BOOL		confirm_dir_local = confirm_dir || is_rename_local;

	isRename = FALSE;	// top level �̂݌��ʂ��o��

	// �J�����g�̃T�C�Y��ۑ�
	curDirStatSize = dirStatBuf.UsedSize();

	if (confirm_dir_local && !isSameDrv)
		ReadDestStatRequest();

	// �f�B���N�g���G���g�����ɂ��ׂēǂݎ��
	ret = ReadDirEntry(dir_len, confirm_dir_local);

	if (confirm_dir_local && (isSameDrv ? ReadDestStat() : WaitReadDestStat()) == FALSE || isAbort || !ret)
		return	FALSE;

	// �t�@�C�����ɏ���
	statEnd = (FileStat *)(fileStatBuf.Buf() + fileStatBuf.UsedSize());
	for (srcStat = (FileStat *)fileStatBuf.Buf(); srcStat < statEnd; srcStat = (FileStat *)((BYTE *)srcStat + srcStat->size)) {
		if (confirm_dir_local)
			dstStat = hash.Search(srcStat->upperName, srcStat->hashVal);

		if (dstStat) {
			if (is_rename_local) {
				SetRenameCount(srcStat);
			}
			else {
				dstStat->isExists = TRUE;
				if (IsOverWriteFile(srcStat, dstStat) == FALSE) {
					total.skipFiles++;
					total.skipTrans += dstStat->FileSize();
					continue;
				}
			}
		}
		total.readFiles++;
		memcpy(MakeAddr(src, dir_len), srcStat->cFileName, srcStat->minSize - offsetof(FileStat, cFileName));
		srcStat->fileID = nextFileID++;
		openFiles[openFilesCnt++] = srcStat;

		if (OpenFileProc(srcStat) == FALSE || srcFsType == FSTYPE_NETWORK || openFilesCnt == info.maxOpenFiles) {
			if (ReadMultiFilesProc(), CloseMultiFilesProc(), isAbort)
				goto END;
		}
	}
	if (ReadMultiFilesProc(), CloseMultiFilesProc(), isAbort)
		goto END;

	statEnd = (FileStat *)(dirStatBuf.Buf() + dirStatBuf.UsedSize());

	// �f�B���N�g���̑��݊m�F
	if (confirm_dir_local) {
		confirm_len = dir_len + (dstBaseLen - srcBaseLen);

		for (srcStat = (FileStat *)(dirStatBuf.Buf() + curDirStatSize); srcStat < statEnd; srcStat = (FileStat *)((BYTE *)srcStat + srcStat->size)) {
			if ((dstStat = hash.Search(srcStat->upperName, srcStat->hashVal)) != NULL) {
				if (is_rename_local)
					SetRenameCount(srcStat);
				else
					srcStat->isExists = dstStat->isExists = TRUE;
			}
			else
				srcStat->isExists = FALSE;
		}
	}

	// SYNC���[�h�̏ꍇ�A�R�s�[���ɖ����t�@�C�����폜
	if (confirm_dir_local && info.mode == SYNCCP_MODE) {
		int		max = dstStatIdxBuf.UsedSize() / sizeof(FileStat *);
		for (int i=0; i < max; i++) {
			if ((dstStat = ((FileStat **)dstStatIdxBuf.Buf())[i])->isExists)
				continue;
			if (isSameDrv) {
				if (dstStat->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
					ret = DeleteDirProc(confirmDst, confirm_len, dstStat->cFileName, dstStat);
				else
					ret = DeleteFileProc(confirmDst, confirm_len, dstStat->cFileName, dstStat);
			}
			else {
				SendRequest(DELETE_FILES, 0, dstStat);
			}
			if (isAbort)
				goto END;
		}
	}

	// �f�B���N�g������
	for (srcStat = (FileStat *)(dirStatBuf.Buf() + curDirStatSize); srcStat < statEnd; srcStat = (FileStat *)((BYTE *)srcStat + srcStat->size)) {
		total.readDirs++;
		new_dir_len = dir_len + sprintfV(MakeAddr(src, dir_len), FMT_CAT_ASTER_V, srcStat->cFileName) -1;
		if (confirm_dir && srcStat->isExists)
			sprintfV(MakeAddr(confirmDst, confirm_len), FMT_CAT_ASTER_V, srcStat->cFileName);
		if (SendRequest(confirm_dir && srcStat->isExists ? INTODIR : MKDIR, 0, srcStat), isAbort)
			goto END;
		if (ReadProc(new_dir_len, confirm_dir && srcStat->isExists), isAbort)
			goto END;
		if (SendRequest(RETURN_PARENT), isAbort)
			goto END;
	}

END:
	// �J�����g�� dir�pBuf �T�C�Y�𕜌�
	dirStatBuf.SetUsedSize(curDirStatSize);
	return	ret && !isAbort;
}

int FastCopy::MakeRenameName(void *buf, int count, void *fname)
{
	void	*ext = strrchrV(fname, '.');
	int		offset = ext ? DiffLen(ext, fname) : MAX_PATH;

	return	sprintfV(buf, FMT_RENAME_V, offset, fname, count, ext ? ext : EMPTY_STR_V);
}

BOOL FastCopy::SetRenameCount(FileStat *stat)
{
	while (1) {
		WCHAR	new_name[MAX_PATH];
		int		len = MakeRenameName(new_name, ++stat->renameCount, stat->upperName);
		DWORD	hash_val = hashVal.MakeHash(new_name, len * CHAR_LEN_V);
		if (hash.Search(new_name, hash_val) == NULL)
			break;
	}
	return	TRUE;
}

/*
	�㏑������
*/
BOOL FastCopy::IsOverWriteFile(FileStat *srcStat, FileStat *dstStat)
{
	if (info.overWrite == BY_NAME)
		return	FALSE;

	if (info.overWrite == BY_ATTR) {
		// �T�C�Y���������A����...
		if (dstStat->FileSize() == srcStat->FileSize() &&
		// �X�V���t�����S�ɓ��������A��������...
		(	(*(_int64 *)&dstStat->ftLastWriteTime == *(_int64 *)&srcStat->ftLastWriteTime) ||
			// src �� dst �̃^�C���X�^���v�̍ŏ��P�ʂ� 1 �b�ȏ�iFAT or SAMBA ���̉\���j�ł���...
			((*(_int64 *)&srcStat->ftLastWriteTime % 10000000) == 0 || (*(_int64 *)&dstStat->ftLastWriteTime % 10000000) == 0) &&
			// �^�C���X�^���v�̍��� 2 �b�ȓ��Ȃ�A����^�C���X�^���v�Ƃ݂Ȃ��āA�㏑�����Ȃ�
			*(_int64 *)&dstStat->ftLastWriteTime + 20000000 >= *(_int64 *)&srcStat->ftLastWriteTime &&
			*(_int64 *)&dstStat->ftLastWriteTime - 20000000 <= *(_int64 *)&srcStat->ftLastWriteTime	))
			return	FALSE;
		return	TRUE;
	}

	if (info.overWrite == BY_LASTEST) {
		// �X�V���t�� dst �Ɠ������Â��ꍇ�A��������...
		if (*(_int64 *)&dstStat->ftLastWriteTime >= *(_int64 *)&srcStat->ftLastWriteTime ||
			// src �� dst �̃^�C���X�^���v�̍ŏ��P�ʂ� 1 �b�ȏ�iFAT or SAMBA ���̉\���j�ł���...
			((*(_int64 *)&srcStat->ftLastWriteTime % 10000000) == 0 || (*(_int64 *)&dstStat->ftLastWriteTime % 10000000) == 0) &&
			// �^�C���X�^���v�̍��� 2 �b�̃}�[�W����t������ŁA �X�V���t�� dst �Ɠ������Â��ꍇ�́A�㏑�����Ȃ�
			*(_int64 *)&dstStat->ftLastWriteTime + 20000000 >= *(_int64 *)&srcStat->ftLastWriteTime)
			return	FALSE;
		return	TRUE;
	}

	if (info.overWrite == BY_ALWAYS)
		return	TRUE;

	return	ConfirmErr("Illegal overwrite mode", 0, FALSE), FALSE;
}

BOOL FastCopy::ReadDirEntry(int dir_len, BOOL confirm_dir)
{
	HANDLE	fh;
	BOOL	ret = TRUE;
	int		len;
	WIN32_FIND_DATAW fdat;

	fileStatBuf.SetUsedSize(0);

	if ((fh = FindFirstFileV(src, &fdat)) == INVALID_HANDLE_VALUE) {
		total.errDirs++;
		return	ConfirmErr("FindFirstFile", MakeAddr(src, srcPrefixLen)), FALSE;
	}
	do {
		if (IsParentOrSelfDirs(fdat.cFileName))
			continue;

		// src �f�B���N�g�����̂ɑ΂��ẮA�t�B���^�Ώۂɂ��Ȃ�
		if (isFilter && (dir_len != srcBaseLen || isMetaSrc) && !FilterCheck(src, &fdat))
			continue;

		// �f�B���N�g�����t�@�C�����̒~��
		if (fdat.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
			len = FdatToFileStat(&fdat, (FileStat *)(dirStatBuf.Buf() + dirStatBuf.UsedSize()), confirm_dir);
			dirStatBuf.AddUsedSize(len);
			if (dirStatBuf.RemainSize() <= maxStatSize)
				dirStatBuf.Grow(MIN_ATTR_BUF);
		}
		else {
			len = FdatToFileStat(&fdat, (FileStat *)(fileStatBuf.Buf() + fileStatBuf.UsedSize()), confirm_dir);
			fileStatBuf.AddUsedSize(len);
			if (fileStatBuf.RemainSize() <= maxStatSize)
				fileStatBuf.Grow(MIN_ATTR_BUF);
		}
	}
	while (!isAbort && FindNextFileV(fh, &fdat));

	if (!isAbort && ::GetLastError() != ERROR_NO_MORE_FILES) {
		total.errFiles++;
		ret = FALSE;
		ConfirmErr("FindNextFile", MakeAddr(src, srcPrefixLen));
	}
	::FindClose(fh);

	return	ret && !isAbort;
}

BOOL FastCopy::OpenFileProc(FileStat *stat)
{
	if (stat->FileSize() == 0)
		return	TRUE;

	if ((stat->hFile = CreateFileV(src, GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_EXISTING, (info.flags & USE_OSCACHE_READ) ? 0 : FILE_FLAG_NO_BUFFERING, 0)) == INVALID_HANDLE_VALUE) {
		stat->lastError = ::GetLastError();
		return	FALSE;
	}
	return	TRUE;
}

BOOL FastCopy::ReadMultiFilesProc(void)
{
	for (int i=0; i < openFilesCnt; i++) {
		if (ReadFileProc(openFiles[i]), isAbort)
			break;
	}
	return	!isAbort;
}

BOOL FastCopy::CloseMultiFilesProc(void)
{
	for (int i=0; i < openFilesCnt; i++) {
		if (openFiles[i]->hFile != INVALID_HANDLE_VALUE)
			::CloseHandle(openFiles[i]->hFile);
	}
	openFilesCnt = 0;

	return	!isAbort;
}

BOOL FastCopy::ReadFileProc(FileStat *stat)
{
	BOOL	ret = TRUE;
	_int64	file_size = stat->FileSize();
	DWORD	trans_size;
	ReqBuf	req_buf;

	if (file_size == 0)
		return	SendRequest(WRITE_FILE, 0, stat);

	if (stat->hFile == INVALID_HANDLE_VALUE) {
		total.errFiles++;
		::SetLastError(stat->lastError);
		if (ConfirmErr("OpenFile", MakeAddr(src, srcPrefixLen)) == Confirm::CONTINUE_RESULT) {
			stat->SetFileSize(0);
			if (info.flags & CREATE_OPENERR_FILE)
				SendRequest(WRITE_FILE, 0, stat);
		}
		return	FALSE;
	}

	for (_int64 remain_size=file_size; remain_size > 0; remain_size -= trans_size) {
		if ((ret = PrepareReqBuf(offsetof(ReqHeader, stat) + (remain_size == file_size ? stat->minSize : 0), remain_size, stat->fileID, &req_buf)) == FALSE)
			break;
		if ((ret = ::ReadFile(stat->hFile, req_buf.buf, req_buf.bufSize, &trans_size, NULL)) == FALSE) {
			total.errFiles++;
			if (ConfirmErr("ReadFile", MakeAddr(src, srcPrefixLen)) == Confirm::CONTINUE_RESULT || remain_size != file_size) {
				stat->SetFileSize(0);
				req_buf.bufSize = 0;
				SendRequest(remain_size == file_size ? WRITE_FILE : WRITE_ABORT, &req_buf, stat);
			}
			break;
		}
		else
			total.readTrans += trans_size;
		SendRequest(remain_size == file_size ? WRITE_FILE : WRITE_FILE_CONT, &req_buf, stat);
	}

	return	ret && !isAbort;
}

void FastCopy::ReadDestStatRequest(void)
{
	cv.Lock();
	readDestStatQueue = TRUE;
	cv.Notify();
	cv.UnLock();
}

BOOL FastCopy::WaitReadDestStat(void)
{
	cv.Lock();
	while (readDestStatQueue && !isAbort)
		cv.Wait();
	cv.UnLock();
	return	readDestStatResult;
}

BOOL FastCopy::ReadDestStat(void)
{
	HANDLE		fh;
	int			num = 0, len;
	FileStat	*dstStat, **dstStatIdx;
	WIN32_FIND_DATAW	fdat;

	if (!isSameDrv)
		cv.UnLock();
	readDestStatResult = TRUE;
	dstStat = (FileStat *)dstStatBuf.Buf();
	dstStatIdx = (FileStat **)dstStatIdxBuf.Buf();
	dstStatBuf.SetUsedSize(0);
	dstStatIdxBuf.SetUsedSize(0);

	if ((fh = FindFirstFileV(confirmDst, &fdat)) == INVALID_HANDLE_VALUE) {
		if (::GetLastError() != ERROR_FILE_NOT_FOUND && strcmpV(MakeAddr(confirmDst, dstBaseLen), ASTERISK_V) == 0) {
			readDestStatResult = FALSE;
			total.errDirs++;
			ConfirmErr("FindFirstFile(stat)", MakeAddr(confirmDst, dstPrefixLen));
		}	// �t�@�C�������w�肵�ẴR�s�[�ŁA�R�s�[�悪������Ȃ��ꍇ�́A
			// �G���g���Ȃ��ł̐����Ƃ݂Ȃ�
		goto END;
	}
	do {
		if (IsParentOrSelfDirs(fdat.cFileName))
			continue;
		dstStatIdx[num++] = dstStat;
		len = FdatToFileStat(&fdat, dstStat, TRUE);
		dstStatBuf.AddUsedSize(len);

		// ���� stat �p buffer �̃Z�b�g
		dstStat = (FileStat *)(dstStatBuf.Buf() + dstStatBuf.UsedSize());
		dstStatIdxBuf.AddUsedSize(sizeof(FileStat *));

		if (dstStatBuf.RemainSize() <= maxStatSize)
			dstStatBuf.Grow(MIN_ATTR_BUF);
		if (dstStatIdxBuf.RemainSize() <= sizeof(FileStat *))
			dstStatIdxBuf.Grow(MIN_ATTRIDX_BUF);
	}
	while (!isAbort && FindNextFileV(fh, &fdat));

	if (!isAbort && ::GetLastError() != ERROR_NO_MORE_FILES) {
		total.errFiles++;
		readDestStatResult = FALSE;
		ConfirmErr("FindNextFile(stat)", MakeAddr(confirmDst, dstPrefixLen));
	}
	::FindClose(fh);

END:
	if (readDestStatResult)
		readDestStatResult = MakeHashTable();

	if (!isSameDrv) {
		cv.Lock();
		cv.Notify();
	}
	readDestStatQueue = FALSE;
	return	readDestStatResult;
}

BOOL FastCopy::MakeHashTable(void)
{
	int		num = dstStatIdxBuf.UsedSize() / sizeof(FileStat *);
	int		require_size = hash.RequireSize(num), grow_size;

	if ((grow_size = require_size - dstStatIdxBuf.RemainSize()) > 0)
		dstStatIdxBuf.Grow(ALIGN_SIZE(grow_size, MIN_ATTRIDX_BUF));

	return	hash.Init((FileStat **)dstStatIdxBuf.Buf(), num, dstStatIdxBuf.Buf() + dstStatIdxBuf.UsedSize());
}

int StatHash::HashNum(int data_num)
{
	return	data_num | 1;
}

BOOL StatHash::Init(FileStat **data, int data_num, void *tbl_buf)
{
	hashNum = HashNum(data_num);
	hashTbl = (FileStat **)tbl_buf;
	memset(hashTbl, 0, hashNum * sizeof(FileStat *));

	for (int i=0; i < data_num; i++) {
		for (FileStat **stat = hashTbl+(data[i]->hashVal % hashNum); *stat; stat = &(*stat)->next)
			;
		*stat = data[i];
	}
	return	TRUE;
}

FileStat *StatHash::Search(void *upperName, DWORD hash_val)
{
	for (FileStat *target = hashTbl[hash_val % hashNum]; target; target = target->next) {
		if (target->hashVal == hash_val && strcmpV(target->upperName, upperName) == 0)
			return	target;
	}

	return	NULL;
}

/*=========================================================================
  ��  �� �F DeleteThread
  �T  �v �F DELETE_MODE ����
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
unsigned WINAPI FastCopy::DeleteThread(void *fastCopyObj)
{
	return	((FastCopy *)fastCopyObj)->DeleteThreadCore();
}

BOOL FastCopy::DeleteThreadCore(void)
{
	if ((info.flags & PRE_SEARCH) && info.mode == DELETE_MODE)
		PreSearch();

	for (int i=0; i < srcArray.Num() && !isAbort; i++) {
		if (InitDeletePath(i))
			DeleteProc(dst, dstBaseLen);
	}
	::PostMessage(info.notifyWnd->hWnd, info.uNotifyMsg, 0, 0);
	return	TRUE;
}

/*
	�폜����
*/
BOOL FastCopy::DeleteProc(void *path, int dir_len)
{
	HANDLE		hDir;
	BOOL		ret = TRUE;
	FileStat	stat;
	WIN32_FIND_DATAW fdat;

	if ((hDir = FindFirstFileV(path, &fdat)) == INVALID_HANDLE_VALUE) {
		total.errDirs++;
		return	ConfirmErr("FindFirstFile(del)", MakeAddr(path, dstPrefixLen)), FALSE;
	}

	do {
		if (IsParentOrSelfDirs(fdat.cFileName))
			continue;

		// �폜�w�肵���f�B���N�g�����́i���[�g�j�łȂ����A�t�B���^�[���O�Ώ�
		if (isFilter && (dstBaseLen != dir_len || isMetaSrc) && !FilterCheck(path, &fdat)) {
			total.filterSkips++;
			continue;
		}

		stat.nFileSizeLow		= fdat.nFileSizeLow;
		stat.nFileSizeHigh		= fdat.nFileSizeHigh;
		stat.dwFileAttributes	= fdat.dwFileAttributes;

		if (stat.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			ret = DeleteDirProc(path, dir_len, fdat.cFileName, &stat);
		else
			ret = DeleteFileProc(path, dir_len, fdat.cFileName, &stat);
	}
	while (!isAbort && FindNextFileV(hDir, &fdat));

	if (!isAbort && ret && ::GetLastError() != ERROR_NO_MORE_FILES) {
		ret = FALSE;
		ConfirmErr("FindNextFile(del)", MakeAddr(path, dstPrefixLen));
	}

	::FindClose(hDir);

	return	ret && !isAbort;
}

BOOL FastCopy::DeleteDirProc(void *path, int dir_len, void *fname, FileStat *stat)
{
	int		new_dir_len = dir_len + sprintfV(MakeAddr(path, dir_len), FMT_CAT_ASTER_V, fname) -1;
	BOOL	ret;
	int		cur_skips = total.filterSkips;

	if ((ret = DeleteProc(path, new_dir_len)), isAbort)
		return	ret;

	if (isFilter && (cur_skips != total.filterSkips || regExp[INC_EXP][FILE_EXP].IsRegistered()))
		return	ret;

	SetChar(path, new_dir_len - 1, 0);

	if (stat->dwFileAttributes & FILE_ATTRIBUTE_READONLY)
		SetFileAttributesV(path, stat->dwFileAttributes & ~FILE_ATTRIBUTE_READONLY);

	if ((ret = RemoveDirectoryV(path)) == FALSE) {
		total.errDirs++;
		return	ConfirmErr("RemoveDirectory", MakeAddr(path, dstPrefixLen)), FALSE;
	}

	total.deleteDirs++;
	return	ret;
}

BOOL FastCopy::DeleteFileProc(void *path, int dir_len, void *fname, FileStat *stat)
{
	strcpyV(MakeAddr(path, dir_len), fname);

	if (stat->dwFileAttributes & FILE_ATTRIBUTE_READONLY)
		SetFileAttributesV(path, FILE_ATTRIBUTE_NORMAL);

	if (DeleteFileV(path) == FALSE) {
		total.errFiles++;
		return	ConfirmErr("DeleteFile", MakeAddr(path, dstPrefixLen)), FALSE;
	}

	total.deleteFiles++;
	total.deleteTrans += stat->FileSize();
	return	TRUE;
}


/*=========================================================================
  ��  �� �F WriteThread
  �T  �v �F Write ����
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
unsigned WINAPI FastCopy::WriteThread(void *fastCopyObj)
{
	return	((FastCopy *)fastCopyObj)->WriteThreadCore();
}

BOOL FastCopy::WriteThreadCore(void)
{
	BOOL	ret = WriteProc(dstBaseLen);

	if (info.mode == MOVE_MODE && !isAbort && errBuf.UsedSize() == 0 && total.errFiles == 0 && total.errDirs == 0)
		DeleteThreadCore();	// �G���[���Ȃ��Ȃ�A�\�[�X�̍폜
	else
		::PostMessage(info.notifyWnd->hWnd, info.uNotifyMsg, 0, 0);

	return	ret;
}

BOOL FastCopy::WriteProc(int dir_len)
{
	BOOL		ret = TRUE;
	int			new_dir_len;
	HANDLE		fh;
	FileStat	sv_stat;

	while (!isAbort) {
		if ((ret = RecvRequest()) == FALSE || writeReq->command == REQ_EOF) {
			break;
		}
		if (writeReq->command == WRITE_FILE) {
			if (writeReq->stat.renameCount == 0)
				strcpyV(MakeAddr(dst, dir_len), writeReq->stat.cFileName);
			else
				MakeRenameName(MakeAddr(dst, dir_len), writeReq->stat.renameCount, writeReq->stat.cFileName);

			if ((ret = WriteFileProc()), isAbort)
				break;
		}
		else if (writeReq->command == MKDIR || writeReq->command == INTODIR) {
			memcpy(&sv_stat, &writeReq->stat, offsetof(FileStat, cFileName));

			if (writeReq->stat.renameCount == 0)
				new_dir_len = dir_len + sprintfV(MakeAddr(dst, dir_len), FMT_STR_V, writeReq->stat.cFileName);
			else
				new_dir_len = dir_len + MakeRenameName(MakeAddr(dst, dir_len), writeReq->stat.renameCount, writeReq->stat.cFileName);

			if (writeReq->command == MKDIR) {
				CreateDirectoryV(dst, NULL);
				total.writeDirs++;
			}
			strcpyV(MakeAddr(dst, new_dir_len++), BACK_SLASH_V);

			if ((ret = WriteProc(new_dir_len)), isAbort)	// �ċA
				break;

			// �^�C���X�^���v/�����̃Z�b�g
			SetChar(dst, --new_dir_len, 0);	// ������ '\\' �����
			if (sv_stat.dwFileAttributes & (FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_READONLY|FILE_ATTRIBUTE_SYSTEM))
				SetFileAttributesV(dst, sv_stat.dwFileAttributes);
			if (IS_WINNT_V && (fh = CreateFileV(dst, GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, 0)) != INVALID_HANDLE_VALUE)
			{
				::SetFileTime(fh, &sv_stat.ftCreationTime, &sv_stat.ftLastAccessTime, &sv_stat.ftLastWriteTime);
				::CloseHandle(fh);
			}
		}
		else if (writeReq->command == DELETE_FILES) {
			if (writeReq->stat.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				ret = DeleteDirProc(dst, dir_len, writeReq->stat.cFileName, &writeReq->stat);
			else
				ret = DeleteFileProc(dst, dir_len, writeReq->stat.cFileName, &writeReq->stat);
		}
		else if (writeReq->command == RETURN_PARENT) {
			break;
		}
		else if (writeReq->command < WRITE_FILE && writeReq->command > REQ_EOF) {
			ret = FALSE;
			ConfirmErr("Illegal Request (internal error)", NULL, FALSE);
			break;
		}
	}
	return	ret && !isAbort;
}

BOOL FastCopy::WriteFileProc(void)
{
	HANDLE		fh;
	BOOL		ret = TRUE;
	_int64		file_size = writeReq->stat.FileSize();
	_int64		remain = file_size;
	DWORD		trans_size;
	FileStat	*stat = &writeReq->stat, sv_stat;
	BOOL		isNonBuf = dstFsType != FSTYPE_NETWORK && (file_size >= nbMinSize || (file_size % dstSectorSize) == 0) && (info.flags & USE_OSCACHE_WRITE) == 0 ? TRUE : FALSE;

	if ((fh = CreateFileV(dst, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, isNonBuf ? FILE_FLAG_NO_BUFFERING : 0, 0)) == INVALID_HANDLE_VALUE) {
		SetFileAttributesV(dst, FILE_ATTRIBUTE_NORMAL);
		if ((fh = CreateFileV(dst, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, isNonBuf ? FILE_FLAG_NO_BUFFERING : 0, 0)) == INVALID_HANDLE_VALUE) {
			total.errFiles++;
			SetErrFileID(writeReq->stat.fileID);
			ConfirmErr("CreateFile", MakeAddr(dst, dstPrefixLen));
			return	FALSE;
		}
	}
	if (file_size > writeReq->bufSize) {
		_int64	alloc_size = isNonBuf ? ALIGN_SIZE(file_size, dstSectorSize) : file_size;
		LONG	high_size = (LONG)(alloc_size >> 32);
		::SetFilePointer(fh, (LONG)alloc_size, &high_size, FILE_BEGIN);
		::SetEndOfFile(fh);
		::SetFilePointer(fh, 0, NULL, FILE_BEGIN);
	}

	while (remain > 0) {
		if ((ret = ::WriteFile(fh, writeReq->buf, remain >= writeReq->bufSize ? writeReq->bufSize : (DWORD)(isNonBuf ? ALIGN_SIZE(remain, dstSectorSize) : remain), &trans_size, NULL)) == FALSE) {
			SetErrFileID(writeReq->stat.fileID);
			ConfirmErr("WriteFile", MakeAddr(dst, dstPrefixLen), GetLastError() != ERROR_DISK_FULL);
			break;
		}
		if ((remain -= trans_size) > 0) {	// ����������
			total.writeTrans += trans_size;
			if (&sv_stat != stat)		// file stat �̑ޔ�
				memcpy((stat = &sv_stat), &writeReq->stat, offsetof(FileStat, cFileName));

			if (RecvRequest() == FALSE || writeReq->command != WRITE_FILE_CONT) {
				ret = FALSE;
				remain = 0;
				break;
			}
		}
		else
			total.writeTrans += trans_size + remain;
	}
	if (ret && remain != 0) {
		::CloseHandle(fh);
		if ((fh = CreateFileV(dst, GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0)) == INVALID_HANDLE_VALUE) {
			total.errFiles++;
			ConfirmErr("CreateFile2", MakeAddr(dst, dstPrefixLen));
			return	 FALSE;
		}
		::SetFilePointer(fh, stat->nFileSizeLow, (LONG *)&stat->nFileSizeHigh, FILE_BEGIN);
		if ((ret = ::SetEndOfFile(fh)) == FALSE)
			ConfirmErr("SetEndOfFile", MakeAddr(dst, dstPrefixLen));
	}
	if (ret)
		::SetFileTime(fh, &stat->ftCreationTime, &stat->ftLastAccessTime, &stat->ftLastWriteTime);

	::CloseHandle(fh);

	if (ret) {
		if (stat->dwFileAttributes & (FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_READONLY|FILE_ATTRIBUTE_SYSTEM))
			SetFileAttributesV(dst, stat->dwFileAttributes);
		total.writeFiles++;
	}
	else {
		total.errFiles++;
		DeleteFileV(dst);
	}
	return	ret && !isAbort;
}

BOOL FastCopy::ChangeToWriteModeCore(void)
{
	writeReqList.MoveList(&readReqList);
	cv.Notify();
	while (!writeReqList.IsEmpty() && !isAbort)
		cv.Wait();
	return	!isAbort;
}

BOOL FastCopy::ChangeToWriteMode(void)
{
	cv.Lock();
	BOOL	ret = ChangeToWriteModeCore();
	cv.UnLock();
	return	ret;
}

BOOL FastCopy::AllocReqBuf(int req_size, _int64 _data_size, ReqBuf *buf)
{
	int		max_free = mainBuf.Buf() + mainBuf.Size() - usedOffset;
	int		data_size = (_data_size > maxTransSize) ? maxTransSize : (int)_data_size;
	int		align_data_size = ALIGN_SIZE(data_size, 8);
	int		sector_data_size = ALIGN_SIZE(data_size, sectorSize);
	int		require_size = align_data_size + req_size;
	BYTE	*align_offset = data_size ? (BYTE *)ALIGN_SIZE((u_int)usedOffset, sectorSize) : usedOffset;

	max_free -= align_offset - usedOffset;

	if (data_size && align_data_size + req_size < sector_data_size)
		require_size = sector_data_size;

	if (require_size > max_free) {
		if (max_free < MIN_BUF) {
			align_offset = mainBuf.Buf();
			if (isSameDrv && ChangeToWriteModeCore() == FALSE)	// Read -> Write �؂�ւ�
				return	FALSE;
		}
		else {
			data_size = max_free - req_size;
			align_data_size = data_size = (data_size / BIGTRANS_ALIGN) * BIGTRANS_ALIGN;
			require_size = data_size + req_size;
		}
	}
	buf->buf = align_offset;
	buf->bufSize = ALIGN_SIZE(data_size, sectorSize);
	buf->req = (ReqHeader *)(buf->buf + align_data_size);
	buf->reqSize = req_size;

	while (!writeReqList.IsEmpty() && !isAbort) {	// isSameDrv == TRUE �̏ꍇ�A�K�� Empty
		if (buf->buf == mainBuf.Buf()) {
			if (freeOffset < usedOffset && (freeOffset - mainBuf.Buf()) >= require_size)
				break;
		}
		else {
			if (freeOffset < usedOffset || buf->buf + require_size <= freeOffset)
				break;
		}
		cv.Wait();
	}

	usedOffset = buf->buf + require_size;
	return	!isAbort;
}

BOOL FastCopy::PrepareReqBuf(int req_size, _int64 data_size, _int64 file_id, ReqBuf *buf)
{
	BOOL ret = TRUE;

	cv.Lock();

	if (errFileID) {
		if (errFileID == file_id)
			ret = FALSE;
		errFileID = 0;
	}

	if (ret)
		ret = AllocReqBuf(req_size, data_size, buf);

	cv.UnLock();

	return	ret;
}

BOOL FastCopy::SendRequest(Command command, ReqBuf *buf, FileStat *stat)
{
	BOOL	ret = TRUE;
	ReqBuf	tmp_buf;

	cv.Lock();

	if (buf == NULL) {
		buf = &tmp_buf;
		ret = AllocReqBuf(offsetof(ReqHeader, stat) + (stat ? stat->minSize : 0), 0, buf);
	}

	if (ret && !isAbort) {
		ReqHeader	*readReq;
		readReq				= buf->req;
		readReq->reqSize	= buf->reqSize;
		readReq->command	= command;
		readReq->buf		= buf->buf;
		readReq->bufSize	= buf->bufSize;
		if (stat)
			memcpy(&readReq->stat, stat, stat->minSize);

		if (isSameDrv) {
			readReqList.AddObj(readReq);
		}
		else {
			writeReqList.AddObj(readReq);
			cv.Notify();
		}
	}

	cv.UnLock();

	return	ret && !isAbort;
}

BOOL FastCopy::RecvRequest(void)
{
	cv.Lock();

	if (writeReq)
		WriteReqDone();

	if (readDestStatQueue)
		ReadDestStat();

	while (writeReqList.IsEmpty() && !isAbort) {
		cv.Wait();
		if (readDestStatQueue)
			ReadDestStat();
	}
	writeReq = writeReqList.TopObj();

	if (writeReq && writeReq->command == REQ_EOF)
		WriteReqDone();

	cv.UnLock();

	return	writeReq && !isAbort;
}

void FastCopy::WriteReqDone(void)
{
	writeReqList.DelObj(writeReq);
	freeOffset = (BYTE *)writeReq + writeReq->reqSize;
	if (!isSameDrv || writeReqList.IsEmpty())
		cv.Notify();
}

void FastCopy::SetErrFileID(_int64 file_id)
{
	cv.Lock();
	errFileID = file_id;
	cv.UnLock();
}

BOOL FastCopy::End(void)
{
	DWORD	total_tick = ::GetTickCount() - startTick;

	isAbort = TRUE;

	while (hWriteThread || hReadThread) {	// WaitForMultipleObject() �ւ̕ύX�͌��
		cv.Lock();
		cv.Notify();
		cv.UnLock();
		if (hReadThread && ::WaitForSingleObject(hReadThread, 100) != WAIT_TIMEOUT) {
			::CloseHandle(hReadThread);
			hReadThread = NULL;
		}
		if (hWriteThread && ::WaitForSingleObject(hWriteThread, 100) != WAIT_TIMEOUT) {
			::CloseHandle(hWriteThread);
			hWriteThread = NULL;
		}
	}

//	mainwin�p��free���Ȃ�
//	errBuf.FreeBuf();

	if (info.mode != DELETE_MODE) {
		delete [] openFiles;
		fileStatBuf.FreeBuf();
		dirStatBuf.FreeBuf();
		dstStatBuf.FreeBuf();
		dstStatIdxBuf.FreeBuf();
		mainBuf.FreeBuf();
	}

	return	TRUE;
}

BOOL FastCopy::Suspend(void)
{
	if (!hReadThread && !hWriteThread || isSuspend)
		return	FALSE;

	if (hReadThread)
		::SuspendThread(hReadThread);

	if (hWriteThread)
		::SuspendThread(hWriteThread);

	isSuspend = TRUE;
	suspendTick = ::GetTickCount();

	return	TRUE;
}

BOOL FastCopy::Resume(void)
{
	if (!hReadThread && !hWriteThread || !isSuspend)
		return	FALSE;

	isSuspend = FALSE;
	startTick += (::GetTickCount() - suspendTick);

	if (hReadThread)
		::ResumeThread(hReadThread);

	if (hWriteThread)
		::ResumeThread(hWriteThread);

	return	TRUE;
}

BOOL FastCopy::GetTransInfo(TransInfo *ti, BOOL fullInfo)
{
	ti->total = total;
	ti->errBuf = &errBuf;
	ti->isSameDrv = isSameDrv;
	ti->ignoreErr = info.ignoreErr;
	ti->tickCount = (isSuspend ? suspendTick : ::GetTickCount()) - startTick;
	if (fullInfo) {
		if (IS_WINNT_V)
			ConvertExternalPath(MakeAddr(dst, dstPrefixLen), ti->curPath, sizeof(ti->curPath)/sizeof(WCHAR));
		else
			sprintfV(ti->curPath, "%.250s", dst);
	}
	return	TRUE;
}

int FastCopy::FdatToFileStat(WIN32_FIND_DATAW *fdat, FileStat *stat, BOOL is_usehash)
{
	stat->fileID			= 0;
	stat->ftCreationTime	= fdat->ftCreationTime;
	stat->ftLastAccessTime	= fdat->ftLastAccessTime;
	stat->ftLastWriteTime	= fdat->ftLastWriteTime;
	stat->nFileSizeLow		= fdat->nFileSizeLow;
	stat->nFileSizeHigh		= fdat->nFileSizeHigh;
	stat->dwFileAttributes	= fdat->dwFileAttributes;
	stat->hFile				= INVALID_HANDLE_VALUE;
	stat->lastError			= 0;
	stat->isExists			= FALSE;
	stat->renameCount		= 0;
	stat->next				= NULL;

	int	len = (sprintfV(stat->cFileName, FMT_STR_V, fdat->cFileName) + 1) * CHAR_LEN_V;
	stat->size = len + offsetof(FileStat, cFileName);
	stat->minSize = ALIGN_SIZE(stat->size, 8);

	if (is_usehash) {
		stat->upperName = stat->cFileName + len;
		memcpy(stat->upperName, stat->cFileName, len);
		CharUpperV(stat->upperName);
		stat->hashVal = hashVal.MakeHash(stat->upperName, len);
		stat->size += len;
	}
	stat->size = ALIGN_SIZE(stat->size, 8);

	return	stat->size;
}

BOOL FastCopy::ConvertExternalPath(const void *path, void *buf, int max_buf, BOOL to_ansi)
{
	if (GetChar(path, 0) == '\\' && GetChar(path, 1) != '\\') {	// UNC
		if (to_ansi) {
			*(char *)buf = '\\';
			buf = (char *)buf + 1;
		}
		else {
			SetChar(buf, 0, '\\');
			buf = MakeAddr(buf, 1);
		}
		max_buf--;
	}
	if (to_ansi)
		::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)path, -1, (char *)buf, max_buf, 0, 0);
	else
		sprintfV(buf, L"%.*s", max_buf, path);
	return	TRUE;
}

FastCopy::Confirm::Result FastCopy::ConfirmErr(const char *message, const void *path, BOOL allow_continue)
{
	if (isAbort)
		return	Confirm::CANCEL_RESULT;

	char	path_buf[MAX_PATH_EX], msg_buf[MAX_PATH_EX + 100];
	DWORD	err_code = ::GetLastError();

	if (path && IS_WINNT_V) {
		ConvertExternalPath(path, path_buf, sizeof(path_buf), TRUE);
		path = path_buf;
	}

	int	len = sprintf(msg_buf, "%s(%u) : %s", message, err_code, path ? path : "");
	WriteErrLog(msg_buf, len);

	if (allow_continue == FALSE)
		isAbort = TRUE;
	else if (info.ignoreErr)
		return	Confirm::CONTINUE_RESULT;

	isSuspend = TRUE;
	suspendTick = ::GetTickCount();

	Confirm	 confirm = { msg_buf, allow_continue, path, Confirm::CONTINUE_RESULT };
	info.notifyWnd->SendMessage(info.uNotifyMsg, CONFIRM_NOTIFY, (LPARAM)&confirm);

	isSuspend = FALSE;
	startTick += (::GetTickCount() - suspendTick);

	switch (confirm.result) {
	case Confirm::IGNORE_RESULT:
		info.ignoreErr = TRUE;
		confirm.result = Confirm::CONTINUE_RESULT;
		break;

	case Confirm::CANCEL_RESULT:
		isAbort = TRUE;
		break;
	}
	return	confirm.result;
}

BOOL FastCopy::WriteErrLog(char *message, int len)
{
#define ERRMSG_SIZE		30
	::EnterCriticalSection(&errCs);

	BOOL	ret = TRUE;
	char	*msg_buf = (char *)errBuf.Buf() + errBuf.UsedSize();

	if (len == -1)
		len = strlen(message);
	len += ERRMSG_SIZE;

	if (errBuf.UsedSize() + len <= errBuf.MaxSize()) {
		if (errBuf.RemainSize() <= len)
			errBuf.Grow(ALIGN_SIZE(len, PAGE_SIZE));
		len = sprintf(msg_buf, "%s%s", errBuf.UsedSize() ? "\r\n" : "", message);
		errBuf.AddUsedSize(len);
	}
	else {
		if (errBuf.RemainSize()) {
			sprintf(msg_buf, "%s", "\r\n Too Many Errors...");
			errBuf.SetUsedSize(errBuf.MaxSize());
		}
		ret = FALSE;
	}
	::LeaveCriticalSection(&errCs);
	return	ret;
}

