// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"

extern HINSTANCE ghInstance;


// DLL �G���g���|�C���g
int APIENTRY DllMain(HINSTANCE hInstance,
					 DWORD fdwReason,
					 LPVOID lpvReserved)
{
	switch(fdwReason) {
	case DLL_PROCESS_ATTACH:
		ghInstance = hInstance;
		MEMLEAK_CHECK();
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

