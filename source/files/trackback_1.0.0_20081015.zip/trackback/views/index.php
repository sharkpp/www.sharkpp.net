<?php
/*******************************************************************************
  The MIT License

  Copyright (c) 2008 Shark++ Software.

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

 ==============================================================================
  参考として The MIT License の日本語訳を下記に併記しますが、頒布条件としては、
  上記原文に従ってください。
 ==============================================================================

  The MIT License

  Copyright (c) 2008 Shark++ Software.

  以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル
  （以下「ソフトウェア」）の複製を取得するすべての人に対し、ソフトウェアを
  無制限に扱うことを無償で許可します。これには、ソフトウェアの複製を使用、
  複写、変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、
  およびソフトウェアを提供する相手に同じことを許可する権利も無制限に含まれ
  ます。

  上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要
  な部分に記載するものとします。

  ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの
  保証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、
  および権利非侵害についての保証も含みますが、それに限定されるものではあり
  ません。作者または著作権者は、契約行為、不法行為、またはそれ以外であろう
  と、ソフトウェアに起因または関連し、あるいはソフトウェアの使用またはその
  他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も
  負わないものとします。 
 *******************************************************************************/
?>
<h1><?php echo __('Trackbacks'); ?></h1>

<ul>
	<li class="trackback-header">
		<ul class="trackback-header-row">
<!--			<li class="trackback-header-col-check" /> -->
			<li class="trackback-header-col-refpage"><?php echo __('Page'); ?></li>
			<li class="trackback-header-col-date"><?php echo __('Date'); ?></li>
			<li class="trackback-header-col-url"><?php echo __('From'); ?></li>
			<li class="trackback-header-col-excerpt"><?php echo __('Excerpt'); ?></li>
			<li class="trackback-header-col-modify"><?php echo __('Modify'); ?></li>
		</ul>
	</li>
</ul>
<ol>
<?php
	foreach($trackback as $tb):
	?>
	<li class="trackback-body">
		<ul class="trackback-body-row-<?php echo odd_even(); ?>">
<!--			<li class="trackback-body-col-check"><input style="" type="checkbox" /></li> -->
			<li class="trackback-body-col-refpage"><a href="<?php echo get_url('page/edit/'.$tb->page_id); ?>"><img alt="<?php echo __('Edit'); ?>" src="../frog/plugins/trackback/images/accessories-text-editor.png" /></a></li>
			<li class="trackback-body-col-date"><?php echo $tb->date('Y-m-d'); ?></li>
			<li class="trackback-body-col-url"><?php echo $tb->link(); ?></li>
			<li class="trackback-body-col-excerpt"><!-- [a href="<?php echo get_url('plugin/trackback/edit/'.$tb->id); ?>"] --><?php echo htmlspecialchars($tb->excerpt); ?><!-- [/a] --></li>
			<li class="trackback-body-col-delete"><a href="<?php echo get_url('plugin/trackback/delete/'.$tb->id); ?>"><img alt="<?php echo __('Delete'); ?>" src="../frog/plugins/trackback/images/user-trash.png" /></a></li>
			<li class="trackback-body-col-reject"><a href="<?php echo get_url('plugin/trackback/reject/'.$tb->id); ?>"><img alt="<?php echo __('Reject'); ?>" src="../frog/plugins/trackback/images/dialog-error.png" /></a></li>
		</ul>
	</li>
<?php endforeach; ?>
<?php if( count($trackback) < 1 ): ?>
	<li class="trackback-body">
		<ul class="trackback-body-row-notfound">
			<li class="trackback-body-col-notfound"><?php echo __('Trackback not found!'); ?></li>
		</ul>
	</li>
<?php endif; ?>
</ol>

<div class="trackback-page">

<?php if( 0 < $page ): ?>
	<span class="trackback-page-first"><a href="<?php echo get_url('plugin/trackback/trackback/'.'1'); ?>"><?php echo __('First'); ?></a></span>
<?php else: ?>
	<span class="trackback-page-first-disable"><?php echo __('First'); ?></span>
<?php endif; ?>

<?php if( 0 < $page ): ?>
	<span class="trackback-page-prev"><a href="<?php echo get_url('plugin/trackback/trackback/'.$page); ?>"><?php echo __('Prev'); ?></a></span>
<?php else: ?>
	<span class="trackback-page-prev-disable"><?php echo __('Prev'); ?></span>
<?php endif; ?>

<?php
	$disp_start_page = $page - 3;
	$disp_last_page  = $page + 3;
	if( $disp_start_page <= 0 ) {
		$disp_last_page += -$disp_start_page;
		$disp_start_page = 0;
	}
	if( $page_num <= $disp_last_page ) {
		$disp_start_page -= $disp_last_page - $page_num + 1;
		$disp_last_page   = $page_num - 1;
	}
	if( $disp_start_page < 0 ) {
		$disp_start_page = 0;
	}
	?>

<?php if( 0 < $disp_start_page ): ?>
	<span class="trackback-page-ellipsis">...</span>
<?php endif; ?>

<?php for($i = $disp_start_page; $i <= $disp_last_page; $i++ ): ?>
	<?php if( $i == $page ): ?>
		<span class="trackback-page-current"><?php echo $i + 1; ?></span>
	<?php else: ?>
		<span class="trackback-page-number"><a href="<?php echo get_url('plugin/trackback/trackback/'.($i+1)); ?>"><?php echo $i + 1; ?></a></span>
	<?php endif; ?>
<?php endfor; ?>

<?php if( $disp_last_page + 1 < $page_num ): ?>
	<span class="trackback-page-ellipsis">...</span>
<?php endif; ?>

<?php if( $page + 1 < $page_num ): ?>
	<span class="trackback-page-next"><a href="<?php echo get_url('plugin/trackback/trackback/'.($page+2)); ?>"><?php echo __('Next'); ?></a></span>
<?php else: ?>
	<span class="trackback-page-next-disable"><?php echo __('Next'); ?></span>
<?php endif; ?>

<?php if( $page + 1 < $page_num ): ?>
	<span class="trackback-page-last"><a href="<?php echo get_url('plugin/trackback/trackback/'.($page_num)); ?>"><?php echo __('Last'); ?></a></span>
<?php else: ?>
	<span class="trackback-page-last-disable"><?php echo __('Last'); ?></span>
<?php endif; ?>

</div>

<div id="popups">
	<div class="popup" id="trackback-popup-delete" style="display: none">
		<div id="busy" class="busy" style="display: none;"><img alt="Spinner" src="images/spinner.gif" /></div>
		<h3><?php echo __('Are you sure you wish to delete it?'); ?></h3>
		<p class="popup-buttons">
			<a id="trackback-popup-delete-link"><?php echo __('yes'); ?></a> 
			<a href="#" onclick="toggle_trackback_delete_popup(); return false;"><?php echo __('no'); ?></a>
		</p>
	</div>
</div>

