/* static char *miscdlg_id = 
	"@(#)Copyright (C) H.Shirouzu 2005   miscdlg.h	Ver1.12"; */
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2005-01-23(Sun)
	Update					: 2005-05-12(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef MISCDLG_H
#define MISCDLG_H
#include "tlib.h"
#include "resource.h"
#include "cfg.h"

class TAboutDlg : public TDlg {
public:
	TAboutDlg(TWin *_parent = NULL);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvCreate(LPARAM lParam);
};

class TExecConfirmDlg : public TDlg {
	void			*src;
	void			*dst;
	FastCopy::Mode	mode;

public:
	TExecConfirmDlg(FastCopy::Mode _mode, TWin *_parent) : TDlg((mode = _mode) == FastCopy::DELETE_MODE ? DELCONFIRM_DIALOG : COPYCONFIRM_DIALOG, _parent) {}
	int Exec(void *_src, void *_dst=NULL);
	virtual BOOL	EvCreate(LPARAM lParam);
};

class TSetupDlg : public TDlg {
	Cfg		*cfg;
public:
	TSetupDlg(Cfg *_cfg, TWin *_parent = NULL);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvCreate(LPARAM lParam);
};

class ShellExt {
	HMODULE	hShellExtDll;

public:
	ShellExt() { hShellExtDll = NULL; }
	~ShellExt() { if (hShellExtDll) UnLoad(); }
	BOOL	Load(char *parent_dir, char *dll_name);
	BOOL	UnLoad(void);
	BOOL	Status(void) { return	hShellExtDll ? TRUE : FALSE; }
	HRESULT	(WINAPI *RegistDllProc)(void);
	HRESULT	(WINAPI *UnRegistDllProc)(void);
	BOOL	(WINAPI *IsRegistDllProc)(void);
	BOOL	(WINAPI *SetMenuFlagsProc)(int);
	int		(WINAPI *GetMenuFlagsProc)(void);
	BOOL	(WINAPI *UpdateDllProc)(void);
};

class TShellExtDlg : public TDlg {
	Cfg			*cfg;
	ShellExt	shellExt;

public:
	TShellExtDlg(Cfg *_cfg, TWin *_parent = NULL);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvCreate(LPARAM lParam);
	virtual BOOL	EvNcDestroy(void);

	BOOL	RegistShellExt(BOOL is_regist);
	BOOL	ReflectStatus(void);
};

BOOL UpdateShellExt(Cfg *);

#define SHEXT_RIGHT_COPY	0x00000001
#define SHEXT_RIGHT_DELETE	0x00000002
#define SHEXT_DD_COPY		0x00000010
#define SHEXT_DD_MOVE		0x00000020
#define SHEXT_SUBMENU_RIGHT	0x00001000
#define SHEXT_SUBMENU_DD	0x00002000
#define SHEXT_SUBMENU_SEP	0x00004000

#endif
