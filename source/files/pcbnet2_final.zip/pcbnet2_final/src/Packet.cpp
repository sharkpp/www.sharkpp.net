// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "Packet.h"


Packet::Packet()
{
	Destroy();
}

Packet::~Packet()
{
	Destroy();
}

int Packet::Read(LPVOID buf, struct sockaddr *addr, int *addrlen, int nMax)
{
	PacketData d;
	int len, size;

	if (p.empty()) return 0;

	d = p.front();
	size = d.len;
	len = size<nMax ? size : nMax;
	if (buf != NULL) memcpy(buf, d.pt, len);
	if (addr != NULL) memcpy(addr, &d.addr, d.addrlen);
	if (addrlen != NULL) *addrlen = d.addrlen;
	delete [] d.pt;
	p.pop_front();

	return len;
}

int Packet::Peek(LPVOID buf, struct sockaddr *addr, int *addrlen, int nMax)
{
	PacketData d;
	int len, size;

	if (p.empty()) return 0;

	d = p.front();
	size = d.len;
	len = size<nMax ? size : nMax;
	if (buf != NULL) memcpy(buf, d.pt, len);
	if (addr != NULL) memcpy(addr, &d.addr, d.addrlen);
	if (addrlen != NULL) *addrlen = d.addrlen;

	return len;
}

BOOL Packet::Write(LPVOID pt, int len, struct sockaddr *addr, int addrlen, BOOL bDirect)
{
	PacketData d;

	memset(&d, 0, sizeof(PacketData));

	memcpy(&d.addr, addr, addrlen);
	d.addrlen = addrlen;

	d.len = len;
	if (bDirect) {
		d.pt = (char *)pt;
	}
	else {
		d.pt = new char[len];
		memcpy(d.pt, pt, len);
	}

	p.push_back(d);

	return FALSE;
}

int Packet::GetNextLength()
{
	return p.empty() ? 0 : p.front().len;
}

int Packet::Count()
{
	return (int)p.size();
}

int Packet::Size()
{
	int n;
	PacketList::iterator it;

	for(n=0, it=p.begin(); it!=p.end(); it++)
		n+=it->len;

	return n;
}

BOOL Packet::Destroy()
{
	PacketData d;
	while(! p.empty()) {
		d = p.front();
		delete [] d.pt;
		p.pop_front();
	}

	return FALSE;
}

