/**
 * @file  icdl.hpp
 * @brief IC�J�[�h�Ƌ��ؓǂݎ��N���X �錾
 *
 * Copyright(c) 2011 sharkpp<webmaster@sharkpp.net> All rights reserved.
 * 
 * The MIT License
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * �ȉ��ɎQ�l�Ƃ��� The MIT License �̓��{���𕹋L���܂����A�Еz�����Ƃ��ẮA
 * ��L�����ɏ]���Ă��������B
 * 
 * The MIT License
 * 
 * �ȉ��ɒ�߂�����ɏ]���A�{�\�t�g�E�F�A����ъ֘A�����̃t�@�C��
 * �i�ȉ��u�\�t�g�E�F�A�v�j�̕������擾���邷�ׂĂ̐l�ɑ΂��A�\�t�g�E�F�A��
 * �������Ɉ������Ƃ𖳏��ŋ����܂��B����ɂ́A�\�t�g�E�F�A�̕������g�p�A
 * ���ʁA�ύX�A�����A�f�ځA�Еz�A�T�u���C�Z���X�A�����/�܂��͔̔����錠���A
 * ����у\�t�g�E�F�A��񋟂��鑊��ɓ������Ƃ������錠�����������Ɋ܂܂�
 * �܂��B
 * 
 * ��L�̒��쌠�\������і{�����\�����A�\�t�g�E�F�A�̂��ׂĂ̕����܂��͏d�v
 * �ȕ����ɋL�ڂ�����̂Ƃ��܂��B
 * 
 * �\�t�g�E�F�A�́u����̂܂܁v�ŁA�����ł��邩�Öقł��邩���킸�A�����
 * �ۏ؂��Ȃ��񋟂���܂��B�����ł����ۏ؂Ƃ́A���i���A����̖ړI�ւ̓K�����A
 * ����ь�����N�Q�ɂ��Ă̕ۏ؂��܂݂܂����A����Ɍ��肳�����̂ł͂���
 * �܂���B��҂܂��͒��쌠�҂́A�_��s�ׁA�s�@�s�ׁA�܂��͂���ȊO�ł��낤
 * �ƁA�\�t�g�E�F�A�ɋN���܂��͊֘A���A���邢�̓\�t�g�E�F�A�̎g�p�܂��͂���
 * ���̈����ɂ���Đ������؂̐����A���Q�A���̑��̋`���ɂ��ĉ���̐ӔC��
 * ����Ȃ����̂Ƃ��܂��B 
 */

/**
 * @mainpage IC�J�[�h�Ƌ��ؓǂݎ�胉�C�u����
 *
 * @section intro_sec �n�߂�
 *
 * ���̃��C�u�������g�p����ɂ́AISO/IEC14443 Type B ���ǂݎ��\��
 * ��ڐGIC�J�[�h���[�_���K�v�ƂȂ�܂��B
 * 
 * �����́A�u�h�b�J�[�h�Ƌ��؋y�щ^�]�Ƌ��؍쐬�V�X�e�����d�l���v(�d�l���o�[�W�����ԍ��F004)��
 * ITU�AISO/IEC���̎������Q�l�ɂ��܂����B
 * 
 * ���̃��C�u�����́uIC�J�[�h�Ƌ��؁v�̃f�[�^�𐳊m�ɓǂ߂邱�Ƃ�ۏႵ�Ă��܂���B@n
 * �����N�����Ă��m��܂���A�ӔC�����܂���B
 * "At your own risk."�łǂ����B
 *
 * @section spec_sec �X�y�b�N
 *
 * �����A�Z���A�{�Г��̓ǂݍ��݁A�ʐ^�A�O���Ȃǂ̕\���ɑΉ����Ă��܂��B
 * �����R�[�h�̑Ή��͂��������ł��B@n
 * �d�q�ؖ�����p�����f�[�^�̌��؂ɂ͑Ή����Ă��܂���B
 * �ʐ^��O���̕\���̎�����gui�T���v�����Q�l�ɂ��Ă��������B
 *
 * @section license_sec ���C�Z���X��
 *
 * ���̃��C�u�����́AMIT���C�Z���X�ɂ��񋟂���܂��B@n
 *
 * Copyright(c) 2011 sharkpp All rights reserved. 
 *
 * ���L�̃��C�u�������\�[�X���p�b�P�[�W�ɂ͊܂܂�Ă��܂��B@n
 * ���C�Z���X���͊e���C�u�����̎w���ɏ]���Ă��������B
 *
 * OpenJpeg Library(http://www.openjpeg.org/)@n
 *  Copyright (c) 2002-2007, Communications and Remote Sensing Laboratory, Universite catholique de Louvain (UCL), Belgium @n
 *  Copyright (c) 2002-2007, Professor Benoit Macq @n
 *  Copyright (c) 2001-2003, David Janssens @n
 *  Copyright (c) 2002-2003, Yannick Verschueren @n
 *  Copyright (c) 2003-2007, Francois-Olivier Devaux and Antonin Descampe @n
 *  Copyright (c) 2005, Herve Drolon, FreeImage Team @n
 *  All rights reserved. @n
 *
 * jbig2dec(http://jbig2dec.sourceforge.net/) @n
 *  Copyright (C) 2001-2002 Artifex Software, Inc. @n
 *
 * @section usage_sec �g�p���@
 *
 * cui�T���v�������gui�T���v�����Q�l�ɂ��Ă��������B
 */

#include "icdlcard.h"
#include "scard.hpp"

#if defined(_MSC_VER) && 1000 < _MSC_VER
#pragma once
#endif

#ifndef ICDL_9209B7DD_A3F9_4F87_A420_F87EF1E179FD_INCLUDE_GUARD
#define ICDL_9209B7DD_A3F9_4F87_A420_F87EF1E179FD_INCLUDE_GUARD

/**
 * @class icdl
 * @brief IC�J�[�h�Ƌ��ؓǂݎ��N���X
 */
class icdl
{
	static const uint32_t ID_MF  = 0x00FF0000;
	static const uint32_t ID_DF1 = 0x00010000;
	static const uint32_t ID_DF2 = 0x00020000;
	static const uint32_t ID_DF3 = 0x00030000;

	scard		m_scard;
	bool		m_sending;
	uint8_t		m_result[2048];
	size_t		m_result_length;


	class scard_cb_type {
		icdl & inst;
		scard_cb_type & operator =(const scard_cb_type &);
	public:
		scard_cb_type(icdl & inst_);
		void operator()(const uint8_t* data, size_t length);
	};

#pragma pack(push, 1)
	struct {
		uint32_t	length;
		uint8_t *	data;
	} m_data[0xFFFF];
#pragma pack(pop)

	uint32_t	m_selected_file;

	bool		m_pin_valid;
	bool		m_prefetched;

	char*		m_code_buff;
	size_t		m_code_len;

private:

	void update(uint16_t tag, const uint8_t * data, size_t length);
	void read_file(uint32_t file_id, uint16_t elementary_file_id, void * buff, size_t * len);


	bool select_master_file();

	bool select_dedicated_file(const uint8_t * dedicated_file_id);

	bool select_elementary_file(uint16_t elementary_file_id);

	bool attestation(uint16_t elementary_file_id, uint16_t pin);

	int  get_allowed_match_count(uint16_t elementary_file_id);

	bool read(uint16_t offset, void * buff, size_t * len);


	void prefetch();


	const char * jis208_to_sjis(uint16_t tag, bool concat = false, size_t offset = 0, size_t length = ~0);

	ICDL_DATE_TYPE castDate(uint16_t tag, size_t offset = 0);

	ICDL_EUDC_TYPE castEudc(uint16_t tag);

	uint32_t       castUint(uint16_t tag);

	uint64_t       castUint64(uint16_t tag);

public:

	/// �R���X�g���N�^
	icdl();

	/// �f�X�g���N�^
	~icdl();

	/**
	 * @brief �J�[�h�֐ڑ�
	 * @param[in] reader_name �J�[�h���[�_�[����
	 * @retval    true        ��������
	 * @retval    false       �������s
	 */
	bool connect(const char * reader_name);

	/**
	 * @brief �J�[�h����ؒf
	 * @retval true  ��������
	 * @retval false �������s
	 */
	bool disconnect();

	/**
	 * @brief �Ïؔԍ��F��
	 * @param[in] pin1 �Ïؔԍ�1
	 * @param[in] pin2 �Ïؔԍ�2
	 * @retval true  ��������
	 * @retval false �������s
	 */
	bool pin_auth(uint16_t pin1, uint16_t pin2);

	/**
	 * @brief �Ïؔԍ�1�̔F�؂̎c���
	 * @retval 0�`3 �c���
	 * @retval -1   �s���A�������͎��s
	 */
	int get_pin1_auth_rest();

	/**
	 * @brief �Ïؔԍ�2�̔F�؂̎c���
	 * @retval 0�`3 �c���
	 * @retval -1   �s���A�������͎��s
	 */
	int get_pin2_auth_rest();

	/**
	 * @brief �J�[�h�ɐڑ����Ă��邩�ۂ�
	 * @retval true  �X�}�[�g�J�[�h���[�_�[�֐ڑ��ς�
	 * @retval false �X�}�[�g�J�[�h���[�_�[�֐ڑ����Ă��Ȃ�
	 */
	bool connected() const;


	const char * get_name_raw()
		{ prefetch(); return (const char*)m_data[TAG_NAME].data; }
	const char * get_name()
		{ prefetch(); return jis208_to_sjis(TAG_NAME); }


	const char * get_phonetic_name_raw()
		{ prefetch(); return (const char*)m_data[TAG_PHONETIC_NAME].data; }
	const char * get_phonetic_name()
		{ prefetch(); return jis208_to_sjis(TAG_PHONETIC_NAME); }


	const char * get_alias_name_raw()
		{ prefetch(); return (const char*)m_data[TAG_ALIAS_NAME].data; }
	const char * get_alias_name()
		{ prefetch(); return jis208_to_sjis(TAG_ALIAS_NAME); }


	const char * get_unified_name_raw()
		{ prefetch(); return (const char*)m_data[TAG_UNIFIED_NAME].data; }
	const char * get_unified_name()
		{ prefetch(); return jis208_to_sjis(TAG_UNIFIED_NAME); }


	ICDL_DATE_TYPE get_birthday()
		{ prefetch(); return castDate(TAG_BIRTHDAY); }


	const char * get_domicile_raw()
		{ prefetch(); return (const char*)m_data[TAG_DOMICILE].data; }
	const char * get_domicile()
		{ prefetch(); return jis208_to_sjis(TAG_DOMICILE); }


	ICDL_DATE_TYPE get_issue_date()
		{ prefetch(); return castDate(TAG_ISSUE_DATE); }


	uint32_t get_reference_number()
		{ prefetch(); return castUint(TAG_REFERENCE_NUMBER); }


	const char * get_license_color_raw()
		{ prefetch(); return (const char*)m_data[TAG_LICENSE_COLOR].data; }
	const char * get_license_color()
		{ prefetch(); return jis208_to_sjis(TAG_LICENSE_COLOR); }


	ICDL_DATE_TYPE get_expiration_date()
		{ prefetch(); return castDate(TAG_EXPIRATION_DATE); }


	const char * get_license_requirement()
		{ prefetch(); return jis208_to_sjis(TAG_LICENSE_REQUIREMENT1),
		                     jis208_to_sjis(TAG_LICENSE_REQUIREMENT2, true),
		                     jis208_to_sjis(TAG_LICENSE_REQUIREMENT3, true),
		                     jis208_to_sjis(TAG_LICENSE_REQUIREMENT4, true); }


	const char * get_license_requirement1_raw()
		{ prefetch(); return (const char*)m_data[TAG_LICENSE_REQUIREMENT1].data; }
	const char * get_license_requirement1()
		{ prefetch(); return jis208_to_sjis(TAG_LICENSE_REQUIREMENT1); }


	const char * get_license_requirement2_raw()
		{ prefetch(); return (const char*)m_data[TAG_LICENSE_REQUIREMENT2].data; }
	const char * get_license_requirement2()
		{ prefetch(); return jis208_to_sjis(TAG_LICENSE_REQUIREMENT2); }


	const char * get_license_requirement3_raw()
		{ prefetch(); return (const char*)m_data[TAG_LICENSE_REQUIREMENT3].data; }
	const char * get_license_requirement3()
		{ prefetch(); return jis208_to_sjis(TAG_LICENSE_REQUIREMENT3); }


	const char * get_license_requirement4_raw()
		{ prefetch(); return (const char*)m_data[TAG_LICENSE_REQUIREMENT4].data; }
	const char * get_license_requirement4()
		{ prefetch(); return jis208_to_sjis(TAG_LICENSE_REQUIREMENT4); }


	const char * get_police_authority_name_raw()
		{ prefetch(); return (const char*)m_data[TAG_POLICE_AUTHORITY_NAME].data; }
	const char * get_police_authority_name()
		{ prefetch(); return jis208_to_sjis(TAG_POLICE_AUTHORITY_NAME); }


	uint64_t get_license_number()
		{ prefetch(); return castUint64(TAG_LICENSE_NUMBER); }


	ICDL_DATE_TYPE get_license_date_motorcycle_or_small_or_moped()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_MOTORCYCLE_OR_SMALL_OR_MOPED); }


	ICDL_DATE_TYPE get_license_date_misc()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_MISC); }


	ICDL_DATE_TYPE get_license_date_class_2()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_CLASS_2); }


	ICDL_DATE_TYPE get_license_date_large_sized_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_LARGE_SIZED_MOTOR_VEHICLE); }


	ICDL_DATE_TYPE get_license_date_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_MOTOR_VEHICLE); }


	ICDL_DATE_TYPE get_license_date_large_sized_special_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_LARGE_SIZED_SPECIAL_MOTOR_VEHICLE); }


	ICDL_DATE_TYPE get_license_date_large_sized_motorcycle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_LARGE_SIZED_MOTORCYCLE); }


	ICDL_DATE_TYPE get_license_date_motorcycle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_MOTORCYCLE); }


	ICDL_DATE_TYPE get_license_date_small_sized_special_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_SMALL_SIZED_SPECIAL_MOTOR_VEHICLE); }


	ICDL_DATE_TYPE get_license_date_moped()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_MOPED); }


	ICDL_DATE_TYPE get_license_date_towing()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_TOWING); }


	ICDL_DATE_TYPE get_license_date_class_2_large_sized_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_CLASS_2_LARGE_SIZED_MOTOR_VEHICLE); }


	ICDL_DATE_TYPE get_license_date_class_2_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_CLASS_2_MOTOR_VEHICLE); }


	ICDL_DATE_TYPE get_license_date_class_2_large_sized_special_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_CLASS_2_LARGE_SIZED_SPECIAL_MOTOR_VEHICLE); }


	ICDL_DATE_TYPE get_license_date_class_2_towing()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_CLASS_2_TOWING); }


	ICDL_DATE_TYPE get_license_date_midsize_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_MIDSIZE_MOTOR_VEHICLE); }


	ICDL_DATE_TYPE get_license_date_class_2_midsize_motor_vehicle()
		{ prefetch(); return castDate(TAG_LICENSE_DATE_CLASS_2_MIDSIZE_MOTOR_VEHICLE); }


	const char * get_registered_domicile_raw()
		{ prefetch(); return (const char*)m_data[TAG_REGISTERED_DOMICILE].data; }
	const char * get_registered_domicile()
		{ prefetch(); return jis208_to_sjis(TAG_REGISTERED_DOMICILE); }


	ICDL_EUDC_TYPE get_eudc(uint16_t index = 0);

	const unsigned char * get_photo()
		{ prefetch(); return m_data[TAG_PHOTO].data; }
	size_t get_photo_length()
		{ prefetch(); return m_data[TAG_PHOTO].length; }


	bool is_append_presents()
		{ prefetch(); return m_data[TAG_APPEND_STATUS].length &&
		                     APPEND_STATUS_MARKER == *m_data[TAG_APPEND_STATUS].data; }


	const char * get_append_domicile_police_authority_name_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_domicile_police_authority_name(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_domicile_police_authority_name_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_domicile_police_authority_name(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_domicile_police_authority_name_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_domicile_police_authority_name(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_domicile_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_domicile_police_authority_name(index, 1 + 7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7); }


	const char * get_append_new_name_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_name(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_new_name_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_name(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_new_name_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_name(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_new_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_name(index, 1 + 7, m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7,
		                                    m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7); }
	const char * get_append_new_name_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_name(index, m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index, false,
		                                    m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2); }


	const char * get_append_new_phonetic_name_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_phonetic_name(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_new_phonetic_name_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_phonetic_name(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_new_phonetic_name_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_phonetic_name(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_new_phonetic_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_phonetic_name(index, 1 + 7, m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7,
		                                    m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7); }
	const char * get_append_new_phonetic_name_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_phonetic_name(index, m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index, false,
		                                    m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2); }


	const char * get_append_new_domicile_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_domicile(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_new_domicile_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_domicile(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_new_domicile_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_domicile(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_new_domicile(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_domicile(index, 1 + 7, m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7,
		                                    m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7); }
	const char * get_append_new_domicile_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_domicile(index, m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index, false,
		                                    m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2); }


	const char * get_append_new_license_requirement_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_license_requirement(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_new_license_requirement_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_license_requirement(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_new_license_requirement_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_license_requirement(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_new_license_requirement(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_license_requirement(index, 1 + 7, m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7,
		                                    m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7); }
	const char * get_append_new_license_requirement_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_new_license_requirement(index, m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index, false,
		                                    m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2); }


	const char * get_append_condition_release_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_condition_release(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_condition_release_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_condition_release(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_condition_release_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_condition_release(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_condition_release(uint16_t index = 0)
		{ prefetch(); if( verify_append_condition_release(index, 1 + 7, m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7,
		                                    m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7); }
	const char * get_append_condition_release_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_condition_release(index, m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index, false,
		                                    m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2); }


	const char * get_append_remark_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_remark(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_remark_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_remark(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_remark_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_remark(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_remark(uint16_t index = 0)
		{ prefetch(); if( verify_append_remark(index, 1 + 7, m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7,
		                                    m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7); }
	const char * get_append_remark_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_remark(index, m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index, false,
		                                    m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2); }


	const char * get_append_spare_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_spare(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_spare_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_spare(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_spare_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_spare(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_spare(uint16_t index = 0)
		{ prefetch(); if( verify_append_spare(index, 1 + 7, m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7,
		                                    m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7); }
	const char * get_append_spare_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_spare(index, m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index, false,
		                                    m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2); }


	bool is_append_registered_domicile_presents()
		{ prefetch(); return m_data[TAG_REGISTERED_DOMICILE_APPEND_STATUS].length &&
		                     APPEND_STATUS_MARKER == *m_data[TAG_REGISTERED_DOMICILE_APPEND_STATUS].data; }


	const char * get_append_registered_domicile_raw(uint16_t index = 0)
		{ prefetch(); if( verify_append_registered_domicile(index, 1 + 7) ) { return NULL; }
		              return (const char*)m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].data + 1 + 7; }
	const int get_append_registered_domicile_jisx(uint16_t index = 0)
		{ prefetch(); if( verify_append_registered_domicile(index, 0, 1) ) { return -1; }
		              return (*m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].data >> 4) * 10 + 
		                     (*m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].data & 15); }
	ICDL_DATE_TYPE get_append_registered_domicile_date(uint16_t index = 0)
		{ prefetch(); if( verify_append_registered_domicile(index, 1, 7) ) { return ICDL_DATE_TYPE(); }
		              return castDate(TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index, 1); }
	const char * get_append_registered_domicile(uint16_t index = 0)
		{ prefetch(); if( verify_append_registered_domicile(index, 1 + 7, m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index, false, 1 + 7,
		                                    m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2-1-7); }
	const char * get_append_registered_domicile_police_authority_name(uint16_t index = 0)
		{ prefetch(); if( verify_append_registered_domicile(index, m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2) ) { return NULL; }
		              return jis208_to_sjis(TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index, false,
		                                    m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length - 5*2); }


	const unsigned char * get_check_code()
		{ prefetch(); return m_data[TAG_CHECK_CODE].data; }
	size_t get_check_code_length()
		{ prefetch(); return m_data[TAG_CHECK_CODE].length; }


	const char * get_serial_number()
		{ prefetch(); return (const char*)m_data[TAG_SERIAL_NUMBER].data; }


	const char * get_publisher_name()
		{ prefetch(); return (const char*)m_data[TAG_PUBLISHER_NAME].data; }


	const char * get_principal_name()
		{ prefetch(); return (const char*)m_data[TAG_PRINCIPAL_NAME].data; }


	const unsigned char * get_principal_key_id()
		{ prefetch(); return m_data[TAG_PRINCIPAL_KEY_ID].data; }
	size_t get_principal_key_id_length()
		{ prefetch(); return m_data[TAG_PRINCIPAL_KEY_ID].length; }

private:


	bool verify_append_domicile_police_authority_name(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME8 - TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1 + index].length; }

	bool verify_append_new_name(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME8 - TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length; }


	bool verify_append_new_phonetic_name(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME8 - TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1 + index].length; }


	bool verify_append_new_domicile(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME8 - TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length; }


	bool verify_append_new_license_requirement(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME8 - TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 + index].length; }


	bool verify_append_condition_release(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME8 - TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1 + index].length; }


	bool verify_append_remark(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME8 - TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1 + index].length; }


	bool verify_append_spare(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME8 - TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1 + index].length; }


	bool verify_append_registered_domicile(uint16_t index, size_t offset, size_t length = 0)
		{ return index < TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME5 - TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 &&
		         m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].data &&
		         offset + length < m_data[TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 + index].length; }
};

#endif
