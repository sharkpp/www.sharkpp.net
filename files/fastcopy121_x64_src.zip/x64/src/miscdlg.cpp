static char *miscdlg_id = 
	"@(#)Copyright (C) H.Shirouzu 2005   miscdlg.cpp	Ver1.12";
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2005-01-23(Sun)
	Update					: 2005-05-10(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "mainwin.h"
#include <stdio.h>

/*
	About Dialog����������
*/
TAboutDlg::TAboutDlg(TWin *_parent) : TDlg(ABOUT_DIALOG, _parent)
{
}

/*
	Window �������� CallBack
*/
BOOL TAboutDlg::EvCreate(LPARAM lParam)
{
	if (rect.left == CW_USEDEFAULT)
	{
		GetWindowRect(&rect);
		int xsize = rect.right - rect.left, ysize = rect.bottom - rect.top;
		int	cx = ::GetSystemMetrics(SM_CXFULLSCREEN), cy = ::GetSystemMetrics(SM_CYFULLSCREEN);
		int	x = (cx - xsize)/2;
		int y = (cy - ysize)/2;

		MoveWindow((x < 0) ? 0 : x % (cx - xsize), (y < 0) ? 0 : y % (cy - ysize), xsize, ysize, FALSE);
	}
	else
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);

	return	TRUE;
}

BOOL TAboutDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hWndCtl)
{
	switch (wID)
	{
	case IDOK:
	case IDCANCEL:
		EndDialog(TRUE);
		return	TRUE;

	case URL_BUTTON:
		::ShellExecute(NULL, NULL, GetLoadStr(IDS_FASTCOPYURL), NULL, NULL, SW_SHOW);
		return	TRUE;
	}
	return	FALSE;
}

/*
	Setup Dialog����������
*/
TSetupDlg::TSetupDlg(Cfg *_cfg, TWin *_parent) : TDlg(SETUP_DIALOG, _parent)
{
	cfg = _cfg;
}

/*
	Window �������� CallBack
*/
BOOL TSetupDlg::EvCreate(LPARAM lParam)
{
	SetDlgItemInt(BUFSIZE_EDIT, cfg->bufSize);
	SetDlgItemInt(MAXTRANS_EDIT, cfg->maxTransSize);
	SetDlgItemInt(NONBUFMINNTFS_EDIT, cfg->nbMinSizeNtfs);
	SetDlgItemInt(NONBUFMINFAT_EDIT, cfg->nbMinSizeFat);
	SetDlgItemInt(HISTORY_EDIT, cfg->maxHistoryNext);
	CheckDlgButton(IGNORE_CHECK, cfg->ignoreErr);
	CheckDlgButton(ESTIMATE_CHECK, cfg->estimateMode);
	CheckDlgButton(ERRLOG_CHECK, cfg->isErrLog);
	CheckDlgButton(EXECCONFIRM_CHECK, cfg->execConfirm);

	if (rect.left == CW_USEDEFAULT)
	{
		GetWindowRect(&rect);
		int xsize = rect.right - rect.left, ysize = rect.bottom - rect.top;
		int	cx = ::GetSystemMetrics(SM_CXFULLSCREEN), cy = ::GetSystemMetrics(SM_CYFULLSCREEN);
		int	x = (cx - xsize)/2;
		int y = (cy - ysize)/2;

		MoveWindow((x < 0) ? 0 : x % (cx - xsize), (y < 0) ? 0 : y % (cy - ysize), xsize, ysize, FALSE);
	}
	else
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);

	return	TRUE;
}

BOOL TSetupDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hWndCtl)
{
	switch (wID)
	{
	case IDOK:
		cfg->bufSize = GetDlgItemInt(BUFSIZE_EDIT);
		cfg->maxTransSize = GetDlgItemInt(MAXTRANS_EDIT);
		cfg->nbMinSizeNtfs = GetDlgItemInt(NONBUFMINNTFS_EDIT);
		cfg->nbMinSizeFat = GetDlgItemInt(NONBUFMINFAT_EDIT);
		cfg->maxHistoryNext = GetDlgItemInt(HISTORY_EDIT);
		cfg->ignoreErr = IsDlgButtonChecked(IGNORE_CHECK);
		cfg->estimateMode = IsDlgButtonChecked(ESTIMATE_CHECK);
		cfg->isErrLog = IsDlgButtonChecked(ERRLOG_CHECK);
		cfg->execConfirm = IsDlgButtonChecked(EXECCONFIRM_CHECK);
		cfg->WriteIni();
		EndDialog(IDOK);
		return	TRUE;

	case IDCANCEL:
		EndDialog(IDCANCEL);
		return	TRUE;
	}
	return	FALSE;
}


/*
	ShellExt
*/
#define CURRENT_SHEXTDLL	"fastext1.dll"
#define REGIST_PROC			"DllRegisterServer"
#define UNREGIST_PROC		"DllUnregisterServer"
#define ISREGIST_PROC		"IsRegistServer"
#define SETMENUFLAGS_PROC	"SetMenuFlags"
#define GETMENUFLAGS_PROC	"GetMenuFlags"
#define UPDATEDLL_PROC		"UpdateDll"

BOOL ShellExt::Load(char *parent_dir, char *dll_name)
{
	if (hShellExtDll)
		UnLoad();

	char	path[MAX_PATH];
	MakePath(path, parent_dir, dll_name);
	if ((hShellExtDll = TLoadLibrary(path)) == NULL)
		return	FALSE;

	RegistDllProc		= (HRESULT (WINAPI *)(void))GetProcAddress(hShellExtDll, REGIST_PROC);
	UnRegistDllProc		= (HRESULT (WINAPI *)(void))GetProcAddress(hShellExtDll, UNREGIST_PROC);
	IsRegistDllProc		= (BOOL (WINAPI *)(void))GetProcAddress(hShellExtDll, ISREGIST_PROC);
	SetMenuFlagsProc	= (BOOL (WINAPI *)(int))GetProcAddress(hShellExtDll, SETMENUFLAGS_PROC);
	GetMenuFlagsProc	= (int (WINAPI *)(void))GetProcAddress(hShellExtDll, GETMENUFLAGS_PROC);
	UpdateDllProc		= (BOOL (WINAPI *)(void))GetProcAddress(hShellExtDll, UPDATEDLL_PROC);

	if (!RegistDllProc || !UnRegistDllProc || !IsRegistDllProc || !SetMenuFlagsProc || !GetMenuFlagsProc || !UpdateDllProc) {
		::FreeLibrary(hShellExtDll);
		hShellExtDll = NULL;
		return	FALSE;
	}
	return	TRUE;
}

BOOL ShellExt::UnLoad(void)
{
	if (hShellExtDll) {
		::FreeLibrary(hShellExtDll);
		hShellExtDll = NULL;
	}
	return	TRUE;
}

/*
	ShellExt Dialog����������
*/
TShellExtDlg::TShellExtDlg(Cfg *_cfg, TWin *_parent) : TDlg(SHELLEXT_DIALOG, _parent)
{
	cfg = _cfg;
}

/*
	Window �������� CallBack
*/
BOOL TShellExtDlg::EvCreate(LPARAM lParam)
{
	if (shellExt.Load(cfg->execDir, CURRENT_SHEXTDLL) == FALSE) {
		MessageBox("Can't load " CURRENT_SHEXTDLL);
		PostMessage(WM_CLOSE, 0, 0);
		return	FALSE;
	}
	CheckDlgButton(AUTOCLOSE_CHECK, cfg->shextAutoClose);
	CheckDlgButton(TASKTRAY_CHECK, cfg->shextTaskTray);
	CheckDlgButton(RIGHT_NOCONFIRM_CHECK, cfg->shextRNoConfirm);
	CheckDlgButton(DD_NOCONFIRM_CHECK, cfg->shextDdNoConfirm);

	ReflectStatus();

	if (rect.left == CW_USEDEFAULT)
	{
		GetWindowRect(&rect);
		int xsize = rect.right - rect.left, ysize = rect.bottom - rect.top;
		int	cx = ::GetSystemMetrics(SM_CXFULLSCREEN), cy = ::GetSystemMetrics(SM_CYFULLSCREEN);
		int	x = (cx - xsize)/2;
		int y = (cy - ysize)/2;

		MoveWindow((x < 0) ? 0 : x % (cx - xsize), (y < 0) ? 0 : y % (cy - ysize), xsize, ysize, FALSE);
	}
	else
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);

	return	TRUE;
}

BOOL TShellExtDlg::ReflectStatus(void)
{
	BOOL	isRegist = shellExt.IsRegistDllProc();

	SetDlgItemText(IDSHELLEXT_OK, isRegist ? GetLoadStr(IDS_SHELLEXT_MODIFY) : GetLoadStr(IDS_SHELLEXT_EXEC));
	::EnableWindow(GetDlgItem(IDSHELLEXT_CANCEL), isRegist);

	int	flags = shellExt.GetMenuFlagsProc();
	CheckDlgButton(RIGHT_COPY_CHECK, flags & SHEXT_RIGHT_COPY);
	CheckDlgButton(RIGHT_DELETE_CHECK, flags & SHEXT_RIGHT_DELETE);
	CheckDlgButton(DD_COPY_CHECK, flags & SHEXT_DD_COPY);
	CheckDlgButton(DD_MOVE_CHECK, flags & SHEXT_DD_MOVE);

	if (flags != -1) {
		CheckDlgButton(RIGHT_SUBMENU_CHECK, flags & SHEXT_SUBMENU_RIGHT);
		CheckDlgButton(DD_SUBMENU_CHECK, flags & SHEXT_SUBMENU_DD);
	}

	return	TRUE;
}

BOOL TShellExtDlg::EvNcDestroy(void)
{
	if (shellExt.Status())
		shellExt.UnLoad();
	return	TRUE;
}

BOOL TShellExtDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hWndCtl)
{
	switch (wID)
	{
	case IDSHELLEXT_OK: case IDSHELLEXT_CANCEL:
		if (RegistShellExt(wID == IDSHELLEXT_OK ? TRUE : FALSE) == FALSE)
			MessageBox("ShellExt Error");
		ReflectStatus();
		return	TRUE;

	case IDOK: case IDCANCEL:
		EndDialog(wID);
		return	TRUE;
	}
	return	FALSE;
}

BOOL TShellExtDlg::RegistShellExt(BOOL is_regist)
{
	if (shellExt.Status() == FALSE)
		return	FALSE;

	cfg->shextAutoClose = IsDlgButtonChecked(AUTOCLOSE_CHECK);
	cfg->shextTaskTray = IsDlgButtonChecked(TASKTRAY_CHECK);
	cfg->shextRNoConfirm = IsDlgButtonChecked(RIGHT_NOCONFIRM_CHECK);
	cfg->shextDdNoConfirm = IsDlgButtonChecked(DD_NOCONFIRM_CHECK);
	cfg->WriteIni();

	if (!is_regist)
		return	shellExt.UnRegistDllProc() == S_OK ? TRUE : FALSE;

	int		flags = 0;

	if (IsDlgButtonChecked(RIGHT_COPY_CHECK))
		flags |= SHEXT_RIGHT_COPY;

	if (IsDlgButtonChecked(RIGHT_DELETE_CHECK))
		flags |= SHEXT_RIGHT_DELETE;

	if (IsDlgButtonChecked(RIGHT_SUBMENU_CHECK))
		flags |= SHEXT_SUBMENU_RIGHT;

	if (IsDlgButtonChecked(DD_COPY_CHECK))
		flags |= SHEXT_DD_COPY;

	if (IsDlgButtonChecked(DD_MOVE_CHECK))
		flags |= SHEXT_DD_MOVE;

	if (IsDlgButtonChecked(DD_SUBMENU_CHECK))
		flags |= SHEXT_SUBMENU_DD;

	if (shellExt.RegistDllProc() != S_OK)
		return	FALSE;

	return	shellExt.SetMenuFlagsProc(flags);
}

BOOL UpdateShellExt(Cfg *cfg)
{
	ShellExt	shellExt;

	return	shellExt.Load(cfg->execDir, CURRENT_SHEXTDLL) && shellExt.UpdateDllProc();
}

int TExecConfirmDlg::Exec(void *_src, void *_dst)
{
	src = _src;
	dst = _dst;

	return	TDlg::Exec();
}

BOOL TExecConfirmDlg::EvCreate(LPARAM lParam)
{
	if (mode == FastCopy::MOVE_MODE)
		SetWindowText(GetLoadStr(IDS_MOVECONFIRM));

	SendDlgItemMessage(MESSAGE_EDIT, EM_SETWORDBREAKPROC, 0, (LPARAM)EditWordBreakProc);
	SetDlgItemTextV(SRC_EDIT, src);
	if (dst)
		SetDlgItemTextV(DST_EDIT, dst);

	if (rect.left == CW_USEDEFAULT) {
		GetWindowRect(&rect);
		rect.left += 30, rect.right += 30;
		rect.top += 30, rect.bottom += 30;
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);
	}

	Show();
	SetForceForegroundWindow();
	return	TRUE;
}


