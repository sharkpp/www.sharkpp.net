<?php


class Trackback extends Record
{
    const TABLE_NAME = 'trackback';
    const NONE = 0;
    const OPEN = 1;
    const CLOSED = 2;

    public static function find($args = null)
    {
        // �p�����[�^���Z�b�g
        $where    = isset($args['where']) ? trim($args['where']) : '';
        $order_by = isset($args['order']) ? trim($args['order']) : 'is_approved, trackback.created_on DESC';
        $offset   = isset($args['offset']) ? (int) $args['offset'] : 0;
        $limit    = isset($args['limit']) ? (int) $args['limit'] : 0;
        
        // �v���y�A�Ɏg�p����p�����[�^
        $where_string = empty($where) ? '' : "AND $where";
        $order_by_string = empty($order_by) ? '' : "ORDER BY $order_by";
        $limit_string = $limit > 0 ? "LIMIT $offset, $limit" : '';
        
        $tablename = self::tableNameFromClassName('Trackback');
        $tablename_page = self::tableNameFromClassName('Page');
        
        // SQL
        $sql = "SELECT trackback.*, page.title AS page_title FROM $tablename AS trackback, $tablename_page AS page ".
               "WHERE trackback.page_id = page.id $where_string $order_by_string $limit_string";
        
        $stmt = self::$__CONN__->prepare($sql);
        $stmt->execute();
        
        // SQL�����s
        if ($limit == 1)
        {
            return $stmt->fetchObject('Trackback');
        }
        else
        {
            $objects = array();
            while ($object = $stmt->fetchObject('Trackback'))
                $objects[] = $object;
            
            return $objects;
        }
    }
    
    public static function findAll($args = null)
    {
        return self::find($args);
    }
    
    public static function findById($id)
    {
        return self::find(array(
            'where' => 'trackback.id='.(int)$id,
            'limit' => 1
        ));
    }
    
} // Trackback class
