// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

// Packet.cpp: CPacket �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "Packet.h"

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CPacket::CPacket()
{
	m_pFirst = NULL;
	m_ppLast = &m_pFirst;
	m_length = 0;
	m_packets = 0;
}

CPacket::~CPacket()
{
	Destroy();
}

int CPacket::Read(LPVOID buf, struct sockaddr_in *addr, int nMax)
{
	LPPACKETSTRUCT &p = m_pFirst;
	PACKETSTRUCT *next;
	int len;

	memset(addr, 0, sizeof(sockaddr_in));
	if (nMax < 0)
		return 0;

	if (p == NULL) return 0;

	len = p->len;
	if (len > nMax) len = nMax;
	memcpy(buf, p->pt, len);
	memcpy(addr, &p->addr, sizeof(p->addr));

	next = p->next;
	delete [] p->pt;
	delete p;
	p = next;
	if (next == NULL)
		m_ppLast = &m_pFirst;

	m_length-=len;
	m_packets--;
	return len;
}

int CPacket::Peek(LPVOID buf, struct sockaddr_in *addr, int nMax)
{
	LPPACKETSTRUCT &p = m_pFirst;
	int len;

	memset(addr, 0, sizeof(sockaddr_in));
	if (nMax < 0)
		return 0;

	if (p == NULL) return 0;

	len = p->len;
	if (len > nMax) len = nMax;
	memcpy(buf, p->pt, len);
	memcpy(addr, &p->addr, sizeof(p->addr));
	return len;
}

BOOL CPacket::Write(LPVOID pt, struct sockaddr_in *addr, int len)
{
	PACKETSTRUCT **pp = m_ppLast;
	PACKETSTRUCT *pnew = new PACKETSTRUCT;
	char *pbuf;

	if (len < 0) return TRUE;

	pbuf = new char[len];
	memcpy(pbuf, pt, len);
	pnew->len = len;
	pnew->pt = pbuf;
	memcpy(&pnew->addr, addr, sizeof(struct sockaddr_in));
	pnew->next = NULL;
	*pp = pnew;
	m_ppLast = &pnew->next;

	m_length+=len;
	m_packets++;
	return FALSE;
}

BOOL CPacket::WriteDirect(LPVOID pt, struct sockaddr_in *addr, int len)
{
	PACKETSTRUCT **pp = m_ppLast;
	PACKETSTRUCT *pnew = new PACKETSTRUCT;

	if (len < 0) return TRUE;

	pnew->len = len;
	pnew->pt = (char *)pt;
	memcpy(&pnew->addr, addr, sizeof(struct sockaddr_in));
	pnew->next = NULL;
	*pp = pnew;
	m_ppLast = &pnew->next;

	m_length+=len;
	m_packets++;
	return FALSE;
}

int CPacket::GetNextLength()
{
	if (m_pFirst == NULL) return 0;
	return m_pFirst->len;
}

int CPacket::CountPacket()
{
	return m_packets;
}

BOOL CPacket::Destroy()
{
	PACKETSTRUCT *p = m_pFirst;
	PACKETSTRUCT *next;

	while(p != NULL) {
		next = p->next;
		delete [] p->pt;
		delete p;
		p = next;
	}

	m_pFirst = NULL;
	m_length = 0;
	m_packets = 0;
	return FALSE;
}

int CPacket::Count()
{
	return m_length;
}
