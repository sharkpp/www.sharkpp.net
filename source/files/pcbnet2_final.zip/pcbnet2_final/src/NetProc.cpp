// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"


LRESULT DNSProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si);
LRESULT PingProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si);

LRESULT TCPProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si);
LRESULT TCPListenProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si);
LRESULT UDPProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si);


LRESULT CALLBACK NetProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	SOCKETINFO *si = (SOCKETINFO *)GetWindowLong(hWnd, GWL_USERDATA);

	if (si != NULL)
		si->Lock();

	if (msg == WM_CREATE && si == NULL) {
		si = (SOCKETINFO *)((LPCREATESTRUCT)lParam)->lpCreateParams;
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)si);

		si->Lock();
		//	�e�탁���o�ϐ��̏�����
		si->hWnd = hWnd;
		si->stat.createTime = GetTickCount();
	}


	// �e�v���V�[�W���̌Ăяo��
	LRESULT lRes = 0;
	if (si != NULL) {
		switch(si->type) {
		case ST_TCP:
			lRes = TCPProc(hWnd, msg, wParam, lParam, si); break;
		case ST_TCPLIS:
			lRes = TCPListenProc(hWnd, msg, wParam, lParam, si); break;
		case ST_UDP:
			lRes = UDPProc(hWnd, msg, wParam, lParam, si); break;
		case ST_DNS:
			lRes = DNSProc(hWnd, msg, wParam, lParam, si); break;
		case ST_PING:
			lRes = PingProc(hWnd, msg, wParam, lParam, si); break;
		default:
			lRes = DefWindowProc(hWnd, msg, wParam, lParam); break;
		}
	}
	else {
		lRes = DefWindowProc(hWnd, msg, wParam, lParam);
	}

	if (msg == WM_CLOSE && si->bClosing && si->fAsyncTask == 0) {
		if (si->map.bAvailable && (si->map.err == 0)) {
			si->fAsyncTask |= ASYNC_NATMAP;
			_beginthread(DeletePortMappingProc, 0, (void *)si);
		}
		else {
			DestroyWindow(hWnd);
			PostQuitMessage(0);
		}
	}

	if (si != NULL)
		si->Unlock();

	return lRes;
}












void TCPResolverThreadProc(void *param)
{
	SOCKETINFO *si = (SOCKETINFO *)param;
	char s[16];
	addrinfo hints;

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = PF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	sprintf(s, "%d", ntohs(((struct sockaddr_in *)&si->addr)->sin_port));
	si->tcp.res0 = NULL;
	getaddrinfo(si->tcp.hostname, s, &hints, &si->tcp.res0);
	si->tcp.res = si->tcp.res0;

	si->Lock();
	si->fAsyncTask &= ~ASYNC_DNS;
	if (si->bClosing) {
		// ���̂܂ɂ����Ă���
		freeaddrinfo(si->tcp.res0);
		si->tcp.res = si->tcp.res0 = NULL;
		if (si->fAsyncTask == 0)
			PostMessage(si->hWnd, WM_CLOSE, 0, 0);
	}
	else {
		PostMessage(si->hWnd, WM_PCBNET_TRY_CONNECT, 0, 0);
	}
	si->Unlock();
}



LRESULT TCPProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si)
{
	int i, len, lim, ret;
	char *buf;
	SOCKETPAIR *sp;

	switch(msg) {
	case WM_CREATE:
		//	������
		memset(&si->tcp, 0, sizeof(si->tcp));
		si->tcp.bSending = TRUE;
		si->tcp.bBlocking = TRUE;
		si->tcp.r = new Buffer();
		si->tcp.s = new Buffer();
		si->tcp.iBufferLen = iMaxBuffer;
		break;

	case WM_PCBNET_CONNECT:
		if (si->bClosing) return -1;
		// �ڑ��J�n(wParam:u_short port, lParam:char *hostname)
		if (si->tcp.bSendable) return 1;
		getstr(si->tcp.hostname, (char *)lParam, sizeof(si->tcp.hostname));
		si->addrlen = sizeof(si->addr);
		ret = WSAStringToAddress(si->tcp.hostname, AF_INET6, NULL, (struct sockaddr *)&si->addr, &si->addrlen);
		if (ret == SOCKET_ERROR) {
			si->addrlen = sizeof(si->addr);
			WSAStringToAddress(si->tcp.hostname, AF_INET, NULL, (struct sockaddr *)&si->addr, &si->addrlen);
		}
		if (ret == SOCKET_ERROR) {
			// Non-Numerical Address
			// Resolver Thread���쐬����
			si->fAsyncTask |= ASYNC_DNS;
			((struct sockaddr_in *)&si->addr)->sin_port = htons((unsigned short)wParam);
			_beginthread(TCPResolverThreadProc, 0, (void *)si);
		}
		else {
			// Numerical Address������
			if (((struct sockaddr_in *)&si->addr)->sin_port == htons(0))
				((struct sockaddr_in *)&si->addr)->sin_port = htons((unsigned short)wParam);
			return TCPProc(hWnd, WM_PCBNET_TRY_CONNECT, 0, 0, si);
		}
		break;

	case WM_PCBNET_TRY_CONNECT:
		if (si->bClosing) return -1;
		if (si->addr.ss_family == PF_UNSPEC) {
			if (si->tcp.res == NULL) {
				// �S�Ď����������s
				si->err = WSANO_DATA;
				if (si->tcp.res0 != NULL)
					freeaddrinfo(si->tcp.res0);
				si->tcp.res0 = si->tcp.res = NULL;
				return 1;
			}
			si->addrlen = si->tcp.res->ai_addrlen;
			memcpy(&si->addr, si->tcp.res->ai_addr, si->addrlen);
			si->tcp.res = si->tcp.res->ai_next;
		}
		si->soc[0] = socket(si->addr.ss_family, SOCK_STREAM, 0);
		if (si->soc[0] == INVALID_SOCKET) {
			memset(&si->addr, 0, sizeof(si->addr));
			si->addrlen = 0;
			PostMessage(hWnd, WM_PCBNET_TRY_CONNECT, 0, 0);
			break;
		}
		si->socs = 1;

		// �\�P�b�g�Ɋւ���e��ݒ�
		i = iTCPSendBuf+1;
		setsockopt(si->soc[0], SOL_SOCKET, SO_SNDBUF, (char *)&i, sizeof(int));
		i = iTCPRecvBuf;
		setsockopt(si->soc[0], SOL_SOCKET, SO_RCVBUF, (char *)&i, sizeof(int));
		WSAAsyncSelect(si->soc[0], hWnd, WM_PCBNET_ASYNC, FD_READ | FD_WRITE | FD_CONNECT | FD_CLOSE);

		if (connect(si->soc[0], (struct sockaddr *)&si->addr, si->addrlen) != SOCKET_ERROR)
			break;	// @@error: WSAEADDRNOTAVAIL
		else if (WSAGetLastError() == WSAEWOULDBLOCK)
			break;

		closesocket(si->soc[0]);
		si->soc[0] = NULL;
		PostMessage(hWnd, WM_PCBNET_TRY_CONNECT, 0, 0);
		break;

	case WM_PCBNET_SOCKATTACH:
		if (si->bClosing) return -1;
		if (si->tcp.bSendable) return 1;
		if (si->soc[0] != NULL) return 1;
		sp = (SOCKETPAIR *)lParam;
		si->soc[0] = sp->soc;
		si->socs = 1;
		memcpy(&si->addr, &sp->addr, sp->addrlen);
		si->addrlen = sp->addrlen;
		WSAAsyncSelect(si->soc[0], hWnd, WM_PCBNET_ASYNC,
			FD_READ | FD_WRITE | FD_CLOSE);
		i = iTCPSendBuf+1;
		setsockopt(si->soc[0], SOL_SOCKET, SO_SNDBUF, (char *)&i, sizeof(int));
		i = iTCPRecvBuf;
		setsockopt(si->soc[0], SOL_SOCKET, SO_RCVBUF, (char *)&i, sizeof(int));
		si->tcp.bSendable = TRUE;
		break;

	case WM_PCBNET_ASYNC:
		// WinSock�񓯊����b�Z�[�W
		if (si->bClosing) return -1;
		if ((SOCKET)wParam != si->soc[0]) break;	// �ԈႢ���b�Z�[�W
		if (WSAGETSELECTEVENT(lParam) == FD_CONNECT && WSAGETSELECTERROR(lParam) != 0) {
			// �ڑ��Ɏ��s�D���g���C
			closesocket(si->soc[0]);
			si->soc[0] = NULL;
			memset(&si->addr, 0, sizeof(si->addr));
			si->addrlen = 0;
			PostMessage(hWnd, WM_PCBNET_TRY_CONNECT, 0, 0);
			break;
		}
		if (WSAGETSELECTERROR(lParam) != 0 && si->err == 0) {		// �G���[����
			si->err = (int)WSAGETSELECTERROR(lParam);
			si->tcp.bSendable = FALSE;
			break;
		}
		switch(WSAGETSELECTEVENT(lParam)) {
			case FD_READ:		// �f�[�^����
				si->tcp.bReadPending = FALSE;
				ioctlsocket(si->soc[0], FIONREAD, (unsigned long *)&len);
				if (len == 0) len = 16;
				lim = si->tcp.iBufferLen - si->tcp.r->Size();
				if (len > 4*1024*1024) len = 4*1024*1024;
				if (len > lim) len = lim;
				if (len > 0) {
					buf = new char[len];
					len = recv(si->soc[0], buf, len, 0);
					if (len > 0) {
						si->tcp.r->Write(buf, len);
						si->stat.receivedOctets += len;
					}
					delete [] buf;
				}
				else {
					si->tcp.bReadPending = TRUE;
				}
				break;
			case FD_WRITE:		// �f�[�^���M�\
				si->tcp.bBlocking = FALSE;
				SendMessage(hWnd, WM_PCBNET_SENDING, 0, 0);
				break;
			case FD_CONNECT:	// �ڑ�����
				if (si->tcp.res0 != NULL)
					freeaddrinfo(si->tcp.res0);
				si->tcp.res0 = si->tcp.res = NULL;
				si->tcp.bSendable = TRUE;
				break;
			case FD_CLOSE:		// �ڑ��ؒf�v��(FIN)
				if (si->tcp.bShutting) {
					si->err = WSAENOTCONN;
					si->tcp.bSendable = FALSE;
				}
				else {
					si->err = WSAEDISCON;
				}
				/*
				buf = new char[1024];
				while(1) {
					len = recv(si->soc[0], buf, 1024, 0);
					if (len == 0) break;
					else if (len == SOCKET_ERROR && WSAGetLastError() == WSAEWOULDBLOCK) continue;
					else if (len == SOCKET_ERROR) break;
					si->stat.receivedOctets += len;
				}
				delete [] buf;
				*/
				break;
		}
		break;

	case WM_PCBNET_SENDING:
		// �f�[�^���M
		if (si->bClosing) return -1;
		if (si->tcp.bBlocking) return 1;
		if (! si->tcp.bSendable) return 1;
		if (! si->tcp.bSending) break;
		if (si->err != 0 && si->err != WSAEDISCON) return 1;
		len = 0;
		buf = new char[iTCPSendBuf];
		while ( (len = si->tcp.s->Peek(buf, iTCPSendBuf)) != 0 ) {
			len = send(si->soc[0], buf, len, 0);
			if (len == SOCKET_ERROR) {
				if (WSAGetLastError() != WSAEWOULDBLOCK) {
					si->err = WSAGetLastError();
					si->tcp.bSendable = FALSE;
				}
				else {
					si->tcp.bBlocking = TRUE;
				}
				break;
			}
			else {
				si->tcp.s->Read(NULL, len);
				si->stat.sentOctets += len;
			}
		}
		delete [] buf;
		if (si->tcp.bShutting && /*si->tcp.s->Size() == 0 && */(! si->tcp.bBlocking) && (si->err == 0 || si->err == WSAEDISCON)) {
			shutdown(si->soc[0], SD_SEND);
			if (si->err == WSAEDISCON) {
				si->err = WSAENOTCONN;
				si->tcp.bSendable = FALSE;
			}
			else {
				si->err = WSAESHUTDOWN;
			}
		}
		break;

	case WM_CLOSE:
		// �\�P�b�g�̃N���[�Y(wParam:int errorcode)
		// �񓯊��^�X�N���c���Ă��Ă��������s�����
		if (! si->bClosing) {
			si->err = (int)wParam;
			si->tcp.bSendable = FALSE;
			if (si->soc[0] != NULL) {
				closesocket(si->soc[0]);
				si->soc[0] = NULL;
			}
			if (si->tcp.r != NULL) {
				si->tcp.r->Destroy();
				delete si->tcp.r;
				si->tcp.r = NULL;
			}
			if (si->tcp.s != NULL) {
				si->tcp.s->Destroy();
				delete si->tcp.s;
				si->tcp.s = NULL;
			}
			si->bClosing = TRUE;
		}
		break;

	case WM_DESTROY:
		// �񓯊��^�X�N���I��������Ŏ��s�����
		if (si->tcp.res0 != NULL)
			freeaddrinfo(si->tcp.res0);
		si->tcp.res0 = si->tcp.res = NULL;
		return DefWindowProc(hWnd, msg, wParam, lParam);
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}

LRESULT TCPListenProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si)
{
	int i;
	char s[64];
	SOCKETPAIR *sp;
	addrinfo hints, *res, *res0;
	int socid;
	SOCKET soc;

	switch(msg) {
	case WM_CREATE:
		//	������
		memset(&si->tcplis, 0, sizeof(si->tcplis));
		si->tcplis.bListening = FALSE;
		break;

	case WM_PCBNET_BIND:
		// Listen�J�n�DwParam�̓|�[�g�ԍ�
		if (si->bClosing) return -1;
		if (si->tcplis.bListening) return 1;
		memset(&hints, 0, sizeof(hints));
		hints.ai_family = PF_UNSPEC;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_flags = AI_PASSIVE;
		sprintf(s, "%d", (int)wParam);
		res0 = NULL;
		getaddrinfo(NULL, s, &hints, &res0);
		if (res0 == NULL) return 1;
		for(res=res0; res!=NULL && si->socs < MAX_SOCKET; res=res->ai_next) {
			if (!( res->ai_family == AF_INET || res->ai_family == AF_INET6)) continue;
			soc = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
			if (soc == INVALID_SOCKET) continue;
			if (bind(soc, res->ai_addr, res->ai_addrlen) == SOCKET_ERROR) {
				closesocket(soc);
				continue;
			}
			WSAAsyncSelect(soc, hWnd, WM_PCBNET_ASYNC, FD_ACCEPT);
			if (listen(soc, SOMAXCONN) == SOCKET_ERROR) {
				closesocket(soc);
				continue;
			}
			si->soc[si->socs] = soc;
			si->family[si->socs] = res->ai_family;
			si->socs++;
		}
		freeaddrinfo(res0);
		if (si->socs == 0)
			return 1;
		si->tcplis.bListening = TRUE;
		break;

	case WM_PCBNET_ACCEPT:
		// �ڑ����󂯓���DlParam��SOCKETPAIR *
		if (si->bClosing) return -1;
		if (! si->tcplis.bListening) return 3;
		for(socid=0; socid<si->socs; socid++) {
			if (si->tcplis.bIncoming[socid]) break;
		}
		if (socid == si->socs) return 1;
		si->tcplis.bIncoming[socid] = FALSE;
		sp = (SOCKETPAIR *)lParam;
		sp->addrlen = sizeof(sp->addr);
		sp->soc = accept(si->soc[socid], (struct sockaddr *)&(sp->addr), &sp->addrlen);
		if (sp->soc == INVALID_SOCKET)
			return 1;
		WSAAsyncSelect(sp->soc, hWnd, 0, 0);
		break;

	case WM_PCBNET_ASYNC:
		// WinSock�񓯊����b�Z�[�W
		if (si->bClosing) return -1;
		for(socid=0; socid<si->socs; socid++) {
			if ((SOCKET)wParam == si->soc[socid]) break;
		}
		if (socid == si->socs) break;	// �ԈႢ���b�Z�[�W
		if (si->type == ST_TCPLIS && WSAGETSELECTERROR(lParam) == WSAECONNABORTED)
			break;								// backlog����ꂽ
		if (WSAGETSELECTERROR(lParam) != 0 && si->err == 0) {		// �G���[����
			break;
		}
		switch(WSAGETSELECTEVENT(lParam)) {
			case FD_ACCEPT:
				si->tcplis.bIncoming[socid] = TRUE;
				break;
		}
		break;

	case WM_CLOSE:
		// �\�P�b�g�̃N���[�Y(wParam:int errorcode)
		// �񓯊��^�X�N���c���Ă��Ă��������s�����
		if (! si->bClosing) {
			si->err = (int)wParam;
			for(i=0; i<si->socs; i++) {
				if (si->soc[i] != NULL) {
					closesocket(si->soc[i]);
					si->soc[i] = NULL;
				}
			}
			si->bClosing = TRUE;
		}
		break;

	case WM_DESTROY:
		// �񓯊��^�X�N���I��������Ŏ��s�����
		return DefWindowProc(hWnd, msg, wParam, lParam);

	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}







void UDPResolverThreadProc(void *param)
{
	SOCKETINFO *si = (SOCKETINFO *)param;
	char s[16];
	addrinfo hints, *res, *res0;
	int i;

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = PF_UNSPEC;
	hints.ai_socktype = SOCK_DGRAM;
	sprintf(s, "%d", ntohs(((struct sockaddr_in *)&si->addr)->sin_port));
	res0 = NULL;
	getaddrinfo(si->udp.hostname, s, &hints, &res0);

	si->Lock();
	si->fAsyncTask &= ~ASYNC_DNS;
	si->udp.bResolved = TRUE;
	if (si->bClosing) {
		// ���̂܂ɂ����Ă���
		freeaddrinfo(res0);
		if (si->fAsyncTask == 0)
			PostMessage(si->hWnd, WM_CLOSE, 0, 0);
	}
	else {
		for(res=res0; res!=NULL; res=res->ai_next) {
			if (!(res->ai_family == PF_INET || res->ai_family == PF_INET6))
				continue;
			for(i=0; i<si->socs; i++) {
				if (si->family[i] == res->ai_family)
					break;
			}
			if (i < si->socs) {
				memcpy(&si->addr, res->ai_addr, res->ai_addrlen);
				si->addrlen = res->ai_addrlen;
				si->udp.bSendable = TRUE;
				break;
			}
		}
		freeaddrinfo(res0);
	}
	si->Unlock();
}



LRESULT UDPProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si)
{
	char *buf;
	SOCKET soc;
	unsigned short port;
	addrinfo hints, *res, *res0;
	struct sockaddr_storage addr;
	int addrlen;
	int len, c, i, ret;
	int socid;
	char s[64];
	BOOL b;

	switch(msg) {
	case WM_CREATE:
		memset(&si->udp, 0, sizeof(si->udp));
			//	������
		si->udp.r = new Packet;
		si->udp.s = new Packet;
		si->udp.iBufferLen = iMaxBuffer;
		break;

	case WM_PCBNET_BIND:
		// Listen�J�n�DwParam�̓|�[�g�ԍ�
		if (si->bClosing) return -1;
		if (si->udp.bBound) return 1;
		memset(&hints, 0, sizeof(hints));
		hints.ai_family = PF_UNSPEC;
		hints.ai_socktype = SOCK_DGRAM;
		hints.ai_flags = AI_PASSIVE;
		res0 = res = NULL;
		if (wParam == 0) {
			getaddrinfo(NULL, "4", &hints, &res0);
		}
		else {
			sprintf(s, "%d", (int)wParam);
			getaddrinfo(NULL, s, &hints, &res0);
		}
		if (res0 == NULL)
			return 1;
		port = htons((unsigned short)wParam);
		for(res=res0; res!=NULL; res=res->ai_next) {
			if (si->socs >= MAX_SOCKET) continue;
			if (!( res->ai_family == AF_INET || res->ai_family == AF_INET6)) continue;
			((struct sockaddr_in *)res->ai_addr)->sin_port = port;
			soc = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
			if (soc == INVALID_SOCKET)
				continue;
			if ((lParam&1) != 0) {
				b = TRUE;
				setsockopt(soc, SOL_SOCKET, SO_REUSEADDR, (char *)&b, sizeof(b));
			}
			if (bind(soc, res->ai_addr, res->ai_addrlen) == SOCKET_ERROR) {
				closesocket(soc);
				if (port != 0 && WSAGetLastError() == WSAEADDRINUSE)
					break;	// �|�[�g�̃R���t���N�g
				continue;
			}
			WSAAsyncSelect(soc, hWnd, WM_PCBNET_ASYNC, FD_READ | FD_WRITE);
			i = 1;
			setsockopt(soc, SOL_SOCKET, SO_BROADCAST, (char *)&i, sizeof(i)); // �f�t�H���g��Broadcast��L��
			if (port == 0) {
				addrlen = sizeof(addr);
				getsockname(soc, (struct sockaddr *)&addr, &addrlen);
				port = ((struct sockaddr_in *)&addr)->sin_port;
			}
			si->soc[si->socs] = soc;
			si->family[si->socs] = res->ai_family;
			si->socs++;
		}
		freeaddrinfo(res0);
		if (res != NULL) {
			// �ǂ����Ŏ��s
			for(i=0; i<si->socs; i++)
				closesocket(si->soc[i]);
			si->socs = 0;
			return 2;
		}

		if (si->socs == 0)
			return 1;
		si->udp.bBound = TRUE;
		break;

	case WM_PCBNET_CONNECT:
		// ���M��ݒ�J�n(wParam:u_short port, lParam:char *hostname)
		if (si->bClosing) return -1;
		if (! si->udp.bBound) return 1;
		si->udp.bResolved = FALSE;
		si->udp.bSendable = FALSE;
		getstr(si->udp.hostname, (char *)lParam, sizeof(si->udp.hostname));
		ret = SOCKET_ERROR;
		if (ret == SOCKET_ERROR) {
			addrlen = sizeof(addr);
			ret = WSAStringToAddress(si->udp.hostname, AF_INET6, NULL, (struct sockaddr *)&addr, &addrlen);
		}
		if (ret == SOCKET_ERROR) {
			addrlen = sizeof(addr);
			ret = WSAStringToAddress(si->udp.hostname, AF_INET, NULL, (struct sockaddr *)&addr, &addrlen);
		}
		if (ret == SOCKET_ERROR) {
			// Non-Numerical Address
			// Resolver Thread���쐬����
			si->fAsyncTask |= ASYNC_DNS;
			((struct sockaddr_in *)&si->addr)->sin_port = htons((unsigned short)wParam);
			_beginthread(UDPResolverThreadProc, 0, (void *)si);
		}
		else {
			// Numerical Address������
			si->addr = addr;
			si->addrlen = addrlen;
			if (((struct sockaddr_in *)&si->addr)->sin_port == htons(0))
				((struct sockaddr_in *)&si->addr)->sin_port = htons((unsigned short)wParam);
			for(i=0; i<si->socs; i++) {
				if (si->family[i] == addr.ss_family)
					break;
			}
			if (i < si->socs)
				si->udp.bSendable = TRUE;
			si->udp.bResolved = TRUE;
		}
		break;

	case WM_PCBNET_ASYNC:
		if (si->bClosing) return -1;
		if (WSAGETSELECTERROR(lParam) != 0) {
			si->err = (int)WSAGETSELECTERROR(lParam);
			break;
		}
		for(socid=0; socid<si->socs; socid++) {
			if ((SOCKET)wParam == si->soc[socid])
				break;
		}
		if (socid == si->socs) break;
		switch(WSAGETSELECTEVENT(lParam)) {
			case FD_READ:
				if (si->udp.r->Size() >= si->udp.iBufferLen) {
					si->udp.bReadPending = TRUE;
					break;
				}
				ioctlsocket(si->soc[socid], FIONREAD, (unsigned long *)&len);
				buf = new char[len>0 ? len : 1];
				addrlen = sizeof(addr);
				len = recvfrom(si->soc[socid], buf, len, 0, (struct sockaddr *)&addr, &addrlen);
				si->udp.r->Write(buf, len, (sockaddr *)&addr, addrlen, TRUE);
				si->udp.bReadPending = FALSE;
				si->stat.receivedOctets += len;
				break;
			case FD_WRITE:
				si->udp.bBlocking = FALSE;
				return UDPProc(hWnd, WM_PCBNET_SENDING, 0, 0, si);
		}
		break;

	case WM_PCBNET_SENDING:
		if (si->bClosing) return -1;
		if (si->udp.bBlocking) return 1;
		while(si->udp.s->Count() > 0) {
			len = si->udp.s->GetNextLength();
			buf = new char[len>0 ? len : 1];
			si->udp.s->Read(buf, (sockaddr *)&addr, &addrlen, len);
			for(i=0; i<si->socs; i++) {
				if (si->family[i] == addr.ss_family) {
					if (sendto(si->soc[i], buf, len, 0, (struct sockaddr *)&addr, addrlen) == SOCKET_ERROR) {
						if (WSAGetLastError() != WSAEWOULDBLOCK) {
							si->err = WSAGetLastError();
							break;
						}
						si->udp.bBlocking = TRUE;
					}
					else {
						si->stat.sentOctets += len;
					}
					break;
				}
			}
			delete [] buf;
		}
		break;


	case WM_CLOSE:
		// �\�P�b�g�̃N���[�Y(wParam:int errorcode)
		// �񓯊��^�X�N���c���Ă��Ă��������s�����
		if (! si->bClosing) {
			si->err = (int)wParam;
			si->udp.bBound = FALSE;
			si->udp.bSendable = FALSE;
			for(i=0; i<si->socs; i++) {
				closesocket(si->soc[i]);
				si->soc[i] = NULL;
			}
			si->socs = 0;
			if (si->udp.r != NULL) {
				si->udp.r->Destroy();
				delete si->udp.r;
				si->udp.r = NULL;
			}
			if (si->udp.s != NULL) {
				si->udp.s->Destroy();
				delete si->udp.s;
				si->udp.s = NULL;
			}
			si->bClosing = TRUE;
		}
		break;

	case WM_DESTROY:
		// �񓯊��^�X�N���I��������Ŏ��s�����
		return DefWindowProc(hWnd, msg, wParam, lParam);

	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}





void DNSResolverThreadProc(void *param)
{
	SOCKETINFO *si = (SOCKETINFO *)param;
	addrinfo hints, *res;
	int ret;
	char host[256], tmp[256];
	struct sockaddr_storage addr;
	int addrlen;

	host[0] = '\0';
	ret = SOCKET_ERROR;
	if (ret == SOCKET_ERROR) {
		addrlen = sizeof(addr);
		ret = WSAStringToAddress(si->dns.hostname, AF_INET6, NULL, (struct sockaddr *)&addr, &addrlen);
	}
	if (ret == SOCKET_ERROR) {
		addrlen = sizeof(addr);
		ret = WSAStringToAddress(si->dns.hostname, AF_INET, NULL, (struct sockaddr *)&addr, &addrlen);
	}
	if (ret != SOCKET_ERROR) {
		tmp[0] = '\0';
		if (getnameinfo((struct sockaddr *)&addr, addrlen, tmp, sizeof(tmp), NULL, 0, NI_NAMEREQD) == 0) {
			getstr(host, tmp, sizeof(host));
		}
	}

	memset(&hints, 0, sizeof(hints));
	si->dns.res0 = NULL;
	getaddrinfo(si->dns.hostname, NULL, &hints, &si->dns.res0);	// @@servname?

	si->Lock();
	si->dns.bReply = TRUE;
	strcpy(si->dns.hostname, host);
	if (si->dns.res0 != NULL) {
		for(res=si->dns.res0; res!=NULL; res=res->ai_next) {
			if (res->ai_family == PF_INET || res->ai_family == PF_INET6)
				break;
		}
		if (res == NULL) {
			si->err = WSANO_DATA;
		}
	}
	else {
		si->err = WSAGetLastError();
	}
	si->fAsyncTask &= ~ASYNC_DNS;
	if (si->bClosing) {
		// ���̂܂ɂ����Ă���
		freeaddrinfo(si->dns.res0);
		si->dns.res0 = NULL;
		if (si->fAsyncTask == 0)
			PostMessage(si->hWnd, WM_CLOSE, 0, 0);
	}

	si->Unlock();
}

LRESULT DNSProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si)
{
	switch(msg) {
	case WM_CREATE:
		memset(&si->dns, 0, sizeof(si->dns));
			//	������
		si->dns.bReply = FALSE;
		si->dns.res0 = NULL;
		break;

	case WM_PCBNET_DNSREQUEST:
		if (si->bClosing) return -1;
		if (si->dns.bReply) return 1;
		getstr(si->dns.hostname, (char *)lParam, sizeof(si->dns.hostname));
		if (si->dns.hostname[0] == '\0') {
			si->err = WSANO_DATA;
			si->dns.bReply = TRUE;
			break;
		}
		si->addrlen = sizeof(si->addr);
		si->fAsyncTask |= ASYNC_DNS;
		_beginthread(DNSResolverThreadProc, 0, (void *)si);
		break;

	case WM_CLOSE:
		// �\�P�b�g�̃N���[�Y(wParam:int errorcode)
		// �񓯊��^�X�N���c���Ă��Ă��������s�����
		if (! si->bClosing) {
			si->err = (int)wParam;
			si->bClosing = TRUE;
		}
		break;

	case WM_DESTROY:
		// �񓯊��^�X�N���I��������Ŏ��s�����
		if (si->dns.res0 != NULL)
			freeaddrinfo(si->dns.res0);
		si->dns.res0 = NULL;
		return DefWindowProc(hWnd, msg, wParam, lParam);

	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}




void PingProc(void *param)
{
	SOCKETINFO *si = (SOCKETINFO *)param;
	SOCKET soc;
	struct sockaddr_storage addr;
	int addrlen;
	struct sockaddr_storage fromaddr;
	int fromaddrlen;
	struct sockaddr_in *paddr4;
	struct sockaddr_in6 *paddr6;
	addrinfo hints, *res;
	int ret;
	icmp_hdr *icmp4;
	ip_hdr *ip4;
	DWORD uid;
	int len;
	int StartTime, TimeOut, Delta;
	char buf[4096];
	struct timeval tv;
	struct fd_set fd;
	int iTripTime;
	int err;
	unsigned char replycode;

	err = 0;
	iTripTime = 0;
	replycode = ICMP_NOREPLY;
	uid = GetTickCount() ^ ((DWORD)si) ^ GetCurrentThreadId();
	memset(&fromaddr, 0, sizeof(fromaddr));
	fromaddrlen = 0;

	ret = SOCKET_ERROR;
	if (FALSE/*@@ICMPV6 not supported now*/ && ret == SOCKET_ERROR) {
		addrlen = sizeof(addr);
		ret = WSAStringToAddress(si->ping.hostname, AF_INET6, NULL, (struct sockaddr *)&addr, &addrlen);
	}
	if (ret == SOCKET_ERROR) {
		addrlen = sizeof(addr);
		ret = WSAStringToAddress(si->ping.hostname, AF_INET, NULL, (struct sockaddr *)&addr, &addrlen);
	}
	if (ret == SOCKET_ERROR) {
		res = NULL;
		memset(&hints, 0, sizeof(hints));
		if (res == NULL && FALSE/*@@ICMPV6 not supported now*/) {
			hints.ai_family = PF_INET6;
			getaddrinfo(si->ping.hostname, "0", &hints, &res);	// @@servname?
		}
		if (res == NULL) {
			hints.ai_family = PF_INET;
			getaddrinfo(si->ping.hostname, "0", &hints, &res);	// @@servname?
		}
		if (res == NULL) {
			err = WSAGetLastError();
			goto EXIT;
		}
		memcpy(&addr, res->ai_addr, res->ai_addrlen);
		addrlen = res->ai_addrlen;
		freeaddrinfo(res);
	}

	if (addr.ss_family == PF_INET) {
		soc = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
		if (soc == NULL) {
			err = WSAENOTSOCK;
			goto EXIT;
		}
		setsockopt(soc, IPPROTO_IP, IP_TTL, (char *)&si->ping.TTL, sizeof(si->ping.TTL));
	}
	else {	/* PF_INET6 */
		soc = socket(AF_INET6, SOCK_RAW, IPPROTO_ICMPV6);
		if (soc == NULL) {
			err = WSAENOTSOCK;
			goto EXIT;
		}
		setsockopt(soc, IPPROTO_IPV6, IPV6_UNICAST_HOPS, (char *)&si->ping.TTL, sizeof(si->ping.TTL));
	}

	len = 64;	// fixed
	icmp4 = (icmp_hdr *)buf;
	memset(icmp4, 0, len);
	icmp4->Type = ICMP_ECHO;
	icmp4->SubCode = 0;
	icmp4->CheckSum = 0;
	icmp4->ping.dwId = uid;
	icmp4->CheckSum = CheckSum((char *)icmp4, len);
	sendto(soc, (char *)icmp4, len, 0, (struct sockaddr *)&addr, addrlen);

	StartTime = (int)GetTickCount();
	TimeOut = StartTime + si->ping.iTimeOut;
	while(Delta = TimeOut - ((int)GetTickCount()), Delta>=0) {
		tv.tv_sec = (Delta+10)/1000;
		tv.tv_usec = (Delta+10)%1000;
		FD_ZERO(&fd);
		FD_SET(soc, &fd);
		if (select(1, &fd, NULL, NULL, &tv) == 1) {
			len = recvfrom(soc, buf, sizeof(buf), 0, NULL, NULL);
			if (len <= 0) continue;
			if (addr.ss_family == PF_INET) {
				ip4 = (ip_hdr *)buf;
				icmp4 = (icmp_hdr *)(buf+sizeof(ip_hdr));
				if (icmp4->Type == ICMP_REPLY) {
					if (icmp4->ping.dwId != uid) continue;
				}
				else {
					if ( ((icmp_hdr *) ( ((char *)icmp4)+sizeof(icmp_hdr)+sizeof(ip_hdr) ))->ping.dwId != uid) continue;
				}
				iTripTime = ((int)GetTickCount()) - StartTime;
				replycode = icmp4->Type;
				paddr4 = (struct sockaddr_in *)&fromaddr;
				fromaddrlen = sizeof(struct sockaddr_in);
				memset(paddr4, 0, fromaddrlen);
				paddr4->sin_family = PF_INET;
				paddr4->sin_addr.s_addr = ip4->srcip;
				break;
			}
			else { /* PF_INET6 */
			}
		}
	}

	closesocket(soc);

	if (iTripTime > si->ping.iTimeOut)
		iTripTime = si->ping.iTimeOut;

EXIT:
	si->Lock();
	si->err = err;
	si->ping.iTripTime = iTripTime;
	si->ping.replycode = replycode;
	memcpy(&si->ping.fromaddr, &fromaddr, sizeof(fromaddr));
	si->ping.fromaddrlen = fromaddrlen;
	si->ping.bResult = TRUE;
	si->fAsyncTask &= ~ASYNC_PING;
	if (si->bClosing && si->fAsyncTask == 0)
		PostMessage(si->hWnd, WM_CLOSE, 0, 0);
	si->Unlock();
}





LRESULT PingProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, SOCKETINFO *si)
{
	int i;

	switch(msg) {
	case WM_CREATE:
		memset(&si->ping, 0, sizeof(si->ping));
			//	������
		break;

	case WM_PCBNET_PING:
		si->fAsyncTask |= ASYNC_PING;
		_beginthread(PingProc, 0, (void *)si);
		break;

	case WM_CLOSE:
		// �\�P�b�g�̃N���[�Y(wParam:int errorcode)
		// �񓯊��^�X�N���c���Ă��Ă��������s�����
		if (! si->bClosing) {
			si->err = (int)wParam;
			si->bClosing = TRUE;
		}
		break;

	case WM_DESTROY:
		// �񓯊��^�X�N���I��������Ŏ��s�����
		for(i=0; i<si->socs; i++) {
			if (si->soc[i] == NULL) continue;
			closesocket(si->soc[i]);
			si->soc[i] = NULL;
		}
		si->socs = 0;
		return DefWindowProc(hWnd, msg, wParam, lParam);

	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}










