#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDM_ABOUT                               104
#define IDI_GUI                                 107
#define IDI_SMALL                               108
#define IDC_GUI                                 109
#define IDD_MAIN_DLG                            111
#define IDB_BASE                                112
#define IDC_PIN1                                1002
#define IDC_SCARD_READER_LIST                   1003
#define IDC_SCARD_CONNECT                       40000
#define IDS_APP_TITLE                           40000
#define IDC_ICDL_IMAGE                          40001
#define IDC_PIN2                                40002
