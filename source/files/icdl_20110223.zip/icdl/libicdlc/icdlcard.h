/**
 * @file  icdlcard.h
 * @brief IC�J�[�h�Ƌ��� �萔��`
 *
 * Copyright(c) 2011 sharkpp<webmaster@sharkpp.net> All rights reserved.
 * 
 * The MIT License
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * �ȉ��ɎQ�l�Ƃ��� The MIT License �̓��{���𕹋L���܂����A�Еz�����Ƃ��ẮA
 * ��L�����ɏ]���Ă��������B
 * 
 * The MIT License
 * 
 * �ȉ��ɒ�߂�����ɏ]���A�{�\�t�g�E�F�A����ъ֘A�����̃t�@�C��
 * �i�ȉ��u�\�t�g�E�F�A�v�j�̕������擾���邷�ׂĂ̐l�ɑ΂��A�\�t�g�E�F�A��
 * �������Ɉ������Ƃ𖳏��ŋ����܂��B����ɂ́A�\�t�g�E�F�A�̕������g�p�A
 * ���ʁA�ύX�A�����A�f�ځA�Еz�A�T�u���C�Z���X�A�����/�܂��͔̔����錠���A
 * ����у\�t�g�E�F�A��񋟂��鑊��ɓ������Ƃ������錠�����������Ɋ܂܂�
 * �܂��B
 * 
 * ��L�̒��쌠�\������і{�����\�����A�\�t�g�E�F�A�̂��ׂĂ̕����܂��͏d�v
 * �ȕ����ɋL�ڂ�����̂Ƃ��܂��B
 * 
 * �\�t�g�E�F�A�́u����̂܂܁v�ŁA�����ł��邩�Öقł��邩���킸�A�����
 * �ۏ؂��Ȃ��񋟂���܂��B�����ł����ۏ؂Ƃ́A���i���A����̖ړI�ւ̓K�����A
 * ����ь�����N�Q�ɂ��Ă̕ۏ؂��܂݂܂����A����Ɍ��肳�����̂ł͂���
 * �܂���B��҂܂��͒��쌠�҂́A�_��s�ׁA�s�@�s�ׁA�܂��͂���ȊO�ł��낤
 * �ƁA�\�t�g�E�F�A�ɋN���܂��͊֘A���A���邢�̓\�t�g�E�F�A�̎g�p�܂��͂���
 * ���̈����ɂ���Đ������؂̐����A���Q�A���̑��̋`���ɂ��ĉ���̐ӔC��
 * ����Ȃ����̂Ƃ��܂��B 
 */

#if defined(_MSC_VER) && 1000 < _MSC_VER
#pragma once
#endif

#ifndef ICDL_0B6C1D32_C9E5_4823_A60F_BE457E03FE95_INCLUDE_GUARD
#define ICDL_0B6C1D32_C9E5_4823_A60F_BE457E03FE95_INCLUDE_GUARD

#if defined(ICDL_PHOTO_DECODE_ENABLE) || defined(ICDL_EUDC_DECODE_ENABLE)
#include <windows.h>
#endif

#if defined(_MSC_VER)

typedef unsigned char     uint8_t;
typedef   signed char      int8_t;
typedef unsigned short   uint16_t;
typedef   signed short    int16_t;
typedef unsigned int     uint32_t;
typedef   signed int      int32_t;
typedef unsigned __int64 uint64_t;
typedef   signed __int64  int64_t;

#else

#include <inttypes.h>

#endif



static const uint16_t SW_NO_ERROR                                  = 0x9000;

static const uint16_t SW_SELECTED_FILE_INVALIDATED                 = 0x6283;

static const uint16_t SW_VERIFICATION_FAILED                       = 0x6300;
static const uint16_t SW_VERIFICATION_FAILED_RETRY_COUNTER_0       = 0x63C0;
static const uint16_t SW_VERIFICATION_FAILED_RETRY_COUNTER_1       = 0x63C1;
static const uint16_t SW_VERIFICATION_FAILED_RETRY_COUNTER_2       = 0x63C2;
static const uint16_t SW_VERIFICATION_FAILED_RETRY_COUNTER_3       = 0x63C3;

static const uint16_t SW_NON_VOLATILE_MEMORY_UNCHANGED             = 0x6400;

static const uint16_t SW_MEMORY_FAILURE                            = 0x6581;
static const uint16_t SW_WRONG_LENGTH                              = 0x6700;

static const uint16_t SW_LOGICAL_CHANNEL_NOT_SUPPORTED             = 0x6881;
static const uint16_t SW_SECURE_MESSAGING_NOT_SUPPORTED            = 0x6882;

static const uint16_t SW_COMMAND_INCOMPATIBLE_WITH_FILE_STRUCTURE  = 0x6981;
static const uint16_t SW_SECURITY_STATUS_NOT_SATISFIED             = 0x6982;
static const uint16_t SW_REFERENCED_DATA_INVALIDATED               = 0x6984;
static const uint16_t SW_NO_CURRENT_EF                             = 0x6986;

static const uint16_t SW_FUNCTION_NOT_SUPPORTED                    = 0x6A81;
static const uint16_t SW_FILE_NOT_FOUND                            = 0x6A82;
static const uint16_t SW_INCORRECT_PARAMETERS_P1_P2                = 0x6A86;
static const uint16_t SW_Lc_INCONSISTENT_WITH_P1_P2                = 0x6A87;
static const uint16_t SW_REFERENCED_DATA_NOT_FOUND                 = 0x6A88;
static const uint16_t SW_OFFSET_OUTSIDE_THE_EF                     = 0x6B00;
static const uint16_t SW_INSTRUCTION_CODE_NOT_SUPPORTED_OR_INVALID = 0x6D00;
static const uint16_t SW_CLASS_NOT_SUPPORTED                       = 0x6E00;


static const uint16_t DPIN = (uint16_t)~0;


static const uint16_t EF_ID_MF_EF01  = 0x2F01;
static const uint16_t EF_ID_MF_EF02  = 0x000A;
static const uint16_t EF_ID_MF_IEF01 = 0x0001;
static const uint16_t EF_ID_MF_IEF02 = 0x0002;
static const uint16_t EF_ID_DF1_EF01 = 0x0001;
static const uint16_t EF_ID_DF1_EF02 = 0x0002;
static const uint16_t EF_ID_DF1_EF03 = 0x0003;
static const uint16_t EF_ID_DF1_EF04 = 0x0004;
static const uint16_t EF_ID_DF1_EF05 = 0x0005;
static const uint16_t EF_ID_DF1_EF06 = 0x0006;
static const uint16_t EF_ID_DF1_EF07 = 0x0007;
static const uint16_t EF_ID_DF2_EF01 = 0x0001;
static const uint16_t EF_ID_DF3_EF01 = 0x0001;


static const uint8_t AID_DF1[16] = { 0xA0, 0x00, 0x00, 0x02, 0x31,
                                     0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static const uint8_t AID_DF2[16] = { 0xA0, 0x00, 0x00, 0x02, 0x31,
                                     0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static const uint8_t AID_DF3[16] = { 0xA0, 0x00, 0x00, 0x02, 0x48,
                                     0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };


static const uint8_t LICENSE_TYPE_YET_ACQUIRED[6]          = {    '0','0','0','0','0','0'};
static const uint8_t LICENSE_TYPE_UNKNOWN_DATE_ACQUIRED[7] = {'*','*','*','*','*','*','*'};


static const uint16_t TAG_CARD_PUBLISHER = 0x45;
static const uint16_t TAG_PREVIOUS_ISSUE = 0x46;
static const size_t   MAXLEN_CARD_PUBLISHER = 11;
static const size_t   MAXLEN_PREVIOUS_ISSUE = 2;


static const uint16_t TAG_PIN_CONFIG = 0x05;
static const size_t   MAXLEN_PIN_CONFIG = 1;

static const uint8_t  PIN_ENABLE      = 0x01;
static const uint8_t  PIN_DISABLE     = 0x00;
static const uint8_t  PIN_ENABLE_MASK = 0x01;


static const uint16_t TAG_JISX_REVISION                                          = 0x11;
static const uint16_t TAG_NAME                                                   = 0x12;
static const uint16_t TAG_PHONETIC_NAME                                          = 0x13;
static const uint16_t TAG_ALIAS_NAME                                             = 0x14;
static const uint16_t TAG_UNIFIED_NAME                                           = 0x15;
static const uint16_t TAG_BIRTHDAY                                               = 0x16;
static const uint16_t TAG_DOMICILE                                               = 0x17;
static const uint16_t TAG_ISSUE_DATE                                             = 0x18;
static const uint16_t TAG_REFERENCE_NUMBER                                       = 0x19;
static const uint16_t TAG_LICENSE_COLOR                                          = 0x1A;
static const uint16_t TAG_EXPIRATION_DATE                                        = 0x1B;
static const uint16_t TAG_LICENSE_REQUIREMENT1                                   = 0x1C;
static const uint16_t TAG_LICENSE_REQUIREMENT2                                   = 0x1D;
static const uint16_t TAG_LICENSE_REQUIREMENT3                                   = 0x1E;
static const uint16_t TAG_LICENSE_REQUIREMENT4                                   = 0x1F;
static const uint16_t TAG_POLICE_AUTHORITY_NAME                                  = 0x20;
static const uint16_t TAG_LICENSE_NUMBER                                         = 0x21;
static const uint16_t TAG_LICENSE_DATE_MOTORCYCLE_OR_SMALL_OR_MOPED              = 0x22;
static const uint16_t TAG_LICENSE_DATE_MISC                                      = 0x23;
static const uint16_t TAG_LICENSE_DATE_CLASS_2                                   = 0x24;
static const uint16_t TAG_LICENSE_DATE_LARGE_SIZED_MOTOR_VEHICLE                 = 0x25;
static const uint16_t TAG_LICENSE_DATE_MOTOR_VEHICLE                             = 0x26;
static const uint16_t TAG_LICENSE_DATE_LARGE_SIZED_SPECIAL_MOTOR_VEHICLE         = 0x27;
static const uint16_t TAG_LICENSE_DATE_LARGE_SIZED_MOTORCYCLE                    = 0x28;
static const uint16_t TAG_LICENSE_DATE_MOTORCYCLE                                = 0x29;
static const uint16_t TAG_LICENSE_DATE_SMALL_SIZED_SPECIAL_MOTOR_VEHICLE         = 0x2A;
static const uint16_t TAG_LICENSE_DATE_MOPED                                     = 0x2B;
static const uint16_t TAG_LICENSE_DATE_TOWING                                    = 0x2C;
static const uint16_t TAG_LICENSE_DATE_CLASS_2_LARGE_SIZED_MOTOR_VEHICLE         = 0x2D;
static const uint16_t TAG_LICENSE_DATE_CLASS_2_MOTOR_VEHICLE                     = 0x2E;
static const uint16_t TAG_LICENSE_DATE_CLASS_2_LARGE_SIZED_SPECIAL_MOTOR_VEHICLE = 0x2F;
static const uint16_t TAG_LICENSE_DATE_CLASS_2_TOWING                            = 0x30;
static const uint16_t TAG_LICENSE_DATE_MIDSIZE_MOTOR_VEHICLE                     = 0x31;
static const uint16_t TAG_LICENSE_DATE_CLASS_2_MIDSIZE_MOTOR_VEHICLE             = 0x32;

static const size_t   MAXLEN_JISX_REVISION                                          =  1;
static const size_t   MAXLEN_NAME                                                   = 72;
static const size_t   MAXLEN_PHONETIC_NAME                                          = 32;
static const size_t   MAXLEN_ALIAS_NAME                                             = 32;
static const size_t   MAXLEN_UNIFIED_NAME                                           = 16;
static const size_t   MAXLEN_BIRTHDAY                                               =  7;
static const size_t   MAXLEN_DOMICILE                                               = 80;
static const size_t   MAXLEN_ISSUE_DATE                                             =  7;
static const size_t   MAXLEN_REFERENCE_NUMBER                                       =  5;
static const size_t   MAXLEN_LICENSE_COLOR                                          =  6;
static const size_t   MAXLEN_EXPIRATION_DATE                                        =  7;
static const size_t   MAXLEN_LICENSE_REQUIREMENT1                                   = 80;
static const size_t   MAXLEN_LICENSE_REQUIREMENT2                                   = 80;
static const size_t   MAXLEN_LICENSE_REQUIREMENT3                                   = 80;
static const size_t   MAXLEN_LICENSE_REQUIREMENT4                                   = 80;
static const size_t   MAXLEN_POLICE_AUTHORITY_NAME                                  = 24;
static const size_t   MAXLEN_LICENSE_NUMBER                                         = 12;
static const size_t   MAXLEN_LICENSE_DATE_MOTORCYCLE_OR_SMALL_OR_MOPED              =  7;
static const size_t   MAXLEN_LICENSE_DATE_MISC                                      =  7;
static const size_t   MAXLEN_LICENSE_DATE_CLASS_2                                   =  7;
static const size_t   MAXLEN_LICENSE_DATE_LARGE_SIZED_MOTOR_VEHICLE                 =  7;
static const size_t   MAXLEN_LICENSE_DATE_MOTOR_VEHICLE                             =  7;
static const size_t   MAXLEN_LICENSE_DATE_LARGE_SIZED_SPECIAL_MOTOR_VEHICLE         =  7;
static const size_t   MAXLEN_LICENSE_DATE_LARGE_SIZED_MOTORCYCLE                    =  7;
static const size_t   MAXLEN_LICENSE_DATE_MOTORCYCLE                                =  7;
static const size_t   MAXLEN_LICENSE_DATE_SMALL_SIZED_SPECIAL_MOTOR_VEHICLE         =  7;
static const size_t   MAXLEN_LICENSE_DATE_MOPED                                     =  7;
static const size_t   MAXLEN_LICENSE_DATE_TOWING                                    =  7;
static const size_t   MAXLEN_LICENSE_DATE_CLASS_2_LARGE_SIZED_MOTOR_VEHICLE         =  7;
static const size_t   MAXLEN_LICENSE_DATE_CLASS_2_MOTOR_VEHICLE                     =  7;
static const size_t   MAXLEN_LICENSE_DATE_CLASS_2_LARGE_SIZED_SPECIAL_MOTOR_VEHICLE =  7;
static const size_t   MAXLEN_LICENSE_DATE_CLASS_2_TOWING                            =  7;
static const size_t   MAXLEN_LICENSE_DATE_MIDSIZE_MOTOR_VEHICLE                     =  7;
static const size_t   MAXLEN_LICENSE_DATE_CLASS_2_MIDSIZE_MOTOR_VEHICLE             =  7;


static const uint16_t TAG_REGISTERED_DOMICILE = 0x41;

static const size_t   MAXLEN_REGISTERED_DOMICILE = 80;


static const uint16_t TAG_EUDC1 = 0x48;
static const uint16_t TAG_EUDC2 = 0x49;


static const uint16_t TAG_APPEND_STATUS                                         = 0x50;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1                = 0x51;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME2                = 0x52;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME3                = 0x53;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME4                = 0x54;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME5                = 0x55;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME6                = 0x56;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME7                = 0x57;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME8                = 0x58;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME9                = 0x59;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME10               = 0x5A;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME11               = 0x5B;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME12               = 0x5C;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME13               = 0x5D;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME14               = 0x5E;
static const uint16_t TAG_APPEND_DOMICILE_POLICE_AUTHORITY_NAME15               = 0x5F;
static const uint16_t TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1                = 0x60;
static const uint16_t TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME2                = 0x61;
static const uint16_t TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME3                = 0x62;
static const uint16_t TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME4                = 0x63;
static const uint16_t TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME5                = 0x64;
static const uint16_t TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME6                = 0x65;
static const uint16_t TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME7                = 0x66;
static const uint16_t TAG_APPEND_NAME_AND_POLICE_AUTHORITY_NAME8                = 0x67;
static const uint16_t TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1       = 0x68;
static const uint16_t TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME2       = 0x69;
static const uint16_t TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME3       = 0x6A;
static const uint16_t TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME4       = 0x6B;
static const uint16_t TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME5       = 0x6C;
static const uint16_t TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME6       = 0x6D;
static const uint16_t TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME7       = 0x6E;
static const uint16_t TAG_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME8       = 0x6F;
static const uint16_t TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1            = 0x70;
static const uint16_t TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME2            = 0x71;
static const uint16_t TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME3            = 0x72;
static const uint16_t TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME4            = 0x73;
static const uint16_t TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME5            = 0x74;
static const uint16_t TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME6            = 0x75;
static const uint16_t TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME7            = 0x76;
static const uint16_t TAG_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME8            = 0x77;
static const uint16_t TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 = 0x78;
static const uint16_t TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME2 = 0x79;
static const uint16_t TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME3 = 0x7A;
static const uint16_t TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME4 = 0x7B;
static const uint16_t TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME5 = 0x7C;
static const uint16_t TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME6 = 0x7D;
static const uint16_t TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME7 = 0x7E;
static const uint16_t TAG_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME8 = 0x7F;
static const uint16_t TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1   = 0x80;
static const uint16_t TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME2   = 0x81;
static const uint16_t TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME3   = 0x82;
static const uint16_t TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME4   = 0x83;
static const uint16_t TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME5   = 0x84;
static const uint16_t TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME6   = 0x85;
static const uint16_t TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME7   = 0x86;
static const uint16_t TAG_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME8   = 0x87;
static const uint16_t TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1              = 0x88;
static const uint16_t TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME2              = 0x89;
static const uint16_t TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME3              = 0x8A;
static const uint16_t TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME4              = 0x8B;
static const uint16_t TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME5              = 0x8C;
static const uint16_t TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME6              = 0x8D;
static const uint16_t TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME7              = 0x8E;
static const uint16_t TAG_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME8              = 0x8F;
static const uint16_t TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1               = 0x90;
static const uint16_t TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME2               = 0x91;
static const uint16_t TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME3               = 0x92;
static const uint16_t TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME4               = 0x93;
static const uint16_t TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME5               = 0x94;
static const uint16_t TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME6               = 0x95;
static const uint16_t TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME7               = 0x96;
static const uint16_t TAG_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME8               = 0x97;

static const size_t   MAXLEN_APPEND_STATUS                                         =   1;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME1                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME2                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME3                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME4                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME5                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME6                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME7                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME8                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME9                =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME10               =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME11               =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME12               =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME13               =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME14               =  25;
static const size_t   MAXLEN_APPEND_DOMICILE_POLICE_AUTHORITY_NAME15               =  25;
static const size_t   MAXLEN_APPEND_NAME_AND_POLICE_AUTHORITY_NAME1                =  97;
static const size_t   MAXLEN_APPEND_NAME_AND_POLICE_AUTHORITY_NAME2                =  97;
static const size_t   MAXLEN_APPEND_NAME_AND_POLICE_AUTHORITY_NAME3                =  97;
static const size_t   MAXLEN_APPEND_NAME_AND_POLICE_AUTHORITY_NAME4                =  97;
static const size_t   MAXLEN_APPEND_NAME_AND_POLICE_AUTHORITY_NAME5                =  97;
static const size_t   MAXLEN_APPEND_NAME_AND_POLICE_AUTHORITY_NAME6                =  97;
static const size_t   MAXLEN_APPEND_NAME_AND_POLICE_AUTHORITY_NAME7                =  97;
static const size_t   MAXLEN_APPEND_NAME_AND_POLICE_AUTHORITY_NAME8                =  97;
static const size_t   MAXLEN_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME1       =  57;
static const size_t   MAXLEN_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME2       =  57;
static const size_t   MAXLEN_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME3       =  57;
static const size_t   MAXLEN_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME4       =  57;
static const size_t   MAXLEN_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME5       =  57;
static const size_t   MAXLEN_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME6       =  57;
static const size_t   MAXLEN_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME7       =  57;
static const size_t   MAXLEN_APPEND_PHONETIC_NAME_AND_POLICE_AUTHORITY_NAME8       =  57;
static const size_t   MAXLEN_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME1            = 105;
static const size_t   MAXLEN_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME2            = 105;
static const size_t   MAXLEN_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME3            = 105;
static const size_t   MAXLEN_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME4            = 105;
static const size_t   MAXLEN_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME5            = 105;
static const size_t   MAXLEN_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME6            = 105;
static const size_t   MAXLEN_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME7            = 105;
static const size_t   MAXLEN_APPEND_DOMICILE_AND_POLICE_AUTHORITY_NAME8            = 105;
static const size_t   MAXLEN_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME1 = 105;
static const size_t   MAXLEN_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME2 = 105;
static const size_t   MAXLEN_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME3 = 105;
static const size_t   MAXLEN_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME4 = 105;
static const size_t   MAXLEN_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME5 = 105;
static const size_t   MAXLEN_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME6 = 105;
static const size_t   MAXLEN_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME7 = 105;
static const size_t   MAXLEN_APPEND_LICENSE_REQUIREMENT_AND_POLICE_AUTHORITY_NAME8 = 105;
static const size_t   MAXLEN_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME1   = 105;
static const size_t   MAXLEN_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME2   = 105;
static const size_t   MAXLEN_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME3   = 105;
static const size_t   MAXLEN_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME4   = 105;
static const size_t   MAXLEN_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME5   = 105;
static const size_t   MAXLEN_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME6   = 105;
static const size_t   MAXLEN_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME7   = 105;
static const size_t   MAXLEN_APPEND_CONDITION_RELEASE_AND_POLICE_AUTHORITY_NAME8   = 105;
static const size_t   MAXLEN_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME1              = 105;
static const size_t   MAXLEN_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME2              = 105;
static const size_t   MAXLEN_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME3              = 105;
static const size_t   MAXLEN_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME4              = 105;
static const size_t   MAXLEN_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME5              = 105;
static const size_t   MAXLEN_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME6              = 105;
static const size_t   MAXLEN_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME7              = 105;
static const size_t   MAXLEN_APPEND_REMARK_AND_POLICE_AUTHORITY_NAME8              = 105;
static const size_t   MAXLEN_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME1               = 105;
static const size_t   MAXLEN_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME2               = 105;
static const size_t   MAXLEN_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME3               = 105;
static const size_t   MAXLEN_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME4               = 105;
static const size_t   MAXLEN_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME5               = 105;
static const size_t   MAXLEN_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME6               = 105;
static const size_t   MAXLEN_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME7               = 105;
static const size_t   MAXLEN_APPEND_SPARE_AND_POLICE_AUTHORITY_NAME8               = 105;


static const uint16_t TAG_EUDC_APPEND_STATUS = 0xA0;
static const uint16_t TAG_EUDC3              = 0xA1;
static const uint16_t TAG_EUDC4              = 0xA2;
static const uint16_t TAG_EUDC5              = 0xA3;
static const uint16_t TAG_EUDC6              = 0xA4;
static const uint16_t TAG_EUDC7              = 0xA5;


static const uint16_t TAG_REGISTERED_DOMICILE_APPEND_STATUS                     = 0xAA;
static const uint16_t TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 = 0xAB;
static const uint16_t TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME2 = 0xAC;
static const uint16_t TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME3 = 0xAD;
static const uint16_t TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME4 = 0xAE;
static const uint16_t TAG_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME5 = 0xAF;

static const size_t   MAXLEN_REGISTERED_DOMICILE_APPEND_STATUS                     =   1;
static const size_t   MAXLEN_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME1 = 105;
static const size_t   MAXLEN_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME2 = 105;
static const size_t   MAXLEN_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME3 = 105;
static const size_t   MAXLEN_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME4 = 105;
static const size_t   MAXLEN_APPEND_REGISTERED_DOMICILE_AND_POLICE_AUTHORITY_NAME5 = 105;


static const uint16_t TAG_CHECK_CODE       = 0xB1;
static const uint16_t TAG_SERIAL_NUMBER    = 0xB2;
static const uint16_t TAG_CHECK_CODE_RFU   = 0xB3;
static const uint16_t TAG_PUBLISHER_NAME   = 0xB4;
static const uint16_t TAG_PRINCIPAL_NAME   = 0xB5;
static const uint16_t TAG_PRINCIPAL_KEY_ID = 0xB6;

static const size_t   MAXLEN_CHECK_CODE       = 256;
static const size_t   MAXLEN_SERIAL_NUMBER    =  16;
static const size_t   MAXLEN_CHECK_CODE_RFU   =  48;
static const size_t   MAXLEN_PUBLISHER_NAME   =  80;
static const size_t   MAXLEN_PRINCIPAL_NAME   = 130;
static const size_t   MAXLEN_PRINCIPAL_KEY_ID =  32;


static const uint16_t TAG_PHOTO    = 0x5F40;

static const size_t   MAXLEN_PHOTO = 2000;


static const uint8_t APPEND_STATUS_MARKER = 0x11;


static const uint8_t CIPHER_ID_TRIPLE_DES = 0x04;


static const uint8_t CARD_MANUFACTURER_RFU = 0xFF;


static const uint8_t ERA_ID_UNKNOWN = 0x30;	///< �s��
static const uint8_t ERA_ID_MEIJI   = 0x31;	///< ����
static const uint8_t ERA_ID_TAISHO  = 0x32;	///< �吳
static const uint8_t ERA_ID_SHOWA   = 0x33;	///< ���a
static const uint8_t ERA_ID_HEISEI  = 0x34;	///< ����

/// ���t�^
typedef struct {
	uint8_t	era_id;	///< ����(�����A�吳�A���a�A����)
	int		year;	///< �N
	int		month;	///< ��
	int		day;	///< ��
} ICDL_DATE_TYPE;

/// �O�����^
typedef struct {
	int		size;	///< �O�����\������h�b�g��
	size_t	length;	///< �O���h�b�g�f�[�^��
	uint8_t*data;	///< �O���h�b�g(MMR�����ŕ�����)
} ICDL_EUDC_TYPE;

#ifdef __cplusplus
extern "C" {
#endif

#if defined(ICDL_PHOTO_DECODE_ENABLE)

/**
 * @brief �ʐ^���r�b�g�}�b�v�n���h���֕ϊ�
 * @param[in] data �ʐ^�f�[�^(JPEG2000�f�[�^��)
 * @param[in] size �ʐ^�f�[�^��
 * @return         �r�b�g�}�b�v�n���h��
 * @note OpenJpeg���C�u�������g�p���ĕϊ��s���܂��B
 *       ICDL_PHOTO_DECODE_ENABLE�̒�`���K�v�ł��B
 */
HBITMAP icdl_photo_to_bitmap(const unsigned char * data, size_t size);

#endif

#if defined(ICDL_EUDC_DECODE_ENABLE)

/**
 * @brief �O�����r�b�g�}�b�v�n���h���֕ϊ�
 * @param[in] data      �O���f�[�^(JPEG2000�f�[�^��)
 * @param[in] size      �O���f�[�^��
 * @param[in] char_dots �O���̃h�b�g�T�C�Y
 * @return              �r�b�g�}�b�v�n���h��(2�F�r�b�g�}�b�v�Ȃ̂Œ���)
 * @note jbig2dec�̃\�[�X�̈ꕔ���g�p���ĕϊ��s���܂��B
 *       ICDL_EUDC_DECODE_ENABLE�̒�`���K�v�ł��B
 */
HBITMAP icdl_eudc_to_bitmap(const unsigned char * data, size_t size, int char_dots);

#endif

#ifdef __cplusplus
}
#endif

#endif
