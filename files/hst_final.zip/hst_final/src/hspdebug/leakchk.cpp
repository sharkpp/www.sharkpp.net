// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#ifdef _DEBUG

#include <windows.h>
#include <crtdbg.h>
#include <stdlib.h>
#include "common.h"

#define DEBUG_FILENAME		"debug.txt"

BOOL bEnable = FALSE;
BOOL bError = FALSE;

int memLeakReport(int reportType, char *userMessage, int *retVal)
{
	if (! bEnable) return TRUE;
	if (reportType == _CRT_ASSERT) return TRUE;
	HANDLE hFile;
	DWORD dwWrite;

	if (! bError) {
		MessageBox(NULL, "Error Detected!", "pcbnet.hpi", MB_OK | MB_ICONSTOP);
		bError = TRUE;
	}

	hFile = CreateFile(DEBUG_FILENAME, GENERIC_WRITE, 0, NULL,
		OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	SetFilePointer(hFile, 0, NULL, FILE_END);
	WriteFile(hFile, userMessage, strlen(userMessage)-1, &dwWrite, NULL);
	WriteFile(hFile, "\r\n", 2, &dwWrite, NULL);
	CloseHandle(hFile);
	*retVal = 0;
	return FALSE;
}

void memLeakCheck()		//	���������[�N�̌��o���s��
{
	if (bEnable) return;
	HANDLE hFile;
	hFile = CreateFile(DEBUG_FILENAME, GENERIC_WRITE, 0, NULL,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	CloseHandle(hFile);
	_CrtSetReportHook(memLeakReport);
	_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG));
	bEnable = TRUE;
}

#endif	// _DEBUG
