<?php

//====================================================================
//  rss.php �T�|�[�g�X�N���v�g
//====================================================================
//
// ���쌠
//  Copyright(C) 2005 by Shark++ Software.
//  ���쌠�͕������܂��񂪁A���R�Ɏg�p�E�����E�Ĕz�z�\�ł��B

$html = <<< OUTPUT

<html>
<head><title>rss.php �⏕/title></head>
<body>
<form method="GET" action="%script_name%">
<table>
	<tr>
		<td align="right">URL�F</td>
		<td><input type="text" name="url" value="%url%" size="100"></td>
	</tr>
	<tr>
		<td align="right">�G���R�[�h�F</td>
		<td><input type="text" name="enc" value="%enc%" size="100"></td>
	</tr>
	<tr>
		<td align="right">�p�^�[���F</td>
		<td><input type="text" name="reg" value="%reg%" size="100"></td>
	</tr>
	<tr>
		<td colspan="2" align="right"><input type="submit" value="���"></td>
	</tr>
</table>
</form>
<hr>
%found%
<hr>
%text%
<hr>
</body>
</html>

OUTPUT;

	//-------------------------------------------------------------------------

	if('' == $_GET['enc']) { $_GET['enc'] = 'auto'; }

	$html = str_replace("%script_name%", $_SERVER['SCRIPT_NAME'], $html);
	$html = str_replace("%url%", $_GET['url'], $html);
	$html = str_replace("%enc%", $_GET['enc'], $html);
	$html = str_replace("%reg%", htmlentities($_GET['reg']), $html);

	//-------------------------------------------------------------------------

	if("" == $_GET['url'])
	{
		echo str_replace("%text%", "", $html);
		exit;
	}

	//-------------------------------------------------------------------------

	$data = file_get_contents($_GET['url']);
	if("" == $data)
	{
		echo str_replace("%text%", "Not Found !", $html);
		exit;
	}

	$data = mb_convert_encoding($data, "SJIS", $_GET['enc']);

	function markup_encode($matches)
	{
		$r = $matches[0];
		foreach($matches as $key => $value)
		{
			$r = str_replace($value, '=='.$key.'=='.$value.'==/'.$key.'==', $r);
		}
		return $r;
	}

	function markup_decode($matches)
	{
		$colors = array(
				'0' => '#808080',
				'1' => '#f04040',
				'2' => '#40f040',
				'3' => '#4040f0',
				'4' => '#f0f040',
				'5' => '#f040f0',
				'6' => '#40f0f0',
				'7' => '#ff00ff',
				'8' => '#0000ff',
				'9' => '#ff00ff',
			);
		if('/' == $matches[1])
		{
			$r = '</font></i>';
		}
		else
		{
			$r = '<i><font color="'.$colors[$matches[2]].'">';
		}
		return $r;
	}

	$reg = "/".str_replace("<", "\<", str_replace(">", "\>", str_replace("/", "\/", str_replace('"', '\"', $_GET['reg']))))."/ims";

	if(!preg_match_all($reg, $data, $m))
	{
		$found = '';
	}
	else
	{
		$found = '<table border="1">';
		$found .= '<tr>';
		for($j = 1; $j < count($m); $j++)
		{
			$found .= '<th><pre>'."\\".$j.'</pre></th>';
		}
		$found .= '</tr>';
		for($i = 0; $i < count($m[0]); $i++)
		{
			$found .= '<tr>';
			for($j = 1; $j < count($m); $j++)
			{
			//	$m[$i] = htmlspecialchars($m[$i]);
				$found .= '<td valign="top"><pre>'.htmlspecialchars($m[$j][$i]).'</pre></td>';
			}
			$found .= '</tr>';
		}
		$found .= '</table>';
	}

	$data = preg_replace_callback($reg, "markup_encode", $data);
//	$data = explode("\n", str_replace("\r", "", $id_data));

	$data = "<pre>".htmlspecialchars($data)."</pre>";
	$data = preg_replace_callback("/==(\/?)([0-9])==/ims", "markup_decode", $data);

	mb_http_output("SJIS");

	$html = str_replace("%found%", $found, $html);
	$html = str_replace("%text%", $data, $html);
	echo $html;

?>
