// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"

extern THREADLIST *pFirstThread;

BOOL debugList(char *p1)
{
	*p1 = '\0';
	THREADLIST *p = pFirstThread;
	int n = 0;

	while(p != NULL) {
		p1+=sprintf(p1, "%03d: %08x->%08x\r\n", n, (unsigned int)p, (unsigned int)p->next);
		p = p->next;
		n++;
	}
	p1+=sprintf(p1, "%03d: ------ NULL ------\r\n", n);
	return 0;
}

BOOL directReadTI(char *buf, LPTHREADLIST tl)
{
	THREADINFO *ti;
	if (! IsSocketHandle(tl, ST_ALL))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;
	ti = tl->ti;

	ti->Lock();
	memcpy(buf, ti, sizeof(THREADINFO));
	ti->Unlock();
	return 0;
}

EXPORT BOOL WINAPI netdebug(char *p1, int p2, int p3, int p4)
{
	if (p3 == 1)
		return directReadTI(p1, (LPTHREADLIST)p2);
	if (p2 == -1)
		return debugList(p1);
	*p1 = '\0';
	THREADLIST *tl = (LPTHREADLIST)p2;
	THREADINFO *ti;
	if (! IsSocketHandle(tl, ST_ALL))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;
	ti = tl->ti;

	char bl[2][6] = { "FALSE", "TRUE" };
	struct in_addr in;
	struct sockaddr_in addr;
	int i;

	ti->Lock();

	p1+=sprintf(p1, "SocketID: 0x%x\r\n", (unsigned int)p2);

	p1+=sprintf(p1, "[THREADLIST]\r\n");
	p1+=sprintf(p1, "ThreadInfo: 0x%x\r\n", (unsigned int)tl->ti);
	p1+=sprintf(p1, "Window Handle: 0x%x\r\n", (unsigned int)tl->hWnd);
	p1+=sprintf(p1, "ThreadID: 0x%x\r\n", (unsigned int)tl->threadID);
	p1+=sprintf(p1, "Thread Handle: 0x%x\r\n", (unsigned int)tl->hThread);
	p1+=sprintf(p1, "Next Thread: 0x%x\r\n", (unsigned int)tl->next);

	p1+=sprintf(p1, "[THREADINFO]\r\n");
	p1+=sprintf(p1, "Type: %d\r\n", ti->type);
	p1+=sprintf(p1, "Socket Descriptor: 0x%x\r\n", (unsigned int)ti->soc);
	p1+=sprintf(p1, "Async Window: 0x%x\r\n", (unsigned int)ti->hWnd);
	p1+=sprintf(p1, "Error Status: %d\r\n", ti->err);
	p1+=sprintf(p1, "Async Handle: 0x%X\r\n", (unsigned int)ti->hAsync);
	p1+=sprintf(p1, "User: %u\r\n", (unsigned int)ti->dwUser);
	if (ti->type & ST_TCPALL) {
		i = sizeof(addr);
		getsockname(ti->soc, (sockaddr *)&addr, &i);
		in.s_addr = ti->tcp.addr;
		p1+=sprintf(p1, "tcp.LocalAddress: %s:%d\r\n", inet_ntoa(addr.sin_addr), (int)ntohs(addr.sin_port));
		p1+=sprintf(p1, "tcp.PeerAddress: %s:%d\r\n", inet_ntoa(in), (int)ntohs(ti->tcp.port));
		p1+=sprintf(p1, "tcp.bAvailable: %s\r\n", bl[ti->tcp.bAvailable]);
		p1+=sprintf(p1, "tcp.bBlocking: %s\r\n", bl[ti->tcp.bBlocking]);
		p1+=sprintf(p1, "tcp.bShutting: %s\r\n", bl[ti->tcp.bShutting]);
		p1+=sprintf(p1, "tcp.ReadBuf: %dbytes used\r\n", ti->tcp.r->Count());
		p1+=sprintf(p1, "tcp.SendBuf: %dbytes used\r\n", ti->tcp.s->Count());
		p1+=sprintf(p1, "tcp.incoming: %s\r\n", bl[ti->tcp.incoming]);
	}
	else if (ti->type & ST_UDPALL) {
		i = sizeof(addr);
		getsockname(ti->soc, (sockaddr *)&addr, &i);
		p1+=sprintf(p1, "udp.LocalAddress: %s:%d\r\n", inet_ntoa(addr.sin_addr), (int)ntohs(addr.sin_port));
		in.s_addr = ti->udp.addr;
		p1+=sprintf(p1, "udp.PeerAddress: %s:%d\r\n", inet_ntoa(in), (int)ntohs(ti->udp.port));
		in.s_addr = ti->udp.fromaddr;
		p1+=sprintf(p1, "udp.LastReceivedAddress: %s:%d\r\n", inet_ntoa(in), (int)ntohs(ti->udp.fromport));
		p1+=sprintf(p1, "udp.bBroadCast: %s\r\n", bl[ti->udp.bBroadCast]);
		p1+=sprintf(p1, "udp.bBlocking: %s\r\n", bl[ti->udp.bBlocking]);
		p1+=sprintf(p1, "udp.ReadBuf: %d Packets %d bytes\r\n", ti->udp.r->CountPacket(), ti->udp.r->Count());
		p1+=sprintf(p1, "udp.SendBuf: %d Packets %d bytes\r\n", ti->udp.s->CountPacket(), ti->udp.r->Count());
	}
	else if (ti->type & ST_DNS) {
		p1+=sprintf(p1, "dns.bReply: %s\r\n", bl[ti->dns.bReply]);
		in.s_addr = ti->dns.addr;
		p1+=sprintf(p1, "dns.Address: %s\r\n", inet_ntoa(in));
	}
	else if (ti->type & ST_PING) {
		p1+=sprintf(p1, "icmp.bReply: %s\r\n", bl[ti->icmp.bReply]);
		in.s_addr = ti->icmp.addr;
		p1+=sprintf(p1, "icmp.Address: %s\r\n", inet_ntoa(in));
		p1+=sprintf(p1, "icmp.DataSize: %d\r\n", ti->icmp.datasize);
		p1+=sprintf(p1, "icmp.TimeOut: %d\r\n", ti->icmp.dwTimeOut);
		p1+=sprintf(p1, "icmp.SendTime: %d\r\n", ti->icmp.dwSendTime);
		p1+=sprintf(p1, "icmp.ReplyTime: %d\r\n", ti->icmp.dwReplyTime);
		p1+=sprintf(p1, "icmp.ReplyCode: %d\r\n", (int)ti->icmp.replycode);
		in.s_addr = ti->icmp.replyfrom;
		p1+=sprintf(p1, "icmp.ReplyAddr: %d\r\n", inet_ntoa(in));
		p1+=sprintf(p1, "icmp.ReplyTTL: %d\r\n", ti->icmp.ttl);
	}
#ifdef RAW_SUPPORT
	else if (ti->type & ST_RAW) {
		p1+=sprintf(p1, "raw.bBlocking: %s\r\n", bl[ti->raw.bBlocking]);
		p1+=sprintf(p1, "raw.ReadBuf: %d Packets %d bytes\r\n", ti->raw.r->CountPacket(), ti->raw.r->Count());
		p1+=sprintf(p1, "raw.SendBuf: %d Packets %d bytes\r\n", ti->raw.s->CountPacket(), ti->raw.r->Count());
	}
#endif

	ti->Unlock();
	return 0;
}









