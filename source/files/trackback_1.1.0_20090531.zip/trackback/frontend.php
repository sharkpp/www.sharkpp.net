<?php

/*******************************************************************************
  The MIT License

  Copyright (c) 2008-2009 Shark++ Software.

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

 ==============================================================================
  参考として The MIT License の日本語訳を下記に併記しますが、頒布条件としては、
  上記原文に従ってください。
 ==============================================================================

  The MIT License

  Copyright (c) 2008-2009 Shark++ Software.

  以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル
  （以下「ソフトウェア」）の複製を取得するすべての人に対し、ソフトウェアを
  無制限に扱うことを無償で許可します。これには、ソフトウェアの複製を使用、
  複写、変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、
  およびソフトウェアを提供する相手に同じことを許可する権利も無制限に含まれ
  ます。

  上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要
  な部分に記載するものとします。

  ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの
  保証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、
  および権利非侵害についての保証も含みますが、それに限定されるものではあり
  ません。作者または著作権者は、契約行為、不法行為、またはそれ以外であろう
  と、ソフトウェアに起因または関連し、あるいはソフトウェアの使用またはその
  他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も
  負わないものとします。 
 *******************************************************************************/

require_once dirname(__FILE__).'/Services/Trackback.php';

//////////////////////////////////////////////////////////////////////
// イベント監視登録

Observer::observe('page_requested', 'trackback_receive');

//////////////////////////////////////////////////////////////////////
// フロントエンドで使用される関数郡

function get_trackback_page_id($query)
{
	if( preg_match('/^(.+)\.trackback(.*)$/', $query, $m) )
	{
		if( empty($_POST) )
		{
			exit();
		}

		if( PluginTrackback::getSetting('spam_block_keyword') != $m[2] )
		{
			exit();
		}

		$m[1] = preg_replace('/(.+)'.URL_SUFFIX.'/', '\1', $m[1]);

		$page = find_page_by_uri($m[1]);

		if( $page->trackback_status != Trackback::OPEN )
		{
			exit();
		}

		if( false !== $page )
		{
			return $page->id;
		}
	//	echo '<pre>'.htmlspecialchars(print_r($page, true)).'</pre>';
	}
	return false;
}

// トラックバックピング受信
function trackback_receive($query)
{
	global $__FROG_CONN__;

	$page_id = get_trackback_page_id($query);

	if( false === $page_id )
	{
		return;
	}

	// Services_Trackbackオブジェクトの生成
	$trackback = new Services_Trackback();

	// トラックバック情報
	$trackbackData = array( 'id' => $page_id );

	// Services_Trackbackオブジェクトの作成
	$trackback = Services_Trackback::create($trackbackData);

	// 送信されたトラックバック情報を受信
	$result = $trackback->receive();

	if( PEAR::isError($result) ) {
		echo $trackback->getResponseError($result->getMessage(), 1);
	} else {

		$auto_approve_trackback = PluginTrackback::getSetting('auto_approve');

		// データーベースへの挿入用SQLを生成
		//  全ての入力のタグを省く
		$sql = 'INSERT INTO '.TABLE_PREFIX.'trackback (page_id, title, excerpt, url, blog_name, host, is_approved, created_on) VALUES ('.
				'\''.$page_id.'\', '.
				$__FROG_CONN__->quote($trackback->get('title')).    ', '.
				$__FROG_CONN__->quote($trackback->get('excerpt')).  ', '.
				$__FROG_CONN__->quote($trackback->get('url')).      ', '.
				$__FROG_CONN__->quote($trackback->get('blog_name')).', '.
				$__FROG_CONN__->quote($trackback->get('host')).     ', '.
				$__FROG_CONN__->quote($auto_approve_trackback).     ', '.
				$__FROG_CONN__->quote(date('Y-m-d H:i:s')).')';

		// データーベースへ挿入
		$__FROG_CONN__->exec($sql);

		// 送信された各情報を取得する
		$values = array(
			'host'		=> $trackback->get('host'),
			'title'		=> $trackback->get('title'),
			'excerpt'	=> $trackback->get('excerpt'),
			'url'		=> $trackback->get('url'),
			'blog_name' => $trackback->get('blog_name'),
		);

		echo $trackback->getResponseSuccess();
	}

	exit();
}

function trackbacks(& $page, $where = '', $value = array())
{
	global $__FROG_CONN__;

	if( '' == $where ) {
		$where .= ' ORDER BY created_on DESC';
	} else {
		$where = ' AND ' . $where;
	}

	array_unshift($value, $page->id, 1);

	$sql = 'SELECT * FROM '.TABLE_PREFIX.'trackback WHERE page_id=? AND is_approved=? '.$where;

	if( $stmt = $__FROG_CONN__->prepare($sql) )
	{
		$stmt->setFetchMode(PDO::FETCH_CLASS, 'Trackback');
		$stmt->execute($value);

		return $stmt->fetchAll();
	}

	return false;
}

function trackbacks_count(& $page, $where = '', $value = array())
{
	global $__FROG_CONN__;

	if( '' == $where ) {
		$where .= ' ORDER BY created_on DESC';
	} else {
		$where = ' AND ' . $where;
	}

	array_unshift($value, $page->id, 1);

	$sql = 'SELECT count(*) FROM '.TABLE_PREFIX.'trackback WHERE page_id=? AND is_approved=? '.$where;

	if( $stmt = $__FROG_CONN__->prepare($sql) )
	{
		$stmt->execute($value);

		return $stmt->fetchColumn();
	}

	return 0;
}

if( version_compare(FROG_VERSION, '0.9.4', '<=') )
{
	class Trackback
	{
		const NONE = 0;
		const OPEN = 1;
		const CLOSED = 2;

		const MAX_EXCERPT_LENGTH = 100;

		function title()     { return htmlspecialchars($this->title); }
		function excerpt($excerpt_length = Trackback::MAX_EXCERPT_LENGTH)
		{
			return htmlspecialchars(mb_strimwidth($this->excerpt, 0, $excerpt_length, '...', 'UTF-8'));
		}
		function url()       { return $this->url; }
		function blog_name() { return htmlspecialchars($this->blog_name); }
		function link($title = '', $class = '')
		{
			if( empty($title) )
				$title = $this->blog_name;
			if( !empty($class) )
				$class = ' class="'.$class.'"';
			return '<a href="'.htmlspecialchars($this->url).'"'.$class.' title="'.htmlspecialchars($title).'">'.htmlspecialchars($title).'</a>';
		}

		function date($format = '%a, %e %b %Y')
		{
			return strftime($format, strtotime($this->created_on));
		}
	}
}
