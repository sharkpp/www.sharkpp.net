static char *mainwin_id = 
	"@(#)Copyright (C) H.Shirouzu 2004-2005   maindlg.cpp	ver1.21";
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2004-09-15(Wed)
	Update					: 2005-07-06(Wed)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "mainwin.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>
// HtmlHelp WorkShop ���C���X�g�[�����āAhtmlhelp.h �� include path ��
// ����邱�ƁB
#define ENABLE_HTML_HELP
#if defined(ENABLE_HTML_HELP)
#include <htmlhelp.h>
#endif

/*=========================================================================
  �N���X �F TFastCopyApp
  �T  �v �F �A�v���P�[�V�����N���X
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
TFastCopyApp::TFastCopyApp(HINSTANCE _hI, LPSTR _cmdLine, int _nCmdShow) : TApp(_hI, _cmdLine, _nCmdShow)
{
}

TFastCopyApp::~TFastCopyApp()
{
}

void TFastCopyApp::InitWindow(void)
{
	TRegisterClass(FASTCOPY_CLASS);

	TDlg *mainDlg = new TMainDlg();
	mainWnd = mainDlg;
	mainDlg->Create();
}

int WINAPI WinMain(HINSTANCE _hI, HINSTANCE, LPSTR arg, int show)
{
	return	TFastCopyApp(_hI, arg, show).Run();
}


/*=========================================================================
  �N���X �F TMainDlg
  �T  �v �F ���C���_�C�A���O
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
TMainDlg::TMainDlg() : TDlg(MAIN_DIALOG), aboutDlg(this), setupDlg(&cfg, this), shellExtDlg(&cfg, this)
{
	cfg.ReadIni();

	isShellExt = FALSE;
	isErrLog = cfg.isErrLog;
	isTaskTray = noConfirmDel = FALSE;
	isNetPlaceSrc = FALSE;
	autoCloseLevel = NO_CLOSE;
	curIconIndex = 0;
	pathLogBuf = NULL;
	hErrLogFile = INVALID_HANDLE_VALUE;
}

TMainDlg::~TMainDlg()
{
}

struct {
	UINT				resId;
	const char			*list_str;
	UINT				cmdline_resId;
	const void			*cmdline_name;
	FastCopy::Mode		mode;
	FastCopy::OverWrite	overWrite;
} COPY_LIST [] = {
	{ IDS_ALLSKIP,		NULL,	IDS_CMD_NOEXIST_ONLY, NULL,	FastCopy::DIFFCP_MODE,	FastCopy::BY_NAME },
	{ IDS_ATTRCMP,		NULL,	IDS_CMD_DIFF,		NULL,	FastCopy::DIFFCP_MODE,	FastCopy::BY_ATTR },
	{ IDS_UPDATECOPY,	NULL,	IDS_CMD_UPDATE,		NULL,	FastCopy::DIFFCP_MODE,	FastCopy::BY_LASTEST },
	{ IDS_FORCECOPY,	NULL,	IDS_CMD_FORCE_COPY,	NULL,	FastCopy::DIFFCP_MODE,	FastCopy::BY_ALWAYS },
	{ IDS_SYNCCOPY,		NULL,	IDS_CMD_SYNC,		NULL,	FastCopy::SYNCCP_MODE,	FastCopy::BY_ATTR },
//	{ IDS_MOVEATTR,		NULL,	IDS_CMD_MOVE,		NULL,	FastCopy::MOVE_MODE,	FastCopy::BY_ATTR },
	{ IDS_MOVEFORCE,	NULL,	IDS_CMD_MOVE,		NULL,	FastCopy::MOVE_MODE,	FastCopy::BY_ALWAYS },
	{ IDS_DELETE,		NULL,	IDS_CMD_DELETE,		NULL,	FastCopy::DELETE_MODE,	FastCopy::BY_ALWAYS },
	{ 0,				NULL,	0,					NULL,	(FastCopy::Mode)0,		(FastCopy::OverWrite)0 }
};

void TMainDlg::SetPathHistory(void)
{
	SendDlgItemMessage(SRC_COMBO, CB_RESETCONTENT, 0, 0);
	SendDlgItemMessage(DST_COMBO, CB_RESETCONTENT, 0, 0);

	for (int i=0; i < cfg.maxHistory; i++) {
		if (GetChar(cfg.srcPathHistory[i], 0))
			SendDlgItemMessageV(SRC_COMBO, CB_INSERTSTRING, i, (LPARAM)cfg.srcPathHistory[i]);
		if (GetChar(cfg.dstPathHistory[i], 0))
			SendDlgItemMessageV(DST_COMBO, CB_INSERTSTRING, i, (LPARAM)cfg.dstPathHistory[i]);
	}

	if (cfg.maxHistory > 0) {
		SetDlgItemTextV(SRC_COMBO, cfg.srcPathHistory[0]);
		SetDlgItemTextV(DST_COMBO, cfg.dstPathHistory[0]);
	}
}

BOOL TMainDlg::SetMiniWindow(void)
{
	GetWindowRect(&rect);
	MoveWindow(rect.left, rect.top, rect.right - rect.left, miniHeight, ::IsWindowVisible(hWnd));
	::ShowWindow(GetDlgItem(ERR_STATIC), SW_HIDE);
	::ShowWindow(GetDlgItem(ERRSTATUS_STATIC), SW_HIDE);
	::ShowWindow(GetDlgItem(ERR_EDIT), SW_HIDE);
	isErrEditHide = TRUE;
	return	TRUE;
}

BOOL TMainDlg::SetNormalWindow(void)
{
	if (IsWindowVisible(hWnd)) {
		::ShowWindow(GetDlgItem(ERR_STATIC), SW_SHOW);
		::ShowWindow(GetDlgItem(ERRSTATUS_STATIC), SW_SHOW);
		::ShowWindow(GetDlgItem(ERR_EDIT), SW_SHOW);
		GetWindowRect(&rect);
		MoveWindow(rect.left, rect.top, rect.right - rect.left, normalHeight, TRUE);
		isErrEditHide = FALSE;
	}
	return	TRUE;
}

BOOL TMainDlg::EvCreate(LPARAM lParam)
{
	char	buf[100];

	// ��O�t�B���^�̐ݒ�
	GetWindowText(buf, sizeof(buf));
	InstallExceptionFilter(buf);

	TaskBarCreateMsg = ::RegisterWindowMessage("TaskbarCreated");
	memset(&ti, 0, sizeof(ti));

	// �����Z�b�g
	SetPathHistory();

	// ���b�Z�[�W�Z�b�g
	SetDlgItemText(STATUS_EDIT, GetLoadStr(IDS_BEHAVIOR));
	SetDlgItemInt(BUFSIZE_EDIT, cfg.bufSize);

	// �R�s�[���[�h���X�g�쐬
	int		i;
	for (i=0; COPY_LIST[i].resId; i++) {
		COPY_LIST[i].list_str = GetLoadStr(COPY_LIST[i].resId);
		SendDlgItemMessage(MODE_COMBO, CB_ADDSTRING, 0, (LPARAM)COPY_LIST[i].list_str);
		COPY_LIST[i].cmdline_name = GetLoadStrV(COPY_LIST[i].cmdline_resId);
	}

	// �R�s�[���[�h���X�g�̃f�t�H���g�I��
	SendDlgItemMessage(MODE_COMBO, CB_SETCURSEL, cfg.copyMode, 0);

	::CheckDlgButton(hWnd, IGNORE_CHECK, cfg.ignoreErr);
	::CheckDlgButton(hWnd, ESTIMATE_CHECK, cfg.estimateMode);
	::CheckDlgButton(hWnd, TOPLEVEL_CHECK, cfg.isTopLevel);
	SetForegroundWindow();
	if (cfg.isTopLevel)
		::SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOMOVE);

	SendDlgItemMessage(STATUS_EDIT, EM_SETWORDBREAKPROC, 0, (LPARAM)EditWordBreakProc);
	SendDlgItemMessage(PATH_EDIT, EM_SETWORDBREAKPROC, 0, (LPARAM)EditWordBreakProc);
	SendDlgItemMessage(ERR_EDIT, EM_SETWORDBREAKPROC, 0, (LPARAM)EditWordBreakProc);
	SendDlgItemMessage(ERR_EDIT, EM_LIMITTEXT, 0, 0);

	GetWindowRect(&rect);

	int	offset_x = (GetSystemMetrics(SM_CXFULLSCREEN) - (rect.right - rect.left)) / 2;
	int	offset_y = (GetSystemMetrics(SM_CYFULLSCREEN) - (rect.bottom - rect.top)) / 2;

	::SetWindowPos(hWnd, NULL, offset_x, offset_y, 0, 0, SWP_NOSIZE|SWP_NOZORDER);
	for (i=0; i < MAX_FASTCOPY_ICON; i++)
		hMainIcon[i] = ::LoadIcon(TApp::GetInstance(), (LPCSTR)(FASTCOPY_ICON + i));
	::SetClassLongPtr(hWnd, GCLP_HICON, (LONG_PTR)hMainIcon[0]);

	RECT	path_rect, err_rect;
	GetWindowRect(&rect);
	::GetWindowRect(GetDlgItem(PATH_EDIT), &path_rect);
	::GetWindowRect(GetDlgItem(ERR_EDIT), &err_rect);
	normalHeight	= rect.bottom - rect.top;
	miniHeight		= normalHeight - (err_rect.bottom - path_rect.bottom);
	SetMiniWindow();
	SetWindowTitle("FastCopy %s", GetVersionStr());

	int		argc;
	void	**argv;

	argv = CommandLineToArgvV(::GetCommandLineV(), &argc);

	// command line mode
	if (argc > 1) {
		if (!CommandLineExecV(argc, argv) && (::GetAsyncKeyState(VK_SHIFT) & 0x8000) == 0) {
			PostMessage(WM_CLOSE, 0, 0);
		}
	}
	else
		Show();
	return	TRUE;
}

BOOL TMainDlg::EvNcDestroy(void)
{
	TaskTray(NIM_DELETE);
	PostQuitMessage(0);
	return	TRUE;
}

BOOL TMainDlg::CancelCopy()
{
	fastCopy.Suspend();
	int	ret = MessageBox(GetLoadStr(IDS_CONFIRM), FASTCOPY, MB_OKCANCEL);
	fastCopy.Resume();
	if (ret == IDOK)
		fastCopy.Aborting();

	return	ret == IDOK ? TRUE : FALSE;
}

BOOL TMainDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID) {
	case IDOK:
		if (!fastCopy.IsStarting()) {
			ExecCopy();
		}
		else if (CancelCopy()) {
			autoCloseLevel = NO_CLOSE;
		}
		return	TRUE;

	case IDCANCEL: case CLOSE_MENUITEM:
		if (!fastCopy.IsStarting()) {
			EndDialog(wID);
		}
		else if (fastCopy.IsAborting()) {
			if (MessageBox(GetLoadStr(IDS_CONFIRMFORCEEND), FASTCOPY, MB_OKCANCEL) == IDOK)
				EndDialog(wID);
		}
		else {
			CancelCopy();
			autoCloseLevel = NOERR_CLOSE;
		}
		return	TRUE;

	case SRC_FILE_BUTTON:
		BrowseDirDlgV(this, SRC_COMBO, GetLoadStrV(IDS_SRC_SELECT), BRDIR_VQUOTE);
		return	TRUE;

	case DST_FILE_BUTTON:
		BrowseDirDlgV(this, DST_COMBO, GetLoadStrV(IDS_DST_SELECT), BRDIR_BACKSLASH);
		return	TRUE;

	case TOPLEVEL_CHECK:
		cfg.isTopLevel = IsDlgButtonChecked(TOPLEVEL_CHECK);
		::SetWindowPos(hWnd, cfg.isTopLevel ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOMOVE);
		cfg.WriteIni();
		break;

	case MODE_COMBO:
		if (wNotifyCode == CBN_SELCHANGE) {
			BOOL	isDelete = COPY_LIST[SendDlgItemMessage(MODE_COMBO, CB_GETCURSEL, 0, 0)].mode == FastCopy::DELETE_MODE;
			if (isDelete && isNetPlaceSrc) {
				SetDlgItemTextV(SRC_COMBO, EMPTY_STR_V);
				isNetPlaceSrc = FALSE;
			}
			SetItemEnable(isDelete);
		}
		return	TRUE;

	case OPENDIR_MENUITEM:
		::ShellExecute(NULL, NULL, cfg.execDir, 0, 0, SW_SHOW);
		return	TRUE;

	case SETUP_MENUITEM:
		if (setupDlg.Exec() == IDOK) {
			SetDlgItemInt(BUFSIZE_EDIT, cfg.bufSize);
			CheckDlgButton(IGNORE_CHECK, cfg.ignoreErr);
			CheckDlgButton(ESTIMATE_CHECK, cfg.estimateMode);
			isErrLog = cfg.isErrLog;
		}
		return	TRUE;

	case SHELLEXT_MENUITEM:
		shellExtDlg.Exec();
		return	TRUE;

	case ABOUT_MENUITEM:
		aboutDlg.Exec();
		return	TRUE;

	case FASTCOPYURL_MENUITEM:
		::ShellExecute(NULL, NULL, GetLoadStr(IDS_FASTCOPYURL), NULL, NULL, SW_SHOW);
		return	TRUE;

#if defined(ENABLE_HTML_HELP)
	case HELP_BUTTON: case HELP_MENUITEM:
		{
			static BOOL (WINAPI *pHtmlHelp)(HWND, LPCSTR, UINT, DWORD_PTR) = NULL;
			if (pHtmlHelp == NULL) {
				DWORD		cookie=0;
				HMODULE		hHtmlHelp = TLoadLibrary("hhctrl.ocx");
				if (hHtmlHelp)
					pHtmlHelp = (BOOL (WINAPI *)(HWND, LPCSTR, UINT, DWORD_PTR))::GetProcAddress(hHtmlHelp, "HtmlHelpA");
				if (pHtmlHelp)
					pHtmlHelp(NULL, NULL, HH_INITIALIZE, (DWORD)&cookie);
			}
			if (pHtmlHelp) {
				char	path[MAX_PATH];
				MakePath(path, cfg.execDir, GetLoadStr(IDS_FASTCOPYHELP));
				if (wID == HELP_BUTTON)
					strcat(path, "#usage");
				pHtmlHelp(hWnd, path, HH_DISPLAY_TOC, 0);
			}
		}
		return	TRUE;
#endif
	}
	return	FALSE;
}

BOOL TMainDlg::EvSysCommand(WPARAM uCmdType, POINTS pos)
{
	switch (uCmdType)
	{
	case SC_RESTORE: case SC_MAXIMIZE:
		return	TRUE;

	case SC_MINIMIZE:
		PostMessage(WM_FASTCOPY_HIDDEN, 0, 0);
		return	TRUE;
	}
	return	FALSE;
}

/*
	DropFiles Event CallBack
*/
BOOL TMainDlg::EvDropFiles(HDROP hDrop)
{
	PathArray	pathArray;
	WCHAR	path[MAX_PATH_EX];
	BOOL	isDstDrop = IsDestDropFiles(hDrop);
	BOOL	isDeleteMode = COPY_LIST[SendDlgItemMessage(MODE_COMBO, CB_GETCURSEL, 0, 0)].mode == FastCopy::DELETE_MODE;
	int		max = isDstDrop ? 1 : ::DragQueryFileV(hDrop, 0xffffffff, 0, 0), max_len = 0;

	// CTL ��������Ă���ꍇ�A���݂̓��e�����Z
	if (!isDstDrop) {
		if (::GetAsyncKeyState(VK_CONTROL) & 0x8000) {
			max_len = ::GetWindowTextLengthV(GetDlgItem(SRC_COMBO)) + 1;
			WCHAR	*buf = new WCHAR [max_len];
			GetDlgItemTextV(SRC_COMBO, buf, max_len);
			pathArray.RegistMultiPath(buf);
			delete [] buf;
		}
		else
			isNetPlaceSrc = FALSE;
	}

	for (int i=0; i < max; i++) {
		if (::DragQueryFileV(hDrop, i, path, sizeof(path) / CHAR_LEN_V) <= 0)
			break;

		if (isDstDrop || !isDeleteMode) {
			if (NetPlaceConvertV(path, path) && !isDstDrop)
				isNetPlaceSrc = TRUE;
		}
		max_len += lstrlenV(path) + 3;
		pathArray.RegistPath(path);
	}
	::DragFinish(hDrop);

	if (max_len > 0) {
		WCHAR	*buf = new WCHAR [max_len += pathArray.Num() * 2];	// ������A���p�̈�

		if (isDstDrop) {
			DWORD	attr = ::GetFileAttributesV(pathArray.Path(0));
			if (attr & FILE_ATTRIBUTE_DIRECTORY) {	// 0xffffffff ���F�߂�(for 95�nOS��root�΍�)
				MakePathV(path, pathArray.Path(0), EMPTY_STR_V);
				SetDlgItemTextV(DST_COMBO, path);
			}
		}
		else {
			if (pathArray.GetMultiPath(buf, max_len))
				SetDlgItemTextV(SRC_COMBO, buf);
		}
		delete [] buf;
	}
	return	TRUE;
}

BOOL TMainDlg::IsDestDropFiles(HDROP hDrop)
{
	POINT	pt;
	RECT	dst_rect;

	if (::DragQueryPoint(hDrop, &pt) == FALSE || ::ClientToScreen(hWnd, &pt) == FALSE)
		return	FALSE;

	if (::GetWindowRect(GetDlgItem(DST_COMBO), &dst_rect) == FALSE || PtInRect(&dst_rect, pt) == FALSE)
		return	FALSE;

	return	TRUE;
}



BOOL TMainDlg::ExecCopy(BOOL cmdLineExec)
{
	int		idx = SendDlgItemMessage(MODE_COMBO, CB_GETCURSEL, 0, 0);
	BOOL	is_delete_mode = COPY_LIST[idx].mode == FastCopy::DELETE_MODE;

	info.ignoreErr		= IsDlgButtonChecked(IGNORE_CHECK);
	info.mode			= COPY_LIST[idx].mode;
	info.overWrite		= COPY_LIST[idx].overWrite;
	info.isPhysLock		= IS_WINNT_V ? TRUE : FALSE;
	info.flags			= cfg.copyFlags | (!is_delete_mode && IsDlgButtonChecked(ESTIMATE_CHECK) ? FastCopy::PRE_SEARCH : 0);
	info.bufSize		= GetDlgItemInt(BUFSIZE_EDIT) * 1024 * 1024;
	info.maxTransSize	= cfg.maxTransSize * 1024 * 1024;
	info.nbMinSizeNtfs	= cfg.nbMinSizeNtfs * 1024;
	info.nbMinSizeFat	= cfg.nbMinSizeFat * 1024;
	info.notifyWnd		= this;
	info.uNotifyMsg		= WM_FASTCOPY_END;
	errBufOffset		= 0;

	int		src_len = ::GetWindowTextLengthV(GetDlgItem(SRC_COMBO)) + 1;
	int		dst_len = ::GetWindowTextLengthV(GetDlgItem(DST_COMBO)) + 1;
	if (src_len <= 1 || !is_delete_mode && dst_len <= 1)
		return	FALSE;

	WCHAR	*src = new WCHAR [src_len], dst[MAX_PATH_EX] = L"";
	BOOL	ret = TRUE;
	BOOL	exec_confirm = cfg.execConfirm || (::GetAsyncKeyState(VK_CONTROL) & 0x8000);

	if (!exec_confirm) {
		if (isShellExt && cmdLineExec)
			exec_confirm = is_delete_mode ? !cfg.shextRNoConfirm : !cfg.shextDdNoConfirm;
		else
			exec_confirm = is_delete_mode ? !noConfirmDel : cfg.execConfirm;
	}

	if (GetDlgItemTextV(SRC_COMBO, src, src_len) == 0 || !is_delete_mode && GetDlgItemTextV(DST_COMBO, dst, MAX_PATH_EX) == 0) {
		MessageBox("Can't get src or dst field");
		ret = FALSE;
	}

	PathArray	srcArray, dstArray;
	srcArray.RegistMultiPath(src);
	if (!is_delete_mode)
		dstArray.RegistPath(dst);

	// �m�F�p�t�@�C���ꗗ

	if (ret && (ret = fastCopy.RegistInfo(&srcArray, &dstArray, &info))) {
		if (!is_delete_mode && cfg.EntryPathHistory(src, dst))
			SetPathHistory();
		cfg.WriteIni();
	}
	else
		SetDlgItemText(STATUS_EDIT, "Error");

	int	src_list_len = src_len + srcArray.Num() * 4;
	void *src_list = new WCHAR [src_list_len];

	if (ret && exec_confirm) {
		srcArray.GetMultiPath(src_list, src_list_len, NEWLINE_STR_V, EMPTY_STR_V);
		if (TExecConfirmDlg(info.mode, this).Exec(src_list, is_delete_mode ? NULL : dst) != IDOK)
			ret = FALSE;
	}

	int		pathLogMax = src_len * CHAR_LEN_V + sizeof(dst);

	if (ret && (pathLogBuf = new char [pathLogMax])) {
		if (IS_WINNT_V) {
			srcArray.GetMultiPath(src_list, src_list_len);
			::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)src_list, -1, (char *)src, src_len * CHAR_LEN_V, 0, 0);
			if (!is_delete_mode)
				::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)dstArray.Path(0), -1, (char *)dst, sizeof(dst), 0, 0);
		}
		int len = sprintf(pathLogBuf, "<Source>  %s\r\n", src);
		if (!is_delete_mode) {
			len += sprintf(pathLogBuf + len, "<DestDir> %s\r\n", dst);
		}
		sprintf(pathLogBuf + len, "<Command> %s\r\n\r\n", COPY_LIST[idx].list_str);
	}

	delete [] src_list;
	delete [] src;

	if (ret) {
		SetMiniWindow();
		SetDlgItemText(ERR_EDIT, "");
		::GetLocalTime(&startTm);

		if ((ret = fastCopy.Start())) {
			SetDlgItemText(IDOK, GetLoadStr(IDS_CANCEL));
			::SetTimer(hWnd, FASTCOPY_TIMER, 1000, NULL);
		}
	}
	if (!ret && pathLogBuf) {
		delete [] pathLogBuf;
		pathLogBuf = NULL;
	}
	return	ret;
}

BOOL TMainDlg::EndCopy(void)
{
	char	buf[1024];

	::KillTimer(hWnd, FASTCOPY_TIMER);

	if (fastCopy.IsStarting()) {
		::EnableWindow(GetDlgItem(IDOK), FALSE);
		fastCopy.End();
		::EnableWindow(GetDlgItem(IDOK), TRUE);
	}
	SetInfo(FALSE, TRUE);

	if (isErrLog) {
		EnableLogFile(isErrLog);
		::SetFilePointer(hErrLogFile, 0, 0, FILE_END);

		DWORD len = sprintf(buf, "-------------------------------------------------\r\n"
			"FastCopy start at %d/%02d/%02d %02d:%02d:%02d\r\n\r\n",
			startTm.wYear, startTm.wMonth, startTm.wDay,
			startTm.wHour, startTm.wMinute, startTm.wSecond);
		::WriteFile(hErrLogFile, buf, len, &len, 0);
		::WriteFile(hErrLogFile, pathLogBuf, strlen(pathLogBuf), &len, 0);

		if (errBufOffset) {
			::WriteFile(hErrLogFile, ti.errBuf->Buf(), errBufOffset, &len, 0);
			len = sprintf(buf, "%s", "\r\n\r\n");
			::WriteFile(hErrLogFile, buf, len, &len, 0);
		}
		else {
			char	msg[] = " No Errors\r\n\r\n";
			::WriteFile(hErrLogFile, msg, sizeof(msg) -1, &len, 0);
		}

		len = GetDlgItemText(STATUS_EDIT, buf, sizeof(buf));
		len += sprintf(buf + len, "%s", "\r\n\r\nResult : ");
		len += GetDlgItemText(ERRSTATUS_STATIC, buf + len, sizeof(buf) - len);
		len += sprintf(buf + len, "%s", "\r\n\r\n");
		::WriteFile(hErrLogFile, buf, len, &len, 0);
		EnableLogFile(FALSE);
	}
	delete [] pathLogBuf;
	pathLogBuf = NULL;

	SetDlgItemText(IDOK, GetLoadStr(IDS_EXECUTE));
	SetDlgItemText(SAMEDRV_STATIC, "");
	if (autoCloseLevel == FORCE_CLOSE || autoCloseLevel == NOERR_CLOSE && (ti.total.errFiles == 0 && ti.total.errDirs == 0))
		PostMessage(WM_CLOSE, 0, 0);
	autoCloseLevel = NO_CLOSE;

	if (isTaskTray)
		TaskTray(NIM_MODIFY, hMainIcon[curIconIndex = 0], FASTCOPY);
	return	TRUE;
}

BOOL TMainDlg::EventUser(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
	case WM_FASTCOPY_END:
		EndCopy();
		return	TRUE;

	case WM_FASTCOPY_NOTIFY:
		switch (lParam) {
		case WM_LBUTTONDOWN: case WM_RBUTTONDOWN:
			SetForceForegroundWindow();
			Show();
			break;

		case WM_LBUTTONUP: case WM_RBUTTONUP:
			Show();
			if (isErrEditHide && ti.errBuf && ti.errBuf->UsedSize())
				SetNormalWindow();
			TaskTray(NIM_DELETE);
			break;
		}
		return	TRUE;

	case WM_FASTCOPY_HIDDEN:
		Show(SW_HIDE);
		TaskTray(NIM_ADD, hMainIcon[0], FASTCOPY);
		return	TRUE;

	default:
		if (uMsg == TaskBarCreateMsg)
		{
			if (isTaskTray)
				TaskTray(NIM_ADD, hMainIcon[0], FASTCOPY);
			return	TRUE;
		}
	}
	return	FALSE;
}

BOOL TMainDlg::EvTimer(WPARAM timerID, TIMERPROC proc)
{
	SetInfo(isTaskTray ? TRUE : FALSE);
	return	TRUE;
}

BOOL TMainDlg::EnableLogFile(BOOL on)
{
	if (on && hErrLogFile == INVALID_HANDLE_VALUE) {
		char	path[MAX_PATH];
		MakePath(path, cfg.execDir, "fastcopy.log");
		hErrLogFile = ::CreateFile(path, GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_ALWAYS, 0, 0);
	}
	else if (!on && hErrLogFile != INVALID_HANDLE_VALUE) {
		::CloseHandle(hErrLogFile);
		hErrLogFile = INVALID_HANDLE_VALUE;
	}
	return	TRUE;
}

BOOL TMainDlg::CommandLineExecV(int argc, void **argv)
{
	VBuf	shellExtBuf;
	BOOL	is_openwin			= FALSE;
	BOOL	is_noexec			= FALSE;
	BOOL	is_delete			= FALSE;
	BOOL	is_estimate			= FALSE;
	void	*CMD_STR			= GetLoadStrV(IDS_CMD_OPT);
	void	*BUSIZE_STR			= GetLoadStrV(IDS_BUFSIZE_OPT);
	void	*LOG_STR			= GetLoadStrV(IDS_LOG_OPT);
	void	*ERRSTOP_STR		= GetLoadStrV(IDS_ERRSTOP_OPT);
	void	*ESTIMATE_STR		= GetLoadStrV(IDS_ESTIMATE_OPT);
	void	*OPENWIN_STR		= GetLoadStrV(IDS_OPENWIN_OPT);
	void	*AUTOCLOSE_STR		= GetLoadStrV(IDS_AUTOCLOSE_OPT);
	void	*FORCECLOSE_STR		= GetLoadStrV(IDS_FORCECLOSE_OPT);
	void	*NOEXEC_STR			= GetLoadStrV(IDS_NOEXEC_OPT);
	void	*SHELLEXT1_STR		= GetLoadStrV(IDS_SHEXT1_OPT);
	void	*SHELLEXT2_STR		= GetLoadStrV(IDS_SHEXT2_OPT);
	void	*SHELLEXT4_STR		= GetLoadStrV(IDS_SHEXT4_OPT);
	void	*FCSHEXT1_STR		= GetLoadStrV(IDS_FCSHEXT1_OPT);
	void	*NOCONFIRMDEL_STR	= GetLoadStrV(IDS_NOCONFIRMDEL_OPT);
	void	*TO_STR				= GetLoadStrV(IDS_TO_OPT);

	argc--, argv++;		// ���s�t�@�C������ skip

	while (*argv && GetChar(*argv, 0) == '/') {
		if (lstrnicmpV(*argv, CMD_STR, lstrlenV(CMD_STR)) == 0) {
			for (int i=0; COPY_LIST[i].cmdline_name; i++) {
				if (lstrcmpiV(MakeAddr(*argv, 5), COPY_LIST[i].cmdline_name) == 0)
					break;
			}
			if (!COPY_LIST[i].cmdline_name)
				return	MessageBox(GetLoadStr(IDS_USAGE), "Illegal Command"), FALSE;

			is_delete = COPY_LIST[i].mode == FastCopy::DELETE_MODE;

			// �R�}���h���[�h��I��
			SendDlgItemMessage(MODE_COMBO, CB_SETCURSEL, i, 0);
		}
		else if (lstrnicmpV(*argv, BUSIZE_STR, lstrlenV(BUSIZE_STR)) == 0) {
			SetDlgItemTextV(BUFSIZE_EDIT, MakeAddr(*argv, 9));
		}
		else if (lstrnicmpV(*argv, LOG_STR, lstrlenV(LOG_STR)) == 0) {
			isErrLog = TRUE;
		}
		else if (lstrnicmpV(*argv, ERRSTOP_STR, lstrlenV(ERRSTOP_STR)) == 0) {
			::CheckDlgButton(hWnd, IGNORE_CHECK, FALSE);
		}
		else if (lstrnicmpV(*argv, ESTIMATE_STR, lstrlenV(ESTIMATE_STR)) == 0) {
			is_estimate = TRUE;
		}
		else if (lstrnicmpV(*argv, OPENWIN_STR, lstrlenV(OPENWIN_STR)) == 0) {
			is_openwin = TRUE;
		}
		else if (lstrnicmpV(*argv, AUTOCLOSE_STR, lstrlenV(AUTOCLOSE_STR)) == 0) {
			autoCloseLevel = NOERR_CLOSE;
		}
		else if (lstrnicmpV(*argv, FORCECLOSE_STR, lstrlenV(FORCECLOSE_STR)) == 0) {
			autoCloseLevel = FORCE_CLOSE;
		}
		else if (lstrnicmpV(*argv, NOEXEC_STR, lstrlenV(NOEXEC_STR)) == 0) {
			is_noexec = TRUE;
		}
		else if (lstrnicmpV(*argv, SHELLEXT1_STR, lstrlenV(SHELLEXT1_STR)) == 0
			|| lstrnicmpV(*argv, SHELLEXT2_STR, lstrlenV(SHELLEXT2_STR)) == 0
			|| lstrnicmpV(*argv, SHELLEXT4_STR, lstrlenV(SHELLEXT4_STR)) == 0) {
			if (MessageBox(GetLoadStr(IDS_UPDATE), FASTCOPY, MB_OKCANCEL) == IDOK)
				UpdateShellExt(&cfg);
			return	FALSE;
		}
		else if (lstrnicmpV(*argv, FCSHEXT1_STR, lstrlenV(FCSHEXT1_STR)) == 0) {
			isShellExt = TRUE;
			is_openwin = !cfg.shextTaskTray;
			autoCloseLevel = cfg.shextAutoClose ? NOERR_CLOSE : NO_CLOSE;
			HANDLE	hStdInput = ::GetStdHandle(STD_INPUT_HANDLE);
			DWORD	read_size;
			BOOL	convertErr = FALSE;

			shellExtBuf.AllocBuf(SHELLEXT_MIN_ALLOC, SHELLEXT_MAX_ALLOC);
			while (::ReadFile(hStdInput, shellExtBuf.Buf() + shellExtBuf.UsedSize(), shellExtBuf.RemainSize(), &read_size, 0) && read_size > 0) {
				if (shellExtBuf.AddUsedSize(read_size) == shellExtBuf.Size())
					shellExtBuf.Grow(SHELLEXT_MIN_ALLOC);
			}
			shellExtBuf.Buf()[shellExtBuf.UsedSize()] = 0;

			if (convertErr)
				return	FALSE;
			if ((argv = CommandLineToArgvV(shellExtBuf.Buf(), &argc)) == NULL)
				break;
			continue;	// �� parse
		}
		else if (lstrnicmpV(*argv, NOCONFIRMDEL_STR, lstrlenV(NOCONFIRMDEL_STR)) == 0) {
			noConfirmDel = TRUE;
		}
		else
			return	MessageBoxV(GetLoadStrV(IDS_USAGE), *argv), FALSE;
		argc--, argv++;
	}

	SetDlgItemText(SRC_COMBO, "");
	SetDlgItemText(DST_COMBO, "");
	PathArray	pathArray;

	int		path_len = 0;
	WCHAR	wBuf[MAX_PATH_EX];

	while (*argv && GetChar(*argv, 0) != '/') {
		void	*path = *argv;
		if (isShellExt && !is_delete) {
			if (NetPlaceConvertV(path, wBuf)) {
				path = wBuf;
				isNetPlaceSrc = TRUE;
			}
		}
		pathArray.RegistPath(path);
		path_len += lstrlenV(path) + 3;
		argc--, argv++;
	}

	void	*path = new WCHAR [path_len];
	if (pathArray.GetMultiPath(path, path_len))
		SetDlgItemTextV(SRC_COMBO, path);
	delete [] path;

	void	*dst_path	= NULL;
	if (argc == 1 && lstrnicmpV(*argv, TO_STR, lstrlenV(TO_STR)) == 0) {
		dst_path = MakeAddr(*argv, lstrlenV(TO_STR));
		if (isShellExt && NetPlaceConvertV(dst_path, wBuf))
			dst_path = wBuf;
		SetDlgItemTextV(DST_COMBO, dst_path);
	}
	else if (argc >= 1)
		return	MessageBox(GetLoadStr(IDS_USAGE), "Too few/many argument"), FALSE;

	if (pathArray.Num() == 0 || (!is_delete && !dst_path)) {
		is_noexec = TRUE;
		if (isShellExt)			// �R�s�[��̖��� shell�N�����́Aautoclose �𖳎�����
			autoCloseLevel = NO_CLOSE;
	}

	SetItemEnable(is_delete);

	if (!is_delete && (is_estimate || !isShellExt && !is_noexec && cfg.estimateMode && !is_estimate))
		::CheckDlgButton(hWnd, ESTIMATE_CHECK, is_estimate);

	if (is_openwin || is_noexec)
		Show();
	else
		TaskTray(NIM_ADD, hMainIcon[0], FASTCOPY);

	return	is_noexec ? TRUE : ExecCopy(TRUE);
}

BOOL TMainDlg::TaskTray(int nimMode, HICON hSetIcon, LPCSTR tip)
{
	NOTIFYICONDATA	tn;

	isTaskTray = nimMode == NIM_DELETE ? FALSE : TRUE;

	memset(&tn, 0, sizeof(tn));
	tn.cbSize = sizeof(tn);
	tn.hWnd = hWnd;
	tn.uID = FASTCOPY_NIM_ID;		// test
	tn.uFlags = NIF_MESSAGE|(hSetIcon ? NIF_ICON : 0)|(tip ? NIF_TIP : 0);
	tn.uCallbackMessage = WM_FASTCOPY_NOTIFY;
	tn.hIcon = hSetIcon;
	if (tip)
		sprintf(tn.szTip, "%.63s", tip);

	return	::Shell_NotifyIcon(nimMode, &tn);
}

BOOL TMainDlg::SetInfo(BOOL is_task_tray, BOOL is_finish_status)
{
	char	buf[512];
	int		len = 0;
	double	doneRate;
	int		done_rate_i;
	int		remain_sec, total_sec, remain_h, remain_m, remain_s;

	fastCopy.GetTransInfo(&ti, is_task_tray ? FALSE : TRUE);
	if (ti.tickCount == 0)
		ti.tickCount++;

#define FILERATE_WARTERMARK	5

	if ((info.flags & FastCopy::PRE_SEARCH) && !ti.total.isPreSearch) {
		double	preFiles, preTrans, doneFiles, doneTrans, fileRate;
		int		misc_files = ti.total.skipFiles + ti.total.skipDirs + ti.total.errFiles + ti.total.errDirs;
		if (info.mode == FastCopy::DELETE_MODE) {
			preFiles = ti.total.preFiles + ti.total.preDirs + 0.01;
			doneFiles = ti.total.deleteFiles + ti.total.deleteDirs + misc_files + 0.01;
			doneRate = doneFiles / preFiles;
		}
		else {
			preFiles = (ti.total.preFiles + ti.total.preDirs) * 2 + 0.01;
			preTrans = (double)(ti.total.preTrans * 2 + 0.01);
			doneFiles = (ti.total.writeFiles + ti.total.writeDirs + ti.total.readFiles + ti.total.readDirs + (misc_files) * 2) + 0.01;
			doneTrans = (double)(ti.total.writeTrans + ti.total.readTrans + (ti.total.skipTrans + ti.total.errTrans) * 2 + 0.01);
			doneRate = ((doneFiles / preFiles) + (doneTrans / preTrans)) / 2;
			if ((fileRate = doneFiles / (ti.tickCount / 1000)) < FILERATE_WARTERMARK) {
				if (((preTrans - doneTrans) / (preFiles - doneFiles + 1)) > (doneTrans / doneFiles) / (FILERATE_WARTERMARK / fileRate))
					doneRate = (doneTrans / preTrans);
			}
		}
		remain_sec = (int)((ti.tickCount / doneRate - ti.tickCount) / 1000);
		total_sec = (int)(ti.tickCount / doneRate / 1000);
		remain_h = remain_sec / 3600, remain_m = (remain_sec % 3600) / 60, remain_s = remain_sec % 60;
		done_rate_i = (int)(doneRate * 100);
		SetWindowTitle("(%d%%) FastCopy %s", done_rate_i, GetVersionStr());
	}

	if (is_task_tray) {
		if (ti.total.isPreSearch) {
			len += sprintf(buf + len, " Estimating (Total %.1f MB/%d files/%d sec)",
				(double)ti.total.preTrans / (1024 * 1024),
				ti.total.preFiles,
				(int)(ti.tickCount / 1000));
		}
		else if ((info.flags & FastCopy::PRE_SEARCH) && !ti.total.isPreSearch && !is_finish_status && doneRate >= 0.0001) {
			len += sprintf(buf + len, "%d%% (Ramain %02d:%02d:%02d) ",
				done_rate_i, remain_h, remain_m, remain_s);
		}
		else if (info.mode == FastCopy::DELETE_MODE) {
			len += sprintf(buf + len, "FastCopy (%.1fMB %dfiles %.2fMB/s %dsec)",
				(double)ti.total.deleteTrans / (1024 * 1024),
				ti.total.deleteFiles,
				(double)ti.total.deleteFiles * 1000 / ti.tickCount,
				ti.tickCount / 1000);
		}
		else {
			len += sprintf(buf + len, "FastCopy (%.1fMB %dfiles %.2fMB/s %dsec)",
				(double)ti.total.writeTrans / (1024 * 1024),
				ti.total.writeFiles,
				(double)ti.total.writeTrans / ti.tickCount / 1024 * 1000 / 1024,
				ti.tickCount / 1000);
		}
		TaskTray(NIM_MODIFY, hMainIcon[curIconIndex = (curIconIndex+1) % MAX_FASTCOPY_ICON], buf);
		return	TRUE;
	}

	if (ti.total.isPreSearch) {
		len += sprintf(buf + len,
			" ---- Estimating ... ---\r\n"
			"PreTrans = %.1f MB\r\n"
			"PreFiles = %d (%d)\r\n"
			"PreTime  = %.2f sec\r\n"
			"PreRate  = %.2f files/s",
			(double)ti.total.preTrans / (1024 * 1024),
			ti.total.preFiles, ti.total.preDirs,
			(double)ti.tickCount / 1000,
			(double)ti.total.preFiles * 1000 / ti.tickCount);
	}
	else if (info.mode == FastCopy::DELETE_MODE) {
		len += sprintf(buf + len,
			"TotalDel  = %.1f MB\r\n"
			"DelFiles  = %d (%d)\r\n"
			"TotalTime = %.2f sec\r\n"
			"FileRate   = %.2f files/s",
			(double)ti.total.deleteTrans / (1024 * 1024),
			ti.total.deleteFiles, ti.total.deleteDirs,
			(double)ti.tickCount / 1000,
			(double)ti.total.deleteFiles * 1000 / ti.tickCount);
	}
	else {
		len = sprintf(buf + len,
			"TotalRead = %.1f MB\r\n"
			"TotalWrite = %.1f MB\r\n"
			"TotalFiles = %d (%d)\r\n"
			, (double)ti.total.readTrans / (1024 * 1024)
			, (double)ti.total.writeTrans / (1024 * 1024)
			, ti.total.writeFiles, ti.total.writeDirs);

		if (ti.total.skipFiles || ti.total.skipDirs) {
			len += sprintf(buf + len,
				"TotalSkip = %.1f MB\r\n"
				"SkipFiles = %d (%d)\r\n"
				, (double)ti.total.skipTrans / (1024 * 1024)
				, ti.total.skipFiles, ti.total.skipDirs);
		}
		if (ti.total.deleteFiles || ti.total.deleteDirs) {
			len += sprintf(buf + len,
				"TotalDel  = %.1f MB\r\n"
				"DelFiles  = %d (%d)\r\n"
				, (double)ti.total.deleteTrans / (1024 * 1024)
				, ti.total.deleteFiles, ti.total.deleteDirs);
		}
		len += sprintf(buf + len,
			"TotalTime = %.2f sec\r\n"
			"TransRate = %.2f MB/s\r\n"
			"FileRate   = %.2f files/s"
			, (double)ti.tickCount / 1000
			, (double)ti.total.writeTrans / ti.tickCount / 1024 * 1000 / 1024
			, (double)ti.total.writeFiles * 1000 / ti.tickCount);
	}

	if ((info.flags & FastCopy::PRE_SEARCH) && !ti.total.isPreSearch && !is_finish_status && doneRate >= 0.0001) {
		len += sprintf(buf + len, "\r\n -- Remain %02d:%02d:%02d (%d%%) --", remain_h, remain_m, remain_s, done_rate_i);
	}
	SetDlgItemText(STATUS_EDIT, buf);

	if (is_finish_status) {
		sprintf(buf, ti.total.errFiles || ti.total.errDirs ? "Finished. (ErrorFiles : %d  ErrorDirs : %d)" : "Finished.", ti.total.errFiles, ti.total.errDirs);
		SetDlgItemText(PATH_EDIT, buf);
		SetWindowTitle("FastCopy %s", GetVersionStr());
	}
	else
		SetDlgItemTextV(PATH_EDIT, ti.total.isPreSearch ? EMPTY_STR_V : ti.curPath);

	SetDlgItemText(SAMEDRV_STATIC, ti.isSameDrv ? GetLoadStr(IDS_SAMEHDD) : GetLoadStr(IDS_DIFFHDD));
	if (info.ignoreErr != ti.ignoreErr)
		::CheckDlgButton(hWnd, IGNORE_CHECK, info.ignoreErr = ti.ignoreErr);

	if (isErrEditHide && ti.errBuf->UsedSize() > 0) {
		SetNormalWindow();
	}
	if (ti.errBuf->UsedSize() > errBufOffset || errBufOffset == MAX_ERR_BUF) {
		if (errBufOffset != MAX_ERR_BUF) {
			char	*msg = (char *)ti.errBuf->Buf() + errBufOffset;
			SendDlgItemMessage(ERR_EDIT, EM_SETSEL, errBufOffset, errBufOffset);
			SendDlgItemMessage(ERR_EDIT, EM_REPLACESEL, 0, (LPARAM)msg);
			errBufOffset = ti.errBuf->UsedSize();	// �����ɂ�...
		}
		sprintf(buf, "(ErrFiles : %d / ErrDirs : %d)", ti.total.errFiles, ti.total.errDirs);
		SetDlgItemText(ERRSTATUS_STATIC, buf);
	}
	return	TRUE;
}

BOOL TMainDlg::SetWindowTitle(char *fmt,...)
{
	char	buf[1024];

	va_list	va;
	va_start(va, fmt);
	DWORD	len = wvsprintf(buf, fmt, va);
	va_end(va);

	return	SetWindowText(buf);
}

void TMainDlg::SetItemEnable(BOOL is_delete)
{
	::EnableWindow(GetDlgItem(DST_FILE_BUTTON), !is_delete);
	::EnableWindow(GetDlgItem(DST_COMBO), !is_delete);
	::ShowWindow(GetDlgItem(ESTIMATE_CHECK), is_delete ? SW_HIDE : SW_SHOW);
}


/*=========================================================================
  �N���X �F BrowseDirDlgV
  �T  �v �F �f�B���N�g���u���E�Y�p�R�����_�C�A���O�g���N���X
  ��  �� �F SHBrowseForFolder �̃T�u�N���X��
  ��  �� �F 
=========================================================================*/
BOOL BrowseDirDlgV(TWin *parentWin, UINT editCtl, void *title, int flg)
{
	if (SHBrowseForFolderV == NULL || SHGetPathFromIDListV == NULL)	// old version NT kernel.
		return	FALSE;

	IMalloc			*iMalloc = NULL;
	BROWSEINFO		brInfo;		// W version �Ƃ̍��́A�����|�C���^�n�����o�̌^�̈Ⴂ�̂�
	LPITEMIDLIST	pidlBrowse;
	WCHAR			fileBuf[MAX_PATH_EX] = L"";
	BOOL			ret = FALSE;
	void			*c_root_v = IS_WINNT_V ? (char *) L"C:\\" : "C:\\";

	parentWin->GetDlgItemTextV(editCtl, fileBuf, MAX_PATH_EX);
	if (GetChar(fileBuf, 0)) {
		void	*tok, *p;
		if ((flg & BRDIR_VQUOTE) && (tok = strtok_pathV(fileBuf, SEMICOLON_V, &p)))
			lstrcpyV(fileBuf, tok);
	}
	if (GetChar(fileBuf, 0) == 0)
		lstrcpyV(fileBuf, c_root_v);
	if (!SUCCEEDED(SHGetMalloc(&iMalloc)))
		return	FALSE;

	TBrowseDirDlgV	dirDlg(fileBuf);
	brInfo.hwndOwner = parentWin->hWnd;
	brInfo.pidlRoot = 0;
	brInfo.pszDisplayName = (char *)fileBuf;
	brInfo.lpszTitle = (char *)title;
	brInfo.ulFlags = BIF_RETURNONLYFSDIRS;
	brInfo.lpfn = TBrowseDirDlgV::BrowseDirDlg_Proc;
	brInfo.lParam = (LPARAM)&dirDlg;
	brInfo.iImage = 0;

	do {
		if ((pidlBrowse = ::SHBrowseForFolderV(&brInfo)) != NULL)
		{
			if (::SHGetPathFromIDListV(pidlBrowse, fileBuf)) {
				WCHAR	buf[MAX_PATH_EX];
				if (flg & BRDIR_BACKSLASH) {
					MakePathV(buf, fileBuf, EMPTY_STR_V);
					lstrcpyV(fileBuf, buf);
				}
				if ((flg & BRDIR_QUOTE) || (flg & BRDIR_VQUOTE) && strchrV(fileBuf, ';')) {
					wsprintfV(buf, FMT_QUOTE_STR_V, fileBuf);
					lstrcpyV(fileBuf, buf);
				}
				::SetDlgItemTextV(parentWin->hWnd, editCtl, fileBuf);
				ret = TRUE;
			}
			iMalloc->Free(pidlBrowse);
			break;
		}
	} while (dirDlg.IsDirty());

	iMalloc->Release();
	return	ret;
}

/*
	BrowseDirDlg�p�R�[���o�b�N
*/
int CALLBACK TBrowseDirDlgV::BrowseDirDlg_Proc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM data)
{
	switch (uMsg)
	{
	case BFFM_INITIALIZED:
		((TBrowseDirDlgV *)data)->CreateByWnd(hWnd);
		break;

	case BFFM_SELCHANGED:
		if (((TBrowseDirDlgV *)data)->hWnd)
			((TBrowseDirDlgV *)data)->SetFileBuf(lParam);
		break;
	}
	return 0;
}

/*
	BrowseDlg�p�T�u�N���X����
*/
BOOL TBrowseDirDlgV::CreateByWnd(HWND _hWnd)
{
	BOOL	ret = TSubClass::CreateByWnd(_hWnd);
	dirtyFlg = FALSE;

// �f�B���N�g���ݒ�
	DWORD	attr = GetFileAttributesV(fileBuf);
	if (attr != 0xffffffff && (attr & FILE_ATTRIBUTE_DIRECTORY) == 0)
		GetParentDirV(fileBuf, fileBuf);

	if (ILCreateFromPathV) {	// 2000/XP
		ITEMIDLIST *pidl = ILCreateFromPathV(fileBuf);
		SendMessageV(BFFM_SETSELECTION, FALSE, (LPARAM)pidl);
		ILFreeV(pidl);
	}
	else {
		char	buf[MAX_PATH_EX], *target;
		if (IS_WINNT_V)			// NT4.0
			::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)fileBuf, -1, target=buf, sizeof(buf), 0, 0);
		else					// Win98
			target = (char *)fileBuf;
		SendMessageV(BFFM_SETSELECTION, TRUE, (LPARAM)target);
	}

// �{�^���쐬
	RECT	tmp_rect;
	::GetWindowRect(GetDlgItem(IDOK), &tmp_rect);
	POINT	pt = { tmp_rect.left, tmp_rect.top };
	::ScreenToClient(hWnd, &pt);
	int		cx = (pt.x - 30) / 2, cy = tmp_rect.bottom - tmp_rect.top;

	::CreateWindow(BUTTON_CLASS, GetLoadStr(IDS_MKDIR), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, 10, pt.y, cx, cy, hWnd, (HMENU)MKDIR_BUTTON, TApp::GetInstance(), NULL);
	::CreateWindow(BUTTON_CLASS, GetLoadStr(IDS_RMDIR), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, 18 + cx, pt.y, cx, cy, hWnd, (HMENU)RMDIR_BUTTON, TApp::GetInstance(), NULL);

	HFONT	hDlgFont = (HFONT)SendDlgItemMessage(IDOK, WM_GETFONT, 0, 0L);
	if (hDlgFont)
	{
		SendDlgItemMessage(MKDIR_BUTTON, WM_SETFONT, (UINT)hDlgFont, 0L);
		SendDlgItemMessage(RMDIR_BUTTON, WM_SETFONT, (UINT)hDlgFont, 0L);
	}

	return	ret;
}

/*
	BrowseDlg�p WM_COMMAND ����
*/
BOOL TBrowseDirDlgV::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID)
	{
	case MKDIR_BUTTON:
		{
			WCHAR	dirBuf[MAX_PATH_EX], path[MAX_PATH_EX];
			TInputDlgV	dlg(dirBuf, this);
			if (dlg.Exec() == FALSE)
				return	TRUE;
			MakePathV(path, fileBuf, dirBuf);
			if (::CreateDirectoryV(path, NULL))
			{
				lstrcpyV(fileBuf, path);
				dirtyFlg = TRUE;
				PostMessage(WM_CLOSE, 0, 0);
			}
		}
		return	TRUE;

	case RMDIR_BUTTON:
		if (::RemoveDirectoryV(fileBuf))
		{
			GetParentDirV(fileBuf, fileBuf);
			dirtyFlg = TRUE;
			PostMessage(WM_CLOSE, 0, 0);
		}
		return	TRUE;
	}
	return	FALSE;
}

BOOL TBrowseDirDlgV::SetFileBuf(LPARAM list)
{
	return	::SHGetPathFromIDListV((LPITEMIDLIST)list, fileBuf);
}

/*
	�e�f�B���N�g���擾�i�K���t���p�X�ł��邱�ƁBUNC�Ή��j
*/
BOOL TBrowseDirDlgV::GetParentDirV(void *srcfile, void *dir)
{
	WCHAR	path[MAX_PATH_EX], *fname=NULL;

	if (::GetFullPathNameV(srcfile, MAX_PATH_EX, path, (void **)&fname) == 0 || fname == NULL)
		return	lstrcpyV(dir, srcfile), FALSE;

	if (((char *)fname - (char *)path) / CHAR_LEN_V > 3 || GetChar(path, 1) != ':')
		SetChar(fname, -1, 0);
	else
		SetChar(fname, 0, 0);		// C:\ �̏ꍇ

	lstrcpyV(dir, path);
	return	TRUE;
}


/*=========================================================================
  �N���X �F TInputDlgV
  �T  �v �F �P�s���̓_�C�A���O
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
BOOL TInputDlgV::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID)
	{
	case IDOK:
		GetDlgItemTextV(INPUT_EDIT, dirBuf, MAX_PATH_EX);
		EndDialog(TRUE);
		return	TRUE;

	case IDCANCEL:
		EndDialog(FALSE);
		return	TRUE;
	}
	return	FALSE;
}

const char *GetVersionStr(void)
{
	static char *version_str;

	if (version_str == NULL)
		version_str = strstr(mainwin_id, "ver");

	return	version_str;
}

#if 0
void DBGWrite(char *fmt,...)
{
	static HANDLE	hDbgFile = INVALID_HANDLE_VALUE;

	if (hDbgFile == INVALID_HANDLE_VALUE)
		hDbgFile = ::CreateFile("c:\\fastcopy_dbg.txt", GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_ALWAYS, 0, 0);

	char	buf[1024];
	va_list	va;
	va_start(va, fmt);
	DWORD	len = wvsprintf(buf, fmt, va);
	va_end(va);
	::WriteFile(hDbgFile, buf, len, &len, 0);
}
#endif

