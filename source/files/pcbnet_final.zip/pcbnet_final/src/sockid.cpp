// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"

EXPORT BOOL WINAPI setuid(int p1, int p2, int p3, int p4)
{
	THREADLIST *tl = (LPTHREADLIST)p1;
	THREADINFO *ti;
	if (! IsSocketHandle(tl, ST_ALL))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;

	ti = tl->ti;
	ti->Lock();
	ti->dwUser = (DWORD)p2;
	ti->Unlock();
	return 0;
}

EXPORT BOOL WINAPI getuid(int *p1, int p2, int p3, int p4)
{
	*p1 = 0;
	THREADLIST *tl = (LPTHREADLIST)p2;
	THREADINFO *ti;
	if (! IsSocketHandle(tl, ST_ALL))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;

	ti = tl->ti;
	ti->Lock();
	*p1 = (int)ti->dwUser;
	ti->Unlock();
	return 0;
}
