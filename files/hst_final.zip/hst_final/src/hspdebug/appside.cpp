// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include <windows.h>
#include "hspdll.h"
#include "common.h"


HWND hDWnd = NULL;

EXPORT BOOL WINAPI OpenDebugChannel(BMSCR *bm, char *p1, int p2, int p3);
EXPORT BOOL WINAPI RegisterDebugWindow(BMSCR *bm, int p1, int p2, int p3);
EXPORT BOOL WINAPI Break(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI Debug(int p1, int p2, int p3, int p4);


EXPORT BOOL WINAPI OpenDebugChannel(BMSCR *bm, char *p1, int p2, int p3)
{
	char mutexName[256];
	char shmemName[256];

	if (hMutex != NULL)
		return 1;

	strcpy(mutexName, MUTEX_HEAD);
	strcat(mutexName, p1);
	strcpy(shmemName, SHARED_MEMORY_HEAD);
	strcat(shmemName, p1);
	hMutex = OpenMutex(MUTEX_ALL_ACCESS, FALSE, mutexName);
	if (hMutex == NULL) {
		MessageBox(NULL,
			"�f�o�b�O�`�����l���̃I�[�v���Ɏ��s���܂����B",
			"�G���[ - hspdebug.hpi",
			MB_OK | MB_ICONERROR);
		return 1;
	}

	hMapping = OpenFileMapping(FILE_MAP_ALL_ACCESS, FALSE, shmemName);
	debuginfo = (LPDEBUGINFO)MapViewOfFile(hMapping, FILE_MAP_ALL_ACCESS, 0, 0, 0);

	/*
	WaitForSingleObject(hMutex, INFINITE);
	debuginfo->bRunning = TRUE;
	ReleaseMutex(hMutex);
	*/

	return 0;
}


EXPORT BOOL WINAPI RegisterDebugWindow(BMSCR *bm, int p1, int p2, int p3)
{
	if (hDWnd != NULL)
		return 1;
	hDWnd = bm->hwnd;
	return 0;
}


EXPORT BOOL WINAPI Break(int p1, int p2, int p3, int p4)
{
	MSG msg;

	if (! debuginfo->bDebugging)
		return -1;

	WaitForSingleObject(hMutex, INFINITE);
	debuginfo->bRunning = FALSE;
	debuginfo->bBreak = FALSE;
	debuginfo->bResume = FALSE;
	ReleaseMutex(hMutex);
	SendMessage(FindWindowEx(hDWnd, NULL, "ListBox", NULL), WM_SETFOCUS, 0, 0);

	while((!debuginfo->bResume) && (debuginfo->bDebugging)) {
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			if (msg.message >= WM_KEYFIRST && msg.message <= WM_KEYLAST)
				continue;
			if (msg.hwnd != hDWnd && GetParent(msg.hwnd) != hDWnd) {
				if (msg.message == WM_LBUTTONDOWN || msg.message == WM_LBUTTONUP || msg.message == WM_LBUTTONDBLCLK ||
					msg.message == WM_RBUTTONDOWN || msg.message == WM_RBUTTONUP || msg.message == WM_RBUTTONDBLCLK ||
					msg.message == WM_MBUTTONDOWN || msg.message == WM_MBUTTONUP || msg.message == WM_MBUTTONDBLCLK ||
					msg.message == WM_NCLBUTTONDOWN || msg.message == WM_NCLBUTTONUP || msg.message == WM_NCLBUTTONDBLCLK ||
					msg.message == WM_NCRBUTTONDOWN || msg.message == WM_NCRBUTTONUP || msg.message == WM_NCRBUTTONDBLCLK ||
					msg.message == WM_NCMBUTTONDOWN || msg.message == WM_NCMBUTTONUP || msg.message == WM_NCMBUTTONDBLCLK ||
					msg.message == WM_MOUSEACTIVATE)
					continue;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
			Sleep(10);
	}

	debuginfo->bRunning = TRUE;
	return 0;
}


EXPORT BOOL WINAPI Debug(int p1, int p2, int p3, int p4)
{
	if (! debuginfo->bDebugging)
		return 0;

	WaitForSingleObject(hMutex, INFINITE);
	debuginfo->current.script = p1;
	debuginfo->current.line = p2;
	if (debuginfo->bBreak) {
		ReleaseMutex(hMutex);
		Break(0, 0, 0, 0);
		return 0;
	}
	else {
		for(int i=0; i<MAX_BREAKPOINTS; i++) {
			if (debuginfo->bp[i].enabled &&
				debuginfo->bp[i].pos.script == p1 &&
				debuginfo->bp[i].pos.line == p2) {
				ReleaseMutex(hMutex);
				Break(0, 0, 0, 0);
				return 0;
			}
		}
	}
	ReleaseMutex(hMutex);
	return 0;
}








