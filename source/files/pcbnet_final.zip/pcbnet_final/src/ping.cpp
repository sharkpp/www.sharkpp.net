// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"


//	PING�\�P�b�g���쐬���AECHO���N�G�X�g�𑗐M
//		p1	�\�P�b�g�n���h�����i�[����ϐ�
//		p2	���M��z�X�g
//		p3	�^�C���A�E�g
//		p4	TTL
EXPORT BOOL WINAPI pingsend(int *p1, char *p2, int p3, int p4)
{
	*p1 = 0;
	if ( InitWSA() ) return -1;		// WinSock�������G���[

	if (p3 == 0)
		p3 = 255;
	if (p4 == 0)
		p4 = 255;
	if (p3 < 0 || p4 < 0 || p3 > 60000 || p4 > 255)
		return -3;

	THREADLIST *tl;
	tl = CreateSocketThread(ST_PING);
	if (tl == NULL)
		return -2;			//	Thread�������G���[

	SendMessage(tl->hWnd, WM_PINGTARGET, (WPARAM)MAKELONG(p3, p4), (LPARAM)p2);
	*p1 = (int)tl;
	return 0;
}


//	�`�F�b�N
//		p1	�\�P�b�gID
EXPORT BOOL WINAPI pingcheck(int p1, int p2, int p3, int p4)
{
	THREADLIST *tl = (LPTHREADLIST)p1;
	THREADINFO *ti;
	if (! IsSocketHandle(tl, ST_PING))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -2;

	ti = tl->ti;

	SendMessage(tl->hWnd, WM_TIMEOUT_CHECK, 0, 0);
	return ti->icmp.bReply ? -1 : 0;
}



//	hostaddr���擾
//		p1	���ʂ��i�[���鐔�l�ϐ�
//		p2	�\�P�b�gID
//		refstr	�Ԃ��ė����z�X�g��IP
EXPORT BOOL WINAPI pingresult(int *p1, int p2, int p3, char *refstr)
{
	*p1 = 0;
	refstr[0] = '\0';
	THREADLIST *tl = (LPTHREADLIST)p2;
	THREADINFO *ti;
	if (! IsSocketHandle(tl, ST_PING))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -2;

	struct in_addr inaddr;
	unsigned long time;
	ti = tl->ti;

	SendMessage(tl->hWnd, WM_TIMEOUT_CHECK, 0, 0);
	if (! ti->icmp.bReply)
		return -1;

	ti->Lock();
	
	if (ti->icmp.replyfrom != 0x00000000 && ti->icmp.replyfrom != 0xffffffff)
		strcpy(refstr, inet_ntoa((inaddr.s_addr = ti->icmp.replyfrom, inaddr)));

	if (ti->err != 0) {
		*p1 = -3;
	}
	else if (ti->icmp.replycode == ICMP_REPLY) {
		time = (ti->icmp.dwReplyTime - ti->icmp.dwSendTime);
		if (time > ti->icmp.dwTimeOut)
			*p1 = -1;
		else
			*p1 = (int)time;
	}
	else if (ti->icmp.replycode == ICMP_UNREACHED) {
		*p1 = -1;
	}
	else if (ti->icmp.replycode == ICMP_TTL) {
		*p1 = -2;
	}
	else {
		*p1 = -4;
	}

	ti->Unlock();
	return 0;
}



