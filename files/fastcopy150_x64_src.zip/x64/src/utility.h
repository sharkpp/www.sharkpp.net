/* static char *utility_id = 
	"@(#)Copyright (C) H.Shirouzu 2004-2005   utility.h	Ver1.30"; */
/* ========================================================================
	Project  Name			: Fast Copy file and directory
	Create					: 2004-09-15(Wed)
	Update					: 2005-11-28(Mon)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef UTILITY_H
#define UTILITY_H

#include "tlib.h"

class Condition {
protected:
	enum WaitEvent { CLEAR_EVENT=0, DONE_EVENT, WAIT_EVENT };
	CRITICAL_SECTION	cs;
	HANDLE				*hEvents;
	WaitEvent			*waitEvents;
	int					max_threads;
	int					waitCnt;

public:
	Condition(void);
	~Condition();

	BOOL Initialize(int _max_threads);
	void UnInitialize(void);

	void Lock(void)		{ ::EnterCriticalSection(&cs); }
	void UnLock(void)	{ ::LeaveCriticalSection(&cs); }

	BOOL Wait(DWORD timeout=INFINITE);
	void Notify(void);
};

class VBuf {
protected:
	BYTE	*buf;
	int		size;
	int		usedSize;
	int		maxSize;
	void	Init();

public:
	VBuf(int _size=0, int _max_size=0);
	~VBuf();
	BOOL	AllocBuf(int _size, int _max_size=0);
	BOOL	LockBuf();
	void	FreeBuf();
	BOOL	Grow(int grow_size);
	BYTE	*Buf() { return	buf; }
	int		Size() { return size; }
	int		MaxSize() { return maxSize; }
	int		UsedSize() { return usedSize; }
	void	SetUsedSize(int _used_size) { usedSize = _used_size; }
	int		AddUsedSize(int _used_size) { return usedSize += _used_size; }
	int		RemainSize(void) { return	size - usedSize; }
};

class Logging {
protected:
	char	*buf;
public:
	Logging();
};

class PathArray {
protected:
	int		num;
	void	**pathArray;
	BOOL	SetPath(int idx, const void *path);

public:
	PathArray(void);
	PathArray(const PathArray &);
	~PathArray();
	void	Init(void);
	int		RegistMultiPath(const void *multi_path, const void *separator=SEMICOLON_V);
	int		GetMultiPath(void *multi_path, int max_len, const void *separator=SEMICLN_SPC_V, const void *escape_char=SEMICOLON_V);

	PathArray& operator=(const PathArray& init);

	void	*Path(int idx) const { return idx < num ? pathArray[idx] : NULL; }
	int		Num(void) const { return	num; }
	BOOL	RegistPath(const void *path);
	BOOL	ReplacePath(int idx, void *new_path);
};

#define MAX_DRIVE_LETTER	26

class DriveMng {
protected:
	struct DriveID {
		BYTE	*data;
		int		len;
	} drvID[MAX_DRIVE_LETTER];	// A-Z drive
	int		noIdCnt;	// for Win95 family

	BOOL	RegisterDriveID(int index, void *data, int len);
	BOOL	SetDriveID(int drvLetter);
	int		LetterToIndex(int drvLetter) { return toupper(drvLetter) - 'A'; }

public:
	DriveMng();
	~DriveMng();
	void	Init();
	BOOL	IsSameDrive(int drvLetter1, int drvLetter2);
};

class HashVal {
	int		max_size;
	u_int	*rand_data;
public:
	HashVal(int max_size=0);
	~HashVal();
	void	Init(int max_size);
	u_int	MakeHash(void *data, int size);
};

// WinNT
#define MOUNTED_DEVICES		"SYSTEM\\MountedDevices"
#define FMT_DOSDEVICES		"\\DosDevices\\%c:"
// Win95
#define ENUM_DEVICES		"Enum"
#define DRIVE_LETTERS		"CurrentDriveLetterAssignment"
#define CONFIG_ENUM			"Config Manager\\Enum"
#define HARDWARE_KEY		"HardWareKey"
#ifndef HKEY_DYN_DATA
#define HKEY_DYN_DATA		((HKEY)0x80000006)
#endif

void *strtok_pathV(void *str, const void *sep, void **p);
void **CommandLineToArgvV(void *cmdLine, int *_argc);
int CALLBACK EditWordBreakProc(LPTSTR str, int cur, int len, int action);
BOOL hexstr2bin(const char *buf, BYTE *bindata, int maxlen, int *len);
void bin2hexstr(const BYTE *bindata, int len, char *buf);
BOOL NetPlaceConvertV(void *src, void *dst);

BOOL InstallExceptionFilter(char *title);

#endif

