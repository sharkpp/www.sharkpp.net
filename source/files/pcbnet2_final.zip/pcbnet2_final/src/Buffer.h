// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <deque>
#include <algorithm>

using namespace std;

#define BUFFER_BLOCK_SIZE 65536

class Buffer  
{

protected:

	typedef deque<char*> DataQueue;

	DataQueue q;

	int offset;
	int size;

public:
	Buffer();
	virtual ~Buffer();
	BOOL Write(void *pt, int len);
	int Read(void *buf, int nMax);
	int Peek(void *buf, int nMax);
	int Size();
	BOOL Destroy();

};

