<?php

include( dirname(__FILE__) . '/spyc.php5' );

class ImportYAML
{
	protected $log = '';
	static protected $STATUS_TEXT = array(
		'draft'    => Page::STATUS_DRAFT,
		'reviewed' => Page::STATUS_REVIEWED,
		'published'=> Page::STATUS_PUBLISHED,
		'hidden'   => Page::STATUS_HIDDEN,
	);

	function import($file)
	{
		$yaml = Spyc::YAMLLoad($file);
		$yaml['slug'] = '';
		return $this->import_core(0, $yaml, 0);
	}

	private function import_core($parent_id, $array, $level)
	{
		if( !isset($array['title']) || empty($array['title']) )
		{
			return false;
		}

		$data = array(
					'parent_id'     => $parent_id,
					'title'         => $array['title'],
					'slug'          => isset($array['slug']) ? $array['slug']
					                                         : bin2hex($array['title']),
					'breadcrumb'    => isset($array['breadcrumb']) ? $array['breadcrumb']
					                                               : $array['title'],
					'keywords'      => '',
					'description'   => '',
					'layout_id'     => '',
					'behavior_id'   => '',
					'status_id'     => Setting::get('default_status_id'),
					'position'      => Page::countFrom('Page', 'parent_id=?', array($parent_id)),
				);
		// status_id を設定
		if( isset($array['status_id']) )
		{
			if( in_array(intval($array['status_id']), self::$STATUS_TEXT) )
			{
				$data['status_id'] = intval($array['status_id']);
			}
			else if( isset(self::$STATUS_TEXT[strtolower($array['status_id'])]) )
			{
				$data['status_id'] = self::$STATUS_TEXT[strtolower($array['status_id'])];
			}
		}

		$page = Page::findOneFrom('Page', 'slug=? and parent_id=?', array($data['slug'], $parent_id));

		$this->log .= sprintf('%s%s%s<br>'
					, str_replace(' ', '&nbsp;&nbsp;', str_pad('', $level, ' '))
					, $array['title']
					, empty($page) ? '[new]' : '');

		// ページが無ければ追加
		if( empty($page) )
		{
			$page = new Page($data);

			if( !$page->save() )
			{
				Flash::set('error', __('Import faild!'));
				return false;
			}
		}

		// 一階層潜る
		if( isset($array['child']) )
		{
			foreach( $array['child'] as $child_array )
			{
				if( !$this->import_core($page->id, $child_array, $level + 1) )
				{
					return false;
				}
			}
		}

		return true;
	}

	public function getLog()
	{
		return $this->log;
	}
}

