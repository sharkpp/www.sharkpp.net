// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#define WINVER 0x400

#include "common.h"

EXPORT BOOL WINAPI rasdial(BMSCR *bm, char *p1, int p2, int p3)
{
	char s[256];
	PROCESS_INFORMATION pi;
	STARTUPINFO si;
	RASDIALDLG rdd;

	memset(&pi, 0, sizeof(pi));
	memset(&si, 0, sizeof(si));
	memset(&rdd, 0, sizeof(rdd));
	rdd.dwSize = sizeof(rdd);
	rdd.hwndOwner = bm->hwnd;
	__try {
		RasDialDlg(NULL, p1, NULL, &rdd);
	}
	__except(1) {
		sprintf(s, "rundll32.exe rnaui.dll,RnaDial %s", p1);
		if ( CreateProcess(NULL, s, NULL, NULL, FALSE, 
							0, NULL, NULL, &si, &pi) == 0)
			return -1;
		WaitForSingleObject(pi.hProcess, INFINITE);
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
	}
	return 0;
}


EXPORT BOOL WINAPI rasentry(char *p1, int p2, int p3, int p4)
{
	p1[0] = '\0';

	RASENTRYNAME *pEntry;
	DWORD cb, cEntries, ret, i;

	pEntry = new RASENTRYNAME;
	pEntry[0].dwSize = cb = sizeof(RASENTRYNAME);
	ret = RasEnumEntries(NULL, NULL, pEntry, &cb, &cEntries);
	delete pEntry;
	if (cb == 0) return 0;
	pEntry = (RASENTRYNAME *)new char[cb];
	pEntry[0].dwSize = sizeof(RASENTRYNAME);
	ret = RasEnumEntries(NULL, NULL, pEntry, &cb, &cEntries);
	if (ret == 0) {
		for(i=0; i<cEntries; i++) {
			strcat(p1, pEntry[i].szEntryName);
			strcat(p1, "\r\n");
		}
	}
	delete [] pEntry;
	if (ret != 0)
		return -1;
	return 0;
}



EXPORT BOOL WINAPI rasenum(char *p1, int p2, int p3, int p4)
{
	p1[0] = '\0';

	RASCONN *pConn;
	DWORD cb, cEntries, ret, i;

	pConn = new RASCONN;
	cb = sizeof(RASCONN);
	pConn[0].dwSize = cb = sizeof(RASCONN);
	RasEnumConnections(pConn, &cb, &cEntries);
	delete pConn;
	if (cb == 0) return 0;
	pConn = (RASCONN *)new char[cb];
	pConn[0].dwSize = sizeof(RASCONN);
	ret = RasEnumConnections(pConn, &cb, &cEntries);
	if (ret == 0) {
		for(i=0; i<cEntries; i++) {
			strcat(p1, pConn[i].szEntryName);
			strcat(p1, "\r\n");
		}
	}
	delete [] pConn;
	if (ret != 0)
		return -1;
	return 0;
}


EXPORT BOOL WINAPI rashang(int p1, int p2, int p3, int p4)
{
	RASCONN *pConn;
	HRASCONN hRas;
	RASCONNSTATUS rstat;
	DWORD cb, cEntries, ret;

	pConn = new RASCONN;
	pConn[0].dwSize = cb = sizeof(RASCONN);
	RasEnumConnections(pConn, &cb, &cEntries);
	delete pConn;
	if (cb == 0) return -1;
	pConn = (RASCONN *)new char[cb];
	pConn[0].dwSize = sizeof(RASCONN);
	ret = RasEnumConnections(pConn, &cb, &cEntries);
	if (ret != 0 || p1 < 0 || p1 >= (int)cEntries) {
		delete [] pConn;
		return -1;
	}
	hRas = pConn->hrasconn;
	delete [] pConn;
	RasHangUp(hRas);
	rstat.dwSize = sizeof(RASCONNSTATUS);
	while(RasGetConnectStatus(hRas, &rstat), rstat.dwError == 0)
		Sleep(10);
	return 0;
}






