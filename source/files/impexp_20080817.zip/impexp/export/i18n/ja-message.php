<?php

/**
 * this file has been translated by: Shark++
 */

return array(

'Export' => 'エクスポート',
'Download export file' => 'エクスポートファイルをダウンロード',
'What is this plugin?' => 'このプラグインは何をするの？',
'Downloaded to the local file from Frog CMS pages.
You can pages backup, import to another weblog.' => 'Frog CMSのページをローカルにダウンロードします。
 ページのバックアップや別のブログにインポートすることが出来ます。',

);