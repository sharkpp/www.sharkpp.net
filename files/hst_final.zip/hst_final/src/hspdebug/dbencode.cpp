// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include <windows.h>
#include <stdio.h>
#include "hspdll.h"
#include "common.h"

#define MAX_INCLUDE_NEST	8

char outDir[MAX_PATH+1] = "";
char commonDir[MAX_PATH+1] = "";


EXPORT BOOL WINAPI DBOutDir(BMSCR *bm, char *p1, int p2, int p3);
EXPORT BOOL WINAPI DBCommonDir(BMSCR *bm, char *p1, int p2, int p3);
BOOL scriptEncode(char *in, int *pn, char *scriptBuf, int nestlevel);
EXPORT BOOL WINAPI DBEncode(char *p1, char *p2, int p3, int p4);



EXPORT BOOL WINAPI DBOutDir(BMSCR *bm, char *p1, int p2, int p3)
{
	strcpy(outDir, p1);
	return 0;
}

EXPORT BOOL WINAPI DBCommonDir(BMSCR *bm, char *p1, int p2, int p3)
{
	strcpy(commonDir, p1);
	return 0;
}

BOOL scriptEncode(char *in, int *pn, char *scriptBuf, int nestlevel)
{
	FILE *fin, *fout, *fcopy;
	char buf[2048], tmp[2048], tmp2[2048], *p, *head;
	char outName[MAX_PATH+1], copyName[MAX_PATH+1];
	int line, n, i;

	if (nestlevel >= MAX_INCLUDE_NEST) return TRUE;

	n = *pn;
	sprintf(outName, "%s\\%03d.ds", outDir, n);
	sprintf(copyName, "%s\\%03d.as", outDir, n);
	fin = fopen(in, "r");
	if (fin == NULL) {
		sprintf(tmp, "%s\\%s", commonDir, in);
		fin = fopen(tmp, "r");
		if (fin == NULL) return TRUE;
	}

	fout = fopen(outName, "w");
	if (fout == NULL) {
		fclose(fin);
		return TRUE;
	}
	fcopy = fopen(copyName, "w");
	if (fcopy == NULL) {
		fclose(fin);
		fclose(fout);
		return TRUE;
	}
	strcat(scriptBuf, in);
	strcat(scriptBuf, "\r\n");
	(*pn)++;

	line = 0;
	while(fgets(buf, 2000, fin) != NULL) {
		for(head = buf; *head==0x20 || *head==0x09; head++);	//	�^�u�E�X�y�[�X��skip

		if (strnicmp(head, "#include", 8) == 0) {
		//	sprintf(tmp, "_d %d,%d:#include \"%03d.ds\"\n", n, line, *pn);
			sprintf(tmp, "#include \"%03d.ds\"\n", *pn);
			fputs(tmp, fout);

			p = strchr(head, '\"') + 1;			//	�t�@�C�����̐擪�ֈړ�
			for(i=0; p[i] != '\"' && p[i] != 0x0d && p[i] != 0x0a && p[i] != '\0'; i++)
				tmp[i] = p[i];
			tmp[i] = '\0';
			if (scriptEncode(tmp, pn, scriptBuf, nestlevel+1))
				return TRUE;
		}
/*		else if (strnicmp(head, "#deffunc", 8) == 0) {
			for(i=0; head[i] != ':' && head[i] != 0x0d && head[i] != 0x0a && head[i] != '\0'; i++)
				tmp[i] = head[i];
			tmp[i] = '\0';
			sprintf(tmp2, ":_d %d,%d", n, line);
			fputs(tmp, fout);
			fputs(tmp2, fout);
			fputs(head+i, fout);
		}
*/		else if (*head == '*') {
			i = 0;
			while(head[i] != 0x20 && head[i] != 0x09 && head[i] != 0x0d &&
				head[i] != 0x0a && head[i] != ':' && head[i] != '\0') i++;
			memcpy(tmp, head, i);
			tmp[i] = '\0';
			sprintf(tmp2, ":_d %d,%d", n, line);
			strcat(tmp, tmp2);
			strcat(tmp, head+i);
			fputs(tmp, fout);
		}
		else if (strnicmp(head, "else", 4) == 0 &&
				 (head[4] == 0x20 || head[4] == 0x09 || head[4] == '{' ||
				  head[4] == 0x0d || head[4] == 0x0a || head[4] == '\0' ) ) {
			for(p = head + 4; *p==0x20 || *p==0x09; p++);
			if (*p == '{') {
				sprintf(tmp, "else{_d %d,%d:%s", n, line, p+1);
			}
			else {
				sprintf(tmp, "else:_d %d,%d:%s", n, line, p);
			}
			fputs(tmp, fout);
		}
		else if (head[0] == '#') {
			fputs(head, fout);
		}
		else {
			sprintf(tmp, "_d %d,%d:", n, line);
			fputs(tmp, fout);
			fputs(head, fout);
		}

		fputs(buf, fcopy);
		line++;
	}
//	sprintf(tmp, "\n_d %d,%d:pos", n, line-1);
//	fputs(tmp, fout);
	fclose(fin);
	fclose(fout);
	fclose(fcopy);
	return FALSE;
}


EXPORT BOOL WINAPI DBEncode(char *p1, char *p2, int p3, int p4)
{
	int pn = 0;
	char curDir[MAX_PATH+1], oldCurDir[MAX_PATH+1];
	char in[MAX_PATH+1], scriptBuf[4096] = "";
	BOOL bFailure;

	GetCurrentDirectory(MAX_PATH+1, oldCurDir);
	p1[0] = '\0';

	if (outDir[0] == '\0') return -2;

	if (strrchr(p2, '\\') == NULL) {
		strcpy(in, oldCurDir);
		strcat(in, "\\");
		strcat(in, p2);
		strcpy(curDir, oldCurDir);
	}
	else {
		strcpy(in, p2);
		strcpy(curDir, p2);
		curDir[(int)(strrchr(p2, '\\') - p2)] = '\0';
	}

	SetCurrentDirectory(curDir);
	bFailure = scriptEncode(strrchr(in, '\\') + 1, &pn, scriptBuf, 0);
	SetCurrentDirectory(oldCurDir);

	if (bFailure)
		return -1;
	strcpy(p1, scriptBuf);
	return 0;
}




