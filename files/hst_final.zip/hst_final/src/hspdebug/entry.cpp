// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include <windows.h>
#include "common.h"

/*
 *		�G���g���|�C���g��`
 */
int APIENTRY DllMain(HINSTANCE hInstance, DWORD fdwReason, LPVOID lpvReserved)
{
	switch(fdwReason) {
	case DLL_PROCESS_ATTACH:
		MEMLEAK_CHECK();
		break;
	}
	return TRUE;
}

