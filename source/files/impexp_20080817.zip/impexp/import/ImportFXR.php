<?php

class ImportFXR
{
	static protected $layout_table;
	static protected $snippet_table;
	static protected $page_table;
	static protected $page_part_table;

	static protected $users;

	protected $base_url;

	protected $log = '';

	function __construct()
	{
		self::$layout_table =
			array(
			//	'id'			=> null,
				'name'			=> null,
				'content_type'	=> null,
				'content'		=> null,
				'created_on'	=> create_function('$val', 'return date("Y-m-d H:i:s", strtotime($val));'),
				'updated_on'	=> create_function('$val', 'return date("Y-m-d H:i:s", strtotime($val));'),
				'created_by_id'	=> create_function('$val', 'return ImportFXR::get_id_from_user_name($val);'),
				'updated_by_id'	=> create_function('$val', 'return ImportFXR::get_id_from_user_name($val);'),
				'position'		=> null,
			);

		self::$snippet_table =
			array(
			//	'id'			=> null,
				'name'			=> null,
				'filter_id'		=> null,
				'content'		=> null,
				'created_on'	=> create_function('$val', 'return date("Y-m-d H:i:s", strtotime($val));'),
				'updated_on'	=> create_function('$val', 'return date("Y-m-d H:i:s", strtotime($val));'),
				'created_by_id'	=> create_function('$val', 'return ImportFXR::get_id_from_user_name($val);'),
				'updated_by_id'	=> create_function('$val', 'return ImportFXR::get_id_from_user_name($val);'),
				'position'		=> null,
			);

		self::$page_table =
			array(
			//	'id'			=> null,
				'parent_id'		=> null,
				'layout_id'		=> null,
				'slug'			=> null,
				'breadcrumb'	=> null,
				'behavior_id'	=> null,
				'status_id'		=> null,
				'created_on'	=> create_function('$val', 'return date("Y-m-d H:i:s", strtotime($val));'),
				'published_on'	=> create_function('$val', 'return date("Y-m-d H:i:s", strtotime($val));'),
				'updated_on'	=> create_function('$val', 'return date("Y-m-d H:i:s", strtotime($val));'),
				'created_by_id'	=> create_function('$val', 'return ImportFXR::get_id_from_user_name($val);'),
				'updated_by_id'	=> create_function('$val', 'return ImportFXR::get_id_from_user_name($val);'),
				'position'		=> null,
				'is_protected'	=> null,
			);

		self::$page_part_table =
			array(
			//	'id'			=> null,
				'name'			=> null,
				'filter_id'		=> null,
				'content'		=> null,
			);

		self::$users = array();
		foreach(Record::findAllFrom('User') as $user)
		{
			self::$users[$user->username] = $user->id;
		}
	}

	public function import($file)
	{
		return $this->import_core(DOMDocument::load($file));
	}

	public function getLog()
	{
		return $this->log;
	}

	private function import_core($dom)
	{

	//	$dom->normalizeDocument();

		// フォーマットチェック

		$root = $dom->getElementsByTagName('rss')->item(0);
		if( empty($root) )
		{
			Flash::set('error', __('Unsupported import format!'));
			return false;
		}

		$channel = $root->getElementsByTagName('channel')->item(0);
		if( empty($channel) )
		{
			Flash::set('error', __('Unsupported import format!'));
			return false;
		}

		// インポートループ

		foreach($channel->childNodes as $item)
		{
		//	echo $item->nodeName . "/" . $item->nodeType . "\n";
			if( XML_ELEMENT_NODE != $item->nodeType )
			{
				continue;
			}

			switch( $item->nodeName )
			{
			case 'frog:base_site_url':
				$this->base_url = $item->nodeValue;
				break;
			case 'frog:export_version':
				if( doubleval($item->nodeValue) + 0.0001 < 1.0 )
				{
					Flash::set('error', __('Unsupported import format!'));
					return false;
				}
				break;
			case 'frog:layout':
				if( false == $this->import_layout($item) )
				{
					Flash::set('error',
							__('Broken import data! Near the %name%'
								, array('%name%' => $item->nodeName))
						);
					return false;
				}
				break;
			case 'frog:snippet':
				if( false == $this->import_snippet($item) )
				{
					Flash::set('error',
							__('Broken import data! Near the %name%'
								, array('%name%' => $item->nodeName))
						);
					return false;
				}
				break;
			case 'item':
				if( false == $this->import_page($item) )
				{
					Flash::set('error',
							__('Broken import data! Near the %name%'
								, array('%name%' => $item->nodeName))
						);
					return false;
				}
				break;
			}
		}

		return true;
	}

	// ユーザー名からIDを取得
	static public function get_id_from_user_name($username)
	{
		return
			isset(self::$users[$username]) ? self::$users[$username]
			                               : AuthUser::getId();
	}

	// データをXMLから取得
	static private function get_value_core(& $table, & $field, & $value)
	{
		if( array_key_exists($field, $table) )
		{
			if( is_null($table[$field]) )
			{
				return $value;
			}
			else
			{
				return $table[$field]($value);
			}
		}
		return false;
	}

	static private function get_value($prefix, & $table, & $element)
	{
		$data = array();
		// データ列挙
		foreach($element->childNodes as $item)
		{
			if( XML_ELEMENT_NODE != $item->nodeType ||
				'frog' != $item->prefix )
			{
				continue;
			}

			$field = str_replace($prefix . '_', '', $item->localName);

			$value = self::get_value_core($table, $field, $item->nodeValue);
			if( false !== $value )
			{
				$data[ $field ] = $value;
			}
		}
		return $data;
	}

	private static function import_fix_date($class_name, $id, $created_on, $updated_on, $published_on = null)
	{
		$data['created_on'] = $created_on;
		$data['updated_on'] = $updated_on;
		if( !is_null($published_on) )
		{
			$data['published_on'] = $published_on;
		}
		return Record::update(
				$class_name,
				$data,
				'id=' . Record::escape($id),
				array()
			);
	}

	private function import_layout(& $element)
	{
		$data = self::get_value('layout', self::$layout_table, $element);

		if( empty($data) )
		{
			return false;
		}

		if( !( $layout = Layout::findOneFrom('Layout', 'name=?', array($data['name'])) ) )
		{
			$layout = new Layout($data);
		}
		else
		{
			$layout->setFromData($data);
			unset($layout->created_by_name);
			unset($layout->updated_by_name);
		}

		if( !$layout->save() )
		{
			return false;
		}

		return self::import_fix_date('Layout', $layout->id, $data['created_on'], $data['updated_on']);
	}

	private function import_snippet(& $element)
	{
		$data = self::get_value('snippet', self::$snippet_table, $element);

		if( empty($data) )
		{
			return false;
		}

		if( !( $snippet = Snippet::findOneFrom('Snippet', 'name=?', array($data['name'])) ) )
		{
			$snippet = new Snippet($data);
		}
		else
		{
			$snippet->setFromData($data);
			unset($snippet->created_by_name);
			unset($snippet->updated_by_name);
		}

		if( !$snippet->save() )
		{
			return false;
		}

		return self::import_fix_date('Snippet', $snippet->id, $data['created_on'], $data['updated_on']);
	}

	private function get_parent_id($path)
	{
		$path = '/' . ltrim(substr($path, strlen($this->base_url)), '/');

		if( URL_SUFFIX == substr($path, -strlen(URL_SUFFIX), strlen(URL_SUFFIX)) )
		{
			$path = substr($path, 0, -strlen(URL_SUFFIX));
		}

		if( '/' == $path )
		{
			$path = '';
		}

		$slugs = explode('/', $path);

		array_pop($slugs);

		$parent_id = 0;

		if( empty($slugs) )
		{
			return $parent_id;
		}

		if( '' != $slugs[0] )
		{
			array_unshift($slugs, '');
		}

		foreach($slugs as $slug)
		{
			if( !( $page = Page::findOneFrom('Page', 'parent_id=? AND slug=?', array($parent_id, $slug)) ) )
			{
				$page =
					new Page(
							array(
								'parent_id'   => $parent_id,
								'title'       => $slug,
								'slug'        => $slug,
								'breadcrumb'  => $slug,
								'keywords'    => '', 'description' => '', 'layout_id'   => '', 'behavior_id' => '',
								'status_id'   => Setting::get('default_status_id'),
								'position'    => '',//Page::countFrom('Page', 'parent_id=?', array($parent_id)),
							)
						);

				if( !$page->save() )
				{
					return false;
				}
			}
			$parent_id = $page->id;
		}

		return $parent_id;
	}

	private function import_page(& $element)
	{
		$data = self::get_value('page', self::$page_table, $element);

		if( empty($data) )
		{
			return false;
		}

		$link = '';

		// データ列挙
		foreach($element->childNodes as $item)
		{
			if( XML_ELEMENT_NODE != $item->nodeType )
			{
				continue;
			}

			switch( $item->nodeName )
			{
			case 'title':
			case 'description':
				$data[ $item->nodeName ] = $item->nodeValue;
				break;
			case 'link':
				$link = $item->nodeValue;
				break;
			}
		}

		if( empty($link) )
		{
			return false;
		}

		if( false === ($data['parent_id'] = $this->get_parent_id($link)) )
		{
			return false;
		}

		if( !( $page = Page::findOneFrom('Page', 'parent_id=? AND slug=?', array($data['parent_id'], $data['slug'])) ) )
		{
			$page = new Page($data);
		}
		else
		{
			$page->setFromData($data);
			unset($page->created_by_name);
			unset($page->updated_by_name);

			if( !empty($page->created_on) ) {
				$page->created_on_time = substr($page->created_on, 0, 10);
				$page->created_on      = substr($page->created_on, 11);
			}
			if( !empty($page->published_on) ) {
				$page->published_on_time = substr($page->published_on, 0, 10);
				$page->published_on      = substr($page->published_on, 11);
			}
		}

		if( !$page->save() )
		{
			return false;
		}

		if( !self::import_fix_date('Page', $page->id, $data['created_on'], $data['updated_on'], $data['published_on']) )
		{
			return false;
		}

		// データ列挙
		foreach($element->childNodes as $item)
		{
			if( XML_ELEMENT_NODE != $item->nodeType )
			{
				continue;
			}

			switch( $item->nodeName )
			{
			case 'frog:part':
				if( false == $this->import_page_part($item, $page->id) )
				{
					return false;
				}
				break;
			}
		}

		return true;
	}

	private function import_page_part(& $element, $page_id)
	{
		$data = self::get_value('part', self::$page_part_table, $element);

		if( empty($data) )
		{
			return false;
		}

	//	$data['content_html'] = $data['content'];
		$data['page_id'] = $page_id;

		if( !( $page_part = Page::findOneFrom('PagePart', 'page_id=? AND name=?', array($page_id, $data['name'])) ) )
		{
			$page_part = new PagePart($data);
		}
		else
		{
			$page_part->setFromData($data);
			unset($page_part->created_by_name);
			unset($page_part->updated_by_name);
		}

		return $page_part->save();
	}
}

