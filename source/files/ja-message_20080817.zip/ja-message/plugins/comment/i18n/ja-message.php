<?php

/**
 * this file has been translated by: Shark++
 */

return array(

// Comments
'Delete' => '削除',
'Reject' => '排除',
'No comments found.' => 'コメントが見つかりません。',

);