// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"

#define isint(x) ((x)>='0'&&(x)<='9')
#define ishex(x) (isint(x) || ((x)>='A' && (x)<='F') || ((x)>='a' && (x)<='f'))



int getint(int *r, char *p, BOOL bSigned)
{
	int n, c;

	n = c = 0;

	if (*p != '-')
		bSigned = FALSE;
	if (bSigned) p++;

	while(isint(*p)) {
		n = n * 10 + (*p - '0');
		p++; c++;
	}
	*r = n * ( bSigned ? -1 : 1);
	return c;
}

int hextoint(char c)
{
	if (! ishex(c)) return -1;
	if (c >= 'A')
		return (c&0x0f)-1+10;
	return c-'0';
}

int hextoint(char *lpszString)
{
	int n, i;

	n = 0;
	for(i=0; ishex(lpszString[i]); i++) {
		n = n * 0x10 + hextoint(lpszString[i]);
	}
	return n;
}

char inttohex(int i)
{
	return i < 10 ? '0'+i : 'A'+(i-10);
}

void inttohex(char *lpszString, int iNum, int iSig, BOOL bPrintZero)
{
	int t, k, i;

	t=1;
	for(k=0; (unsigned int)iNum >= (unsigned int)t; k++)
		t <<= 4;

	if (bPrintZero) {
		for(i=iSig-1; i>=0; i--) {
			lpszString[i] = inttohex((int)(((unsigned int)iNum)&0xf));
			iNum >>= 4;
		}
	}
	else {
		if (k >= iSig) {
			for(i=iSig-1; i>=0; i--) {
				lpszString[i] = inttohex((int)(((unsigned int)iNum)&0xf));
				iNum >>= 4;
			}
		}
		else {
			for(i=k-1; i>=0; i--) {
				lpszString[i] = inttohex((int)(((unsigned int)iNum)&0xf));
				iNum >>= 4;
			}
		}
	}
}


int strtoint(char *lpszString)
{
	int n;
	if (strncmp(lpszString, "0x", 2) == 0) {
		return hextoint(&lpszString[2]);
	}
	getint(&n, lpszString, TRUE);
	return n;
}






int pack_sub(char *lpOut, char cFormatCode, int iSize, CHSPParam *lpprm)
{
	CHSPParam &prm = *lpprm;
	char *p;
	char s[64];
	int n, t, i;
	int type;

	type = prm.nexttype();
	switch(cFormatCode) {
	case 'i':
		t = prm.geti();
		if (prm.geterr()) return -prm.geterr();
		*(int *)lpOut = t;
		return sizeof(int);
	case 's':
	case 'S':
		t = prm.geti();
		if (prm.geterr()) return -prm.geterr();
		*(short *)lpOut = (short)t;
		return sizeof(short);
	case 'c':
	case 'C':
		t = prm.geti();
		if (prm.geterr()) return -prm.geterr();
		*(char *)lpOut = (char)t;
		return sizeof(char);
	case 'a':
		p = prm.gets();
		if (prm.geterr()) return -prm.geterr();
		n = strlen(p);
		if (iSize < 0) iSize = n+1;
		if (iSize > n+1) {
			memcpy(lpOut, p, n);
			memset(&lpOut[n], '\0', iSize - n);
		}
		else {
			memcpy(lpOut, p, iSize);
		}
		return iSize;
	case 'd':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0) return -3;
		memcpy(lpOut, p, iSize);
		return iSize;
	case 'D':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0)
			iSize = prm.getsize(prm.getpval());
		memcpy(lpOut, p, iSize);
		return iSize;
	case 'x':
		if (iSize < 0) iSize = 1;
		memset(lpOut, '\0', iSize);
		return iSize;
	case 'f':
		p = (char *)prm.gets();
		if (prm.geterr()) return -prm.geterr();
		*(float *)lpOut = *(float *)p;
		return sizeof(float);
	case 'F':
		p = (char *)prm.gets();
		if (prm.geterr()) return -prm.geterr();
		*(double *)lpOut = *(double *)p;
		return sizeof(double);
	case 'N':
		t = prm.geti();
		if (prm.geterr()) return -prm.geterr();
		*(int *)lpOut = (int)htonl((unsigned long)t);
		return sizeof(int);
	case 'n':
		t = prm.geti();
		if (prm.geterr()) return -prm.geterr();
		*(short *)lpOut = (short)htons((unsigned short)t);
		return sizeof(short);
	case 'p':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)lpOut = (int)p;
		return sizeof(void *);
	case 'H':
		p = (char *)prm.gets();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0) return -3;
		n = strlen(p);
		for(i=0; i<iSize; i++) {
			if (i*2 >= n) {
				t = 0;
			}
			else if (i*2+1 == n) {
				t = hextoint(p[i*2]) * 0x10;
			}
			else {
				strncpy(s, &p[i*2], 2)[2] = '\0';
				t = hextoint(s);
			}
			lpOut[i] = (char)t;
		}
		return iSize;
	case 'h':
		p = (char *)prm.gets();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0) return -3;
		n = strlen(p);
		for(i=0; i<iSize; i++) {
			if (n-2-(i*2) <= -2) {
				t = 0;
			}
			else {
				if (n-2-(i*2) < 0)
					strncpy(s, &p[0], 1)[1] = '\0';
				else
					strncpy(s, &p[n-2-(i*2)], 2)[2] = '\0';
				t = hextoint(s);
			}
			lpOut[i] = (char)t;
		}
		return iSize;
	case '@':
		if (iSize < 0)
			iSize = prm.getwid();
		*(int *)lpOut = (int)prm.getbmscr(iSize)->hwnd;
		return sizeof(int);
	default:
		return -3;
	}
}





EXPORT BOOL WINAPI pack(HSPEXINFO *hei, int _p1, int _p2, int _p3)
{
	CHSPParam prm(hei);
	char *lpOut, *lpszFormat;
	int posOut, posFormat;
	int ret;
	int iSize;
	char cFormatCode;

	lpOut = (char *)prm.getv();
	lpszFormat = prm.gets();
	if (prm.geterr()) return prm.geterr();

	posOut = posFormat = 0;
	while((cFormatCode = lpszFormat[posFormat]) != '\0') {
		posFormat++;
		ret = getint(&iSize, &lpszFormat[posFormat], FALSE);
		if (ret == 0)
			iSize = -1;
		else
			posFormat+=ret;
		ret = pack_sub(&lpOut[posOut], cFormatCode, iSize, &prm);
		if (ret < 0)
			return -ret;	// failed while parsing format string
		posOut+=ret;
	}
	return -posOut;
}





int unpack_sub(char *lpIn, char cFormatCode, int iSize, CHSPParam *lpprm)
{
	CHSPParam &prm = *lpprm;
	char *p;
	int t, i;

	switch(cFormatCode) {
	case 'i':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)p = *(int *)lpIn;
		return sizeof(int);
	case 's':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)p = (int)*(unsigned short *)lpIn;
		return sizeof(short);
	case 'S':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)p = (int)*(short *)lpIn;
		return sizeof(short);
	case 'c':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)p = (int)*(unsigned char *)lpIn;
		return sizeof(char);
	case 'C':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)p = (int)*(char *)lpIn;
		return sizeof(char);
	case 'a':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0)
			iSize = strlen(lpIn)+1;
		strncpy(p, lpIn, iSize)[iSize] = '\0';
		return iSize;
	case 'd':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0) return -3;
		memcpy(p, lpIn, iSize);
		return iSize;
	case 'D':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0)
			iSize = prm.getsize(prm.getpval());
		memcpy(p, lpIn, iSize);
		return iSize;
	case 'x':
		if (iSize < 0) iSize = 1;
		return iSize;
	case 'f':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(float *)p = *(float *)lpIn;
		return sizeof(float);
	case 'F':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(double *)p = *(double *)lpIn;
		return sizeof(double);
	case 'N':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)p = (int)ntohl(*(unsigned long *)lpIn);
		return sizeof(int);
	case 'n':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)p = (int)ntohs(*(unsigned short *)lpIn);
		return sizeof(short);
	case 'p':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		*(int *)p = *(int *)lpIn;
		return sizeof(void *);
	case 'H':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0) return -3;
		for(i=0; i<iSize; i++)
			p+=sprintf(p, "%02x", (int)*(unsigned char *)lpIn);
		return iSize;
	case 'h':
		p = (char *)prm.getv();
		if (prm.geterr()) return -prm.geterr();
		if (iSize < 0) return -3;
		for(i=0; i<iSize; i++)
			if (lpIn[i] != 0) break;
		if (i == iSize) {
			sprintf(p, "0");
			return iSize;
		}
		t=0;
		for(i=iSize-1; i>=0; i--) {
			if (lpIn[i] == 0 && t == 0)
				continue;
			if (t == 0) {
				p+=sprintf(p, "%x", (int)*(unsigned char *)lpIn);
				t = 1;
			}
			else {
				p+=sprintf(p, "%02x", (int)*(unsigned char *)lpIn);
			}
		}
		return iSize;
	default:
		return -3;
	}
}


EXPORT BOOL WINAPI unpack(HSPEXINFO *hei, int _p1, int _p2, int _p3)
{
	CHSPParam prm(hei);
	char *lpIn, *lpszFormat;
	int posIn, posFormat;
	int ret;
	int iSize;
	char cFormatCode;

	lpIn = (char *)prm.getv();
	lpszFormat = prm.gets();
	if (prm.geterr()) return prm.geterr();

	posIn = posFormat = 0;
	while((cFormatCode = lpszFormat[posFormat]) != '\0') {
		posFormat++;
		ret = getint(&iSize, &lpszFormat[posFormat], FALSE);
		if (ret == 0)
			iSize = -1;
		else
			posFormat+=ret;
		ret = unpack_sub(&lpIn[posIn], cFormatCode, iSize, &prm);
		if (ret < 0)
			return -ret;	// failed while parsing format string
		posIn+=ret;
	}
	return -posIn;
}


