<?php

$PDO = Record::getConnection();
$driver = strtolower($PDO->getAttribute(Record::ATTR_DRIVER_NAME));

// トラックバックテーブルの構造を定義 ----------------------------------------

if ($driver == 'mysql')
{
	$utf8_support = version_compare(mysql_get_client_info(), '4.1.0', '>=');

	$PDO->exec("CREATE TABLE ".TABLE_PREFIX."trackback (
	  id int(11) unsigned NOT NULL auto_increment,
	  page_id int(11) unsigned NOT NULL default '0',
	  title varchar(100) default NULL,
	  url varchar(200) default NULL,
	  excerpt text,
	  blog_name varchar(200) default NULL,
	  host varchar(100) default NULL,
	  is_approved tinyint(1) unsigned NOT NULL default '1',
	  created_on datetime default NULL,
	  PRIMARY KEY  (id),
	  KEY page_id (page_id),
	  KEY created_on (created_on)
	) ENGINE=MyISAM  ".($utf8_support?"DEFAULT CHARSET=utf8":""));
	
	$PDO->exec("ALTER TABLE ".TABLE_PREFIX."page ADD trackback_status tinyint(1) NOT NULL default '0' AFTER status_id");
}
else if ($driver == 'sqlite')
{
	$PDO->exec("CREATE TABLE trackback (
	    id INTEGER NOT NULL PRIMARY KEY,
	    page_id int(11) NOT NULL default '0',
	    title text ,
	    excerpt text ,
	    url text, 
	    blog_name text , 
	    host text , 
	    is_approved tinyint(1) NOT NULL default '1' , 
	    created_on datetime default NULL 
	)");
	$PDO->exec("CREATE INDEX trackback_page_id ON trackback (page_id)");
	$PDO->exec("CREATE INDEX trackback_created_on ON trackback (created_on)");
	
	$PDO->exec("ALTER TABLE page ADD trackback_status tinyint(1) NOT NULL default '0'");
}

// トラックバック用のフォームと表示用のスニペットのサンプルの追加

$PDO->exec("INSERT INTO ".TABLE_PREFIX."snippet (name, filter_id, content, content_html, created_on, created_by_id) VALUES ('trackback-form', '', '"
	. "<p>\r\n  TRACKBACK：<input type=\"text\" readonly=\"readonly\" value=\"<?php echo \$this->url().\".trackback\"; ?>\" size=\"100\" />\r\n</p>"
	. "', '"
	. "<p>\r\n  TRACKBACK：<input type=\"text\" readonly=\"readonly\" value=\"<?php echo \$this->url().\".trackback\"; ?>\" size=\"100\" />\r\n</p>"
	. "', '".date('Y-m-d H:i:s')."', 1)");
$PDO->exec("INSERT INTO ".TABLE_PREFIX."snippet (name, filter_id, content, content_html, created_on, created_by_id) VALUES ('trackback-each', '', '"
	. "<p><strong><?php echo \$num_trackbacks = trackbacks_count(\$this); ?></strong> trackback<?php if (1 < \$num_trackbacks) { echo ''s''; } ?></p>\r\n"
	. "<?php \$trackbacks = trackbacks(\$this); ?>\r\n"
	. "<ol class=\"trackbacks\">\r\n"
	. "<?php foreach (\$trackbacks as \$trackback): ?>\r\n"
	. "  <li class=\"trackback\">\r\n"
	. "    <p><?php echo \$trackback->title(); ?></p>\r\n"
	. "    <p><?php echo \$trackback->excerpt(); ?></p>\r\n"
	. "    <p><small class=\"trackback-date\">Trackback from <?php echo \$trackback->link(); ?> <?php echo \$trackback->date(); ?></small></p>\r\n"
	. "  </li>\r\n"
	. "<?php endforeach; // trackbacks; ?>\r\n"
	. "</ol>"
	. "', '"
	. "<p><strong><?php echo \$num_trackbacks = trackbacks_count(\$this); ?></strong> trackback<?php if (1 < \$num_trackbacks) { echo ''s''; } ?></p>\r\n"
	. "<?php \$trackbacks = trackbacks(\$this); ?>\r\n"
	. "<ol class=\"trackbacks\">\r\n"
	. "<?php foreach (\$trackbacks as \$trackback): ?>\r\n"
	. "  <li class=\"trackback\">\r\n"
	. "    <p><?php echo \$trackback->title(); ?></p>\r\n"
	. "    <p><?php echo \$trackback->excerpt(); ?></p>\r\n"
	. "    <p><small class=\"trackback-date\">Trackback from <?php echo \$trackback->link(); ?> <?php echo \$trackback->date(); ?></small></p>\r\n"
	. "  </li>\r\n"
	. "<?php endforeach; // trackbacks; ?>\r\n"
	. "</ol>"
	. "', '".date('Y-m-d H:i:s')."', 1)");

