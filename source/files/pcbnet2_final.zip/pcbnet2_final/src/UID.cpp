// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"

EXPORT BOOL WINAPI setuid(int p1, int p2, int p3, int p4)
{
	SOCKETINFO *si = (SOCKETINFO *)p1;
	if (! IsSocket(si))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;	// ��\�P�b�g

	si->Lock();
	si->dwUser = (DWORD)p2;
	si->Unlock();
	return 0;
}

EXPORT BOOL WINAPI getuid(int *p1, int p2, int p3, int p4)
{
	*p1 = 0;
	SOCKETINFO *si = (SOCKETINFO *)p2;
	if (! IsSocket(si))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;	// ��\�P�b�g

	si->Lock();
	*p1 = (int)si->dwUser;
	si->Unlock();
	return 0;
}
