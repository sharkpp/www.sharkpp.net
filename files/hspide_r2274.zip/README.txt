# the Hot Soup Processer™ integrated development environment

このソフトは [Hot Soup Processer™](http://hsp.tv/) の統合開発環境です。

## 特徴

このソフトは次のような特徴を持っています。

1. 使い捨てのコードから大規模なソースまで規模に限らず対応(予定)
2. プロジェクト管理に対応(予定)
3. ブレークポイントを自由に設定可能
4. 一時停止、ステップ実行などが可能でコードの動きをトレース可能

## 作成者

Copyright© 2011-2012 by [sharkpp](http://www.sharkpp.net/).

## インストール

1. パッケージの展開を行います。
2. HSPインストールフォルダの hsp3debug.dll の名前を変更します。
3. HSPインストールフォルダへ hspide.exe、hsp3debug.dll、hspcmp.exe を移動させます。

**これは暫定的な処理です、インストーラなど簡単にインストールできる仕組みを実装する予定です**

## アンインストール

1. HSPインストールフォルダから hspide.ini を削除します。
2. HSPインストールフォルダから hspide.exe、hsp3debug.dll、hspcmp.exe を削除します。
3. hsp3debug.dllを元に戻します。

## 使い方

作成中...

