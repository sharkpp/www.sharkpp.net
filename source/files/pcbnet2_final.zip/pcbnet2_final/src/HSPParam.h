// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#ifndef _HSPPARAM_H_DEFINED_
#define _HSPPARAM_H_DEFINED_

#include <vector>

class CHSPParam {
public:
	int getsize(PVAL2 *pv);
	HSPEXINFO *hei;
	int *strsize;
	char *refstr;
	char *stmp;

	CHSPParam(HSPEXINFO *_hei);
	~CHSPParam();
	int getdi(int def);
	int geti();
	void * getv();
	char * getds(char *def);
	char * gets();
	PVAL2 * getpval();
	int realloc(PVAL2 *pv, int size, int mode);
	int fread(char *fname, void *readmem, int rlen, int seekofs);
	int fsize(char *fname);
	BMSCR * getbmscr(int wid);
	int getobj(int wid, int id, HSPOBJINFO *inf);
	int setobj(int wid, int id, HSPOBJINFO *inf);
	int nexttype();
	int geterr();
	int getwid();

private:
	std::vector<char *> garbage;
};

#endif

