/* static char *cfg_id = 
	"@(#)Copyright (C) H.Shirouzu 2005   cfg.h	Ver1.10"; */
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2005-01-23(Sun)
	Update					: 2005-05-03(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef CFG_H
#define CFG_H
#include "tlib.h"
#include "resource.h"

class Cfg {
protected:
	TInifile	ini;
	BOOL IniStrToV(char *inipath, void *path);
	BOOL VtoIniStr(void *path, char *inipath);

public:
	int		bufSize;
	int		maxTransSize;
	int		nbMinSizeNtfs;
	int		nbMinSizeFat;
	int		maxHistory;
	int		maxHistoryNext;
	int		copyMode;
	int		copyFlags;
	BOOL	ignoreErr;
	int		estimateMode;
	BOOL	isTopLevel;
	BOOL	isErrLog;
	BOOL	shextAutoClose;
	BOOL	shextTaskTray;
	BOOL	shextDdNoConfirm;
	BOOL	shextRNoConfirm;
	BOOL	execConfirm;
	void	**srcPathHistory;
	void	**dstPathHistory;
	char	*execDir;
	char	*execPath;

	Cfg();
	~Cfg();
	BOOL ReadIni(void);
	BOOL WriteIni(void);
	BOOL EntryPathHistory(void *src, void *dst);
};


#endif
