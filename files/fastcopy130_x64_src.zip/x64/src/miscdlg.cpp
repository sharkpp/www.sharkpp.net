static char *miscdlg_id = 
	"@(#)Copyright (C) H.Shirouzu 2005   miscdlg.cpp	Ver1.30";
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2005-01-23(Sun)
	Update					: 2005-11-28(Mon)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "mainwin.h"
#include <stdio.h>

// HtmlHelp WorkShop ���C���X�g�[�����āAhtmlhelp.h �� include path ��
// ����邱�ƁB
#define ENABLE_HTML_HELP
#if defined(ENABLE_HTML_HELP)
#include <htmlhelp.h>
#endif

/*
	About Dialog����������
*/
TAboutDlg::TAboutDlg(TWin *_parent) : TDlg(ABOUT_DIALOG, _parent)
{
}

/*
	Window �������� CallBack
*/
BOOL TAboutDlg::EvCreate(LPARAM lParam)
{
	if (rect.left == CW_USEDEFAULT)
	{
		GetWindowRect(&rect);
		int xsize = rect.right - rect.left, ysize = rect.bottom - rect.top;
		int	cx = ::GetSystemMetrics(SM_CXFULLSCREEN), cy = ::GetSystemMetrics(SM_CYFULLSCREEN);
		int	x = (cx - xsize)/2;
		int y = (cy - ysize)/2;

		MoveWindow((x < 0) ? 0 : x % (cx - xsize), (y < 0) ? 0 : y % (cy - ysize), xsize, ysize, FALSE);
	}
	else
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);

	return	TRUE;
}

BOOL TAboutDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hWndCtl)
{
	switch (wID)
	{
	case IDOK:
	case IDCANCEL:
		EndDialog(TRUE);
		return	TRUE;

	case URL_BUTTON:
		::ShellExecute(NULL, NULL, GetLoadStr(IDS_FASTCOPYURL), NULL, NULL, SW_SHOW);
		return	TRUE;
	}
	return	FALSE;
}

/*
	Setup Dialog����������
*/
TSetupDlg::TSetupDlg(Cfg *_cfg, TWin *_parent) : TDlg(SETUP_DIALOG, _parent)
{
	cfg = _cfg;
}

/*
	Window �������� CallBack
*/
BOOL TSetupDlg::EvCreate(LPARAM lParam)
{
	SetDlgItemInt(BUFSIZE_EDIT, cfg->bufSize);
	SetDlgItemInt(MAXTRANS_EDIT, cfg->maxTransSize);
	SetDlgItemInt(NONBUFMINNTFS_EDIT, cfg->nbMinSizeNtfs);
	SetDlgItemInt(NONBUFMINFAT_EDIT, cfg->nbMinSizeFat);
	SetDlgItemInt(HISTORY_EDIT, cfg->maxHistoryNext);
	CheckDlgButton(IGNORE_CHECK, cfg->ignoreErr);
	CheckDlgButton(ESTIMATE_CHECK, cfg->estimateMode);
	CheckDlgButton(ERRLOG_CHECK, cfg->isErrLog);
	CheckDlgButton(EXECCONFIRM_CHECK, cfg->execConfirm);
	CheckDlgButton(SAMEDIR_RENAME_CHECK, cfg->isSameDirRename);

	if (rect.left == CW_USEDEFAULT)
	{
		GetWindowRect(&rect);
		int xsize = rect.right - rect.left, ysize = rect.bottom - rect.top;
		int	cx = ::GetSystemMetrics(SM_CXFULLSCREEN), cy = ::GetSystemMetrics(SM_CYFULLSCREEN);
		int	x = (cx - xsize)/2;
		int y = (cy - ysize)/2;

		MoveWindow((x < 0) ? 0 : x % (cx - xsize), (y < 0) ? 0 : y % (cy - ysize), xsize, ysize, FALSE);
	}
	else
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);

	return	TRUE;
}

BOOL TSetupDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hWndCtl)
{
	switch (wID)
	{
	case IDOK:
		cfg->bufSize = GetDlgItemInt(BUFSIZE_EDIT);
		cfg->maxTransSize = GetDlgItemInt(MAXTRANS_EDIT);
		cfg->nbMinSizeNtfs = GetDlgItemInt(NONBUFMINNTFS_EDIT);
		cfg->nbMinSizeFat = GetDlgItemInt(NONBUFMINFAT_EDIT);
		cfg->maxHistoryNext = GetDlgItemInt(HISTORY_EDIT);
		cfg->ignoreErr = IsDlgButtonChecked(IGNORE_CHECK);
		cfg->estimateMode = IsDlgButtonChecked(ESTIMATE_CHECK);
		cfg->isErrLog = IsDlgButtonChecked(ERRLOG_CHECK);
		cfg->execConfirm = IsDlgButtonChecked(EXECCONFIRM_CHECK);
		cfg->isSameDirRename = IsDlgButtonChecked(SAMEDIR_RENAME_CHECK);
		cfg->WriteIni();
		EndDialog(IDOK);
		return	TRUE;

	case IDCANCEL:
		EndDialog(IDCANCEL);
		return	TRUE;
	}
	return	FALSE;
}


/*
	ShellExt
*/
#define CURRENT_SHEXTDLL	"fastext1.dll"
#define REGIST_PROC			"DllRegisterServer"
#define UNREGIST_PROC		"DllUnregisterServer"
#define ISREGIST_PROC		"IsRegistServer"
#define SETMENUFLAGS_PROC	"SetMenuFlags"
#define GETMENUFLAGS_PROC	"GetMenuFlags"
#define UPDATEDLL_PROC		"UpdateDll"

BOOL ShellExt::Load(char *parent_dir, char *dll_name)
{
	if (hShellExtDll)
		UnLoad();

	char	path[MAX_PATH];
	MakePath(path, parent_dir, dll_name);
	if ((hShellExtDll = TLoadLibrary(path)) == NULL)
		return	FALSE;

	RegistDllProc		= (HRESULT (WINAPI *)(void))GetProcAddress(hShellExtDll, REGIST_PROC);
	UnRegistDllProc		= (HRESULT (WINAPI *)(void))GetProcAddress(hShellExtDll, UNREGIST_PROC);
	IsRegistDllProc		= (BOOL (WINAPI *)(void))GetProcAddress(hShellExtDll, ISREGIST_PROC);
	SetMenuFlagsProc	= (BOOL (WINAPI *)(int))GetProcAddress(hShellExtDll, SETMENUFLAGS_PROC);
	GetMenuFlagsProc	= (int (WINAPI *)(void))GetProcAddress(hShellExtDll, GETMENUFLAGS_PROC);
	UpdateDllProc		= (BOOL (WINAPI *)(void))GetProcAddress(hShellExtDll, UPDATEDLL_PROC);

	if (!RegistDllProc || !UnRegistDllProc || !IsRegistDllProc || !SetMenuFlagsProc || !GetMenuFlagsProc || !UpdateDllProc) {
		::FreeLibrary(hShellExtDll);
		hShellExtDll = NULL;
		return	FALSE;
	}
	return	TRUE;
}

BOOL ShellExt::UnLoad(void)
{
	if (hShellExtDll) {
		::FreeLibrary(hShellExtDll);
		hShellExtDll = NULL;
	}
	return	TRUE;
}

/*
	ShellExt Dialog����������
*/
TShellExtDlg::TShellExtDlg(Cfg *_cfg, TWin *_parent) : TDlg(SHELLEXT_DIALOG, _parent)
{
	cfg = _cfg;
}

/*
	Window �������� CallBack
*/
BOOL TShellExtDlg::EvCreate(LPARAM lParam)
{
	if (shellExt.Load(cfg->execDir, CURRENT_SHEXTDLL) == FALSE) {
		MessageBox("Can't load " CURRENT_SHEXTDLL);
		PostMessage(WM_CLOSE, 0, 0);
		return	FALSE;
	}
	CheckDlgButton(AUTOCLOSE_CHECK, cfg->shextAutoClose);
	CheckDlgButton(TASKTRAY_CHECK, cfg->shextTaskTray);
	CheckDlgButton(RIGHT_NOCONFIRM_CHECK, cfg->shextRNoConfirm);
	CheckDlgButton(DD_NOCONFIRM_CHECK, cfg->shextDdNoConfirm);

	ReflectStatus();

	if (rect.left == CW_USEDEFAULT)
	{
		GetWindowRect(&rect);
		int xsize = rect.right - rect.left, ysize = rect.bottom - rect.top;
		int	cx = ::GetSystemMetrics(SM_CXFULLSCREEN), cy = ::GetSystemMetrics(SM_CYFULLSCREEN);
		int	x = (cx - xsize)/2;
		int y = (cy - ysize)/2;

		MoveWindow((x < 0) ? 0 : x % (cx - xsize), (y < 0) ? 0 : y % (cy - ysize), xsize, ysize, FALSE);
	}
	else
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);

	return	TRUE;
}

BOOL TShellExtDlg::ReflectStatus(void)
{
	BOOL	isRegist = shellExt.IsRegistDllProc();

	SetDlgItemText(IDSHELLEXT_OK, isRegist ? GetLoadStr(IDS_SHELLEXT_MODIFY) : GetLoadStr(IDS_SHELLEXT_EXEC));
	::EnableWindow(GetDlgItem(IDSHELLEXT_CANCEL), isRegist);

	int	flags = shellExt.GetMenuFlagsProc();
	CheckDlgButton(RIGHT_COPY_CHECK, flags & SHEXT_RIGHT_COPY);
	CheckDlgButton(RIGHT_DELETE_CHECK, flags & SHEXT_RIGHT_DELETE);
	CheckDlgButton(DD_COPY_CHECK, flags & SHEXT_DD_COPY);
	CheckDlgButton(DD_MOVE_CHECK, flags & SHEXT_DD_MOVE);

	if (flags != -1) {
		CheckDlgButton(RIGHT_SUBMENU_CHECK, flags & SHEXT_SUBMENU_RIGHT);
		CheckDlgButton(DD_SUBMENU_CHECK, flags & SHEXT_SUBMENU_DD);
	}

	return	TRUE;
}

BOOL TShellExtDlg::EvNcDestroy(void)
{
	if (shellExt.Status())
		shellExt.UnLoad();
	return	TRUE;
}

BOOL TShellExtDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hWndCtl)
{
	switch (wID)
	{
	case IDSHELLEXT_OK: case IDSHELLEXT_CANCEL:
		if (RegistShellExt(wID == IDSHELLEXT_OK ? TRUE : FALSE) == FALSE)
			MessageBox("ShellExt Error");
		ReflectStatus();
		return	TRUE;

	case IDOK: case IDCANCEL:
		EndDialog(wID);
		return	TRUE;
	}
	return	FALSE;
}

BOOL TShellExtDlg::RegistShellExt(BOOL is_regist)
{
	if (shellExt.Status() == FALSE)
		return	FALSE;

	cfg->shextAutoClose = IsDlgButtonChecked(AUTOCLOSE_CHECK);
	cfg->shextTaskTray = IsDlgButtonChecked(TASKTRAY_CHECK);
	cfg->shextRNoConfirm = IsDlgButtonChecked(RIGHT_NOCONFIRM_CHECK);
	cfg->shextDdNoConfirm = IsDlgButtonChecked(DD_NOCONFIRM_CHECK);
	cfg->WriteIni();

	if (!is_regist)
		return	shellExt.UnRegistDllProc() == S_OK ? TRUE : FALSE;

	int		flags = 0;

	if (IsDlgButtonChecked(RIGHT_COPY_CHECK))
		flags |= SHEXT_RIGHT_COPY;

	if (IsDlgButtonChecked(RIGHT_DELETE_CHECK))
		flags |= SHEXT_RIGHT_DELETE;

	if (IsDlgButtonChecked(RIGHT_SUBMENU_CHECK))
		flags |= SHEXT_SUBMENU_RIGHT;

	if (IsDlgButtonChecked(DD_COPY_CHECK))
		flags |= SHEXT_DD_COPY;

	if (IsDlgButtonChecked(DD_MOVE_CHECK))
		flags |= SHEXT_DD_MOVE;

	if (IsDlgButtonChecked(DD_SUBMENU_CHECK))
		flags |= SHEXT_SUBMENU_DD;

	if (shellExt.RegistDllProc() != S_OK)
		return	FALSE;

	return	shellExt.SetMenuFlagsProc(flags);
}

BOOL UpdateShellExt(Cfg *cfg)
{
	ShellExt	shellExt;

	return	shellExt.Load(cfg->execDir, CURRENT_SHEXTDLL) && shellExt.UpdateDllProc();
}

int TExecConfirmDlg::Exec(const void *_src, const void *_dst)
{
	src = _src;
	dst = _dst;

	return	TDlg::Exec();
}

BOOL TExecConfirmDlg::EvCreate(LPARAM lParam)
{
	if (title)
		SetWindowTextV(title);

	SendDlgItemMessage(MESSAGE_EDIT, EM_SETWORDBREAKPROC, 0, (LPARAM)EditWordBreakProc);
	SetDlgItemTextV(SRC_EDIT, src);
	if (dst)
		SetDlgItemTextV(DST_EDIT, dst);

	if (rect.left == CW_USEDEFAULT) {
		GetWindowRect(&rect);
		rect.left += 30, rect.right += 30;
		rect.top += 30, rect.bottom += 30;
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);
	}

	Show();
	SetForceForegroundWindow();
	return	TRUE;
}

BOOL TExecConfirmDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hWndCtl)
{
	switch (wID)
	{
	case HELP_CONFIRM_BUTTON:
		ShowHelp(hWnd, cfg->execDir, GetLoadStr(IDS_FASTCOPYHELP), "#shellcancel");
		return	TRUE;

	case IDOK: case IDCANCEL:
		EndDialog(wID);
		return	TRUE;
	}
	return	FALSE;
}

HWND ShowHelp(HWND hOwner, LPCSTR help_dir, LPCSTR help_file, LPCSTR section)
{
#if defined(ENABLE_HTML_HELP)
	static HWND (WINAPI *pHtmlHelp)(HWND, LPCSTR, UINT, DWORD_PTR) = NULL;

	if (pHtmlHelp == NULL) {
		DWORD		cookie=0;
		HMODULE		hHtmlHelp = TLoadLibrary("hhctrl.ocx");
		if (hHtmlHelp)
			pHtmlHelp = (HWND (WINAPI *)(HWND, LPCSTR, UINT, DWORD_PTR))::GetProcAddress(hHtmlHelp, "HtmlHelpA");
		if (pHtmlHelp)
			pHtmlHelp(NULL, NULL, HH_INITIALIZE, (DWORD)&cookie);
	}
	if (pHtmlHelp) {
		char	path[MAX_PATH];

		MakePath(path, help_dir, help_file);
		if (section)
			strcat(path, section);
		return	pHtmlHelp(hOwner, path, HH_DISPLAY_TOC, 0);
	}
#endif
	return	NULL;
}

/*=========================================================================
  �N���X �F BrowseDirDlgV
  �T  �v �F �f�B���N�g���u���E�Y�p�R�����_�C�A���O�g���N���X
  ��  �� �F SHBrowseForFolder �̃T�u�N���X��
  ��  �� �F 
=========================================================================*/
BOOL BrowseDirDlgV(TWin *parentWin, UINT editCtl, void *title, int flg)
{
	if (SHBrowseForFolderV == NULL || SHGetPathFromIDListV == NULL)	// old version NT kernel.
		return	FALSE;

	WCHAR	fileBuf[MAX_PATH_EX] = L"", buf[MAX_PATH_EX] = L"";
	BOOL	ret = FALSE;
	void	*c_root_v = IS_WINNT_V ? (void *)L"C:\\" : (void *)"C:\\";

	parentWin->GetDlgItemTextV(editCtl, fileBuf, MAX_PATH_EX);
	if (GetChar(fileBuf, 0)) {
		void	*tok, *p;
		if ((flg & BRDIR_VQUOTE) && (tok = strtok_pathV(fileBuf, SEMICOLON_V, &p)))
			strcpyV(fileBuf, tok);
	}
	if (GetChar(fileBuf, 0) == 0)
		strcpyV(fileBuf, c_root_v);

	DirFileMode mode = DIRSELECT;
	TBrowseDirDlgV	dirDlg(title, fileBuf, flg, parentWin);
	TOpenFileDlg	fileDlg(parentWin, TOpenFileDlg::MULTI_OPEN, OFDLG_DIRSELECT);

	while (mode != SELECT_EXIT) {
		switch (mode) {
		case DIRSELECT:
			if (dirDlg.Exec()) {
				if (flg & BRDIR_BACKSLASH) {
					MakePathV(buf, fileBuf, EMPTY_STR_V);
					strcpyV(fileBuf, buf);
				}
				if ((flg & BRDIR_QUOTE) || (flg & BRDIR_VQUOTE) && lstrchrV(fileBuf, ';')) {
					sprintfV(buf, FMT_QUOTE_STR_V, fileBuf);
					strcpyV(fileBuf, buf);
				}
				::SetDlgItemTextV(parentWin->hWnd, editCtl, fileBuf);
				ret = TRUE;
			}
			else if (dirDlg.GetMode() == FILESELECT) {
				mode = FILESELECT;
				continue;
			}
			mode = SELECT_EXIT;
			break;

		case FILESELECT:
			SetChar(buf, sprintfV(buf, FMT_STR_V, GetLoadStrV(IDS_ALLFILES_FILTER)) + 1, 0);
			fileDlg.Exec(editCtl, NULL, buf, fileBuf);
			if (fileDlg.GetMode() == DIRSELECT)
				mode = DIRSELECT;
			else
				mode = SELECT_EXIT;
			break;
		}
	}

	return	ret;
}

TBrowseDirDlgV::TBrowseDirDlgV(void *title, void *_fileBuf, int _flg, TWin *parentWin)
{
	fileBuf = _fileBuf;
	flg = _flg;

	iMalloc = NULL;
	SHGetMalloc(&iMalloc);

	brInfo.hwndOwner = parentWin->hWnd;
	brInfo.pidlRoot = 0;
	brInfo.pszDisplayName = (char *)fileBuf;
	brInfo.lpszTitle = (char *)title;
	brInfo.ulFlags = BIF_RETURNONLYFSDIRS;
	brInfo.lpfn = TBrowseDirDlgV::BrowseDirDlg_Proc;
	brInfo.lParam = (LPARAM)this;
	brInfo.iImage = 0;
}

TBrowseDirDlgV::~TBrowseDirDlgV()
{
	if (iMalloc)
		iMalloc->Release();
}

BOOL TBrowseDirDlgV::Exec()
{
	LPITEMIDLIST	pidlBrowse;
	BOOL	ret = FALSE;

	do {
		mode = DIRSELECT;
		if ((pidlBrowse = ::SHBrowseForFolderV(&brInfo)) != NULL) {
			if (::SHGetPathFromIDListV(pidlBrowse, fileBuf))
				ret = TRUE;
			iMalloc->Free(pidlBrowse);
			return	ret;
		}
	} while (mode == RELOAD);

	return	ret;
}

/*
	BrowseDirDlg�p�R�[���o�b�N
*/
int CALLBACK TBrowseDirDlgV::BrowseDirDlg_Proc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM data)
{
	switch (uMsg)
	{
	case BFFM_INITIALIZED:
		((TBrowseDirDlgV *)data)->CreateByWnd(hWnd);
		break;

	case BFFM_SELCHANGED:
		if (((TBrowseDirDlgV *)data)->hWnd)
			((TBrowseDirDlgV *)data)->SetFileBuf(lParam);
		break;
	}
	return 0;
}

/*
	BrowseDlg�p�T�u�N���X����
*/
BOOL TBrowseDirDlgV::CreateByWnd(HWND _hWnd)
{
	BOOL	ret = TSubClass::CreateByWnd(_hWnd);

// �f�B���N�g���ݒ�
	DWORD	attr = GetFileAttributesV(fileBuf);
	if (attr != 0xffffffff && (attr & FILE_ATTRIBUTE_DIRECTORY) == 0)
		GetParentDirV(fileBuf, fileBuf);

	if (ILCreateFromPathV) {	// 2000/XP
		ITEMIDLIST *pidl = ILCreateFromPathV(fileBuf);
		SendMessageV(BFFM_SETSELECTION, FALSE, (LPARAM)pidl);
		ILFreeV(pidl);
	}
	else {
		char	buf[MAX_PATH_EX], *target;
		if (IS_WINNT_V)			// NT4.0
			::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)fileBuf, -1, target=buf, sizeof(buf), 0, 0);
		else					// Win98
			target = (char *)fileBuf;
		SendMessageV(BFFM_SETSELECTION, TRUE, (LPARAM)target);
	}

// �{�^���쐬
	RECT	tmp_rect;
	::GetWindowRect(GetDlgItem(IDOK), &tmp_rect);
	POINT	pt = { tmp_rect.left, tmp_rect.top };
	::ScreenToClient(hWnd, &pt);
	int		cx = (pt.x - 30) / 2, cy = tmp_rect.bottom - tmp_rect.top;

	::CreateWindow(BUTTON_CLASS, GetLoadStr(IDS_MKDIR), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, 10, pt.y, cx, cy, hWnd, (HMENU)MKDIR_BUTTON, TApp::GetInstance(), NULL);
	::CreateWindow(BUTTON_CLASS, GetLoadStr(IDS_RMDIR), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, 18 + cx, pt.y, cx, cy, hWnd, (HMENU)RMDIR_BUTTON, TApp::GetInstance(), NULL);

	if (flg & BRDIR_FILESELECT) {
		GetClientRect(hWnd, &rect);
		int		file_cx = cx * 3 / 2;
		::CreateWindow(BUTTON_CLASS, GetLoadStr(IDS_FILESELECT), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, rect.right - file_cx - 18, 10, file_cx, cy, hWnd, (HMENU)FILESELECT_BUTTON, TApp::GetInstance(), NULL);
	}

	HFONT	hDlgFont = (HFONT)SendDlgItemMessage(IDOK, WM_GETFONT, 0, 0L);
	if (hDlgFont)
	{
		SendDlgItemMessage(MKDIR_BUTTON, WM_SETFONT, (UINT)hDlgFont, 0L);
		SendDlgItemMessage(RMDIR_BUTTON, WM_SETFONT, (UINT)hDlgFont, 0L);
		if (flg & BRDIR_FILESELECT)
			SendDlgItemMessage(FILESELECT_BUTTON, WM_SETFONT, (UINT)hDlgFont, 0L);
	}

	return	ret;
}

/*
	BrowseDlg�p WM_COMMAND ����
*/
BOOL TBrowseDirDlgV::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID)
	{
	case MKDIR_BUTTON:
		{
			WCHAR	dirBuf[MAX_PATH_EX], path[MAX_PATH_EX];
			TInputDlgV	dlg(dirBuf, this);
			if (dlg.Exec() == FALSE)
				return	TRUE;
			MakePathV(path, fileBuf, dirBuf);
			if (::CreateDirectoryV(path, NULL))
			{
				strcpyV(fileBuf, path);
				mode = RELOAD;
				PostMessage(WM_CLOSE, 0, 0);
			}
		}
		return	TRUE;

	case RMDIR_BUTTON:
		if (::RemoveDirectoryV(fileBuf))
		{
			GetParentDirV(fileBuf, fileBuf);
			mode = RELOAD;
			PostMessage(WM_CLOSE, 0, 0);
		}
		return	TRUE;

	case FILESELECT_BUTTON:
		mode = FILESELECT;
		PostMessage(WM_CLOSE, 0, 0);
		return	TRUE;
	}
	return	FALSE;
}

BOOL TBrowseDirDlgV::SetFileBuf(LPARAM list)
{
	return	::SHGetPathFromIDListV((LPITEMIDLIST)list, fileBuf);
}

/*
	�e�f�B���N�g���擾�i�K���t���p�X�ł��邱�ƁBUNC�Ή��j
*/
BOOL TBrowseDirDlgV::GetParentDirV(void *srcfile, void *dir)
{
	WCHAR	path[MAX_PATH_EX], *fname=NULL;

	if (::GetFullPathNameV(srcfile, MAX_PATH_EX, path, (void **)&fname) == 0 || fname == NULL)
		return	strcpyV(dir, srcfile), FALSE;

	if (((char *)fname - (char *)path) / CHAR_LEN_V > 3 || GetChar(path, 1) != ':')
		SetChar(fname, -1, 0);
	else
		SetChar(fname, 0, 0);		// C:\ �̏ꍇ

	strcpyV(dir, path);
	return	TRUE;
}


/*=========================================================================
  �N���X �F TInputDlgV
  �T  �v �F �P�s���̓_�C�A���O
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
BOOL TInputDlgV::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID)
	{
	case IDOK:
		GetDlgItemTextV(INPUT_EDIT, dirBuf, MAX_PATH_EX);
		EndDialog(TRUE);
		return	TRUE;

	case IDCANCEL:
		EndDialog(FALSE);
		return	TRUE;
	}
	return	FALSE;
}

int TConfirmDlg::Exec(const char *_message, BOOL _allow_continue, TWin *_parent)
{
	message = _message;
	parent = _parent;
	allow_continue = _allow_continue;
	return	TDlg::Exec();
}

BOOL TConfirmDlg::EvCreate(LPARAM lParam)
{
	if (!allow_continue) {
		SetWindowText(GetLoadStr(IDS_ERRSTOP));
		::EnableWindow(GetDlgItem(IDOK), FALSE);
		::EnableWindow(GetDlgItem(IDIGNORE), FALSE);
		::SetFocus(GetDlgItem(IDCANCEL));
	}
	SendDlgItemMessage(MESSAGE_EDIT, EM_SETWORDBREAKPROC, 0, (LPARAM)EditWordBreakProc);
	SetDlgItemText(MESSAGE_EDIT, message);

	if (rect.left == CW_USEDEFAULT) {
		GetWindowRect(&rect);
		rect.left += 30, rect.right += 30;
		rect.top += 30, rect.bottom += 30;
		MoveWindow(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);
	}

	Show();
	SetForceForegroundWindow();
	return	TRUE;
}

/*
	�t�@�C���_�C�A���O�p�ėp���[�`��
*/
BOOL TOpenFileDlg::Exec(UINT editCtl, void *title, void *filter, void *defaultDir)
{
	WCHAR		buf[MAX_PATH_EX];
	PathArray	pathArray;

	if (parent == NULL)
		return FALSE;

	parent->GetDlgItemTextV(editCtl, buf, MAX_PATH_EX);
	if (pathArray.RegistMultiPath(buf) >= 1) {
		strcpyV(buf, pathArray.Path(0));
		pathArray.Init();
	}

	if (Exec(buf, title, filter, defaultDir) == FALSE)
		return	FALSE;

	if (defaultDir) {
		int			dir_len = strlenV(defaultDir), offset = dir_len + 1;
		if (GetChar(buf, offset)) {
			if (lGetCharV(buf, lstrlenV(buf) -1) != '\\')	// �h���C�u���[�g�̂ݗ�O
				SetChar(buf, dir_len++, '\\');
			for (; GetChar(buf, offset); offset++) {
				offset += sprintfV(MakeAddr(buf, dir_len), FMT_STR_V, MakeAddr(buf, offset));
				pathArray.RegistPath(buf);
			}
			if (pathArray.GetMultiPath(buf, MAX_PATH_EX)) {
				parent->SetDlgItemTextV(editCtl, buf);
				return	TRUE;
			}
		}
	}
	parent->SetDlgItemTextV(editCtl, buf);
	return	TRUE;
}

#ifndef OFN_ENABLESIZING
#define OFN_ENABLESIZING 0x00800000
#endif

BOOL TOpenFileDlg::Exec(void *target, void *title, void *filter, void *defaultDir)
{
	OPENFILENAMEW	ofn;
	WCHAR	szDirName[MAX_PATH] = L"", szFile[MAX_PATH_EX] = L"";
	void	*fname = NULL;

	mode = FILESELECT;

	if (GetChar(target, 0)) {
		DWORD	attr = ::GetFileAttributesV(target);
		if (attr != 0xffffffff && (attr & FILE_ATTRIBUTE_DIRECTORY))
			strcpyV(szDirName, target);
		else if (::GetFullPathNameV(target, MAX_PATH, szDirName, &fname) && fname) {
			SetChar(fname, -1, 0);
		}
	}
	if (GetChar(szDirName, 0) == 0 && defaultDir)
		strcpyV(szDirName, defaultDir);
	memset(&ofn, 0, sizeof(ofn));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = parent ? parent->hWnd : NULL;
	ofn.lpstrFilter = (WCHAR *)filter;
	ofn.nFilterIndex = filter ? 1 : 0;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = MAX_PATH_EX;
	ofn.lpstrTitle = (WCHAR *)title;
	ofn.lpstrInitialDir = szDirName;
	ofn.lCustData = (LPARAM)this;
	ofn.lpfnHook = hook ? hook : OpenFileDlgProc;
	ofn.Flags = OFN_HIDEREADONLY|OFN_EXPLORER|OFN_ENABLEHOOK|OFN_ENABLESIZING;
	if (openMode == OPEN || openMode == MULTI_OPEN)
		ofn.Flags |= OFN_FILEMUSTEXIST | (openMode == MULTI_OPEN ? OFN_ALLOWMULTISELECT : 0);
	else
		ofn.Flags |= (openMode == NODEREF_SAVE ? OFN_NODEREFERENCELINKS : 0);

	WCHAR	orgDir[MAX_PATH];
	::GetCurrentDirectoryV(MAX_PATH, orgDir);

	BOOL	ret = (openMode == OPEN || openMode == MULTI_OPEN) ? ::GetOpenFileNameV(&ofn) : ::GetSaveFileNameV(&ofn);

	::SetCurrentDirectoryV(orgDir);
	if (ret)
	{
		if (openMode == MULTI_OPEN)
			memcpy(target, szFile, MAX_PATH_EX * CHAR_LEN_V);
		else
			strcpyV(target, ofn.lpstrFile);

		if (defaultDir)
			strcpyV(defaultDir, ofn.lpstrFile);
	}

	return	ret;
}

UINT_PTR WINAPI TOpenFileDlg::OpenFileDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg) {
	case WM_INITDIALOG:
		((TOpenFileDlg *)(((OPENFILENAMEW *)lParam)->lCustData))->CreateByWnd(hdlg);
		return TRUE;
	}
	return FALSE;
}

/*
	TOpenFileDlg�p�T�u�N���X����
*/
BOOL TOpenFileDlg::CreateByWnd(HWND _hWnd)
{
	BOOL	ret = TSubClass::CreateByWnd(::GetParent(_hWnd));

	if ((flg & OFDLG_DIRSELECT) == 0)
		return	ret;

// �{�^���쐬
	RECT	ok_rect, client_rect;

	::GetWindowRect(GetDlgItem(IDOK), &ok_rect);
	GetWindowRect(&rect);
	::GetClientRect(hWnd, &client_rect);
	int	cx = (ok_rect.right - ok_rect.left) * 2;
	int	cy = ok_rect.bottom - ok_rect.top;
	int	x = ::GetSystemMetrics(SM_CXDLGFRAME);
	int	y = ok_rect.top - rect.top + cy * 4 / 3 - ::GetSystemMetrics(SM_CYDLGFRAME);

	::CreateWindow(BUTTON_CLASS, GetLoadStr(IDS_DIRSELECT), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, x, y, cx, cy, hWnd, (HMENU)DIRSELECT_BUTTON, TApp::GetInstance(), NULL);

	HFONT	hDlgFont = (HFONT)SendDlgItemMessage(IDOK, WM_GETFONT, 0, 0L);
	if (hDlgFont)
		SendDlgItemMessage(DIRSELECT_BUTTON, WM_SETFONT, (UINT)hDlgFont, 0L);

	return	ret;
}

/*
	BrowseDlg�p WM_COMMAND ����
*/
BOOL TOpenFileDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID)
	{
	case DIRSELECT_BUTTON:
		mode = DIRSELECT;
		PostMessage(WM_CLOSE, 0, 0);
		return	TRUE;
	}
	return	FALSE;
}


