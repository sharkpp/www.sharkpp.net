/* static char *cfg_id = 
	"@(#)Copyright (C) H.Shirouzu 2005-2007   cfg.h	Ver1.52"; */
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2005-01-23(Sun)
	Update					: 2007-02-06(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef CFG_H
#define CFG_H
#include "tlib.h"
#include "resource.h"

struct Job {
	void	*title;
	void	*src;
	void	*dst;
	void	*cmd;
	int		bufSize;
	int		estimateMode;
	int		diskMode;
	BOOL	ignoreErr;
	BOOL	enableOwdel;
	BOOL	enableAcl;
	BOOL	enableStream;
	BOOL	isFilter;
	void	*includeFilter;
	void	*excludeFilter;

	void Init() {
		memset(this, 0, sizeof(Job));
	}
	void SetString(void *_title, void *_src, void *_dst, void *_cmd, void *_includeFilter, void *_excludeFilter) {
		title = strdupV(_title);
		src = strdupV(_src);
		dst = strdupV(_dst);
		cmd = strdupV(_cmd);
		includeFilter = strdupV(_includeFilter);
		excludeFilter = strdupV(_excludeFilter);
	}
	void Set(const Job *job) {
		memcpy(this, job, sizeof(Job));
		SetString(job->title, job->src, job->dst, job->cmd, job->includeFilter, job->excludeFilter);
	}
	void UnSet() {
		free(excludeFilter);
		free(includeFilter);
		free(cmd);
		free(dst);
		free(src);
		free(title);
		Init();
	}

	Job() {
		Init();
	}
	Job(const Job& job) {
		Init();
		Set(&job);
	}
	~Job() { UnSet(); }
};


class Cfg {
protected:
	TInifile	ini;
	BOOL IniStrToV(char *inipath, void *path);
	BOOL VtoIniStr(void *path, char *inipath);
	BOOL EntryHistory(void **path_array, void ****history_array, int max);

public:
	int		bufSize;
	int		maxTransSize;
	int		maxOpenFiles;
	int		maxAttrSize;
	int		maxDirSize;
	int		nbMinSizeNtfs;
	int		nbMinSizeFat;
	int		maxHistory;
	int		maxHistoryNext;
	int		copyMode;
	int		copyFlags;
	int		skipEmptyDir;	// 0:no, 1:filter-mode only, 2:always
	int		forceStart;		// 0:delete only, 1:always(copy+delete)
	BOOL	ignoreErr;
	int		estimateMode;
	int		diskMode;
	int		lcid;
	int		waitTick;
	BOOL	isAutoSlowIo;
	BOOL	speedLevel;
	BOOL	enableOwdel;
	BOOL	enableAcl;
	BOOL	enableStream;
	BOOL	enableNSA;
	BOOL	isTopLevel;
	BOOL	isErrLog;
	BOOL	isSameDirRename;
	BOOL	shextAutoClose;
	BOOL	shextTaskTray;
	BOOL	shextDdNoConfirm;
	BOOL	shextRNoConfirm;
	BOOL	execConfirm;
	void	**srcPathHistory;
	void	**dstPathHistory;
	void	**delPathHistory;
	void	**includeHistory;
	void	**excludeHistory;
	char	*execDir;
	char	*execPath;
	void	*logPath;	// UNICODE
	Job		**jobArray;
	int		jobMax;

	Cfg();
	~Cfg();
	BOOL ReadIni(void);
	BOOL WriteIni(void);
	BOOL EntryPathHistory(void *src, void *dst);
	BOOL EntryDelPathHistory(void *del);
	BOOL EntryFilterHistory(void *inc, void *exc);

	int SearchJobV(void *title);
	BOOL AddJob(const Job *job);
	BOOL DelJobV(void *title);
};


#endif
