// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "Buffer.h"


Buffer::Buffer()
{
	q.push_back(new char[BUFFER_BLOCK_SIZE]);
	size = offset = 0;
}

Buffer::~Buffer()
{
	while(! q.empty()) {
		delete [] q.front();
		q.pop_front();
	}
}

int Buffer::Size()
{
	return size;
}

BOOL Buffer::Destroy()
{
	while(q.size() > 1) {
		delete [] q.front();
		q.pop_front();
	}
	offset = 0;
	size = 0;

	return FALSE;
}

BOOL Buffer::Write(void *pt, int len)
{
	int srcoffset, destoffset;
	
	srcoffset = 0;
	destoffset = (offset+size)%BUFFER_BLOCK_SIZE;

	while(srcoffset < len) {
		int nextsize = min(len-srcoffset, BUFFER_BLOCK_SIZE-destoffset);
		memcpy(q.back()+destoffset, (char*)pt+srcoffset, nextsize);
		srcoffset += nextsize;
		destoffset += nextsize;
		size += nextsize;
		if (destoffset == BUFFER_BLOCK_SIZE) {
			q.push_back(new char[BUFFER_BLOCK_SIZE]);
			destoffset = 0;
		}
	}

	return FALSE;
}

int Buffer::Read(void *buf, int nMax)
{
	int destoffset, len;

	destoffset = 0;
	len = min(size, nMax);

	while(destoffset < len) {
		int nextsize = min(size, min(len-destoffset, BUFFER_BLOCK_SIZE-offset));
		if (buf != NULL)
			memcpy((char*)buf+destoffset, q.front()+offset, nextsize);
		destoffset += nextsize;
		offset += nextsize;
		size -= nextsize;
		if (offset == BUFFER_BLOCK_SIZE) {
			delete [] q.front();
			q.pop_front();
			offset = 0;
		}
	}

	return len;
}

int Buffer::Peek(void *buf, int nMax)
{
	int destoffset, srcoffset, len;
	DataQueue::iterator it;

	destoffset = 0;
	srcoffset = offset;
	len = min(size, nMax);

	if (buf == NULL)
		return len;

	it = q.begin();
	while(destoffset < len) {
		int nextsize = min(size, min(len-destoffset, BUFFER_BLOCK_SIZE-srcoffset));
		memcpy((char*)buf+destoffset, *it+srcoffset, nextsize);
		destoffset += nextsize;
		srcoffset += nextsize;
		if (srcoffset == BUFFER_BLOCK_SIZE) {
			it++;
			srcoffset = 0;
		}
	}

	return len;
}
