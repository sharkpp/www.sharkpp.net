static char *cfg_id = 
	"@(#)Copyright (C) H.Shirouzu 2004-2005   cfg.cpp	Ver1.10";
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2004-09-15(Wed)
	Update					: 2005-05-03(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "mainwin.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>

#define FASTCOPY_INI		"fastcopy.ini"
#define MAIN_SECTION		"main"
#define SRC_HISTORY			"src_history"
#define DST_HISTORY			"dst_history"

#define MAX_HISTORY_KEY		"max_history"
#define COPYMODE_KEY		"default_copy_mode"
#define COPYFLAGS_KEY		"default_copy_flags"
#define IGNORE_ERR_KEY		"ignore_error"
#define ESTIMATE_KEY		"estimate_mode"
#define ISTOPLEVEL_KEY		"is_toplevel"
#define ISERRLOG_KEY		"is_errlog"
#define BUFSIZE_KEY			"bufsize"
#define MAXTRANSSIZE_KEY	"max_transize"
#define SHEXTAUTOCLOSE_KEY	"shext_autoclose"
#define SHEXTTASKTRAY_KEY	"shext_tasktray"
#define SHEXTDDNOCONFIRM_KEY "shext_dd_noconfirm"
#define SHEXTRNOCONFIRM_KEY	"shext_right_noconfirm"
#define EXECCONRIM_KEY		"exec_confirm"

#define NONBUFMINSIZENTFS_KEY	"nonbuf_minsize_ntfs"
#define NONBUFMINSIZEFAT_KEY	"nonbuf_minsize_fat"

#define DEFAULT_MAX_HISTORY		10
#define DEFAULT_COPYMODE		1
#define DEFAULT_COPYFLAGS		0
#define DEFAULT_BUFSIZE			16
#define DEFAULT_MAXTRANSSIZE	8
#define DEFAULT_NBMINSIZE_NTFS	0		// nbMinSize �Q��
#define DEFAULT_NBMINSIZE_FAT	128		// nbMinSize �Q��

/*=========================================================================
  �N���X �F Cfg
  �T  �v �F �R���t�B�O�N���X
  ��  �� �F 
  ��  �� �F 
=========================================================================*/
Cfg::Cfg()
{
	char	buf[MAX_PATH], path[MAX_PATH], *fname = NULL;

	::GetModuleFileName(NULL, buf, sizeof(buf));
	::GetFullPathName(buf, sizeof(path), path, &fname);

	execPath = strdup(path);
	if (fname) {
		*fname = 0;
		execDir = strdup(path);
	}
	else
		execDir = strdup(".\\");

	MakePath(path, execDir, FASTCOPY_INI);
	ini.Init(path);
}

Cfg::~Cfg()
{
	free(execPath);
	free(execDir);
}

BOOL Cfg::ReadIni(void)
{
	srcPathHistory	= NULL;
	dstPathHistory	= NULL;

	ini.SetSection(MAIN_SECTION);
	bufSize			= ini.GetInt(BUFSIZE_KEY, DEFAULT_BUFSIZE);
	maxTransSize	= ini.GetInt(MAXTRANSSIZE_KEY, DEFAULT_MAXTRANSSIZE);
	nbMinSizeNtfs	= ini.GetInt(NONBUFMINSIZENTFS_KEY, DEFAULT_NBMINSIZE_NTFS);
	nbMinSizeFat	= ini.GetInt(NONBUFMINSIZEFAT_KEY, DEFAULT_NBMINSIZE_FAT);
	maxHistoryNext	= maxHistory = ini.GetInt(MAX_HISTORY_KEY, DEFAULT_MAX_HISTORY);
	copyMode		= ini.GetInt(COPYMODE_KEY, DEFAULT_COPYMODE);
	copyFlags		= ini.GetInt(COPYFLAGS_KEY, DEFAULT_COPYFLAGS);
	ignoreErr		= ini.GetInt(IGNORE_ERR_KEY, TRUE);
	estimateMode	= ini.GetInt(ESTIMATE_KEY, FALSE);
	isTopLevel		= ini.GetInt(ISTOPLEVEL_KEY, FALSE);
	isErrLog		= ini.GetInt(ISERRLOG_KEY, TRUE);
	shextAutoClose	= ini.GetInt(SHEXTAUTOCLOSE_KEY, TRUE);
	shextTaskTray	= ini.GetInt(SHEXTTASKTRAY_KEY, FALSE);
	shextDdNoConfirm = ini.GetInt(SHEXTDDNOCONFIRM_KEY, FALSE);
	shextRNoConfirm	= ini.GetInt(SHEXTRNOCONFIRM_KEY, FALSE);
	execConfirm		= ini.GetInt(EXECCONRIM_KEY, FALSE);

	char	*section_array[] = { SRC_HISTORY, DST_HISTORY };
	void	***history_array[] = { &srcPathHistory, &dstPathHistory };

	for (int i=0; i < 2; i++) {
		char	*&section = section_array[i];
		void	**&history = *history_array[i];
		char	buf[MAX_HISTORY_BUF * 4], key[100];
		WCHAR	wbuf[MAX_HISTORY_BUF];

		ini.SetSection(section);
		history = (void **)calloc(maxHistory, sizeof(WCHAR *));
		for (int j=0; j < maxHistory; j++) {
			wsprintf(key, "%d", j);
			ini.GetStr(key, buf, sizeof(buf), "");
			IniStrToV(buf, wbuf);
			history[j] = strdupV(wbuf);
		}
	}
	if (::GetFileAttributes(ini.GetIniFileName()) == 0xffffffff) {
		WriteIni();
	}
	return	TRUE;
}

BOOL Cfg::WriteIni(void)
{
	ini.SetSection(MAIN_SECTION);
	ini.SetInt(BUFSIZE_KEY, bufSize);
	ini.SetInt(MAXTRANSSIZE_KEY, maxTransSize);
	ini.SetInt(NONBUFMINSIZENTFS_KEY, nbMinSizeNtfs);
	ini.SetInt(NONBUFMINSIZEFAT_KEY, nbMinSizeFat);
	ini.SetInt(MAX_HISTORY_KEY, maxHistoryNext);
	ini.SetInt(COPYMODE_KEY, copyMode);
//	ini.SetInt(COPYFLAGS_KEY, copyFlags);
	ini.SetInt(IGNORE_ERR_KEY, ignoreErr);
	ini.SetInt(ESTIMATE_KEY, estimateMode);
	ini.SetInt(ISTOPLEVEL_KEY, isTopLevel);
	ini.SetInt(ISERRLOG_KEY, isErrLog);
	ini.SetInt(SHEXTAUTOCLOSE_KEY, shextAutoClose);
	ini.SetInt(SHEXTTASKTRAY_KEY, shextTaskTray);
	ini.SetInt(SHEXTDDNOCONFIRM_KEY, shextDdNoConfirm);
	ini.SetInt(SHEXTRNOCONFIRM_KEY, shextRNoConfirm);
	ini.SetInt(EXECCONRIM_KEY, execConfirm);

	char	*section_array[] = { SRC_HISTORY, DST_HISTORY };
	void	***history_array[] = { &srcPathHistory, &dstPathHistory };

	for (int i=0; i < 2; i++) {
		char	*&section = section_array[i];
		void	**&history = *history_array[i];
		char	key[100], buf[MAX_HISTORY_BUF * 4];

		ini.SetSection(section);
		for (int j=0; j < maxHistory; j++) {
			wsprintf(key, "%d", j);
			VtoIniStr(history[j], buf);
			ini.SetStr(key, buf);
		}
	}
	return	TRUE;
}

BOOL Cfg::EntryPathHistory(void *src, void *dst)
{
	BOOL	ret = TRUE;
	void	*target_path;
	void	*path_array[] = { src, dst };
	void	***history_array[] = { &srcPathHistory, &dstPathHistory };

	for (int i=0; i < 2; i++) {
		int		idx;
		void	*&path = path_array[i];
		void	**&history = *history_array[i];

		if (lstrlenV(path) >= MAX_HISTORY_BUF || GetChar(path, 0) == 0) {
			ret = FALSE;
			continue;
		}
		for (idx=0; idx < maxHistory; idx++) {
			if (lstrcmpiV(path, history[idx]) == 0)
				break;
		}
		if (idx) {
			if (idx == maxHistory) {
				target_path = strdupV(path);
				free(history[--idx]);
			}
			else {
				target_path = history[idx];
			}
			memmove(history + 1, history, idx * sizeof(void *));
			history[0] = target_path;
		}
	}
	return	ret;
}

BOOL Cfg::IniStrToV(char *inipath, void *path)
{
	if (IS_WINNT_V) {
		int		len = strlen(inipath) + 1;
		if (*inipath == '|') {
			hexstr2bin(inipath + 1, (BYTE *)path, len, &len);
		}
		else
			::MultiByteToWideChar(CP_ACP, 0, (char *)inipath, -1, (WCHAR *)path, len);
	}
	else
		lstrcpyV(path, inipath);

	return	TRUE;
}

BOOL Cfg::VtoIniStr(void *path, char *inipath)
{
	if (IS_WINNT_V) {
		int		len = (lstrlenV(path) + 1) * CHAR_LEN_V;
		int		err_cnt = 0;

		*inipath = 0;
		if (!::WideCharToMultiByte(CP_ACP, 0, (WCHAR *)path, -1, inipath, len, 0, &err_cnt))
			return	FALSE;

		if (err_cnt) {
			*inipath = '|';
			bin2hexstr((BYTE *)path, len, inipath + 1);
		}
	}
	else
		lstrcpyV(inipath, path);

	return	TRUE;
}

