// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"
#include "general.h"


int iNATStatus = NATSTAT_NOTINIT;
int iNATError = 0;
IGDINFO IGDInfo;



int SOAPAction(char *hostname, unsigned short port, char *devicetype, char *action, HTTPREQUEST *req, char *out, int outsize)
{
	// @@IPv4-dependent
	SOCKET soc;
	struct sockaddr_in addr;
	char buf[4096];
	char *p, *body;
	int len, ret;
	struct hostent *ent;
	list<HTTPHEADER>::iterator it;
	fd_set fd;
	struct timeval tv;
	int TimeOut, Delta;

	//OutputDebugString("in SOAPAction()\n");

	ent = gethostbyname(hostname);
	if (ent == NULL) return -1;
	if (ent->h_addrtype != AF_INET) return -1;

	soc = socket(AF_INET, SOCK_STREAM, 0);
	if (soc == INVALID_SOCKET) return -1;

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = PF_INET;
	addr.sin_addr.s_addr = *(unsigned long *)ent->h_addr_list[0];
	addr.sin_port = htons(port);

	if (connect(soc, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
		closesocket(soc);
		return -1;
	}

	//OutputDebugString("- Connected to SOAP Server\n");

	p = buf;
	p += sprintf(p, "POST %s HTTP/1.0\r\n", req->Path);
	p += sprintf(p, "SOAPAction: %s#%s\r\n", devicetype, action);
	if (port == 80)
		p += sprintf(p, "Host: %s\r\n", hostname);
	else
		p += sprintf(p, "Host: %s:%d\r\n", hostname, (int)port);
	for(it=req->Headers.begin(); it!=req->Headers.end(); it++) {
		p += sprintf(p, "%s: %s\r\n", it->Tag, it->Value);
	}
	p += sprintf(p, "Content-Length: %d\r\n", (req->Body==NULL ? 0 : strlen(req->Body)));
	p += sprintf(p, "Content-Type: text/xml\r\n");
	p += sprintf(p, "Connection: close\r\n");
	p += sprintf(p, "\r\n");

	send(soc, buf, strlen(buf), 0);
	if (req->Body != NULL)
		send(soc, req->Body, strlen(req->Body), 0);
	//@!(Why?) Sleep(300);
	//shutdown(soc, SD_SEND);

	//OutputDebugString("- SOAP Request sent\n");
	//OutputDebugString("-----------------------------------\n");
	//OutputDebugString(buf);
	//if (req->Body != NULL) OutputDebugString(req->Body);
	//OutputDebugString("\n-----------------------------------\n");

	TimeOut = ((int)GetTickCount()) + HTTP_TIMEOUT;
	len = 0;
	while(len < outsize) {
		Delta = TimeOut - ((int)GetTickCount());
		if (Delta < 0) break;
		tv.tv_sec = (Delta+100)/1000;
		tv.tv_usec = (Delta+100)%1000;
		FD_ZERO(&fd);
		FD_SET(soc, &fd);
		if (select(1, &fd, NULL, NULL, &tv) <= 0) continue;
		ret = recv(soc, out+len, outsize-len, 0);
		if (ret == 0) break;
		if (ret == SOCKET_ERROR) break;
		len += ret;
	}
	shutdown(soc, SD_SEND);
	closesocket(soc);
	if (len == outsize || Delta < 0 || ret == SOCKET_ERROR)
		return -1;
	out[len] = '\0';

	//OutputDebugString("- Received SOAP response\n");

	// HTTP�w�b�_����
	ret = ParseHTTPResponse(&req->res, out);
	if (ret < 0)
		return -1;

	// XML���`
	body = out+ret;
	//OutputDebugString("- SOAP Response was successfully parsed\n");
	//OutputDebugString("-----------------------------------\n");
	//OutputDebugString(body);
	//OutputDebugString("\n-----------------------------------\n");
	RenewXML(body);

	return ret;
}



int GetErrorCode(char *xml)
{
	char tmp[16];

	GetXMLEntry(tmp, sizeof(tmp), xml, "errorcode");
	return atoi(tmp);
}






BOOL DiscoverIGD()
{
	SOCKET soc;
	struct sockaddr_in addr;
	char buf[4096];
	char *p;
	int len, ret;
	HTTPRESPONSE res;
	list<HTTPHEADER>::iterator it;
	fd_set fd;
	struct timeval tv;
	int TimeOut, Delta;
	BOOL bIGDFound;

	soc = socket(AF_INET, SOCK_DGRAM, 0);
	if (soc == INVALID_SOCKET) {
		iNATError = NATERR_NETDOWN;
		return FALSE;
	}

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = PF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	if (bind(soc, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
		closesocket(soc);
		iNATError = NATERR_NETDOWN;
		return FALSE;
	}

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = PF_INET;
	addr.sin_addr.s_addr = inet_addr("239.255.255.250");
	addr.sin_port = htons(1900);

	p = buf;
	p += sprintf(p, "M-SEARCH * HTTP/1.1\r\n");
	p += sprintf(p, "MX: 1\r\n");
	p += sprintf(p, "Host: 239.255.255.250:1900\r\n");
	p += sprintf(p, "MAN: \"ssdp:discover\"\r\n");
	p += sprintf(p, "ST: urn:schemas-upnp-org:service:WANPPPConnection:1\r\n");
	p += sprintf(p, "\r\n");

	sendto(soc, buf, strlen(buf), 0, (struct sockaddr *)&addr, sizeof(addr));

	p = buf;
	p += sprintf(p, "M-SEARCH * HTTP/1.1\r\n");
	p += sprintf(p, "MX: 1\r\n");
	p += sprintf(p, "Host: 239.255.255.250:1900\r\n");
	p += sprintf(p, "MAN: \"ssdp:discover\"\r\n");
	p += sprintf(p, "ST: urn:schemas-upnp-org:service:WANIPConnection:1\r\n");
	p += sprintf(p, "\r\n");

	sendto(soc, buf, strlen(buf), 0, (struct sockaddr *)&addr, sizeof(addr));

	// �ԓ��҂�
	bIGDFound = FALSE;
	TimeOut = ((int)GetTickCount()) + HTTP_TIMEOUT;
	while(Delta = TimeOut - ((int)GetTickCount()), Delta>=0) {
		tv.tv_sec = (Delta+100)/1000;
		tv.tv_usec = (Delta+100)%1000;
		FD_ZERO(&fd);
		FD_SET(soc, &fd);
		if (select(1, &fd, NULL, NULL, &tv) <= 0) continue;
		len = recvfrom(soc, buf, sizeof(buf)-1, 0, NULL, NULL);
		if (len <= 0) break;
		buf[len] = '\0';
		ret = ParseHTTPResponse(&res, buf);
		if (ret < 0) continue;
		if (strcmp(res.Protocol, "HTTP/1.1")) continue;
		if (res.Code != 200) continue;
		for(it = res.Headers.begin(); it != res.Headers.end(); it++) {
			if (stricmp(it->Tag, "Location") == 0) {
				if (it->Value[0] != '\0') break;
			}
		}
		if (it == res.Headers.end()) continue;
		for(it = res.Headers.begin(); it != res.Headers.end(); it++) {
			if (stricmp(it->Tag, "ST") == 0) {
				if (strcmp(it->Value, "urn:schemas-upnp-org:service:WANPPPConnection:1") == 0) break;
				if (strcmp(it->Value, "urn:schemas-upnp-org:service:WANIPConnection:1") == 0) break;
			}
		}
		if (it == res.Headers.end()) continue;
		bIGDFound = TRUE;
		break;
	}

	closesocket(soc);

	if (! bIGDFound) {
		iNATError = NATERR_IGDNOTFOUND;
		return FALSE;
	}

	for(it = res.Headers.begin(); it != res.Headers.end(); it++) {
		if (stricmp(it->Tag, "Location") == 0) break;
	}
	if (it == res.Headers.end()) return FALSE;
	getstr(IGDInfo.DeviceURL, it->Value, sizeof(IGDInfo.DeviceURL));
	if (strncmp(IGDInfo.DeviceURL, "http://", 7) != 0) return FALSE;
	p = getstr(IGDInfo.DeviceHost, IGDInfo.DeviceURL + 7, sizeof(IGDInfo.DeviceHost), '/');
	IGDInfo.DevicePath[0] = '/';
	getstr(IGDInfo.DevicePath+1, p, sizeof(IGDInfo.DevicePath)-1);

	IGDInfo.DevicePort = 80;
	if ((p = strchr(IGDInfo.DeviceHost, ':')) != NULL) {
		*p = '\0';
		IGDInfo.DevicePort = (unsigned short)atoi(p+1);
	}

	for(it = res.Headers.begin(); it != res.Headers.end(); it++) {
		if (stricmp(it->Tag, "ST") == 0) break;
	}
	if (it == res.Headers.end()) {
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}
	getstr(IGDInfo.DeviceType, it->Value, sizeof(IGDInfo.DeviceType));

	return TRUE;
}



BOOL GetControlURL()
{
	// @@IPv4-dependent
	SOCKET soc;
	struct sockaddr_in addr;
	char buf[4096], tmp[4096];
	char *dbuf;
	char *p, *body;
	int len, ret;
	struct hostent *ent;
	HTTPRESPONSE res;
	HTTPREQUEST req;
	list<HTTPHEADER>::iterator it;
	fd_set fd;
	struct timeval tv;
	int TimeOut, Delta;
	char ControlURL[2048];
	char ControlURLBase[1024];
	char ControlURLTail[1024];

	ent = gethostbyname(IGDInfo.DeviceHost);
	if (ent == NULL) {
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}
	if (ent->h_addrtype != AF_INET) {
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}

	soc = socket(AF_INET, SOCK_STREAM, 0);
	if (soc == INVALID_SOCKET) {
		iNATError = NATERR_NETDOWN;
		return FALSE;
	}

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = PF_INET;
	addr.sin_addr.s_addr = *(unsigned long *)ent->h_addr_list[0];
	addr.sin_port = htons(IGDInfo.DevicePort);

	if (connect(soc, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
		closesocket(soc);
		iNATError = NATERR_NETDOWN;
		return FALSE;
	}

	p = buf;
	p += sprintf(p, "GET %s HTTP/1.0\r\n", IGDInfo.DevicePath);
	if (IGDInfo.DevicePort == 80)
		p += sprintf(p, "Host: %s\r\n", IGDInfo.DeviceHost);
	else
		p += sprintf(p, "Host: %s:%d\r\n", IGDInfo.DeviceHost, (int)IGDInfo.DevicePort);
	p += sprintf(p, "Connection: close\r\n");
	p += sprintf(p, "\r\n");

	send(soc, buf, strlen(buf), 0);
	//@!(Why?) Sleep(300);
	//shutdown(soc, SD_SEND);

	TimeOut = ((int)GetTickCount()) + HTTP_TIMEOUT;
	len = 0;
	dbuf = new char[MAX_XMLSIZE];
	while(len < MAX_XMLSIZE) {
		Delta = TimeOut - ((int)GetTickCount());
		if (Delta < 0) break;
		tv.tv_sec = (Delta+100)/1000;
		tv.tv_usec = (Delta+100)%1000;
		FD_ZERO(&fd);
		FD_SET(soc, &fd);
		if (select(1, &fd, NULL, NULL, &tv) <= 0) continue;
		ret = recv(soc, dbuf+len, MAX_XMLSIZE-len, 0);
		if (ret == 0) break;
		if (ret == SOCKET_ERROR) break;
		len += ret;
	}
	shutdown(soc, SD_SEND);
	closesocket(soc);
	if (len == MAX_XMLSIZE) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}
	if (Delta < 0 || ret == SOCKET_ERROR) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}
	dbuf[len] = '\0';

	// HTTP�w�b�_����
	res.Protocol[0] = '\0';
	res.Code = 0;
	res.Headers.clear();
	ret = ParseHTTPResponse(&res, dbuf);
	if (ret < 0 || strcmp(res.Protocol, "HTTP/1.1") != 0 || res.Code != 200) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}

	// XML���`
	body = dbuf+ret;
	RenewXML(body);

	// ControlURL�̎擾
	sprintf(tmp, "<servicetype>%s", IGDInfo.DeviceType);
	p = strstr(body, tmp);
	if (p == NULL) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}
	if (! GetXMLEntry(ControlURLTail, sizeof(ControlURLTail), p, "controlurl")) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}

	if (! GetXMLEntry(ControlURLBase, sizeof(ControlURLBase), body, "baseurl")) {
		if (IGDInfo.DevicePort == 80)
			sprintf(ControlURLBase, "http://%s", IGDInfo.DeviceHost);
		else
			sprintf(ControlURLBase, "http://%s:%d", IGDInfo.DeviceHost, (int)IGDInfo.DevicePort);
	}

	sprintf(ControlURL, "%s%s", ControlURLBase, ControlURLTail);

	if (strncmp(ControlURL, "http://", 7) != 0) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}

	p = getstr(IGDInfo.ControlHost, ControlURL+7, sizeof(IGDInfo.ControlHost), '/');
	IGDInfo.ControlPath[0] = '/';
	getstr(IGDInfo.ControlPath+1, p, sizeof(IGDInfo.ControlPath)-1);
	if ((p = strchr(IGDInfo.ControlHost, ':')) != NULL) {
		*p = '\0';
		IGDInfo.ControlPort = (unsigned short)atoi(p+1);
	}

	getstr(IGDInfo.ControlURL, ControlURL, sizeof(IGDInfo.ControlURL));


	delete [] dbuf;

	return TRUE;
}




BOOL GetExternalIPAddress()
{
	// @@IPv4-dependent
	char buf[4096];
	char *dbuf;
	char *p, *body;
	int ret;
	HTTPRESPONSE res;
	HTTPREQUEST req;
	list<HTTPHEADER>::iterator it;

	dbuf = new char[MAX_XMLSIZE];

	// ExternalIPAdress�̎擾
	getstr(req.Path, IGDInfo.ControlPath, sizeof(req.Path));
	req.Headers.clear();
	req.res.Headers.clear();

	p = buf;
	p += sprintf(p, "<?xml version=\"1.0\"?>\r\n");
	p += sprintf(p, "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ");
	p += sprintf(p, "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n");
	p += sprintf(p, "<s:Body>\r\n");
	p += sprintf(p, "<u:GetExternalIPAddress xmlns:u=\"%s\"></u:GetExternalIPAddress>\r\n", IGDInfo.DeviceType);
	p += sprintf(p, "</s:Body>\r\n");
	p += sprintf(p, "</s:Envelope>\r\n");

	req.Headers.clear();
	getstr(req.Path, IGDInfo.ControlPath, sizeof(req.Path));
	req.Body = buf;
	ret = SOAPAction(IGDInfo.ControlHost, IGDInfo.ControlPort, IGDInfo.DeviceType, "GetExternalIPAddress", &req, dbuf, MAX_XMLSIZE);
	if (ret < 0) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}
	body = dbuf + ret;

	if (! GetXMLEntry(IGDInfo.ExternalIPAddress, sizeof(IGDInfo.ExternalIPAddress), body, "newexternalipaddress")) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}

	delete [] dbuf;

	return TRUE;
}





unsigned int __stdcall InitUPnPNATProc(void *param)
{
	SOCKETINFO *si = (SOCKETINFO *)param;

	if (iNATError == 0)
		DiscoverIGD();
	if (iNATError == 0)
		GetControlURL();
	if (iNATError == 0)
		GetExternalIPAddress();
	
	if (iNATError == 0) {
		iNATStatus = NATSTAT_AVAILABLE;
	}
	else {
		iNATStatus = NATSTAT_NOTAVAILABLE;
	}

	EndThread(si);
	return 0;
}


void InitUPnPNAT()
{
	SOCKETINFO *si;

	if (iNATStatus != NATSTAT_NOTINIT)
		return;

	iNATStatus = NATSTAT_INITIALIZING;
	iNATError = 0;
	si = new SOCKETINFO;
	si->type = ST_SPECIAL;
	si->hThread = (HANDLE)_beginthreadex(NULL, 0, InitUPnPNATProc, (void *)si, 0, (unsigned int *)&si->threadID);
	si->hWnd = NULL;
	ssx.insert(si);
}

int EnumPortMapping(PORTSET *s)
{
	// @@IPv4-dependent
	char buf[4096], tmp[256];
	char *dbuf, *xml;
	char *p;
	int ret;
	int i;
	HTTPREQUEST req;
	PORT port;
	list<HTTPHEADER>::iterator it;

	/*
		PortMapping�̎擾
	*/

	s->clear();
	dbuf = new char[MAX_XMLSIZE];

	for(i=0; ; i++) {
		p = buf;
		p += sprintf(p, "<?xml version=\"1.0\"?>\r\n");
		p += sprintf(p, "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ");
		p += sprintf(p, "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n");
		p += sprintf(p, "<s:Body>\r\n");
		p += sprintf(p, "<u:GetGenericPortMappingEntry xmlns:u=\"%s\">\r\n", IGDInfo.DeviceType);
		p += sprintf(p, "<NewPortMappingIndex>%d</NewPortMappingIndex>\r\n", i);
		p += sprintf(p, "</u:GetGenericPortMappingEntry>\r\n");
		p += sprintf(p, "</s:Body>\r\n");
		p += sprintf(p, "</s:Envelope>\r\n");

		req.Headers.clear();
		getstr(req.Path, IGDInfo.ControlPath, sizeof(req.Path));
		req.Body = buf;
		ret = SOAPAction(IGDInfo.ControlHost, IGDInfo.ControlPort, IGDInfo.DeviceType, "GetGenericPortMappingEntry", &req, dbuf, MAX_XMLSIZE);

		if (ret < 0 || req.res.Code != 200)
			break;

		xml = dbuf+ret;

		GetXMLEntry(tmp, sizeof(tmp), xml, "newprotocol");
		if (stricmp(tmp, "TCP") == 0) port.first = SOCK_STREAM;
		else if (stricmp(tmp, "UDP") == 0) port.first = SOCK_DGRAM;
		else port.first = 0;
		port.second = (unsigned short)GetXMLEntryInt(xml, "newexternalport");

		s->insert(port);
	}
		
	delete [] dbuf;

	return i;
}



int AddPortMapping(PORTMAPPING *mapping)
{
	// @@IPv4-dependent
	char buf[4096];
	char *dbuf;
	char *p;
	int ret;
	HTTPREQUEST req;
	list<HTTPHEADER>::iterator it;
	PORTSET s;
	PORT port;
	PORTSET::iterator pit;
	unsigned short sh;

	EnumPortMapping(&s);

	if (ntohs(mapping->exaddr.sin_port) == 0) {
		port.first = mapping->socktype;
		for(sh=DYNAMIC_PORT_BEGIN; sh<DYNAMIC_PORT_END; sh++) {
			port.second = sh;
			pit = s.find(port);
			if (pit == s.end())
				break;
		}
		if (sh == DYNAMIC_PORT_END) return NATERR_PORTNOTAVAIL;
		mapping->exaddr.sin_port = htons(sh);
	}
	else {
		port.first = mapping->socktype;
		port.second = ntohs(mapping->exaddr.sin_port);
		pit = s.find(port);
		if (pit != s.end())
			return NATERR_PORTNOTAVAIL;
	}

	mapping->exaddr.sin_addr.s_addr = inet_addr(IGDInfo.ExternalIPAddress);

	/*
		PortMapping�̐ݒ�
	*/

	p = buf;
	p += sprintf(p, "<?xml version=\"1.0\"?>\r\n");
	p += sprintf(p, "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ");
	p += sprintf(p, "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n");
	p += sprintf(p, "<s:Body>\r\n");
	p += sprintf(p, "<u:AddPortMapping xmlns:u=\"%s\">\r\n", IGDInfo.DeviceType);
	p += sprintf(p, "<NewRemoteHost></NewRemoteHost>\r\n");
	p += sprintf(p, "<NewExternalPort>%d</NewExternalPort>\r\n", (int)ntohs(mapping->exaddr.sin_port));
	p += sprintf(p, "<NewProtocol>%s</NewProtocol>\r\n", mapping->socktype==SOCK_STREAM ? "TCP" : "UDP");
	p += sprintf(p, "<NewInternalPort>%d</NewInternalPort>\r\n", (int)ntohs(mapping->inaddr.sin_port));
	p += sprintf(p, "<NewInternalClient>%s</NewInternalClient>\r\n", inet_ntoa(mapping->inaddr.sin_addr));
	p += sprintf(p, "<NewEnabled>1</NewEnabled>\r\n");
	p += sprintf(p, "<NewPortMappingDescription>%s</NewPortMappingDescription>\r\n", mapping->description);
	p += sprintf(p, "<NewLeaseDuration>0</NewLeaseDuration>\r\n");
	p += sprintf(p, "</u:AddPortMapping>\r\n");
	p += sprintf(p, "</s:Body>\r\n");
	p += sprintf(p, "</s:Envelope>\r\n");

	req.Headers.clear();
	getstr(req.Path, IGDInfo.ControlPath, sizeof(req.Path));
	req.Body = buf;
	dbuf = new char[MAX_XMLSIZE];
	ret = SOAPAction(IGDInfo.ControlHost, IGDInfo.ControlPort, IGDInfo.DeviceType, "AddPortMapping", &req, dbuf, MAX_XMLSIZE);
	delete [] dbuf;
	if (ret < 0 || req.res.Code != 200)
		return NATERR_FAILEDREGISTMAP;

	return 0;
}


int DeletePortMapping(PORTMAPPING *mapping)
{
	// @@IPv4-dependent
	char buf[4096];
	char *dbuf;
	char *p;
	int ret;
	HTTPREQUEST req;
	list<HTTPHEADER>::iterator it;

	/*
		PortMapping�̍폜
	*/

	p = buf;
	p += sprintf(p, "<?xml version=\"1.0\"?>\r\n");
	p += sprintf(p, "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ");
	p += sprintf(p, "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n");
	p += sprintf(p, "<s:Body>\r\n");
	p += sprintf(p, "<u:DeletePortMapping xmlns:u=\"%s\">\r\n", IGDInfo.DeviceType);
	p += sprintf(p, "<NewRemoteHost></NewRemoteHost>\r\n");
	p += sprintf(p, "<NewExternalPort>%d</NewExternalPort>\r\n", (int)ntohs(mapping->exaddr.sin_port));
	p += sprintf(p, "<NewProtocol>%s</NewProtocol>\r\n", mapping->socktype==SOCK_STREAM ? "TCP" : "UDP");
	p += sprintf(p, "</u:DeletePortMapping>\r\n");
	p += sprintf(p, "</s:Body>\r\n");
	p += sprintf(p, "</s:Envelope>\r\n");

	req.Headers.clear();
	getstr(req.Path, IGDInfo.ControlPath, sizeof(req.Path));
	req.Body = buf;
	dbuf = new char[MAX_XMLSIZE];
	ret = SOAPAction(IGDInfo.ControlHost, IGDInfo.ControlPort, IGDInfo.DeviceType, "DeletePortMapping", &req, dbuf, MAX_XMLSIZE);
	delete [] dbuf;
	if (ret < 0 || req.res.Code != 200)
		return NATERR_FAILEDUNREGISTMAP;

	return 0;
}



void AddPortMappingProc(void *param)
{
	SOCKETINFO *si = (SOCKETINFO *)param;
	if ((si->map.err = AddPortMapping(&si->map)) == 0) {
		si->map.bAvailable = TRUE;
	}

	si->Lock();
	si->fAsyncTask &= ~ASYNC_NATMAP;
	if (si->bClosing && si->fAsyncTask == 0)
		PostMessage(si->hWnd, WM_CLOSE, 0, 0);
	si->Unlock();
}

void DeletePortMappingProc(void *param)
{
	SOCKETINFO *si = (SOCKETINFO *)param;
	if ((si->map.err = DeletePortMapping(&si->map)) == 0) {
		si->map.bAvailable = FALSE;
	}

	si->Lock();
	si->fAsyncTask &= ~ASYNC_NATMAP;
	if (si->bClosing && si->fAsyncTask == 0)
		PostMessage(si->hWnd, WM_CLOSE, 0, 0);
	si->Unlock();
}






















EXPORT BOOL WINAPI natinit(int p1, int p2, int p3, int p4)
{
	if (Initialize())
		return -4;	// WinSock�������G���[

	switch(iNATStatus) {
		case NATSTAT_AVAILABLE:
			return -1;	// UPnPNAT�L��

		case NATSTAT_NOTINIT:
			InitUPnPNAT();
			return 0;	// �T����

		case NATSTAT_INITIALIZING:
			return 0;	// �T����

		case NATSTAT_NOTAVAILABLE:
			switch(iNATError) {
				case NATERR_IGDNOTFOUND:
					return -2;	// UPnPNAT���[�^�����݂��Ȃ�
				case NATERR_IGDNOTSUPP:
					return -3;	// ��Ή�UPnPNAT���[�^
				case NATERR_NETDOWN:
					return -4;	// �ڑ��s��
				default:
					return -4;
			}

		default:
			return -4;
	}
}



EXPORT BOOL WINAPI natbind(int p1, int p2, int p3, int p4)
{
	// @@IPv4-dependent
	SOCKETINFO *si = (SOCKETINFO *)p1;

	if (! IsSocket(si, ST_TCPLIS|ST_UDP))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -4;	// ��\�P�b�g

	if (iNATStatus != NATSTAT_AVAILABLE)
		return -3;	// NAT Traversal ���p�s��

	char tmp[256];
	struct hostent *ent;
	SOCKET soc;
	int i;
	struct sockaddr_in addr4;
	int addrlen;

	if (si->map.bAvailable) return -1;	// ����bind�ς�
	if ((si->fAsyncTask&ASYNC_NATMAP) != 0) return -2;	// bind���s��

	si->Lock();

	for(i=0; i<si->socs; i++) {
		if (si->family[i] == PF_INET) break;
	}
	if (i == si->socs) {
		si->Unlock();
		return -1;
	}
	soc = si->soc[i];

	si->map.socktype = si->type == ST_TCPLIS ? SOCK_STREAM : SOCK_DGRAM;
	memset(&si->map.inaddr, 0, sizeof(si->map.inaddr));
	memset(&si->map.exaddr, 0, sizeof(si->map.exaddr));
	si->map.inaddr.sin_family = si->map.exaddr.sin_family = PF_INET;
	gethostname(tmp, sizeof(tmp));
	ent = gethostbyname(tmp);
	si->map.inaddr.sin_addr.s_addr = *(unsigned int *)ent->h_addr_list[0];
	addrlen = sizeof(addr4);
	getsockname(soc, (struct sockaddr *)&addr4, &addrlen);
	si->map.inaddr.sin_port = addr4.sin_port;
	si->map.exaddr.sin_port = htons((unsigned short)p2);
	sprintf(si->map.description, "pcbnet2 NAT Mapper [%08x%08x%08x]", GetCurrentThreadId(), (int)si, GetTickCount());
	si->map.err = 0;

	si->fAsyncTask |= ASYNC_NATMAP;
	_beginthread(AddPortMappingProc, 0, (void *)si);

	si->Unlock();

	return 0;
}


EXPORT BOOL WINAPI natcheck(int p1, int p2, int p3, char *refstr)
{
	*refstr = '\0';
	SOCKETINFO *si = (SOCKETINFO *)p1;
	if (! IsSocket(si, ST_TCPLIS|ST_UDP))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -3;	// ��\�P�b�g

	if (si->map.err != 0)
		return -2;	// bind���Ɏ��s
	else if (! si->map.bAvailable)
		return 0;	// bind����Ă��Ȃ�

	char tmp[128];
	DWORD dw;

	dw = sizeof(tmp);
	WSAAddressToString((struct sockaddr *)&si->map.exaddr, sizeof(si->map.exaddr), NULL, tmp, &dw);

	strcpy(refstr, tmp);
	return -1;	// bind�ς�
}




EXPORT BOOL WINAPI natfree(int p1, int p2, int p3, int p4)
{
	// @@IPv4-dependent
	SOCKETINFO *si = (SOCKETINFO *)p1;

	if (! IsSocket(si, ST_TCPLIS|ST_UDP))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -3;	// ��\�P�b�g

	if (iNATStatus != NATSTAT_AVAILABLE)
		return -3;	// NAT Traversal ���p�s��

	if (! si->map.bAvailable) return -1;	// bind����Ă��Ȃ�
	if ((si->fAsyncTask&ASYNC_NATMAP) != 0) return -2;	// bind��

	si->Lock();

	si->map.err = 0;

	si->fAsyncTask |= ASYNC_NATMAP;
	_beginthread(DeletePortMappingProc, 0, (void *)si);

	si->Unlock();

	return 0;
}



/*
EXPORT BOOL WINAPI natenum(char *p1, int p2, int p3, int p4)
{
	PORTSET s;
	PORTSET::iterator it;

	p1[0] = '\0';

	if (iNATStatus != NATSTAT_AVAILABLE)
		return 0;	// NAT Traversal ���p�s��

	EnumPortMapping(&s);

	for(it=s.begin(); it!=s.end(); it++) {
		if (it->first == SOCK_STREAM)
			p1 += sprintf(p1, "TCP:");
		else if (it->first == SOCK_DGRAM)
			p1 += sprintf(p1, "UDP:");
		else
			p1 += sprintf(p1, "???:");
		p1 += sprintf(p1, "%d\r\n", (int)it->second);
	}

	return -(int)s.size();
}


EXPORT BOOL WINAPI soapaction(char *p1, char *p2, int p3, int p4)
{
	PORTSET s;
	PORTSET::iterator it;
	HTTPREQUEST req;
	int ret;
	char *dbuf;
	char buf[4096];

	p1[0] = '\0';

	if (p3 <= 0) return 3;

	if (iNATStatus != NATSTAT_AVAILABLE)
		return -1;	// NAT Traversal ���p�s��

	p = buf;
	p += sprintf(p, "<?xml version=\"1.0\"?>\r\n");
	p += sprintf(p, "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ");
	p += sprintf(p, "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n");
	p += sprintf(p, "<s:Body>\r\n");
	p += sprintf(p, "<u:%s xmlns:u=\"%s\">\r\n", p2, IGDInfo.DeviceType);
	p += sprintf(p, "<NewPortMappingIndex>%d</NewPortMappingIndex>\r\n", i);
	p += sprintf(p, "</u:GetGenericPortMappingEntry>\r\n");
	p += sprintf(p, "</s:Body>\r\n");
	p += sprintf(p, "</s:Envelope>\r\n");

	req.Headers.clear();
	getstr(req.Path, IGDInfo.ControlPath, sizeof(req.Path));
	req.Body = buf;
	ret = SOAPAction(IGDInfo.ControlHost, IGDInfo.ControlPort, IGDInfo.DeviceType, "GetExternalIPAddress", &req, dbuf, MAX_XMLSIZE);
	if (ret < 0) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}
	body = dbuf + ret;

	if (! GetXMLEntry(IGDInfo.ExternalIPAddress, sizeof(IGDInfo.ExternalIPAddress), body, "newexternalipaddress")) {
		delete [] dbuf;
		iNATError = NATERR_IGDNOTSUPP;
		return FALSE;
	}

	delete [] dbuf;

	return -(int)s.size();
}


*/