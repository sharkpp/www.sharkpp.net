/**
 * @file  icdl.cpp
 * @brief IC�J�[�h�Ƌ��ؓǂݎ��N���X ����
 *
 * Copyright(c) 2011 sharkpp<webmaster@sharkpp.net> All rights reserved.
 * 
 * The MIT License
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * �ȉ��ɎQ�l�Ƃ��� The MIT License �̓��{���𕹋L���܂����A�Еz�����Ƃ��ẮA
 * ��L�����ɏ]���Ă��������B
 * 
 * The MIT License
 * 
 * �ȉ��ɒ�߂�����ɏ]���A�{�\�t�g�E�F�A����ъ֘A�����̃t�@�C��
 * �i�ȉ��u�\�t�g�E�F�A�v�j�̕������擾���邷�ׂĂ̐l�ɑ΂��A�\�t�g�E�F�A��
 * �������Ɉ������Ƃ𖳏��ŋ����܂��B����ɂ́A�\�t�g�E�F�A�̕������g�p�A
 * ���ʁA�ύX�A�����A�f�ځA�Еz�A�T�u���C�Z���X�A�����/�܂��͔̔����錠���A
 * ����у\�t�g�E�F�A��񋟂��鑊��ɓ������Ƃ������錠�����������Ɋ܂܂�
 * �܂��B
 * 
 * ��L�̒��쌠�\������і{�����\�����A�\�t�g�E�F�A�̂��ׂĂ̕����܂��͏d�v
 * �ȕ����ɋL�ڂ�����̂Ƃ��܂��B
 * 
 * �\�t�g�E�F�A�́u����̂܂܁v�ŁA�����ł��邩�Öقł��邩���킸�A�����
 * �ۏ؂��Ȃ��񋟂���܂��B�����ł����ۏ؂Ƃ́A���i���A����̖ړI�ւ̓K�����A
 * ����ь�����N�Q�ɂ��Ă̕ۏ؂��܂݂܂����A����Ɍ��肳�����̂ł͂���
 * �܂���B��҂܂��͒��쌠�҂́A�_��s�ׁA�s�@�s�ׁA�܂��͂���ȊO�ł��낤
 * �ƁA�\�t�g�E�F�A�ɋN���܂��͊֘A���A���邢�̓\�t�g�E�F�A�̎g�p�܂��͂���
 * ���̈����ɂ���Đ������؂̐����A���Q�A���̑��̋`���ɂ��ĉ���̐ӔC��
 * ����Ȃ����̂Ƃ��܂��B 
 */

#include "icdl.hpp"
#include <algorithm>

icdl::scard_cb_type::scard_cb_type(icdl & inst_)
	: inst(inst_)
{
}

void icdl::scard_cb_type::operator()(const uint8_t* data, size_t length)
{
	::memcpy(inst.m_result, data, length);
	inst.m_result_length = length;
	inst.m_sending = false;
}

icdl::icdl()
	: m_sending(false)
	, m_result_length(0)
	, m_selected_file(0x00)
	, m_pin_valid(false)
	, m_prefetched(false)
	, m_code_buff(new char [4096])
	, m_code_len(0)
{
	::memset(m_data, 0, sizeof(m_data));
}

icdl::~icdl()
{
	disconnect();

	for(int i = 0; i < sizeof(m_data)/sizeof(m_data[0]); i++) {
		delete [] m_data[i].data;
	}
	
	delete [] m_code_buff;
}

bool icdl::connect(const char * reader_name)
{
	return m_scard.connect(reader_name);
}

bool icdl::disconnect()
{
	return m_scard.disconnect();
}

void icdl::update(uint16_t tag, const uint8_t * data, size_t length)
{
	delete [] m_data[tag].data;
	
	m_data[tag].length = (uint32_t)length;
	m_data[tag].data   = new uint8_t[length + 1];
	::memcpy(m_data[tag].data, data, length);
	m_data[tag].data[length] = 0;
}

const char * icdl::jis208_to_sjis(uint16_t tag, bool concat, size_t offset, size_t length)
{
	size_t          len  = (size_t)~0 != length ? (std::min)(offset + length, m_data[tag].length)
	                                            : m_data[tag].length;
	const uint8_t * data = (const uint8_t *)m_data[tag].data + offset;
	char *          p    = m_code_buff;


	if( !concat ) {
		m_code_len = 0;
	} else if( offset < len ) {
		p += m_code_len;
		*p++ = '\r';
		*p++ = '\n';
		m_code_len += 2;
	}

	for(const uint8_t * last = data + len; data < last; data += 2)
	{
		uint8_t c1, c2;
		if( 0xFF == data[0] && 0xF0 == (data[1] & 0xF0) ) {
			c1 = data[0];
			c2 = data[1];
		} else {
			c1 = ((data[0] - 0x21) >> 1) + 0x81;
			c2 =   data[1] + (data[0] & 1 ? 0x1f : 0x7e);
			if( 0 != (data[0] & 1) && 0x7f <= c2 ) { c2++; }
			if( 0xA0 <= c1 ) { c1 += 0x40; }
		}
		*p++ = (char)c1;
		*p++ = (char)c2;
	}

	if( offset < len || !concat ) {
		*p = 0;
	}

	m_code_len += size_t(p - m_code_buff);

	return m_code_buff;
}

ICDL_DATE_TYPE icdl::castDate(uint16_t tag, size_t offset)
{
	uint8_t*       data = m_data[tag].data + offset;
	ICDL_DATE_TYPE v = { ERA_ID_UNKNOWN };


	if( m_data[tag].length < offset + 7 ) {
		return v;
	}

	if( !::memcmp(LICENSE_TYPE_UNKNOWN_DATE_ACQUIRED, data + offset, sizeof(LICENSE_TYPE_UNKNOWN_DATE_ACQUIRED)) )
	{
		v.era_id	= ERA_ID_UNKNOWN;
	}
	else
	{
		v.era_id	= data[offset + 0];
		v.year		= (data[offset + 1] - 0x30) * 10 + (data[offset + 2] - 0x30);
		v.month		= (data[offset + 3] - 0x30) * 10 + (data[offset + 4] - 0x30);
		v.day		= (data[offset + 5] - 0x30) * 10 + (data[offset + 6] - 0x30);
	}

	return v;
}

ICDL_EUDC_TYPE icdl::castEudc(uint16_t tag)
{
	uint8_t*       data = m_data[tag].data;
	ICDL_EUDC_TYPE v = {};

	if( !m_data[tag].length || !data ) {
		return v;
	}

	v.size		= (*data>>4)*10|(*data&15);
	v.length	= m_data[tag].length - 1;
	v.data		= data + 1;

	return v;
}

uint32_t icdl::castUint(uint16_t tag)
{
	size_t    len  = m_data[tag].length;
	uint8_t*  data = m_data[tag].data;
	uint32_t n = 0;

	for(size_t i = 0; i < len; i++) {
		n = n * 10 + (data[i] - 0x30);
	}

	return n;
}

uint64_t icdl::castUint64(uint16_t tag)
{
	size_t    len  = m_data[tag].length;
	uint8_t*  data = m_data[tag].data;
	uint64_t n = 0;

	for(size_t i = 0; i < len; i++) {
		n = n * 10 + (data[i] - 0x30);
	}

	return n;
}


ICDL_EUDC_TYPE icdl::get_eudc(uint16_t index)
{
	prefetch();
	if( index < 2 ) {
		return castEudc(TAG_EUDC1 + index);
	} else if( m_data[TAG_APPEND_STATUS].length &&
	           APPEND_STATUS_MARKER == *m_data[TAG_APPEND_STATUS].data &&
	           index < 7 ) {
		return castEudc(TAG_EUDC3 + index);
	}
	ICDL_EUDC_TYPE tmp = {};
	return tmp;
}

bool icdl::pin_auth(uint16_t pin1, uint16_t pin2)
{
	uint8_t tmp[4096];
	size_t len;

	len = sizeof(tmp);
	read_file(ID_MF, EF_ID_MF_EF02, tmp, &len);
	update(tmp[0], tmp + 2, tmp[1]);


	if( PIN_ENABLE != (*m_data[TAG_PIN_CONFIG].data & PIN_ENABLE_MASK) )
	{
		pin1 = DPIN;
		pin2 = DPIN;
	}


	if( !attestation(EF_ID_MF_IEF01, pin1) ||
		!attestation(EF_ID_MF_IEF02, pin2) )
	{
		return false;
	}

	m_pin_valid = true;

	return true;
}

int icdl::get_pin1_auth_rest()
{
	return get_allowed_match_count(EF_ID_MF_IEF01);
}

int icdl::get_pin2_auth_rest()
{
	return get_allowed_match_count(EF_ID_MF_IEF02);
}

bool icdl::connected() const
{
	return m_scard.connected() && m_pin_valid;
}

void icdl::read_file(uint32_t file_id, uint16_t elementary_file_id, void * buff, size_t * len)
{
	if( file_id != m_selected_file )
	{
		switch( file_id )
		{
		case ID_MF:
			select_master_file();
			break;
		case ID_DF1:
			select_dedicated_file(AID_DF1);
			break;
		case ID_DF2:
			select_dedicated_file(AID_DF2);
			break;
		case ID_DF3:
			select_dedicated_file(AID_DF3);
			break;
		default:
			return;
		}

		m_selected_file = file_id;
	}


	select_elementary_file(elementary_file_id);


	read(0, buff, len);
}

void icdl::prefetch()
{
	static const uint32_t READ_FILE_ID[] = {
			ID_MF|EF_ID_MF_EF01,
			ID_DF1|EF_ID_DF1_EF01, ID_DF1|EF_ID_DF1_EF02,
			ID_DF1|EF_ID_DF1_EF03, ID_DF1|EF_ID_DF1_EF04,
			ID_DF1|EF_ID_DF1_EF05, ID_DF1|EF_ID_DF1_EF06,
			ID_DF1|EF_ID_DF1_EF07,
			ID_DF2|EF_ID_DF2_EF01,
		};
	uint8_t tmp[4096], *p, *last;
	size_t len;

	if( m_prefetched || !m_pin_valid )
	{
		return;
	}
	m_prefetched = true;


	for(int i = 0; i < sizeof(READ_FILE_ID)/sizeof(READ_FILE_ID[0]);
		i++)
	{
		len = sizeof(tmp);
		read_file(READ_FILE_ID[i] & 0xFFFF0000, READ_FILE_ID[i] & 0xFFFF, tmp, &len);

#if 0
		char fname[256];
		sprintf(fname, "%08X.dat", READ_FILE_ID[i]);
		FILE *fp = fopen(fname, "wb");
		fwrite(tmp, 1, len, fp);
		fclose(fp);
#endif

		if( (ID_DF2|EF_ID_DF2_EF01) == READ_FILE_ID[i] )
		{
			size_t offset = 0x82 == tmp[2] ? 5 : 3;
			size_t length = 0x82 == tmp[2] ? ((tmp[3] << 8)|tmp[4]) : tmp[2];
			update((tmp[0]<<8)|tmp[1], tmp + offset, length);
		}
		else
		{
			for(p = tmp, last = tmp + len; p < last && 0xFF != *p; ) {
				size_t offset = 0x82 == p[1] ? 4 : 2;
				size_t length = 0x82 == p[1] ? ((p[2] << 8)|p[3]) : p[1];
				update(p[0], p + offset, length);
				p += offset + length;
			}
		}
	}

}


bool icdl::select_master_file()
{
	static const uint8_t MASTER_FILE_SELECT_CMD[] = { 0x00, 0xA4, 0x00, 0x00 };

	if( !m_scard.connected() ) {
		return false;
	}

	if( !m_scard.transmit(scard_cb_type(*this), MASTER_FILE_SELECT_CMD, sizeof(MASTER_FILE_SELECT_CMD)) )
	{
		return false;
	}

	while(m_sending);

	return SW_NO_ERROR == scard::read_status_byte(m_result, m_result_length);
}


bool icdl::select_dedicated_file(const uint8_t * dedicated_file_id)
{
	static const uint8_t DEDICATED_FILE_SELECT_CMD_HEADER[]  = { 0x00, 0xA4 };

	if( !m_scard.connected() ) {
		return false;
	}


















	uint8_t cmd[1+1+1+1+1+16] = {};
	::memcpy(cmd, DEDICATED_FILE_SELECT_CMD_HEADER, sizeof(DEDICATED_FILE_SELECT_CMD_HEADER));
	cmd[2] = 0x04;
	cmd[3] = 0x0C;
	cmd[4] = 16;
	::memcpy(cmd + 5, dedicated_file_id, 16);

	if( !m_scard.transmit(scard_cb_type(*this), cmd, sizeof(cmd)) )
	{
		return false;
	}

	while(m_sending);

	return SW_NO_ERROR == scard::read_status_byte(m_result, m_result_length);
}


bool icdl::select_elementary_file(uint16_t elementary_file_id)
{
	static const uint8_t ELEMENTARY_FILE_SELECT_CMD_HEADER[] = { 0x00, 0xA4, 0x02, 0x0C, 0x02 };

	if( !m_scard.connected() ) {
		return false;
	}


	uint8_t cmd[1+1+1+1+1+2] = {};
	memcpy(cmd, ELEMENTARY_FILE_SELECT_CMD_HEADER, sizeof(ELEMENTARY_FILE_SELECT_CMD_HEADER));
	cmd[5] = elementary_file_id >> 8;
	cmd[6] = elementary_file_id & 0xFF;

	if( !m_scard.transmit(scard_cb_type(*this), cmd, sizeof(cmd)) )
	{
		return false;
	}

	while(m_sending);

	return SW_NO_ERROR == scard::read_status_byte(m_result, m_result_length);
}


bool icdl::attestation(uint16_t elementary_file_id, uint16_t pin)
{
	static const uint8_t VERIFY_CMD_HEADER[] = { 0x00, 0x20, 0x00 };

	if( !m_scard.connected() ) {
		return false;
	}


	if( EF_ID_MF_IEF01 != elementary_file_id &&
	    EF_ID_MF_IEF02 != elementary_file_id )
	{
		return false;
	}


	uint8_t cmd[1+1+1+1+1+4] = {};
	::memcpy(cmd, VERIFY_CMD_HEADER, sizeof(VERIFY_CMD_HEADER));
	cmd[3] = 0x80 | (elementary_file_id & 0x1F);
	cmd[4] = 4;
	cmd[5] = (BYTE)(DPIN == pin ? '*' : '0' + (pin / 1000     ));
	cmd[6] = (BYTE)(DPIN == pin ? '*' : '0' + (pin /  100 % 10));
	cmd[7] = (BYTE)(DPIN == pin ? '*' : '0' + (pin /   10 % 10));
	cmd[8] = (BYTE)(DPIN == pin ? '*' : '0' + (pin        % 10));

	if( !m_scard.transmit(scard_cb_type(*this), cmd, sizeof(cmd)) )
	{
		return false;
	}

	while(m_sending);

	return SW_NO_ERROR == scard::read_status_byte(m_result, m_result_length);
}


int icdl::get_allowed_match_count(uint16_t elementary_file_id)
{
	static const uint8_t VERIFY_CMD_HEADER[] = { 0x00, 0x20, 0x00 };

	if( !m_scard.connected() ) {
		return -1;
	}


	if( EF_ID_MF_IEF01 != elementary_file_id &&
	    EF_ID_MF_IEF02 != elementary_file_id )
	{
		return -1;
	}


	uint8_t cmd[1+1+1+1] = { };
	memcpy(cmd, VERIFY_CMD_HEADER, sizeof(VERIFY_CMD_HEADER));
	cmd[3] = 0x80 | (elementary_file_id & 0x1F);

	if( !m_scard.transmit(scard_cb_type(*this), cmd, sizeof(cmd)) )
	{
		return -1;
	}

	while(m_sending);

	return SW_VERIFICATION_FAILED_RETRY_COUNTER_0
				!= (scard::read_status_byte(m_result, m_result_length) & 0xFFF0)
			? -1 : int(m_result[m_result_length - 1] & 0x0F);
}


bool icdl::read(uint16_t offset, void * buff, size_t * len)
{
	static const uint8_t READ_BINARY_CMD_HEADER[] = { 0x00, 0xB0 };

	if( !m_scard.connected() ) {
		return false;
	}

	if( 0x7FFF < offset )
	{
		return false;
	}

	uint32_t cch = (uint32_t)(len ? *len : 0);


	uint8_t cmd[1+1+1+1+3] = { };
	memcpy(cmd, READ_BINARY_CMD_HEADER, sizeof(READ_BINARY_CMD_HEADER));
	cmd[2] = 0x00 | (offset >> 8);
	cmd[3] = offset & 0xFF;
	cmd[4] = 0x00;
	cmd[5] = (uint8_t)(cch >> 8);
	cmd[6] = (uint8_t)(cch & 0xFF);

	if( !m_scard.transmit(scard_cb_type(*this), cmd, sizeof(cmd)) )
	{
		return false;
	}

	while(m_sending);

	if( SW_NO_ERROR != scard::read_status_byte(m_result, m_result_length) )
	{
		return false;
	}

	if( len ) {
		*len = m_result_length - 2;
	}

	::memcpy(buff, m_result, m_result_length - 2);

	return true;
}
