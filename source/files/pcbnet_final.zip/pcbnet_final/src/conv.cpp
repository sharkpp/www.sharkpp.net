// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"
#include "md5.h"

EXPORT BOOL WINAPI xtoyl(int *p1, int p2, int p3, int p4)
{
	*p1 = (int)htonl((u_long)p2);
	return 0;
}

EXPORT BOOL WINAPI xtoys(int *p1, int p2, int p3, int p4)
{
	*p1 = (int)htons((u_short)p2);
	return 0;
}

EXPORT BOOL WINAPI calccs(char *p1, int p2, int p3, int p4)
{
	int cs;

	cs = (int)CheckSum(p1, p2);
	return -cs;
}

EXPORT BOOL WINAPI calcmd5(char *p1, int p2, int p3, char *refstr)
{
	MD5_CTX context;
	unsigned char digest[16];

	MD5Init(&context);
	MD5Update(&context, (unsigned char *)p1, p2);
	MD5Final(digest, &context);

	sprintf(refstr,
		"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
		(int)digest[0], (int)digest[1], (int)digest[2], (int)digest[3], 
		(int)digest[4], (int)digest[5], (int)digest[6], (int)digest[7], 
		(int)digest[8], (int)digest[9], (int)digest[10], (int)digest[11], 
		(int)digest[12], (int)digest[13], (int)digest[14], (int)digest[15]);
	return 0;
}
