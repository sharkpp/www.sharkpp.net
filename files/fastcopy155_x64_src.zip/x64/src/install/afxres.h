#include <windows.h>
#include <winver.h>

#define IDC_STATIC	-1
