// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"
#include "general.h"


EXPORT BOOL WINAPI dnsrequest(int *p1, char *p2, int p3, int p4)
{
	*p1 = 0;
	if (Initialize()) return -1;		// WinSock�������G���[

	SOCKETINFO *si;
	si = CreateSocket(ST_DNS);
	if (si == NULL)
		return -2;			//	�\�P�b�g�������G���[

	SendMessage(si->hWnd, WM_PCBNET_DNSREQUEST, 0, (LPARAM)p2);
	*p1 = (int)si;
	return 0;
}


EXPORT BOOL WINAPI dnscheck(int p1, int p2, int p3, int p4)
{
	SOCKETINFO *si = (SOCKETINFO *)p1;
	if (! IsSocket(si, ST_DNS))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -3;	// ��\�P�b�g

	if (si->dns.bReply) {
		if (si->err == 0)
			return -1;	// �ԓ�������
		else
			return -2;	// �G���[
	}
	return 0;	// ���ԓ�
}


EXPORT BOOL WINAPI dnsreply(char *p1, int p2, int p3, int p4)
{
	*p1 = '\0';
	SOCKETINFO *si = (SOCKETINFO *)p2;
	if (! IsSocket(si, ST_DNS))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -4;	// ��\�P�b�g

	if (p3 < 0 || p3 > 1) return -1;	// �͈͊O�p�����[�^

	if (! si->dns.bReply) return -2;	// ���ԓ�
	if (si->err != 0) return -3;	// �G���[

	si->Lock();

	addrinfo *res;
	char tmp[128];
	int ret;

	ret = 0;
	switch(p3) {
		case 0:		// address
			for(res=si->dns.res0; res!=NULL; res=res->ai_next) {
				if (res->ai_family == PF_INET || res->ai_family == PF_INET6)
					break;
			}
			if (res != NULL) {
				if (getnameinfo(res->ai_addr, res->ai_addrlen, tmp, sizeof(tmp), NULL, 0, NI_NUMERICHOST) == 0)
					strcpy(p1, tmp);
			}
			break;
		case 1:		// hostname
			if (si->dns.hostname[0] != '\0')
				strcpy(p1, si->dns.hostname);
			else
				ret = -1;
			break;
	}

	si->Unlock();
	return ret;
}


EXPORT BOOL WINAPI dnsclose(int p1, int p2, int p3, int p4)
{
	if (! IsSocket((SOCKETINFO *)p1, ST_DNS))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;
	return netclose(p1, p2, p3, p4);
}
EXPORT BOOL WINAPI dnserror(int *p1, int p2, int p3, int p4)
{
	if (! IsSocket((SOCKETINFO *)p1, ST_DNS))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;
	return neterror(p1, p2, p3, p4);
}
EXPORT BOOL WINAPI dnsfail(int p1, int p2, int p3, int p4)
{
	if (! IsSocket((SOCKETINFO *)p1, ST_DNS))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;
	return netfail(p1, p2, p3, p4);
}
