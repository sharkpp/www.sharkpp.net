// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include <windows.h>
#include <stdio.h>
#include "hspdll.h"
#include "common.h"

EXPORT BOOL WINAPI CreateDebugChannel(BMSCR *bm, char *p1, int p2, int p3);
EXPORT BOOL WINAPI GetCurrentLine(int *p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI BreakApp(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI ResumeApp(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI SetBreakPoint(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI GetBreakPoint(int *p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI DeleteBreakPoint(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI ClearBreakPoint(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI GetExceptionInfo(char *p1, int p2, int p3, char *refstr);


EXPORT BOOL WINAPI CreateDebugChannel(BMSCR *bm, char *p1, int p2, int p3)
{
	char mutexName[256];
	char shmemName[256];

	if (hMutex != NULL)
		return 1;

	strcpy(mutexName, MUTEX_HEAD);
	strcat(mutexName, p1);
	strcpy(shmemName, SHARED_MEMORY_HEAD);
	strcat(shmemName, p1);
	hMutex = CreateMutex(NULL, TRUE, mutexName);
	if (GetLastError() == ERROR_ALREADY_EXISTS) {
		ReleaseMutex(hMutex);
		CloseHandle(hMutex);
		return -2;
	}

	hMapping = CreateFileMapping((HANDLE)0xFFFFFFFF, NULL, PAGE_READWRITE,
		0, sizeof(DEBUGINFO), shmemName);
	if (hMapping == NULL) {
		ReleaseMutex(hMutex);
		CloseHandle(hMutex);
		return -3;
	}
	debuginfo = (LPDEBUGINFO)MapViewOfFile(hMapping, FILE_MAP_ALL_ACCESS, 0, 0, 0);
	if (debuginfo == NULL) {
		CloseHandle(hMapping);
		ReleaseMutex(hMutex);
		CloseHandle(hMutex);
		return -4;
	}

	memset(debuginfo, 0, sizeof(DEBUGINFO));
	debuginfo->current.script = -1;
	debuginfo->current.line = -1;
	debuginfo->bDebugging = TRUE;
	debuginfo->bRunning = TRUE;
	ReleaseMutex(hMutex);

	return 0;
}


EXPORT BOOL WINAPI GetCurrentLine(int *p1, int p2, int p3, int p4)
{
	p1[0] = -1; p1[1] = -1; p1[2] = -1;
	if (hMutex == NULL)
		return -1;
	WaitForSingleObject(hMutex, INFINITE);
	if (! debuginfo->bDebugging)	p1[0] = 2;
	else if (debuginfo->bException)	p1[0] = 3;
	else if (debuginfo->bRunning)	p1[0] = 0;
	else							p1[0] = 1;
	p1[1] = debuginfo->current.script;
	p1[2] = debuginfo->current.line;
	ReleaseMutex(hMutex);
	return 0;
}


EXPORT BOOL WINAPI BreakApp(int p1, int p2, int p3, int p4)
{
	if (hMutex == NULL)
		return -1;
	WaitForSingleObject(hMutex, INFINITE);
	debuginfo->bBreak = TRUE;
	ReleaseMutex(hMutex);
	return 0;
}


EXPORT BOOL WINAPI ResumeApp(int p1, int p2, int p3, int p4)
{
	if (hMutex == NULL)
		return -1;
	if (debuginfo->bRunning)
		return -2;
	WaitForSingleObject(hMutex, INFINITE);
	debuginfo->bRunning = TRUE;
	debuginfo->bResume = TRUE;
	ReleaseMutex(hMutex);
	return 0;
}


EXPORT BOOL WINAPI StepInApp(int p1, int p2, int p3, int p4)
{
	if (hMutex == NULL)
		return -1;
	if (debuginfo->bRunning)
		return -2;
	WaitForSingleObject(hMutex, INFINITE);
	debuginfo->bRunning = TRUE;
	debuginfo->bBreak = TRUE;
	debuginfo->bResume = TRUE;
	ReleaseMutex(hMutex);
	return 0;
}


EXPORT BOOL WINAPI SetBreakPoint(int p1, int p2, int p3, int p4)
{
	if (hMutex == NULL)
		return -1;
	if (p1 < 0 || p1 >= MAX_BREAKPOINTS)
		return -2;
	WaitForSingleObject(hMutex, INFINITE);
	if (p2 < 0 || p3 < 0) {
		debuginfo->bp[p1].enabled = FALSE;
	}
	else {
		debuginfo->bp[p1].enabled = TRUE;
		debuginfo->bp[p1].pos.script = p2;
		debuginfo->bp[p1].pos.line = p3;
	}
	ReleaseMutex(hMutex);
	return 0;
}


EXPORT BOOL WINAPI GetBreakPoint(int *p1, int p2, int p3, int p4)
{
	p1[0] = -1; p1[1] = -1; p1[2] = -1;
	if (hMutex == NULL)
		return -1;
	if (p2 < 0 || p2 >= MAX_BREAKPOINTS)
		return -2;
	WaitForSingleObject(hMutex, INFINITE);
	p1[0] = debuginfo->bp[p2].enabled;
	p1[1] = debuginfo->bp[p2].pos.script;
	p1[2] = debuginfo->bp[p2].pos.line;
	ReleaseMutex(hMutex);
	return 0;
}


EXPORT BOOL WINAPI FindBreakPoint(int *p1, int p2, int p3, int p4)
{
	*p1 = -1;
	if (hMutex == NULL)
		return -1;

	BOOL bFindFree = p2<0 || p3<0;

	int i;
	WaitForSingleObject(hMutex, INFINITE);
	for(i=0; i<MAX_BREAKPOINTS; i++) {
		if (bFindFree) {
			if (! debuginfo->bp[i].enabled) {
				*p1 = i;
				break;
			}
		}
		else {
			if (debuginfo->bp[i].enabled &&
				debuginfo->bp[i].pos.script == p2 &&
				debuginfo->bp[i].pos.line == p3 ) {
				*p1 = i;
				break;
			}
		}
	}
	ReleaseMutex(hMutex);
	return 0;
}


EXPORT BOOL WINAPI DeleteBreakPoint(int p1, int p2, int p3, int p4)
{
	return SetBreakPoint(p1, -1, -1, p4);
}


EXPORT BOOL WINAPI ClearBreakPoint(int p1, int p2, int p3, int p4)
{
	int i;
	if (hMutex == NULL)
		return -1;
	WaitForSingleObject(hMutex, INFINITE);
	for(i=0; i<MAX_BREAKPOINTS; i++)
		debuginfo->bp[i].enabled = FALSE;
	ReleaseMutex(hMutex);
	return 0;
}



EXPORT BOOL WINAPI GetExceptionInfo(char *p1, int p2, int p3, char *refstr)
{
	if (hMutex == NULL)
		return -1;
	if (! debuginfo->bException)
		return -2;

	char exceptionName[64];

	WaitForSingleObject(hMutex, INFINITE);

	switch(debuginfo->de.u.Exception.ExceptionRecord.ExceptionCode) {
	case EXCEPTION_ACCESS_VIOLATION:
		strcpy(exceptionName, "Access Violation");
		break;
	case EXCEPTION_IN_PAGE_ERROR:
		strcpy(exceptionName, "Page Error");
		break;
	case EXCEPTION_INT_DIVIDE_BY_ZERO:
		strcpy(exceptionName, "Divide By Zero");
		break;
	case EXCEPTION_INT_OVERFLOW:
		strcpy(exceptionName, "Overflow");
		break;
	case EXCEPTION_STACK_OVERFLOW:
		strcpy(exceptionName, "Stack Overflow");
		break;
	default:
		strcpy(exceptionName, "General Exception");
		break;
	}

//	char s[16];
//	strcpy(refstr, _itoa((int)debuginfo->de.u.Exception.ExceptionRecord.ExceptionAddress, s, 16));
	sprintf(refstr, "0x%08x", (int)debuginfo->de.u.Exception.ExceptionRecord.ExceptionAddress);

	ReleaseMutex(hMutex);
	
	strcpy(p1, exceptionName);
	return 0;
}





