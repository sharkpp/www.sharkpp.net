/* static char *miscdlg_id = 
	"@(#)Copyright (C) H.Shirouzu 2005-2006   miscdlg.h	Ver1.40"; */
/* ========================================================================
	Project  Name			: Fast/Force copy file and directory
	Create					: 2005-01-23(Sun)
	Update					: 2006-03-26(Sun)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef MISCDLG_H
#define MISCDLG_H
#include "tlib.h"
#include "resource.h"
#include "cfg.h"

class TAboutDlg : public TDlg {
public:
	TAboutDlg(TWin *_parent = NULL);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvCreate(LPARAM lParam);
};

class TExecConfirmDlg : public TDlg {
	const void		*src;
	const void		*dst;
	const void		*title;
	Cfg				*cfg;
	FastCopy::Info	*info;
	BOOL			isShellExt;

public:
	TExecConfirmDlg(FastCopy::Info *_info, Cfg *_cfg, TWin *_parent, const void *_title=NULL, BOOL _isShellExt=FALSE) : TDlg(_info->mode == FastCopy::DELETE_MODE ? DELCONFIRM_DIALOG : COPYCONFIRM_DIALOG, _parent), cfg(_cfg), info(_info), title(_title), isShellExt(_isShellExt) {}
	int Exec(const void *_src, const void *_dst=NULL);
	virtual BOOL	EvCreate(LPARAM lParam);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hWndCtl);
};

class TSetupDlg : public TDlg {
	Cfg		*cfg;
public:
	TSetupDlg(Cfg *_cfg, TWin *_parent = NULL);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvCreate(LPARAM lParam);
	virtual BOOL	EventScroll(UINT uMsg, int Code, int nPos, HWND hwndScrollBar);

};

class ShellExt {
	HMODULE	hShellExtDll;

public:
	ShellExt() { hShellExtDll = NULL; }
	~ShellExt() { if (hShellExtDll) UnLoad(); }
	BOOL	Load(char *parent_dir, char *dll_name);
	BOOL	UnLoad(void);
	BOOL	Status(void) { return	hShellExtDll ? TRUE : FALSE; }
	HRESULT	(WINAPI *RegisterDllProc)(void);
	HRESULT	(WINAPI *UnRegisterDllProc)(void);
	BOOL	(WINAPI *IsRegisterDllProc)(void);
	BOOL	(WINAPI *SetMenuFlagsProc)(int);
	int		(WINAPI *GetMenuFlagsProc)(void);
	BOOL	(WINAPI *UpdateDllProc)(void);
};

class TShellExtDlg : public TDlg {
	Cfg			*cfg;
	ShellExt	shellExt;

public:
	TShellExtDlg(Cfg *_cfg, TWin *_parent = NULL);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvCreate(LPARAM lParam);
	virtual BOOL	EvNcDestroy(void);

	BOOL	RegisterShellExt(BOOL is_register);
	BOOL	ReflectStatus(void);
};

BOOL UpdateShellExt(Cfg *);
HWND ShowHelp(HWND hOwner, LPCSTR help_dir, LPCSTR help_file, LPCSTR section=NULL);

#define SHEXT_RIGHT_COPY	0x00000001
#define SHEXT_RIGHT_DELETE	0x00000002
#define SHEXT_DD_COPY		0x00000010
#define SHEXT_DD_MOVE		0x00000020
#define SHEXT_SUBMENU_RIGHT	0x00001000
#define SHEXT_SUBMENU_DD	0x00002000
#define SHEXT_SUBMENU_SEP	0x00004000


enum	DirFileMode { DIRSELECT, RELOAD, FILESELECT, SELECT_EXIT };

class TBrowseDirDlgV : public TSubClass
{
public:
	DirFileMode mode;

protected:
	void		*fileBuf;
	IMalloc		*iMalloc;
	BROWSEINFO	brInfo;		// W version �Ƃ̍��́A�����|�C���^�n�����o�̌^�̈Ⴂ�̂�
	int			flg;

public:
	TBrowseDirDlgV(void *title, void *_fileBuf, int _flg, TWin *parentWin);
	virtual ~TBrowseDirDlgV();
	virtual BOOL	CreateByWnd(HWND _hWnd);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	SetFileBuf(LPARAM list);
	virtual BOOL	Exec();
	DirFileMode GetMode(void) { return mode; };
	BOOL	GetParentDirV(void *srcfile, void *dir);
	static int CALLBACK BrowseDirDlg_Proc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM data);
};

#define BRDIR_QUOTE			0x0001
#define BRDIR_VQUOTE		0x0002
#define BRDIR_BACKSLASH		0x0004
#define BRDIR_FILESELECT	0x0008
BOOL BrowseDirDlgV(TWin *parentWin, UINT editCtl, void *title, int flg=0);

class TInputDlgV : public TDlg
{
protected:
	void	*dirBuf;

public:
	TInputDlgV(void *_dirBuf, TWin *_win) : TDlg(INPUT_DIALOG, _win) { dirBuf = _dirBuf; }
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
};

#define OFDLG_DIRSELECT		0x0001
class TOpenFileDlg : public TSubClass {
public:
	enum	OpenMode { OPEN, MULTI_OPEN, SAVE, NODEREF_SAVE };
	int		flg;
	DirFileMode mode;

protected:
	TWin			*parent;
	LPOFNHOOKPROC	hook;
	OpenMode		openMode;

public:
	TOpenFileDlg(TWin *_parent, OpenMode _openMode=OPEN, int _flg=0, LPOFNHOOKPROC _hook=NULL) { parent = _parent; hook = _hook; openMode = _openMode; flg = _flg; }

	static UINT_PTR WINAPI OpenFileDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam);
	virtual BOOL CreateByWnd(HWND _hWnd);
	virtual BOOL EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL Exec(void *target, void *title=NULL, void *filter=NULL, void *defaultDir=NULL);
	virtual BOOL Exec(UINT editCtl, void *title=NULL, void *filter=NULL, void *defaultDir=NULL);

	DirFileMode GetMode(void) { return mode; };
};

class TJobDlg : public TDlg {
	Cfg		*cfg;

public:
	TJobDlg(Cfg *cfg, TWin *_parent = NULL);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvCreate(LPARAM lParam);
	BOOL AddJob();
	BOOL DelJob();
};

class TMsgBox : public TDlg {
protected:
	void	*msg;
	void 	*title;
	UINT	style;
	BOOL	isExecV;

public:
	TMsgBox(TWin *_parent);
	~TMsgBox();

	virtual BOOL EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL EvCreate(LPARAM lParam);
	virtual UINT ExecV(void *_msg, void *_title=L"Error", UINT _style=MB_OK);
	virtual UINT Exec(char *_msg, char *_title="Error", UINT _style=MB_OK);
};

int SetSpeedLevelLabel(TDlg *dlg, int level=-1);

#endif
