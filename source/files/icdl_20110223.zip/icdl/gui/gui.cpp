/**
 * @file  gui.cpp
 * @brief IC�J�[�h�Ƌ��ؓǂݎ��N���Xgui�T���v��
 *
 * Copyright(c) 2011 sharkpp<webmaster@sharkpp.net> All rights reserved.
 * 
 * The MIT License
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * �ȉ��ɎQ�l�Ƃ��� The MIT License �̓��{���𕹋L���܂����A�Еz�����Ƃ��ẮA
 * ��L�����ɏ]���Ă��������B
 * 
 * The MIT License
 * 
 * �ȉ��ɒ�߂�����ɏ]���A�{�\�t�g�E�F�A����ъ֘A�����̃t�@�C��
 * �i�ȉ��u�\�t�g�E�F�A�v�j�̕������擾���邷�ׂĂ̐l�ɑ΂��A�\�t�g�E�F�A��
 * �������Ɉ������Ƃ𖳏��ŋ����܂��B����ɂ́A�\�t�g�E�F�A�̕������g�p�A
 * ���ʁA�ύX�A�����A�f�ځA�Еz�A�T�u���C�Z���X�A�����/�܂��͔̔����錠���A
 * ����у\�t�g�E�F�A��񋟂��鑊��ɓ������Ƃ������錠�����������Ɋ܂܂�
 * �܂��B
 * 
 * ��L�̒��쌠�\������і{�����\�����A�\�t�g�E�F�A�̂��ׂĂ̕����܂��͏d�v
 * �ȕ����ɋL�ڂ�����̂Ƃ��܂��B
 * 
 * �\�t�g�E�F�A�́u����̂܂܁v�ŁA�����ł��邩�Öقł��邩���킸�A�����
 * �ۏ؂��Ȃ��񋟂���܂��B�����ł����ۏ؂Ƃ́A���i���A����̖ړI�ւ̓K�����A
 * ����ь�����N�Q�ɂ��Ă̕ۏ؂��܂݂܂����A����Ɍ��肳�����̂ł͂���
 * �܂���B��҂܂��͒��쌠�҂́A�_��s�ׁA�s�@�s�ׁA�܂��͂���ȊO�ł��낤
 * �ƁA�\�t�g�E�F�A�ɋN���܂��͊֘A���A���邢�̓\�t�g�E�F�A�̎g�p�܂��͂���
 * ���̈����ɂ���Đ������؂̐����A���Q�A���̑��̋`���ɂ��ĉ���̐ӔC��
 * ����Ȃ����̂Ƃ��܂��B 
 */

#include "stdafx.h"
#include <windowsx.h>
#include <winscard.h>
#include <stdarg.h>
#include <libicdlc/icdl.hpp>
#include <libicdlc/scard.hpp>
#include "gui.h"


#include <libopenjpeg/openjpeg.h>

#include <jbig2dec/jbig2.h>
#include <jbig2dec/jbig2_mmr.h>

#pragma comment(lib, "winscard.lib")

#ifdef _DEBUG
#pragma comment(lib,"dist/LibOpenJPEGd.lib")
#else
#pragma comment(lib,"dist/LibOpenJPEG.lib")
#endif

#define ComboBox_AddString2(hwnd, text, data) \
	ComboBox_SetItemData(hwnd, ComboBox_AddString(hwnd, text), (DWORD_PTR)(data))

#define MAX_LOADSTRING 100


HINSTANCE g_hInst = NULL;
TCHAR szTitle[MAX_LOADSTRING];

typedef struct {
	HWND	hwnd;
	HDC		hdc;
	HBITMAP	hbmp;
	RECT	rc;
	RECT	rcCanvas;
	icdl	reader;
} ICDL_CONTEXT;


INT_PTR CALLBACK    DlgProc(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp);
bool LoadICDL(ICDL_CONTEXT * ctx, LPCTSTR lpszCardReader, WORD pin1, WORD pin2);
void DrawICDL(ICDL_CONTEXT * ctx);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                       HINSTANCE hPrevInstance,
                       LPTSTR    lpCmdLine,
                       int       /*nCmdShow*/)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	g_hInst = hInstance;

	MSG msg;


	LoadString(g_hInst, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);

	HWND hDlg = CreateDialog(g_hInst, MAKEINTRESOURCE(IDD_MAIN_DLG), NULL, DlgProc);


	while (GetMessage(&msg, NULL, 0, 0))
	{
		if( !::IsDialogMessage(hDlg, &msg) )
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}

typedef struct SCardReadersListupCB {
	HWND hCombobox;
	SCardReadersListupCB(HWND hwnd)
		: hCombobox(hwnd)
	{}
	bool operator ()(LPCTSTR lpszReaderName) {
		ComboBox_AddString2(hCombobox, lpszReaderName, ComboBox_GetCount(hCombobox));
		return true;
	}
} SCardReadersListupCB;

INT_PTR CALLBACK DlgProc(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp)
{
	static ICDL_CONTEXT context = {};

	switch( msg )
	{
	case WM_INITDIALOG: {
		context.hwnd = hDlg;
		FORWARD_WM_COMMAND(hDlg, IDC_SCARD_READER_LIST,
		                   NULL, CBN_SELCHANGE, ::SendMessage);
		Edit_LimitText(GetDlgItem(hDlg, IDC_PIN1), 4);
		Edit_LimitText(GetDlgItem(hDlg, IDC_PIN2), 4);
		return (INT_PTR)TRUE; }

	case WM_DESTROY:
		DeleteObject((HBITMAP)SelectObject(context.hdc, context.hbmp));
		DeleteDC(context.hdc);
		PostQuitMessage(0);
		break;

	case WM_COMMAND:

		switch(GET_WM_COMMAND_ID(wp, lp))
		{
		case IDOK:
		case IDCANCEL:

			::DestroyWindow(hDlg);
			break;

		case IDC_SCARD_CONNECT: {
			HWND hCombo  = GetDlgItem(hDlg, IDC_SCARD_READER_LIST);
			int  nCurSel = ComboBox_GetCurSel(hCombo);
			bool bReload = false;
			if( 0 <= nCurSel &&
				-1 != (int)ComboBox_GetItemData(hCombo, nCurSel) )
			{
				TCHAR szReaderName[256];
				ComboBox_GetText(hCombo, szReaderName, _countof(szReaderName));
				WORD pin1 = (WORD)GetDlgItemInt(hDlg, IDC_PIN1, NULL, TRUE) % 10000;
				WORD pin2 = (WORD)GetDlgItemInt(hDlg, IDC_PIN2, NULL, TRUE) % 10000;
				if( GetWindowTextLength(GetDlgItem(hDlg, IDC_PIN1)) &&
					GetWindowTextLength(GetDlgItem(hDlg, IDC_PIN2)) )
				{
					if( LoadICDL(&context, szReaderName, pin1, pin2) ) {
						RECT rc;
						GetClientRect(hDlg, &rc);
						SendMessage(hDlg, WM_SIZE, 0, MAKELPARAM(rc.right - rc.left, rc.bottom - rc.top));
					} else {
						bReload = true;
					}
				} else {
					MessageBox(hDlg, _T("�Ïؔԍ�����͂��Ă�������"), _T(""), MB_OK);
				}
			} else {
				bReload = true;
			}
			if( bReload ) {
				ComboBox_SetCurSel(hCombo, ComboBox_GetCount(hCombo) - 1);
				FORWARD_WM_COMMAND(hDlg, IDC_SCARD_READER_LIST,
								   NULL, CBN_SELCHANGE, ::SendMessage);
			}
			break; }

		case IDC_SCARD_READER_LIST: {
			HWND hCombo = GetDlgItem(hDlg, IDC_SCARD_READER_LIST);
			switch(GET_WM_COMMAND_CMD(wp, lp))
			{
			case CBN_SELCHANGE:
				if( !ComboBox_GetCount(hCombo) ||
					-1 == (int)ComboBox_GetItemData(hCombo, ComboBox_GetCurSel(hCombo)) )
				{
					LONG lr = NO_ERROR;
					ComboBox_ResetContent(hCombo);
					if( !scard::enumeration(SCardReadersListupCB(hCombo), true, &lr) )
					{
						switch( lr )
						{
						case SCARD_E_NO_SERVICE:
							ComboBox_AddString2(hCombo, _T("ERROR:�X�}�[�g�J�[�h�T�[�r�X��~"), -1);
							break;
						case SCARD_E_NO_READERS_AVAILABLE:
							ComboBox_AddString2(hCombo, _T("ERROR:�J�[�h���[�_���ڑ�"), -1);
							break;
						case SCARD_W_REMOVED_CARD:
							ComboBox_AddString2(hCombo, _T("ERROR:�J�[�h��ڐG"), -1);
							break;
						case SCARD_W_UNRESPONSIVE_CARD:
							ComboBox_AddString2(hCombo, _T("ERROR:�J�[�h������"), -1);
							break;
						default: {
							TCHAR tmp[256];
#if defined(__STDC_LIB_EXT1__) || defined(__STDC_SECURE_LIB__)
							_stprintf_s(tmp, _T("ERROR:���̑�(0x%08X)"), lr);
#else
							_stprintf(tmp, _T("ERROR:���̑�(0x%08X)"), lr);
#endif
							ComboBox_AddString2(hCombo, tmp, -1);
							break; }
						}
					}
					ComboBox_AddString2(hCombo, _T("-- �ēǂݍ��� --"), -1);
					ComboBox_SetCurSel(hCombo, 0);
				}
				break;
			}
			break; }
		}

		return (INT_PTR)TRUE;

	case WM_PAINT: {
		PAINTSTRUCT ps;
		BeginPaint(hDlg, &ps);
		SetStretchBltMode(ps.hdc, HALFTONE);
		StretchBlt(ps.hdc, context.rc.left, context.rc.top, context.rc.right - context.rc.left, context.rc.bottom - context.rc.top,
					context.hdc, 0, 0, context.rcCanvas.right - context.rcCanvas.left, context.rcCanvas.bottom - context.rcCanvas.top, SRCCOPY);
		EndPaint(hDlg, &ps);
		return (INT_PTR)TRUE; }

	case WM_SIZE: {
		SIZE sz = { LOWORD(lp), HIWORD(lp) };
		HWND hCtrl = GetDlgItem(hDlg, IDC_ICDL_IMAGE);
		GetWindowRect(hCtrl, &context.rc);
		ScreenToClient(hDlg, (LPPOINT)&context.rc);
		context.rc.right = sz.cx - context.rc.left;
		context.rc.bottom= sz.cy - context.rc.left;
		SetWindowPos(hCtrl, NULL, context.rc.left, context.rc.top,
						context.rc.right - context.rc.left, context.rc.bottom - context.rc.top, SWP_NOZORDER);
		DrawICDL(&context);
		InvalidateRect(hDlg, NULL, FALSE);
		return (INT_PTR)TRUE; }
	}

	return (INT_PTR)FALSE;
}

void icdl_draw_text(ICDL_CONTEXT * ctx, HDC hdc, const RECT & rect, int font_size, LPCTSTR format, ...)
{
	TCHAR buff[4096];
	RECT  rc = rect;
	HFONT hOldFont = NULL;
	int   length;

	va_list args;
	va_start(args, format);
#if defined(__STDC_LIB_EXT1__) || defined(__STDC_SECURE_LIB__)
	length = _vsntprintf_s(buff, _countof(buff), format, args);
#else
	length = _vsntprintf(buff, _countof(buff), format, args);
#endif
	va_end(args);

	for(int i = 0,w = 0; i < font_size ; --w, ++i)
	{
		RECT rc_ = { 0, 0, 1000, 100 };
		DeleteObject(hOldFont);
		hOldFont = (HFONT)SelectObject(hdc, CreateFont(
				-font_size, w, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
				OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, font_size < 18 ? CLEARTYPE_QUALITY : ANTIALIASED_QUALITY, DEFAULT_PITCH,
				_T("�l�r �o�S�V�b�N")
			));
		DrawText(hdc, buff, length, &rc_, DT_CALCRECT|DT_NOPREFIX);
		if( rc_.right - rc_.left < rect.right - rect.left ) {
			break;
		}
		if( !w ) {
			w = font_size;
		}
	}

	for(TCHAR * pa = buff, *pb; *pa; pa = pb)
	{
		SIZE sz;
		if( '\n' == (BYTE)pa[0] )
		{
			pb = pa + 1;
			GetTextExtentPoint32(hdc, _T("##"), lstrlen(_T("##")), &sz);
			rc.top += sz.cy;
			rc.left = rect.left;
			continue;
		}

		else if( 0xFF == (BYTE)pa[0] && 0xF0 == ((BYTE)pa[1] & 0xF0) )
		{
			pb = pa + 2;
			GetTextExtentPoint32(hdc, _T("##"), lstrlen(_T("##")), &sz);
			ICDL_EUDC_TYPE eudc = ctx->reader.get_eudc(((BYTE)pa[1] & 0x0F) - 1);
			if( eudc.data ) {
				HDC hdc2 = CreateCompatibleDC(hdc);
				HBITMAP hbmp = (HBITMAP)SelectObject(hdc2, icdl_eudc_to_bitmap(eudc.data, eudc.length, eudc.size));
				SetStretchBltMode(hdc, HALFTONE);
				StretchBlt(hdc, rc.left, rc.top, sz.cx, sz.cy, hdc2, 0, 0, eudc.size, eudc.size, SRCCOPY);
				DeleteObject(SelectObject(hdc2, hbmp));
				DeleteDC(hdc2);
			}
		}
		else
		{
			pb = CharNext(pa);
			size_t len = size_t(pb - pa);
			GetTextExtentPoint32(hdc, pa, len, &sz);
			DrawText(hdc, pa, len, &rc, DT_SINGLELINE|DT_NOPREFIX);
		}
		rc.left += sz.cx;
	}

	DeleteObject(SelectObject(hdc, hOldFont));
}

bool LoadICDL(ICDL_CONTEXT * ctx, LPCTSTR lpszCardReader, WORD pin1, WORD pin2)
{
	if( !ctx->reader.connect(lpszCardReader) ) 
	{
		MessageBox(NULL, _T("�J�[�h�ւ̐ڑ��Ɏ��s���܂���"), _T(""), MB_OK);
		return false;
	}

	if( !ctx->reader.pin_auth(pin1, pin2) )
	{
		TCHAR tmp[128];
		::wsprintf(tmp, _T("�Ïؔԍ��̔F�؂Ɏ��s���܂���\n�Ïؔԍ����m�F���Ă�������\n�c���:PIN1=%d��,PIN2=%d��")
			, ctx->reader.get_pin1_auth_rest()
			, ctx->reader.get_pin2_auth_rest());
		MessageBox(NULL, tmp, _T(""), MB_OK);
		return false;
	}
	return true;
}

void rgb2rect(HBITMAP hbmp, RECT * rect)
{
	BITMAP  bmp;
	GetObject(hbmp, sizeof(bmp), &bmp);

	for(int i = 0; i < 0x100; i++) {
		::SetRect(rect + i, bmp.bmWidth, bmp.bmHeight, 0, 0);
	}

	LPBYTE p = (LPBYTE)bmp.bmBits + (bmp.bmHeight - 1) * bmp.bmWidthBytes;
	for(int y = 0; y < bmp.bmHeight; y++, p-=bmp.bmWidth+bmp.bmWidthBytes) {
		for(int x = 0; x < bmp.bmWidth; x++, p++)
		{
			int index = (int)*p - 128;
			if( 0 <= index ) {
				if( x < rect[index].left ) {
					if( rect[index].right ) {
						rect[index].right= rect[index].left;
						rect[index].left = x;
					} else {
						rect[index].left = x;
						rect[index].right= 1;
					}
				} else if( rect[index].right <= x ) {
					rect[index].right = x;
				}
				if( y < rect[index].top ) {
					if( rect[index].bottom ) {
						rect[index].bottom= rect[index].top;
						rect[index].top   = y;
					} else {
						rect[index].top = y;
						rect[index].bottom = 1;
					}
				} else if( rect[index].bottom <= y ) {
					rect[index].bottom = y;
				}
				*p = 78;
			}
		}
	}
}

void DrawICDL(ICDL_CONTEXT * ctx)
{
	const static TCHAR* ERA_TEXT[] = {
			_T("�s��"), _T("����"), _T("�吳"), _T("���a"), _T("����"), _T("RFU"), _T("RFU"), _T("RFU")
		};

	if( !ctx->reader.connected() ) {
		return;
	}

	HBITMAP hBmp = (HBITMAP)LoadImage(g_hInst, MAKEINTRESOURCE(IDB_BASE), IMAGE_BITMAP, 0, 0,
										LR_VGACOLOR|LR_CREATEDIBSECTION);
	BITMAP  bmp;
	GetObject(hBmp, sizeof(bmp), &bmp);
	//
	RECT rc[0x100];
	rgb2rect(hBmp, rc);
	//
	ctx->rc.right -= ctx->rc.left;
	ctx->rc.bottom-= ctx->rc.top;
	ctx->rc.right  = ctx->rc.right >= ctx->rc.bottom ? ctx->rc.right
	                                                 : (bmp.bmWidth >= bmp.bmHeight ? (ctx->rc.bottom * bmp.bmHeight + bmp.bmWidth - 1) / bmp.bmWidth
	                                                                                : (ctx->rc.bottom * bmp.bmWidth  + bmp.bmHeight- 1) / bmp.bmHeight);
	ctx->rc.bottom = ctx->rc.right <  ctx->rc.bottom ? ctx->rc.bottom
	                                                 : (bmp.bmWidth >= bmp.bmHeight ? (ctx->rc.right * bmp.bmHeight + bmp.bmWidth - 1) / bmp.bmWidth
	                                                                                : (ctx->rc.right * bmp.bmWidth  + bmp.bmHeight- 1) / bmp.bmHeight);
	ctx->rc.right += ctx->rc.left;
	ctx->rc.bottom+= ctx->rc.top;
	ctx->rcCanvas.left   = 0;
	ctx->rcCanvas.top    = 0;
	ctx->rcCanvas.right  = bmp.bmWidth;
	ctx->rcCanvas.bottom = bmp.bmHeight;

	if( ctx->hdc ) {
		DeleteObject((HBITMAP)SelectObject(ctx->hdc, ctx->hbmp));
		DeleteDC(ctx->hdc);
	}
	HDC hdc = GetDC(ctx->hwnd);
	ctx->hdc  = CreateCompatibleDC(hdc);
	ctx->hbmp = (HBITMAP)SelectObject(ctx->hdc, CreateCompatibleBitmap(hdc, ctx->rcCanvas.right - ctx->rcCanvas.left,
	                                                                        ctx->rcCanvas.bottom - ctx->rcCanvas.top));
	ReleaseDC(ctx->hwnd, hdc);
	hdc = CreateCompatibleDC(ctx->hdc);

	hBmp = (HBITMAP)SelectObject(hdc, hBmp);
	SetStretchBltMode(ctx->hdc, HALFTONE);
	StretchBlt(ctx->hdc, 0, 0, ctx->rcCanvas.right - ctx->rcCanvas.left, ctx->rcCanvas.bottom - ctx->rcCanvas.top,
				hdc, 0, 0, bmp.bmWidth, bmp.bmHeight, SRCCOPY);
	DeleteObject(SelectObject(hdc, hBmp));
	DeleteDC(hdc);
	int    nMode = ::SetBkMode(ctx->hdc, TRANSPARENT);
	HBRUSH hbr   = (HBRUSH)::SelectObject(ctx->hdc, ::GetStockObject(NULL_BRUSH));
	HPEN   hpen  = (HPEN)  ::SelectObject(ctx->hdc, ::CreatePen(PS_SOLID, 12, RGB(0,0,0)));

	int i = 0;

	TCHAR buff[256] = {};
	for(TCHAR * pa = (TCHAR*)ctx->reader.get_name(), *pb, *pc = buff; *pa; pa = pb) {
		if( 0xFF == (BYTE)pa[0] && 0xF0 == ((BYTE)pa[1] & 0xF0) ) {
			pb = pa + 2;
		} else {
			pb = CharNext(pa);
		}
		if( buff < pc ) {
			lstrcat(pc, _T("�@"));
			pc = CharNext(pc);
		}
		for(; pa < pb; ++pa, ++pc)
			*pc = *pa;
	}
	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),    buff);                                                                    i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),    ERA_TEXT[ctx->reader.get_birthday().era_id - ERA_ID_UNKNOWN]);            i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%2d"),   ctx->reader.get_birthday().year);                                         i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%2d"),   ctx->reader.get_birthday().month);                                        i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%2d"),   ctx->reader.get_birthday().day);                                          i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),    ctx->reader.get_registered_domicile());                                   i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),    ctx->reader.get_domicile());                                              i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),    ERA_TEXT[ctx->reader.get_issue_date().era_id - ERA_ID_UNKNOWN]);          i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"),  ctx->reader.get_issue_date().year);                                       i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"),  ctx->reader.get_issue_date().month);                                      i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"),  ctx->reader.get_issue_date().day);                                        i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%d"),    ctx->reader.get_reference_number());                                      i++;

	     if( !lstrcmp(ctx->reader.get_license_color(), _T("�D��")) ) { SetBkColor(ctx->hdc, RGB(218,161, 48)); }
	else if( !lstrcmp(ctx->reader.get_license_color(), _T("�V�K")) ) { SetBkColor(ctx->hdc, RGB(115,255, 66)); }
	else                                                             { SetBkColor(ctx->hdc, RGB(  0,192,255)); }
	ExtTextOut(ctx->hdc, rc[i].left, rc[i].top, ETO_OPAQUE, &rc[i], _T(""), 0, NULL);
	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T(" %s%02d�N%02d��%02d���܂ŗL��")
	                                                                     , ERA_TEXT[ctx->reader.get_expiration_date().era_id - ERA_ID_UNKNOWN]
	                                                                     , ctx->reader.get_expiration_date().year
	                                                                     , ctx->reader.get_expiration_date().month
	                                                                     , ctx->reader.get_expiration_date().day);                                       i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),   ctx->reader.get_license_requirement1());                                  i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),   ctx->reader.get_license_requirement2());                                  i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),   ctx->reader.get_license_requirement3());                                  i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),   ctx->reader.get_license_requirement4());                                  i++;

	if( !lstrcmp(ctx->reader.get_license_color(), _T("�D��")) ) {
		::InflateRect(&rc[i], -6, -6);
		::RoundRect(ctx->hdc, rc[i].left, rc[i].top, rc[i].right, rc[i].bottom, 30, 30);
		::InflateRect(&rc[i], -7, -7);
		icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),   ctx->reader.get_license_color());                                      i++;
	} else {
		i++;
	}

	icdl_draw_text(ctx, ctx->hdc, rc[i], (rc[i].bottom - rc[i].top) * 12 / 10, _T("%lld"), ctx->reader.get_license_number());                                        i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),   ERA_TEXT[ctx->reader.get_license_date_motorcycle_or_small_or_moped().era_id - ERA_ID_UNKNOWN]); i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_motorcycle_or_small_or_moped().year);        i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_motorcycle_or_small_or_moped().month);       i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_motorcycle_or_small_or_moped().day);         i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),   ERA_TEXT[ctx->reader.get_license_date_misc().era_id - ERA_ID_UNKNOWN]);   i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_misc().year);                                i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_misc().month);                               i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_misc().day);                                 i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%s"),   ERA_TEXT[ctx->reader.get_license_date_class_2().era_id - ERA_ID_UNKNOWN]);i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_class_2().year);                             i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_class_2().month);                            i++;

	icdl_draw_text(ctx, ctx->hdc, rc[i], rc[i].bottom - rc[i].top, _T("%02d"), ctx->reader.get_license_date_class_2().day);                              i++;

#define has_license(type, value) \
	if( value.year != 0 ) { \
		icdl_draw_text(ctx, ctx->hdc, rc[i], (rc[i].right - rc[i].left) * (lstrlen(type) <= lstrlen(_T(" �@\n �@")) ? 8 : 6) / 10, _T("%s"), type); i++; \
	} else { \
		icdl_draw_text(ctx, ctx->hdc, rc[i], (rc[i].right - rc[i].left) * 6 / 10, _T("%s"), _T("\n �|")); i++; \
	}

	has_license(_T(" ��\n �^"),      ctx->reader.get_license_date_large_sized_motor_vehicle()                );
	has_license(_T(" ��\n �t"),      ctx->reader.get_license_date_moped()                                    );
	has_license(_T(" ��\n �^"),      ctx->reader.get_license_date_midsize_motor_vehicle()                    );
	has_license(_T(" ��\n ��"),      ctx->reader.get_license_date_towing()                                   );
	has_license(_T(" ��\n ��"),      ctx->reader.get_license_date_motor_vehicle()                            );
	has_license(_T(" ��\n ��"),      ctx->reader.get_license_date_class_2_large_sized_motor_vehicle()        );
	has_license(_T(" ��\n ��"),      ctx->reader.get_license_date_large_sized_special_motor_vehicle()        );
	has_license(_T(" ��\n ��"),      ctx->reader.get_license_date_class_2_midsize_motor_vehicle()            );
	has_license(_T(" ��\n ��\n ��"), ctx->reader.get_license_date_large_sized_motorcycle()                   );
	has_license(_T(" ��\n ��"),      ctx->reader.get_license_date_class_2_motor_vehicle()                    );
	has_license(_T(" ��\n ��\n ��"), ctx->reader.get_license_date_motorcycle()                               );
	has_license(_T(" ��\n ��\n ��"), ctx->reader.get_license_date_class_2_large_sized_special_motor_vehicle());
	has_license(_T(" ��\n ��") ,     ctx->reader.get_license_date_small_sized_special_motor_vehicle()        );
	has_license(_T(" ��\n ��\n ��"), ctx->reader.get_license_date_class_2_towing()                           );

	if( ctx->reader.get_photo_length() )
	{
		HBITMAP hbmp = icdl_photo_to_bitmap(ctx->reader.get_photo(), ctx->reader.get_photo_length());
		if( hbmp ) {
			BITMAP bmp;
			::GetObject(hbmp, sizeof(bmp), &bmp);
			hdc = ::CreateCompatibleDC(ctx->hdc);
			HBITMAP hBmp = (HBITMAP)::SelectObject(hdc, hbmp);
			::SetStretchBltMode(ctx->hdc, HALFTONE);
			::StretchBlt(ctx->hdc, rc[i].left, rc[i].top, rc[i].right - rc[i].left, rc[i].bottom - rc[i].top, hdc, 0, 0, bmp.bmWidth, bmp.bmHeight, SRCCOPY);
			::DeleteObject(::SelectObject(hdc, hBmp));
			::DeleteDC(hdc);
		}
	}

	::SelectObject(ctx->hdc, hbr);
	::SelectObject(ctx->hdc, hpen);
	::SetBkMode(ctx->hdc, nMode);
}

