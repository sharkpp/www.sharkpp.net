<?php

/**
 * this file has been translated by: westup
 */

return array(

// files
'File' => '文件',
'Size' => '大小',
'Permissions' => '权限',
'Change mode' => '改变模式',
'Remove file' => '移除文件',
'Create new file' => '创建新文件',
'Create new directory' => '建立新目录',
'Upload file' => '上传文件',
'overwrite it?'=> '覆盖?',
'rename' => '重命名',
'rename icon' => '重命名图标',
'remove' => '删除图标',

'File :name has been created with success!' => '文件 <strong>:名称</strong>创建成功!',
'Directory is not writable! File has not been saved!' => '该目录不可写. 文件没有被保存',
'File :name has been created!' => '文件 <strong>:名称</strong> 已创建!',
'File :name has not been created!' => '文件 <strong>:名称</strong> 还没有被创建!',
'Directory :name has been created!' => '目录 <strong>:名称</strong> 已创建!',
'Directory :name has not been created!' => '目录 <strong>:名称</strong> 还没有被创建!',
'File :name has been deleted with success!' => '文件 <strong>:名称</strong> 已成功删除!',
'File :name has not been deleted!' => '文件<strong>:名称</strong> 还没有被删除!',
'Directory :name has been deleted with success!' => '目录 <strong>:名称</strong> 已成功删除!',
'Directory :name has not been deleted!' => '目录 <strong>:名称</strong> 还没有被删除!',
'File :name has been uploaded with success!' => '文件 <strong>:名称</strong> 上传成功!',
'File has not been uploaded!' => '文件没有被上传!',
'Permissions of file has been changed!' => '文件权限已更改!',
'Permissions of directory has been changed!' => '目录权限已更改!',
'Change mode has not been done!' => '改变模式还没完成!',
'File or directory not found!' => '没有发现文件和目录!',

);