<?php

/**
 * this file has been translated by: Shark++
 */

return array(

// Trackbacks
'Trackback has been approved!' => 'トラックバックが承認されました。',
'Trackback has been deleted!' => 'トラックバックが削除されました。',
'Trackback has been saved!' => 'トラックバックが保存されました。',
'Trackback has been unapproved!' => 'トラックバックが拒絶されました。',
'Trackback has not been deleted!' => 'トラックバックは削除されていません。',
'Trackback has not been saved!' => 'トラックバックは保存されていません。',
'Trackback not found!' => 'トラックバックが見つかりません。',
'trackback not found!' => 'トラックバックが見つかりません。',
'Edit trackback' => 'トラックバックの編集',
'Body' => '本文',
'Title' => 'タイトル',
'Excerpt' => '抜粋',
'Blog name' => 'ブログ名',
//'Save' => '保存して終了',
'or' => 'か',
'Cancel' => 'キャンセル',
'Trackbacks' => 'トラックバック',
'Modify' => '変更',
'Are you sure you wish to delete it?' => '本当にこれを削除しようとしていますか？',
'Delete' => '削除',
'Reject' => '排除',
'Approve' => '承認',
'No trackbacks found.' => 'トラックバックは在りません。',
'none' => 'なし',
'Open' => '開く',
'Closed' => '閉じる',

);