//  written by sharkpp.

typedef unsigned char byte;
typedef unsigned int  uint32_t;
