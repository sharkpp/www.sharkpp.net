<?php

Plugin::setInfos(array(
    'id'          => 'import',
    'title'       => 'Importer', 
    'description' => 'Import plugin.', 
    'version'     => '1.0', 
    'website'     => 'http://www.sharkpp.net/')
);

Plugin::addController('import', 'Import');

