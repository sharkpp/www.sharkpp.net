/* static char *fastcopy_id = 
	"@(#)Copyright (C) H.Shirouzu 2004-2006   mainwin.h	Ver1.55"; */
/* ========================================================================
	Project  Name			: Fast Copy file and directory
	Create					: 2004-09-15(Wed)
	Update					: 2007-02-06(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#ifndef FASTCOPY_H
#define FASTCOPY_H

#include "fastcopy.h"
#include "cfg.h"
#include "miscdlg.h"

#define FASTCOPY			"FastCopy"
#define FASTCOPY_CLASS		"fastcopy_class"
#define WM_FASTCOPY_MSG		(WM_USER + 100)
#define WM_FASTCOPY_NOTIFY	(WM_USER + 101)
#define WM_FASTCOPY_HIDDEN	(WM_USER + 102)
#define FASTCOPY_TIMER		100
#define FASTCOPY_NIM_ID		100

#define FASTCOPYLOG_MUTEX	"FastCopyLogMutex"

#define MAX_HISTORY_BUF		8192
#define MAX_HISTORY_CHAR_BUF (MAX_HISTORY_BUF * 4)

#define SHELLEXT_MIN_ALLOC		(16 * 1024)
#define SHELLEXT_MAX_ALLOC		(4 * 1024 * 1024)

struct CopyInfo {
	UINT				resId;
	char				*list_str;
	UINT				cmdline_resId;
	void				*cmdline_name;
	FastCopy::Mode		mode;
	FastCopy::OverWrite	overWrite;
};

class TConfirmDlg : public TDlg {
	BOOL		allow_continue;
	const char	*message;
public:
	TConfirmDlg(UINT _resId=CONFIRM_DIALOG) : TDlg(_resId) {}
	int Exec(const char *_message, BOOL _allow_continue, TWin *_parent);
	virtual BOOL	EvCreate(LPARAM lParam);
};

struct DlgItem {
	HWND	hWnd;
	WINPOS	wpos;
};

#define MAX_NORMAL_FASTCOPY_ICON	4
#define FCNORMAL_ICON_INDEX			0
#define FCWAIT_ICON_INDEX			MAX_NORMAL_FASTCOPY_ICON
#define MAX_FASTCOPY_ICON			MAX_NORMAL_FASTCOPY_ICON + 1

class TMainDlg : public TDlg {
protected:
	FastCopy	fastCopy;
	FastCopy::Info	info;
	Cfg			cfg;
	HICON		hMainIcon[MAX_FASTCOPY_ICON];
	enum AutoCloseLevel { NO_CLOSE, NOERR_CLOSE, FORCE_CLOSE } autoCloseLevel;
	enum { NORMAL_EXEC=1, LISTING_EXEC=2, CMDLINE_EXEC=4 };
	BOOL		isTaskTray;
	BOOL		isAutoSlow;

	RECT		orgRect;
	enum {	srcbutton_item=0, dstbutton_item, srccombo_item, dstcombo_item,
			status_item, mode_item, bufstatic_item, bufedit_item, help_item,
			ignore_item, estimate_item, top_item, list_item, ok_item, atonce_item,
			autoslow_item, autoslowstatic_item, samedrv_item, incstatic_item, 
			excstatic_item, inccombo_item, exccombo_item, filter_item, 
			path_item, errstatic_item, errstatus_item, erredit_item, max_dlgitem };
	DlgItem		dlgItems[max_dlgitem];

	int			miniHeight;
	int			normalHeight;
	UINT		timerID;
	BOOL		noConfirmDel;
	UINT		curIconIndex;
	UINT		TaskBarCreateMsg;
	SYSTEMTIME	startTm;
	DWORD		endTick;
	UINT		diskMode;
	BOOL		isRegExp;
	BOOL		isShellExt;
	BOOL		isNetPlaceSrc;
	BOOL		isErrEditHide;
	BOOL		isDelay;
	int			skipEmptyDir;
	int			forceStart;
	int			listBufOffset;
	int			errBufOffset;
	BOOL		isErrLog;
	char		*pathLogBuf;
	HANDLE		hErrLogFile;
	HANDLE		hErrLogMutex;
	TransInfo	ti;

// for detect autoslow status
	DWORD		timerCnt;
	POINT		curPt;
	HWND		curForeWnd;

	TAboutDlg		aboutDlg;
	TSetupDlg		setupDlg;
	TShellExtDlg	shellExtDlg;
	TJobDlg			jobDlg;

protected:
	BOOL	MoveCenter(BOOL isShow);
	BOOL	SetupWindow();
	BOOL	ExecCopy(DWORD exec_flags);
	BOOL	ExecCopyCore(void);
	BOOL	EndCopy(void);
	BOOL	CancelCopy(void);
	void	SetItemEnable(BOOL is_delete);
	FastCopy::Mode	GetCopyMode(void);
	void	ReflectFilterCheck(BOOL is_invert=FALSE);
	void	SetDlgItem(UINT ctl_id, DlgItem *item);
	void	SetSize(void);
	void	UpdateMenu();
	void	SetJob(int idx);
	BOOL	IsListing() { return (info.flags & FastCopy::LISTING_ONLY) ? TRUE : FALSE; }

public:
	TMainDlg();
	virtual ~TMainDlg();

	virtual BOOL	EvCreate(LPARAM lParam);
	virtual BOOL	EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl);
	virtual BOOL	EvNcDestroy(void);
	virtual BOOL	EvTimer(WPARAM timerID, TIMERPROC proc);
	virtual BOOL	EvSysCommand(WPARAM uCmdType, POINTS pos);
	virtual BOOL	EvSize(UINT fwSizeType, WORD nWidth, WORD nHeight);
	virtual BOOL	EvDropFiles(HDROP hDrop);
/*
	virtual BOOL	EvEndSession(BOOL nSession, BOOL nLogOut);
	virtual BOOL	EvQueryOpen(void);
	virtual BOOL	EvHotKey(int hotKey);
	virtual BOOL	EventButton(UINT uMsg, int nHitTest, POINTS pos);
	virtual BOOL	EventInitMenu(UINT uMsg, HMENU hMenu, UINT uPos, BOOL fSystemMenu);
*/
	virtual BOOL	EventUser(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual void	Show(int mode = SW_SHOWDEFAULT);

	BOOL	EnableLogFile(BOOL on);
	BOOL	CommandLineExecV(int argc, void **argv);
	BOOL	SetMiniWindow(void);
	BOOL	SetNormalWindow(void);
	void	RefreshWindow(BOOL is_start_stop=FALSE);
	BOOL	SetWindowTitle(char *fmt,...);
	BOOL	IsDestDropFiles(HDROP hDrop);
	BOOL	SetInfo(BOOL is_task_tray=FALSE, BOOL is_finish_status=FALSE);
	void	SetHistory(int *item, void ***history);
	void	SetPathHistory(void);
	void	SetFilterHistory(void);
	BOOL	TaskTray(int nimMode, HICON hSetIcon=NULL, LPCSTR tip=NULL);
};

class TFastCopyApp : public TApp {
public:
	TFastCopyApp(HINSTANCE _hI, LPSTR _cmdLine, int _nCmdShow);
	virtual ~TFastCopyApp();

	virtual void	InitWindow(void);
};

const char *GetVersionStr(void);
void DBGWrite(char *fmt,...);

#endif

