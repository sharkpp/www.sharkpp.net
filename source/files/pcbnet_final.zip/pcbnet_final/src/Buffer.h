// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

// Buffer.h: CBuffer �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BUFFER_H__4D7E5AB1_7FEE_471C_A155_691F68C0CA78__INCLUDED_)
#define AFX_BUFFER_H__4D7E5AB1_7FEE_471C_A155_691F68C0CA78__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>

class CBuffer  
{
protected:
	struct BinData {
		int len;
		char *pt;
		BinData *next;
	};
public:
	int Peek(LPVOID buf, int nMax);
	CBuffer();
	virtual ~CBuffer();
	BOOL Write(LPVOID pt, int len);
	BOOL WriteDirect(LPVOID pt, int len);
	int Read(LPVOID buf, int nMax);
	int Count();
	int GetNextLength();
	BOOL Destroy();

protected:
	int m_read;
	BinData *m_pFirst;
	BinData **m_ppLast;
	int m_length;
};

#endif // !defined(AFX_BUFFER_H__4D7E5AB1_7FEE_471C_A155_691F68C0CA78__INCLUDED_)
