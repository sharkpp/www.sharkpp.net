// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include <windows.h>
#include "hspdll.h"
#include "hspparam.h"

CHSPParam::CHSPParam(HSPEXINFO *_hei)
{
	hei = _hei;
	strsize = hei->strsize;
	refstr = hei->refstr;
	stmp = hei->stmp;
}

CHSPParam::~CHSPParam()
{
	unsigned int i;
	for(i=0; i<garbage.size(); i++) {
		delete [] garbage[i];
	}
	garbage.clear();
}

int CHSPParam::getdi(int def)
{
	return hei->HspFunc_prm_getdi(def);
}

int CHSPParam::geti()
{
	return hei->HspFunc_prm_geti();
}

void * CHSPParam::getv()
{
	return (void *)hei->HspFunc_prm_getv();
}

char * CHSPParam::getds(char *def)
{
	char *p, *q;
	int len;

	p = hei->HspFunc_prm_getds(def);
	if (p != NULL) {
		len = strlen(p);
		q = new char[len+1];
		strcpy(q, p);
		garbage.push_back(q);
	}
	else {
		q = NULL;
	}
	return q;
}

char * CHSPParam::gets()
{
	char *p, *q;
	int len;

	p = hei->HspFunc_prm_gets();
	if (p != NULL) {
		len = strlen(p);
		q = new char[len+1];
		strcpy(q, p);
		garbage.push_back(q);
	}
	else {
		q = NULL;
	}
	return q;
}

PVAL2 * CHSPParam::getpval()
{
	return *hei->pval;
}

int CHSPParam::realloc(PVAL2 *pv, int size, int mode)
{
	return hei->HspFunc_val_realloc(pv, size, mode);
}

int CHSPParam::fread(char *fname, void *readmem, int rlen, int seekofs)
{
	return hei->HspFunc_fread(fname, readmem, rlen, seekofs);
}

int CHSPParam::fsize(char *fname)
{
	return hei->HspFunc_fsize(fname);
}

BMSCR * CHSPParam::getbmscr(int wid)
{
	return (BMSCR *)hei->HspFunc_getbmscr(wid);
}

int CHSPParam::getobj(int wid, int id, HSPOBJINFO *inf)
{
	return hei->HspFunc_getobj(wid, id, inf);
}

int CHSPParam::setobj(int wid, int id, HSPOBJINFO *inf)
{
	return hei->HspFunc_setobj(wid, id, inf);
}

int CHSPParam::nexttype()
{
	return *hei->nptype;
}

int CHSPParam::geterr()
{
	return *hei->er;
}

int CHSPParam::getwid()
{
	return *hei->actscr;
}

int CHSPParam::getsize(PVAL2 *pv)
{
	int iSize;
	int i;
	
	iSize = 1;
	for(i=0; i<5; i++) {
		if (pv->len[i] == 0)
			break;
		iSize *= pv->len[i];
	}
	if (pv->flag == 4)
		iSize *= sizeof(int);
	return iSize;
}
