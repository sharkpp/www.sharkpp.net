<h1><?php echo __('Edit trackback'); ?></h1>

<form action="<?php echo get_url('plugin/trackback/edit/'.$trackback->id); ?>" method="post">
  <div class="form-area">
    <p class="content">
      <label for="trackback_title"><?php echo __('Title'); ?></label>
      <input class="textarea" type="text" cols="40" id="trackback_title" name="trackback[title]" style="width: 100%" onkeydown="return allowTab(event, this);" value="<?php echo htmlentities($trackback->title, ENT_COMPAT, 'UTF-8'); ?>" />
    </p>
    <p class="content">
      <label for="trackback_url"><?php echo __('Url'); ?></label>
      <input class="textarea" type="text" cols="40" id="trackback_url" name="trackback[url]" style="width: 100%" onkeydown="return allowTab(event, this);" value="<?php echo htmlentities($trackback->url, ENT_COMPAT, 'UTF-8'); ?>" />
    </p>
    <p class="content">
      <label for="trackback_excerpt"><?php echo __('Excerpt'); ?></label>
      <textarea class="textarea" cols="40" id="trackback_excerpt" name="trackback[excerpt]" rows="20" style="width: 100%" onkeydown="return allowTab(event, this);"><?php echo htmlentities($trackback->excerpt, ENT_COMPAT, 'UTF-8'); ?></textarea>
    </p>
    <p class="content">
      <label for="trackback_blog_name"><?php echo __('Blog name'); ?></label>
      <input class="textarea" type="text" cols="40" id="trackback_blog_name" name="trackback[blog_name]" style="width: 100%" onkeydown="return allowTab(event, this);" value="<?php echo htmlentities($trackback->blog_name, ENT_COMPAT, 'UTF-8'); ?>" />
    </p>
  </div>
  <p class="buttons">
    <input class="button" name="commit" type="submit" accesskey="s" value="<?php echo __('Save'); ?>" />
    <?php echo __('or'); ?> <a href="<?php echo get_url('plugin/trackback'); ?>"><?php echo __('Cancel'); ?></a>
  </p>
</form>
