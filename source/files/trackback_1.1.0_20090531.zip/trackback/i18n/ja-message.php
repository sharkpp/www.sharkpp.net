<?php

/*******************************************************************************
  The MIT License

  Copyright (c) 2008-2009 Shark++ Software.

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

 ==============================================================================
  参考として The MIT License の日本語訳を下記に併記しますが、頒布条件としては、
  上記原文に従ってください。
 ==============================================================================

  The MIT License

  Copyright (c) 2008-2009 Shark++ Software.

  以下に定める条件に従い、本ソフトウェアおよび関連文書のファイル
  （以下「ソフトウェア」）の複製を取得するすべての人に対し、ソフトウェアを
  無制限に扱うことを無償で許可します。これには、ソフトウェアの複製を使用、
  複写、変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、
  およびソフトウェアを提供する相手に同じことを許可する権利も無制限に含まれ
  ます。

  上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要
  な部分に記載するものとします。

  ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの
  保証もなく提供されます。ここでいう保証とは、商品性、特定の目的への適合性、
  および権利非侵害についての保証も含みますが、それに限定されるものではあり
  ません。作者または著作権者は、契約行為、不法行為、またはそれ以外であろう
  と、ソフトウェアに起因または関連し、あるいはソフトウェアの使用またはその
  他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も
  負わないものとします。 
 *******************************************************************************/

/**
 * this file has been translated by: Shark++
 */

return array(
	'"Yes" to choose the back of the truck and received approval to open automatically.' => '「はい」を選ぶと受信したトラックバックに対しての公開承認を自動的に行います。',
	'Approve' => '承認',
	'Are you sure you wish to delete it?' => '本当にこれを削除しようとしていますか？',
	'Auto approve' => '自動承認',
	'Blog name' => 'ブログ名',
	'Date' => '日付',
	'Default status id' => '初期ステータス',
	'Delete' => '削除',
	'Documentation' => 'ドキュメント',
	'Edit' => '編集',
	'Excerpt' => '抜粋',
	'First' => '先頭',
	'From' => '送信元',
	'Last' => '末尾',
	'Moderation' => '承認待ち',
	'Modify' => '変更',
	'Next' => '次',
	'No trackbacks found for moderation.' => '承認待ちのトラックバックが見つかりません。',
	'Open' => '開く',
	'Page' => 'ページ',
	'Ping title' => 'ピングタイトル',
	'Prev' => '前',
	'Reject' => '排除',
	'Settings' => '設定',
	'Spam block keyword' => 'スパム防止キーワード',
	'Specify the number of trackbacks per page in the backend.' => 'バックエンドで１ページに表示するトラックバックの数を指定します。',
	'Specify use blog title in the trackback ping. In the blank here and use the administration title.' => 'トラックバックピングで送信するタイトルを指定します。空欄にすると管理画面のタイトルを使用します。',
	'The key word to add to track back URL and to defend from the track back spam simply is specified.' => 'トラックバックURLに追加してトラックバックスパムから簡易に防御するためのキーワードを指定します。',
	'The trackback status is specified in the early adding the page.' => 'ページの追加時の初期トラックバックステータスを指定します。',
	'Trackback and Ping plugin for Frog CMS' => 'トラックバック・ピング プラグイン for Frog CMS',
	'Trackback has been approved!' => 'トラックバックが承認されました。',
	'Trackback has been deleted!' => 'トラックバックが削除されました。',
	'Trackback has been unapproved!' => 'トラックバックが拒絶されました。',
	'Trackback not found!' => 'トラックバックが見つかりません。',
	'Trackbacks' => 'トラックバック',
	'Trackbacks per page' => 'ページ毎のトラックバック数',
	'or' => 'か',
	'Invalid setting value.' => 'おかしな設定項目の値です',
	'Please specify one or more for a number of track backs of each pages.' => 'ページ毎のトラックバック数には1以上を指定してください。',
	'The state is displayed in the tab' => 'タブに状態を表示',
	'When "Yes" is chosen, the number of the track back and approval waiting is displayed in the tab.' => '「はい」を選ぶとトラックバックと承認待ちの数をタブに表示します。',
	);
