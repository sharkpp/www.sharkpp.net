// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

EXPORT BOOL WINAPI isip(BMSCR *bm, char *p1, int p2, int p3);
EXPORT BOOL WINAPI getip(char *p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netclose(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI neterror(int *p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netfail(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netipv6(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI issocket(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netstrict(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netsilent(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netbuffer(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI tcpconf(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netextra(void *p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netinit(int p1, int p2, int p3, int p4);
EXPORT BOOL WINAPI netclear(int p1, int p2, int p3, int p4);









