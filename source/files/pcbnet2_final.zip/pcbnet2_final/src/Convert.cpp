// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"

#define isbase64(x) ( ((x)>='A' && (x)<='Z') || ((x)>='a' && (x)<='z') || ((x)>='0' && (x)<='9') || (x)=='+' || (x)=='/' || (x)=='=' )

EXPORT BOOL WINAPI xtoyl(int *p1, int p2, int p3, int p4)
{
	*p1 = (int)htonl((u_long)p2);
	return 0;
}

EXPORT BOOL WINAPI xtoys(int *p1, int p2, int p3, int p4)
{
	*p1 = (int)htons((u_short)p2);
	return 0;
}



EXPORT BOOL WINAPI checksum(char *p1, int p2, int p3, int p4)
{
	int cs;

	cs = (int)CheckSum(p1, p2);
	return -cs;
}

EXPORT BOOL WINAPI md5(char *p1, int p2, int p3, char *refstr)
{
	refstr[0] = '\0';

	static MD5_CTX context;
	static BOOL bCont = FALSE;
	unsigned char digest[16];

	if (! bCont)
		MD5Init(&context);

	if (p2 != 0)
		MD5Update(&context, (unsigned char *)p1, p2);

	if (p3 == 0) {
		MD5Final(digest, &context);

		sprintf(refstr,
			"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
			(int)digest[0], (int)digest[1], (int)digest[2], (int)digest[3], 
			(int)digest[4], (int)digest[5], (int)digest[6], (int)digest[7], 
			(int)digest[8], (int)digest[9], (int)digest[10], (int)digest[11], 
			(int)digest[12], (int)digest[13], (int)digest[14], (int)digest[15]);
	}
	else {
		bCont = TRUE;
	}
	return 0;
}

EXPORT BOOL WINAPI enbase64(HSPEXINFO *hei, int _p1, int _p2, int _p3)
{
	CHSPParam prm(hei);
	char *p1, *p2;
	int p3;
	int i, len;
	const char *tbl1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

	p1 = (char *)prm.getv();
	p2 = (char *)prm.getv();
	p3 = prm.getdi(0);
	if (prm.geterr()) return prm.geterr();

	len = p3;

	for(i=0; i<len/3; i++) {
		p1[i*4+0] = tbl1[(((unsigned int)p2[i*3+0])>>2) & 63];
		p1[i*4+1] = tbl1[(((unsigned int)p2[i*3+0])<<4 | ((unsigned int)p2[i*3+1])>>4) & 63];
		p1[i*4+2] = tbl1[(((unsigned int)p2[i*3+1])<<2 | ((unsigned int)p2[i*3+2])>>6) & 63];
		p1[i*4+3] = tbl1[((unsigned int)p2[i*3+2]) & 63];
	}
	if (len%3 == 1) {
		p1[i*4+0] = tbl1[(((unsigned int)p2[i*3+0])>>2) & 63];
		p1[i*4+1] = tbl1[(((unsigned int)p2[i*3+0])<<4 | ((unsigned int)p2[i*3+1])>>4) & 63];
		p1[i*4+2] = tbl1[64];
		p1[i*4+3] = tbl1[64];
		i++;
	}
	if (len%3 == 2) {
		p1[i*4+0] = tbl1[(((unsigned int)p2[i*3+0])>>2) & 63];
		p1[i*4+1] = tbl1[(((unsigned int)p2[i*3+0])<<4 | ((unsigned int)p2[i*3+1])>>4) & 63];
		p1[i*4+2] = tbl1[(((unsigned int)p2[i*3+1])<<2 | ((unsigned int)p2[i*3+2])>>6) & 63];
		p1[i*4+3] = tbl1[64];
		i++;
	}
	p1[i*4] = '\0';

	return -(int)strlen(p1);
}

EXPORT BOOL WINAPI debase64(HSPEXINFO *hei, int _p1, int _p2, int _p3)
{
	CHSPParam prm(hei);
	char *p1, *p2;

	int i, len;
	const unsigned int tbl2[] = {
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	62,	-1,	-1,	-1,	63,
		52,	53,	54,	55,	56,	57,	58,	59,	60,	61,	-1,	-1,	-1,	0,	-1,	-1,
		-1,	0,	1,	2,	3,	4,	5,	6,	7,	8,	9,	10,	11,	12,	13,	14,
		15,	16,	17,	18,	19,	20,	21,	22,	23,	24,	25,	-1,	-1,	-1,	-1,	-1,
		-1,	26, 27,	28,	29,	30,	31,	32,	33,	34,	35,	36,	37,	38,	39,	40,
		41,	42,	43,	44,	45,	46,	47,	48,	49,	50,	51,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
		-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,
	};

	p1 = (char *)prm.getv();
	p2 = (char *)prm.getv();
	if (prm.geterr()) return prm.geterr();

	p1[0] = '\0';
	len = strlen(p2);

	if (len%4 != 0) return 0;
	for(i=0; i<len; i++)
		if (! isbase64(p2[i]))
			break;
	if (i < len)
		return 0;

	for(i=0; i<len/4; i++) {
		p1[i*3+0] = (char)(tbl2[(unsigned char)p2[i*4+0]]<<2 | tbl2[(unsigned char)p2[i*4+1]]>>4);
		p1[i*3+1] = (char)(tbl2[(unsigned char)p2[i*4+1]]<<4 | tbl2[(unsigned char)p2[i*4+2]]>>2);
		p1[i*3+2] = (char)(tbl2[(unsigned char)p2[i*4+2]]<<6 | tbl2[(unsigned char)p2[i*4+3]]);
	}
	p1[i*3] = '\0';

	return -(int)strlen(p1);
}