/* @(#)Copyright (C) H.Shirouzu 2005-2006   regexp.cpp	ver1.31 */
/* ========================================================================
	Project  Name			: Regular Expression / Wild Card Match Library
	Create					: 2005-11-03(The)
	Update					: 2006-01-31(Tue)
	Reference				: 
	======================================================================== */

typedef unsigned _int64	RegStates;

class RegExp {
public:
	RegExp();
	~RegExp();

	enum CaseSense { CASE_SENSE, CASE_INSENSE };

	void	Init();
	BOOL	RegistWildCard(const void *wild_str, CaseSense cs=CASE_SENSE);
//	BOOL	RegistRegStr(const void *reg_str, CaseSense cs=CASE_SENSE);
	BOOL	IsMatch(const void *target);
	BOOL	IsRegistered(void) { return	max_state ? TRUE : FALSE; }

protected:
	enum StatesType { NORMAL_TBL, REV_TBL, MAX_STATES_TBL };
	RegStates	**states_tbl[MAX_STATES_TBL];
	RegStates	(*epsilon_tbl)[BYTE_NUM];
	RegStates	end_states;
	int			max_state;

	void		AddRegStates(StatesType type, WCHAR ch, const RegStates &state_pattern);
	RegStates	GetRegStates(StatesType type, WCHAR ch);
	void		AddEpStates(int state, const RegStates &add_states);
	RegStates	GetEpStates(RegStates cur_states);
	inline void AddRegStatesEx(StatesType type, WCHAR ch, CaseSense cs);
};

