// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"

THREADLIST *pFirstThread = NULL;


LRESULT TCPProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, THREADINFO *ti)
{
	unsigned long uad=0;
	int i=0, len=0;
	char *buf=NULL;
	struct sockaddr_in addr;
	ACCEPTSTRUCT *acc=NULL;

	switch(msg) {
	case WM_CREATE:
		memset(&ti->tcp, 0, sizeof(ti->tcp));
			//	������
		ti->tcp.bAvailable = FALSE;
		ti->tcp.bBlocking = FALSE;
		ti->tcp.bShutting = FALSE;
		ti->tcp.r = new CBuffer;
		ti->tcp.s = new CBuffer;
		ti->tcp.incoming = FALSE;
		ti->soc = socket(PF_INET, SOCK_STREAM, 0);
		WSAAsyncSelect(ti->soc, hWnd, WM_ASYNC,
			FD_READ | FD_WRITE | FD_CONNECT | FD_ACCEPT | FD_CLOSE);
		i = iTCPSendBuf+1;
		setsockopt(ti->soc, SOL_SOCKET, SO_SNDBUF, (char *)&i, sizeof(int));
		i = iTCPRecvBuf;
		setsockopt(ti->soc, SOL_SOCKET, SO_RCVBUF, (char *)&i, sizeof(int));
		break;
	case WM_FATAL_CLOSE:
		ti->err = (int)wParam;
		ti->tcp.bAvailable = FALSE;
		if (ti->soc != NULL) {
			closesocket(ti->soc);
			ti->soc = NULL;
		}
		ti->tcp.r->Destroy();
		ti->tcp.s->Destroy();
		break;
	case WM_CONNECT:
		if (ti->tcp.bAvailable) return 1;
		ti->tcp.port = htons((unsigned short)wParam);
		uad = inet_addr((char *)lParam);
		if (uad == INADDR_NONE) {
			ti->hAsync = WSAAsyncGetHostByName(hWnd, WM_DNSREPLY, (char *)lParam, (char *)ti->ent, MAXGETHOSTSTRUCT);
		}
		else {
			ti->tcp.addr = uad;
			addr.sin_family = AF_INET;
			addr.sin_addr.s_addr = uad;
			addr.sin_port = ti->tcp.port;
			memset(&addr.sin_zero, 0, sizeof(addr.sin_zero));
			if (connect(ti->soc, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
				if (WSAGetLastError() != WSAEWOULDBLOCK)
					ti->err = WSAGetLastError();
			}
		}
		break;
	case WM_BIND:
		if (ti->tcp.bAvailable) return 1;
		addr.sin_addr.s_addr = gBindAddress;
		addr.sin_family = AF_INET;
		addr.sin_port = htons((unsigned short)wParam);
		memset(&addr.sin_zero, 0, sizeof(addr.sin_zero));
		if (bind(ti->soc, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR)
			return 1;
		listen(ti->soc, SOMAXCONN);
		ti->tcp.bAvailable = TRUE;
		ti->tcp.incoming = FALSE;
		break;
	case WM_ACCEPT:
		if (! ti->tcp.bAvailable) return 3;
		if (! ti->tcp.incoming) return 2;
		ti->tcp.incoming = FALSE;
		acc = (LPACCEPTSTRUCT)lParam;
		len = sizeof(acc->from);
		acc->soc = accept(ti->soc, (struct sockaddr *)&(acc->from), &len);
		if (acc->soc == INVALID_SOCKET)
			return 1;
		WSAAsyncSelect(acc->soc, hWnd, 0, 0);
		break;
	case WM_SOCKATTACH:
		if (ti->tcp.bAvailable) return 1;
		closesocket(ti->soc);
		ti->soc = (SOCKET)wParam;
		ti->tcp.bAvailable = TRUE;
		WSAAsyncSelect(ti->soc, hWnd, WM_ASYNC,
			FD_READ | FD_WRITE | FD_CONNECT | FD_ACCEPT | FD_CLOSE);
		i = iTCPSendBuf+1;
		setsockopt(ti->soc, SOL_SOCKET, SO_SNDBUF, (char *)&i, sizeof(int));
		i = iTCPRecvBuf;
		setsockopt(ti->soc, SOL_SOCKET, SO_RCVBUF, (char *)&i, sizeof(int));
		break;
	case WM_ASYNC:
		if (ti->err == WSAENOBUFS) break;
		if (ti->type == ST_TCPLISTEN && WSAGETSELECTERROR(lParam) == WSAECONNABORTED)
			break;	// backlog����ꂽ���ۂ�
		if (WSAGETSELECTERROR(lParam) != 0 && ti->err == 0) {
			ti->err = (int)WSAGETSELECTERROR(lParam);
			ti->tcp.bAvailable = FALSE;
			break;
		}
		if ((SOCKET)wParam != ti->soc) break;
		switch(WSAGETSELECTEVENT(lParam)) {
			case FD_READ:
				ioctlsocket(ti->soc, FIONREAD, (unsigned long *)&len);
				if (len > 0) {
					buf = new char[len];
					len = recv(ti->soc, buf, len, 0);
					if ((ti->tcp.r->Count() + len) > iMaxBuffer) {
						delete [] buf;
						TCPProc(hWnd, WM_FATAL_CLOSE, WSAENOBUFS, 0, ti);
					}
					else {
						ti->tcp.r->WriteDirect(buf, len);
					}
				}
				break;
			case FD_WRITE:
				ti->tcp.bBlocking = FALSE;
				TCPProc(hWnd, WM_SENDING, 0, 0, ti);
				break;
			case FD_CONNECT:
				ti->tcp.bAvailable = TRUE;
				break;
			case FD_CLOSE:
				if (ti->tcp.bShutting) {
					ti->err = WSAESHUTDOWN;
				}
				else {
					ti->err = WSAEDISCON;
				}
				break;
			case FD_ACCEPT:
				ti->tcp.incoming = TRUE;
				break;
		}
		break;
	case WM_DNSREPLY:
		if (ti->hAsync == NULL) break;
		ti->hAsync = NULL;
		if (ti->tcp.bAvailable) break;
		if (WSAGETASYNCERROR(lParam) != 0) {
			ti->err = WSAGETASYNCERROR(lParam);
			ti->tcp.bAvailable = FALSE;
			break;
		}
		ti->tcp.addr = *((unsigned long *)(ti->ent->h_addr_list[0]));
		if (isWildcardHost(ti->tcp.addr)) {
			ti->err = WSAHOST_NOT_FOUND;
			ti->tcp.bAvailable = FALSE;
			break;
		}
		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = ti->tcp.addr;
		addr.sin_port = ti->tcp.port;
		memset(&addr.sin_zero, 0, sizeof(addr.sin_zero));
		if (connect(ti->soc, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
			if (WSAGetLastError() != WSAEWOULDBLOCK)
				ti->err = WSAGetLastError();
		}
		break;
	case WM_SENDING:
		if (ti->tcp.bBlocking) return 1;
		i = iTCPSendBuf;
		buf = new char[i];
		while ( (len = ti->tcp.s->Peek(buf, i)) != 0 ) {
			len = send(ti->soc, buf, len, 0);
			if (len == SOCKET_ERROR) {
				if (WSAGetLastError() != WSAEWOULDBLOCK) {
					ti->err = WSAGetLastError();
					ti->tcp.bAvailable = FALSE;
				}
				else {
					ti->tcp.bBlocking = TRUE;
				}
				break;
			}
			ti->tcp.s->Read(NULL, len);
		}
		delete [] buf;
		if (len == 0 && (!ti->tcp.bBlocking) && ti->tcp.bShutting) {
			shutdown(ti->soc, SD_SEND);
			if (ti->err == WSAEDISCON)
				ti->err = WSAESHUTDOWN;
		}
		break;
	case WM_SOCKDESTROY:
		DestroyWindow(hWnd);
		break;
	case WM_CLOSE:
		break;
	case WM_DESTROY:
		delete ti->tcp.r;
		delete ti->tcp.s;
		return DefWindowProc(hWnd, msg, wParam, lParam);
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}


LRESULT UDPProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, THREADINFO *ti)
{
	int len=0;
	char *buf=NULL;
	struct sockaddr_in addr;
	int addrlen=0;

	switch(msg) {
	case WM_CREATE:
		memset(&ti->udp, 0, sizeof(ti->udp));
			//	������
		ti->udp.bBlocking = FALSE;
		ti->udp.addr = htonl(INADDR_NONE);
		ti->udp.port = htons(0);
		ti->udp.fromaddr = htonl(INADDR_NONE);
		ti->udp.port = htons(0);
		ti->udp.bBroadCast = FALSE;
		ti->udp.r = new CPacket;
		ti->udp.s = new CPacket;
		ti->soc = socket(PF_INET, SOCK_DGRAM, 0);
		WSAAsyncSelect(ti->soc, hWnd, WM_ASYNC,
			FD_READ | FD_WRITE | FD_CLOSE);
		break;
	case WM_FATAL_CLOSE:
		ti->err = (int)wParam;
		if (ti->soc != NULL) {
			closesocket(ti->soc);
			ti->soc = NULL;
		}
		ti->udp.r->Destroy();
		ti->udp.s->Destroy();
		break;
	case WM_BIND:
		addr.sin_addr.s_addr = gBindAddress;
		addr.sin_family = AF_INET;
		addr.sin_port = htons((unsigned short)wParam);
		memset(&addr.sin_zero, 0, sizeof(addr.sin_zero));
		addrlen = sizeof(addr);
		if (bind(ti->soc, (struct sockaddr *)&addr, addrlen) == SOCKET_ERROR)
			return 1;
		break;
	case WM_SENDTO:
		ti->udp.bBroadCast = FALSE;
		ti->udp.port = htons((unsigned short)wParam);
		ti->udp.addr = inet_addr((char *)lParam);
		if (ti->udp.addr == INADDR_NONE)
			ti->hAsync = WSAAsyncGetHostByName(hWnd, WM_DNSREPLY, (char *)lParam, (char *)ti->ent, MAXGETHOSTSTRUCT);
		break;
	case WM_ASYNC:
		if (ti->err == WSAENOBUFS) break;
		if (WSAGETSELECTERROR(lParam) != 0) {
			ti->err = (int)WSAGETSELECTERROR(lParam);
			break;
		}
		if ((SOCKET)wParam != ti->soc) break;
		switch(WSAGETSELECTEVENT(lParam)) {
			case FD_READ:
				ioctlsocket(ti->soc, FIONREAD, (unsigned long *)&len);
				if (len == 0)
					buf = new char[1];
				else
					buf = new char[len];
				addrlen = sizeof(addr);
				len = recvfrom(ti->soc, buf, len, 0, (struct sockaddr *)&addr, &addrlen);
				if (ti->udp.r->Count() + len > iMaxBuffer) {
					delete [] buf;
					UDPProc(hWnd, WM_FATAL_CLOSE, WSAENOBUFS, 0, ti);
				}
				else {
					ti->udp.r->WriteDirect(buf, &addr, len);
				}
				break;
			case FD_WRITE:
				ti->udp.bBlocking = FALSE;
				return UDPProc(hWnd, WM_SENDING, 0, 0, ti);
		}
		break;
	case WM_DNSREPLY:
		if (ti->hAsync == NULL) break;
		ti->hAsync = NULL;
		if (WSAGETASYNCERROR(lParam) != 0) {
			ti->udp.addr = htonl(INADDR_ERROR);
			break;
		}
		ti->udp.addr = *((unsigned long *)(ti->ent->h_addr_list[0]));
		if (isWildcardHost(ti->udp.addr)) {
			ti->udp.addr = htonl(INADDR_ERROR);
			break;
		}
		break;
	case WM_SENDING:
		if (ti->udp.bBlocking) return 1;
		while(ti->udp.s->CountPacket() > 0) {
			len = ti->udp.s->GetNextLength();
			if (len != 0)
				buf = new char[len];
			else
				buf = NULL;
			ti->udp.s->Read(buf, &addr, len);
			addrlen = sizeof(addr);
			if (sendto(ti->soc, buf, len, 0, (struct sockaddr *)&addr, addrlen) == SOCKET_ERROR) {
				if (WSAGetLastError() != WSAEWOULDBLOCK) {
					ti->err = WSAGetLastError();
					break;
				}
				ti->udp.bBlocking = TRUE;
				if (len != 0) delete [] buf;
				break;
			}
			if (len != 0) delete [] buf;
		}
		break;
	case WM_SOCKDESTROY:
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		delete ti->udp.s;
		delete ti->udp.r;
		return DefWindowProc(hWnd, msg, wParam, lParam);
	case WM_CLOSE:
		break;
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}


LRESULT DNSProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, THREADINFO *ti)
{
	unsigned long addr;

	switch(msg) {
	case WM_CREATE:
		memset(&ti->dns, 0, sizeof(ti->dns));
			//	������
		ti->dns.bReply = FALSE;
		ti->dns.addr = INADDR_NONE;
		break;
	case WM_DNSREQUEST:
		if (ti->dns.bReply || ti->hAsync != NULL) break;
			//	IP�A�h���X�Ȃ�hostbyaddr�A���̑��Ȃ�hostbyname�ɓn��
		if ( (ti->dns.addr = inet_addr((char *)lParam)) == INADDR_NONE) {
			ti->hAsync = WSAAsyncGetHostByName(hWnd, WM_DNSREPLY, (char *)lParam, (char *)ti->ent, MAXGETHOSTSTRUCT);
		}
		else {
			ti->hAsync = WSAAsyncGetHostByAddr(hWnd, WM_DNSREPLY, (char *)&ti->dns.addr, 4, AF_INET, (char *)ti->ent, MAXGETHOSTSTRUCT);
		}
		break;
	case WM_DNSREPLY:
		ti->hAsync = NULL;
		ti->dns.bReply = TRUE;
		if (WSAGETASYNCERROR(lParam) != 0) {
			ti->err = WSAGETASYNCERROR(lParam);
			break;
		}
		addr = *((unsigned long *)(ti->ent->h_addr_list[0]));
		if (isWildcardHost(addr)) {
			ti->err = WSAHOST_NOT_FOUND;
			break;
		}
		break;
	case WM_SOCKDESTROY:
		DestroyWindow(hWnd);
		break;
	case WM_CLOSE:
		break;
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}


LRESULT ICMPProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, THREADINFO *ti)
{
	struct sockaddr_in addr;
	int addrlen, i;
	char *buf;
	IPHEADER *ipheader;
	ICMPHEADER *icmpheader;
	unsigned long time;

	switch(msg) {
	case WM_CREATE:
		memset(&ti->icmp, 0, sizeof(ti->icmp));
			//	������
		ti->icmp.bReply = FALSE;
		ti->soc = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
		if (ti->soc == INVALID_SOCKET) return -1;
		WSAAsyncSelect(ti->soc, hWnd, WM_ASYNC, FD_READ);
		break;
	case WM_PINGTARGET:
		ti->icmp.dwTimeOut = (unsigned long)LOWORD(wParam);
		i = (int)HIWORD(wParam);
		setsockopt(ti->soc, IPPROTO_IP, IP_TTL, (char *)&i, sizeof(i));
		if ((ti->icmp.addr = inet_addr((char *)lParam)) == htonl(INADDR_NONE))
			ti->hAsync = WSAAsyncGetHostByName(hWnd, WM_DNSREPLY, (char *)lParam, (char *)ti->ent, MAXGETHOSTSTRUCT);
		else
			ICMPProc(hWnd, WM_SENDPING, 0, 0, ti);
		break;
	case WM_DNSREPLY:
		ti->hAsync = NULL;
		if (WSAGETASYNCERROR(lParam) != 0) {
			ti->err = WSAGETASYNCERROR(lParam);
			ti->icmp.replyfrom = htonl(INADDR_NONE);
			ti->icmp.bReply = TRUE;
			break;
		}
		ti->icmp.addr = *((unsigned long *)(ti->ent->h_addr_list[0]));
		if (isWildcardHost(ti->icmp.addr)) {
			ti->err = WSAHOST_NOT_FOUND;
			ti->icmp.replyfrom = htonl(INADDR_NONE);
			ti->icmp.bReply = TRUE;
			break;
		}
		ICMPProc(hWnd, WM_SENDPING, 0, 0, ti);
		break;
	case WM_SENDPING:
		ti->icmp.datasize = 32 - sizeof(ICMPHEADER);
		memset(&addr, 0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = ti->icmp.addr;
		icmpheader = (LPICMPHEADER)new char[sizeof(ICMPHEADER) + ti->icmp.datasize];
		icmpheader->Type = ICMP_ECHO;
		icmpheader->SubCode = 0;
		icmpheader->CheckSum = 0;
		icmpheader->ping.dwId = ti->icmp.dwUid = ((unsigned long)ti)^((unsigned long)GetTickCount());
		memset(icmpheader+1, 'x', ti->icmp.datasize);
		icmpheader->CheckSum = CheckSum((char *)icmpheader, sizeof(ICMPHEADER) + ti->icmp.datasize);
		time = GetTickCount();
		ti->icmp.dwSendTime = time;
		ti->icmp.dwReplyTime = time;
		sendto(ti->soc, (char *)icmpheader, sizeof(ICMPHEADER) + ti->icmp.datasize, 0,
				(struct sockaddr *)&addr, sizeof(addr));
		delete [] (char *)icmpheader;
		break;
	case WM_ICMPREPLY:
		if (ti->icmp.bReply) break;
		ti->icmp.dwReplyTime = GetTickCount();
		buf = new char[MAX_PACKET];
		memset(buf, 0, MAX_PACKET);
		addrlen = sizeof(addr);
		recvfrom(ti->soc, buf, MAX_PACKET, 0, (struct sockaddr *)&addr, &addrlen);
		ipheader = (LPIPHEADER)buf;
		icmpheader = (LPICMPHEADER)(buf + ipheader->headerlen*4);
		ti->icmp.replycode = icmpheader->Type;
		ti->icmp.replyfrom = ipheader->srcip;
		if (! SendMessage(hWnd, WM_TIMEOUT_CHECK, 0, 0)) {
			switch(icmpheader->Type) {
			case ICMP_REPLY:
				if (icmpheader->ping.dwId == ti->icmp.dwUid) {
					ti->icmp.bReply = TRUE;
					ti->icmp.ttl = ipheader->ttl;
				}
				break;
			case ICMP_UNREACHED:
			case ICMP_TTL:
				if ( ti->icmp.dwUid ==
					( (ICMPHEADER *) ( ((char *)icmpheader) + sizeof(ICMPHEADER) + sizeof(IPHEADER)))->ping.dwId) {
					ti->icmp.bReply = TRUE;
					ti->icmp.ttl = ((IPHEADER *)(icmpheader+1))->ttl;
				}
				break;
			}
		}
		delete [] buf;
		break;
	case WM_TIMEOUT_CHECK:
		if (ti->icmp.addr == htonl(INADDR_NONE))
			return FALSE;
		time = GetTickCount() - ti->icmp.dwSendTime;
		if (time > ti->icmp.dwTimeOut) {
			ti->icmp.replycode = 0;
			ti->icmp.dwReplyTime = GetTickCount();
			ti->icmp.bReply = TRUE;
			return TRUE;
		}
		return FALSE;
	case WM_ASYNC:
		if ((SOCKET)wParam != ti->soc) break;
		switch(WSAGETSELECTEVENT(lParam)) {
			case FD_READ:
				ICMPProc(hWnd, WM_ICMPREPLY, 0, 0, ti);
				break;
		}
		break;
	case WM_SOCKDESTROY:
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	case WM_CLOSE:
		break;
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}


#ifdef RAW_SUPPORT

LRESULT RAWProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam, THREADINFO *ti)
{
	int len;
	char *buf;
	struct sockaddr_in addr;
	int addrlen;
	int i;
	unsigned long uad;

	switch(msg) {
	case WM_CREATE:
		memset(&ti->raw, 0, sizeof(ti->raw));
			//	������
		ti->soc = socket(PF_INET, SOCK_RAW, IPPROTO_RAW);
		if (ti->soc == INVALID_SOCKET) return -1;
		ti->raw.r = new CPacket;
		ti->raw.s = new CPacket;
		i = 1;
		i = setsockopt(ti->soc, IPPROTO_IP, IP_HDRINCL, (char *)&i, sizeof(i));
		if (i != 0) return -1;
		WSAAsyncSelect(ti->soc, hWnd, WM_ASYNC,
			FD_READ | FD_WRITE | FD_CLOSE);
		break;
	case WM_FATAL_CLOSE:
		ti->err = (int)wParam;
		if (ti->soc != NULL) {
			closesocket(ti->soc);
			ti->soc = NULL;
		}
		ti->raw.r->Destroy();
		ti->raw.s->Destroy();
		break;
	case WM_BIND:
		addr.sin_addr.s_addr = gBindAddress;
		addr.sin_family = AF_INET;
		addr.sin_port = htons((unsigned short)wParam);
		memset(&addr.sin_zero, 0, sizeof(addr.sin_zero));
		addrlen = sizeof(addr);
		if (bind(ti->soc, (struct sockaddr *)&addr, addrlen) == SOCKET_ERROR)
			return 1;
		break;
	case WM_CONNECT:
		uad = (unsigned long)lParam;
		memset(&addr, 0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = uad;
		if (connect(ti->soc, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
			return 1;
		}
		break;
	case WM_ASYNC:
		if (WSAGETSELECTERROR(lParam) != 0) {
			ti->err = (int)WSAGETSELECTERROR(lParam);
			break;
		}
		if ((SOCKET)wParam != ti->soc) break;
		switch(WSAGETSELECTEVENT(lParam)) {
			case FD_READ:
				ioctlsocket(ti->soc, FIONREAD, (unsigned long *)&len);
				buf = new char[len];
				addrlen = sizeof(addr);
				len = recvfrom(ti->soc, buf, len, 0, (struct sockaddr *)&addr, &addrlen);
				if ((ti->raw.r->Count() + len) > iMaxBuffer) {
					delete [] buf;
					RAWProc(hWnd, WM_FATAL_CLOSE, WSAENOBUFS, 0, ti);
				}
				else {
					ti->raw.r->WriteDirect(buf, &addr, len);
				}
				break;
			case FD_WRITE:
				ti->raw.bBlocking = FALSE;
				return RAWProc(hWnd, WM_SENDING, 0, 0, ti);
		}
		break;
	case WM_SENDING:
		if (ti->raw.bBlocking) return 1;
		while(ti->raw.s->CountPacket() != 0) {
			len = ti->raw.s->GetNextLength();
			if (len != 0)
				buf = new char[len];
			else
				buf = NULL;
			ti->raw.s->Read(buf, &addr, len);
			addrlen = sizeof(addr);
			if (sendto(ti->soc, buf, len, 0, (struct sockaddr *)&addr, addrlen) == SOCKET_ERROR) {
				if (WSAGetLastError() != WSAEWOULDBLOCK) {
					ti->err = WSAGetLastError();
					break;
				}
				ti->raw.bBlocking = TRUE;
				if (len != 0) delete [] buf;
				break;
			}
			if (len != 0) delete [] buf;
		}
		break;
	case WM_SOCKDESTROY:
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		delete ti->raw.s;
		delete ti->raw.r;
		return DefWindowProc(hWnd, msg, wParam, lParam);
	case WM_CLOSE:
		break;
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}

#endif




LRESULT CALLBACK NetProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	THREADINFO *ti = (LPTHREADINFO)GetWindowLong(hWnd, GWL_USERDATA);
	if (ti != NULL) ti->Lock();

	if (msg == WM_CREATE && ti == NULL) {
		ti = (LPTHREADINFO)((LPCREATESTRUCT)lParam)->lpCreateParams;
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)ti);

		ti->Lock();
			//	�e�탁���o�ϐ��̏�����
		ti->hWnd = hWnd;
		ti->dwUser = 0;
			//	HOSTENT�\���̂̊m��
		ti->ent = (HOSTENT *)new char[MAXGETHOSTSTRUCT];
	}

	LRESULT lRes = 0;
	if (ti != NULL) {
		switch(ti->type) {
		case ST_TCP:
		case ST_TCPLISTEN:
			lRes = TCPProc(hWnd, msg, wParam, lParam, ti); break;
		case ST_UDP:
			lRes = UDPProc(hWnd, msg, wParam, lParam, ti); break;
		case ST_DNS:
			lRes = DNSProc(hWnd, msg, wParam, lParam, ti); break;
		case ST_PING:
			lRes = ICMPProc(hWnd, msg, wParam, lParam, ti); break;
#ifdef RAW_SUPPORT
		case ST_RAW:
			lRes = RAWProc(hWnd, msg, wParam, lParam, ti); break;
#endif
		default:
			lRes = DefWindowProc(hWnd, msg, wParam, lParam); break;
		}
	}
	else
		lRes = DefWindowProc(hWnd, msg, wParam, lParam);

	if (msg == WM_DESTROY) {
			//	soc,hAsync,ent�̓E�B���h�E�Ƌ��ɗL��B
		if (ti->soc != NULL)
			closesocket(ti->soc);
		if (ti->hAsync != NULL)
			WSACancelAsyncRequest(ti->hAsync);
		delete [] (char *)ti->ent;
		PostQuitMessage(0);
	}

	if (ti != NULL) ti->Unlock();
	return lRes;
}
