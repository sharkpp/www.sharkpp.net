// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <list>

using namespace std;

class Packet
{

protected:
	typedef struct {
		int len;
		struct sockaddr_storage addr;
		int addrlen;
		char *pt;
	} PacketData;

	typedef list<PacketData> PacketList;

	PacketList p;

public:
	Packet();
	virtual ~Packet();
	BOOL Write(LPVOID pt, int len, struct sockaddr *addr, int addrlen, BOOL bDirect=FALSE);
	int Read(LPVOID buf, struct sockaddr *addr, int *addrlen, int nMax);
	int Peek(LPVOID buf, struct sockaddr *addr, int *addrlen, int nMax);
	int GetNextLength();
	int Count();
	int Size();
	BOOL Destroy();
};
