<?php

/**
 * this file has been translated by: Shark++
 */

return array(

'Import' => 'インポート',
'Import file' => 'インポートファイル',
'What is this plugin?' => 'このプラグインは何をするの？',
'Import to Frog CMS from local files.' => 'Frog CMSへローカルファイルからインポートします。',

);