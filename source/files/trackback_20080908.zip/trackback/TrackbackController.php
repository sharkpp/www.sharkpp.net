<?php

class TrackbackController extends PluginController
{
    function __construct()
    {
        AuthUser::load();
        if ( ! AuthUser::isLoggedIn())
            redirect(get_url('login'));
        
        $this->setLayout('backend');
    }
    
    function index()
    {
        $this->display('trackback/views/index', array(
            'trackbacks' => Trackback::findAll()
        ));
    }
    
    function edit($id=null)
    {
        if (is_null($id))
            redirect(get_url('plugin/trackback'));
        
        if ( ! $trackback = Trackback::findById($id))
        {
            Flash::set('error', __('trackback not found!'));
            redirect(get_url('plugin/trackback'));
        }
        
        // �ۑ����悤�Ƃ��Ă��邩���ׂ�
        if (get_request_method() == 'POST')
            return $this->_edit($id);
        
        // �\��
        $this->display('trackback/views/edit', array(
            'action'  => 'edit',
            'trackback' => $trackback
        ));
    }
    
    function _edit($id)
    {
        $trackback = Record::findByIdFrom('trackback', $id);
        $trackback->setFromData($_POST['trackback']);
        
        if ( ! $trackback->save())
        {
            Flash::set('error', __('Trackback has not been saved!'));
            redirect(get_url('plugin/trackback/edit/'.$id));
        }
        else Flash::set('success', __('Trackback has been saved!'));
        
        redirect(get_url('plugin/trackback'));
    }
    
    function delete($id)
    {
        // �폜����g���b�N�o�b�N������
        if ($trackback = Record::findByIdFrom('Trackback', $id))
        {
            if ($trackback->delete())
                Flash::set('success', __('Trackback has been deleted!'));
            else
                Flash::set('error', __('Trackback has not been deleted!'));
        }
        else Flash::set('error', __('Trackback not found!'));
        
        redirect(get_url('plugin/trackback'));
    }
    
    function approve($id)
    {
        // �F�؂���g���b�N�o�b�N������
        if ($trackback = Record::findByIdFrom('Trackback', $id))
        {
            $trackback->is_approved = 1;
            if ($trackback->save())
                Flash::set('success', __('Trackback has been approved!'));
        }
        else Flash::set('error', __('Trackback not found!'));
        
        redirect(get_url('plugin/trackback'));
    }
    
    function unapprove($id)
    {
        // ��F�؂���g���b�N�o�b�N������
        if ($trackback = Record::findByIdFrom('Trackback', $id))
        {
            $trackback->is_approved = 0;
            if ($trackback->save())
                Flash::set('success', __('Trackback has been unapproved!'));
        }
        else Flash::set('error', __('Trackback not found!'));
        
        redirect(get_url('plugin/trackback'));
    }

} // TrackbackController class
