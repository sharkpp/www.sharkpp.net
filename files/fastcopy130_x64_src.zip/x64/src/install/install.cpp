static char *install_id = 
	"@(#)Copyright (C) H.Shirouzu 2005   install.cpp	Ver1.20";
/* ========================================================================
	Project  Name			: Installer for FastCopy
	Module Name				: Installer Application Class
	Create					: 2005-02-02(Wed)
	Update					: 2005-05-24(Tue)
	Copyright				: H.Shirouzu
	Reference				: 
	======================================================================== */

#include "../tlib.h"
#include "instrc.h"
#include "install.h"

char	*SetupFiles [] = { FASTCOPY_EXE, INSTALL_EXE, README_TXT, HELP_CHM, CURRENT_SHEXTDLL, NULL };

/*
	WinMain
*/
int WINAPI WinMain(HINSTANCE hI, HINSTANCE, LPSTR cmdLine, int nCmdShow)
{
	return	TInstApp(hI, cmdLine, nCmdShow).Run();
}

/*
	�C���X�g�[���A�v���P�[�V�����N���X
*/
TInstApp::TInstApp(HINSTANCE _hI, LPSTR _cmdLine, int _nCmdShow) : TApp(_hI, _cmdLine, _nCmdShow)
{
}

TInstApp::~TInstApp()
{
}

void TInstApp::InitWindow(void)
{
	TDlg *maindlg = new TInstDlg(cmdLine);
	mainWnd = maindlg;
	maindlg->Create();
}


/*
	���C���_�C�A���O�N���X
*/
TInstDlg::TInstDlg(char *cmdLine) : TDlg(INSTALL_DIALOG), staticText(this)
{
	cfg.mode = strcmp(cmdLine, "/r") ? SETUP_MODE : UNINSTALL_MODE;
	cfg.programLink	= TRUE;
	cfg.desktopLink	= TRUE;
}

TInstDlg::~TInstDlg()
{
}

/*
	���C���_�C�A���O�p WM_INITDIALOG �������[�`��
*/
BOOL TInstDlg::EvCreate(LPARAM lParam)
{
	GetWindowRect(&rect);
	int		cx = ::GetSystemMetrics(SM_CXFULLSCREEN), cy = ::GetSystemMetrics(SM_CYFULLSCREEN);
	int		xsize = rect.right - rect.left, ysize = rect.bottom - rect.top;

	::SetClassLongPtr(hWnd, GCLP_HICON, (LONG_PTR)::LoadIcon(TApp::GetInstance(), (LPCSTR)SETUP_ICON));
	MoveWindow((cx - xsize)/2, (cy - ysize)/2, xsize, ysize, TRUE);
	Show();

// �v���p�e�B�V�[�g�̐���
	staticText.CreateByWnd(GetDlgItem(INSTALL_STATIC));
	propertySheet = new TInstSheet(&staticText, &cfg);

// ���݃f�B���N�g���ݒ�
	char		buf[MAX_PATH], setupDir[MAX_PATH];
	TRegistry	reg(HKEY_LOCAL_MACHINE);

// Program Files�̃p�X���o��
	if (reg.OpenKey(REGSTR_PATH_SETUP)) {
		if (reg.GetStr(REGSTR_PROGRAMFILES, buf, sizeof(buf)))
			MakePath(setupDir, buf, FASTCOPY);
		reg.CloseKey();
	}

// ���ɃZ�b�g�A�b�v����Ă���ꍇ�́A�Z�b�g�A�b�v�f�B���N�g����ǂݏo��
	if (reg.OpenKey(REGSTR_PATH_UNINSTALL)) {
		if (reg.OpenKey(FASTCOPY)) {
			if (reg.GetStr(REGSTR_VAL_UNINSTALLER_COMMANDLINE, setupDir, sizeof(setupDir)))
				GetParentDir(setupDir, setupDir);
			reg.CloseKey();
		}
		reg.CloseKey();
	}
	SetDlgItemText(FILE_EDIT, setupDir);

	CheckDlgButton(cfg.mode == SETUP_MODE ? SETUP_RADIO : UNINSTALL_RADIO, 1);
	ChangeMode();

	return	TRUE;
}

/*
	���C���_�C�A���O�p WM_COMMAND �������[�`��
*/
BOOL TInstDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID) {
	case IDOK:
		propertySheet->GetData();
		if (cfg.mode == UNINSTALL_MODE)
			UnInstall();
		else
			Install();
		return	TRUE;

	case IDCANCEL:
		::PostQuitMessage(0);
		return	TRUE;

	case FILE_BUTTON:
		BrowseDirDlg(this, FILE_EDIT, "Select Install Directory");
		return	TRUE;

	case SETUP_RADIO:
	case UNINSTALL_RADIO:
		if (wNotifyCode == BN_CLICKED)
			ChangeMode();
		return	TRUE;
	}
	return	FALSE;
}

void TInstDlg::ChangeMode(void)
{
	cfg.mode = IsDlgButtonChecked(SETUP_RADIO) ? SETUP_MODE : UNINSTALL_MODE;
	::EnableWindow(GetDlgItem(FILE_EDIT), cfg.mode == SETUP_MODE);
	propertySheet->Paste();
}

BOOL IsSameFile(char *src, char *dst)
{
	WIN32_FIND_DATA	src_dat, dst_dat;
	HANDLE	hFind;

	if ((hFind = ::FindFirstFile(src, &src_dat)) == INVALID_HANDLE_VALUE)
		return	FALSE;
	::FindClose(hFind);

	if ((hFind = ::FindFirstFile(dst, &dst_dat)) == INVALID_HANDLE_VALUE)
		return	FALSE;
	::FindClose(hFind);

	if (src_dat.nFileSizeLow != dst_dat.nFileSizeLow || src_dat.nFileSizeHigh != dst_dat.nFileSizeHigh)
		return	FALSE;

	return	(*(_int64 *)&dst_dat.ftLastWriteTime == *(_int64 *)&src_dat.ftLastWriteTime) ||
		// src �� dst �̃^�C���X�^���v�̍ŏ��P�ʂ� 1 �b�ȏ�iFAT or SAMBA ���̉\���j�ł���...
		// �^�C���X�^���v�̍��� 2 �b�ȓ��Ȃ�A����^�C���X�^���v�Ƃ݂Ȃ�
		((*(_int64 *)&src_dat.ftLastWriteTime % 10000000) == 0 || (*(_int64 *)&dst_dat.ftLastWriteTime % 10000000) == 0) &&
			*(_int64 *)&dst_dat.ftLastWriteTime + 20000000 >= *(_int64 *)&src_dat.ftLastWriteTime &&
			*(_int64 *)&dst_dat.ftLastWriteTime - 20000000 <= *(_int64 *)&src_dat.ftLastWriteTime;
}

BOOL DelayCopy(char *src, char *dst)
{
	char	tmp_file[MAX_PATH];
	BOOL	ret = FALSE;

	wsprintf(tmp_file, "%s.new", dst);

	if (::CopyFile(src, tmp_file, FALSE) == FALSE)
		return	FALSE;

	if (IsWinNT()) {
		ret = ::MoveFileEx(tmp_file, dst, MOVEFILE_DELAY_UNTIL_REBOOT|MOVEFILE_REPLACE_EXISTING);
	}
	else {
		char	win_ini[MAX_PATH], short_tmp[MAX_PATH], short_dst[MAX_PATH];

		::GetShortPathName(tmp_file, short_tmp, sizeof(short_tmp));
		::GetShortPathName(dst, short_dst, sizeof(short_dst));
		::GetWindowsDirectory(win_ini, sizeof(win_ini));
		strcat(win_ini, "\\WININIT.INI");
		// WritePrivateProfileString("Rename", "NUL", short_dst, win_ini); �K�v�Ȃ���
		ret = WritePrivateProfileString("Rename", short_dst, short_tmp, win_ini);
	}
	return	ret;
}

BOOL TInstDlg::Install(void)
{
	char	buf[MAX_PATH], setupDir[MAX_PATH], setupPath[MAX_PATH], curDir[MAX_PATH];
	BOOL	is_delay_copy = FALSE;

// �C���X�g�[���p�X�ݒ�
	GetDlgItemText(FILE_EDIT, setupDir, sizeof(setupDir));
	CreateDirectory(setupDir, NULL);
	DWORD	attr = GetFileAttributes(setupDir);

	if (attr == 0xffffffff || (attr & FILE_ATTRIBUTE_DIRECTORY) == 0)
		return	MessageBox(GetLoadStr(IDS_NOTCREATEDIR)), FALSE;
	MakePath(setupPath, setupDir, FASTCOPY_EXE);

	if (MessageBox(GetLoadStr(IDS_START), INSTALL_STR, MB_OKCANCEL|MB_ICONINFORMATION) != IDOK)
		return	FALSE;

// �t�@�C���R�s�[
	if (cfg.mode == SETUP_MODE) {
		char	installPath[MAX_PATH], orgDir[MAX_PATH];

		::GetModuleFileName(NULL, orgDir, sizeof(orgDir));
		GetParentDir(orgDir, orgDir);

		for (int cnt=0; SetupFiles[cnt] != NULL; cnt++) {
			MakePath(buf, orgDir, SetupFiles[cnt]);
			MakePath(installPath, setupDir, SetupFiles[cnt]);

			if (::CopyFile(buf, installPath, FALSE) || IsSameFile(buf, installPath))
				continue;
			if (strcmp(SetupFiles[cnt], CURRENT_SHEXTDLL) == 0 && DelayCopy(buf, installPath)) {
				is_delay_copy = TRUE;
				continue;
			}
			return	MessageBox(installPath, GetLoadStr(IDS_NOTCREATEFILE)), FALSE;
		}
	}

// �X�^�[�g�A�b�v���f�X�N�g�b�v�ɓo�^
	TRegistry	reg(HKEY_CURRENT_USER);
	if (reg.OpenKey(REGSTR_SHELLFOLDERS)) {
		char	*regStr[]	= { REGSTR_PROGRAMS, REGSTR_DESKTOP, NULL };
		BOOL	execFlg[]	= { cfg.programLink, cfg.desktopLink, NULL };

		for (int cnt=0; regStr[cnt]; cnt++) {
			if (reg.GetStr(regStr[cnt], buf, sizeof(buf))) {
				if (cnt != 0 || RemoveSameLink(buf, buf) != TRUE)
					::wsprintf(buf + strlen(buf), "\\%s", FASTCOPY_SHORTCUT);
				if (execFlg[cnt])
					SymLink(setupPath, buf);
				else
					DeleteLink(buf);
			}
		}
		reg.CloseKey();
	}

// �V�F���g������ update
	::GetModuleFileName(NULL, curDir, sizeof(curDir));
	GetParentDir(curDir, curDir);

	MakePath(buf, setupDir, CURRENT_SHEXTDLL);
	HMODULE		hShellExtDll = TLoadLibrary(buf);

	if (hShellExtDll) {
		BOOL (WINAPI *UpdateDllProc)(void) = (BOOL (WINAPI *)(void))GetProcAddress(hShellExtDll, "UpdateDll");

		if (UpdateDllProc)
			UpdateDllProc();
		::FreeLibrary(hShellExtDll);

		// ���o�[�W���� dll �̍폜
		char	*oldDlls[] = { SHELLEXT1_DLL, SHELLEXT2_DLL, SHELLEXT3_DLL, SHELLEXT4_DLL, NULL };
		for (int i=0; oldDlls[i]; i++) {
			MakePath(buf, setupDir, oldDlls[i]);
			if (::GetFileAttributes(buf) != 0xffffffff) {
				if (::DeleteFile(buf) == FALSE)
					::MoveFileEx(buf, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
			}
		}
	}

#if 0
// ���W�X�g���ɃA���C���X�g�[������o�^
	if (reg.OpenKey(REGSTR_PATH_UNINSTALL)) {
		if (reg.CreateKey(FASTCOPY)) {
			MakePath(buf, setupDir, INSTALL_EXE);
			strcat(buf, " /r");
			reg.SetStr(REGSTR_VAL_UNINSTALLER_DISPLAYNAME, FASTCOPY);
			reg.SetStr(REGSTR_VAL_UNINSTALLER_COMMANDLINE, buf);
			reg.CloseKey();
		}
		reg.CloseKey();
	}
#endif

// �R�s�[�����A�v���P�[�V�������N��
	if (MessageBox(GetLoadStr(is_delay_copy ? IDS_DELAYSETUPCOMPLETE : IDS_SETUPCOMPLETE), INSTALL_STR, MB_OKCANCEL|MB_ICONINFORMATION) == IDOK) {
		::SetCurrentDirectory(setupDir);
		::WinExec(setupPath, SW_SHOW);
	}

	::PostQuitMessage(0);
	return	TRUE;
}

BOOL TInstDlg::UnInstall(void)
{
	char	buf[MAX_PATH];

	if (MessageBox(GetLoadStr(IDS_START), UNINSTALL_STR, MB_OKCANCEL|MB_ICONINFORMATION) != IDOK)
		return	FALSE;

// �X�^�[�g�A�b�v���f�X�N�g�b�v����폜
	TRegistry	reg(HKEY_CURRENT_USER);
	if (reg.OpenKey(REGSTR_SHELLFOLDERS)) {
		char	*regStr[]	= { REGSTR_PROGRAMS, REGSTR_DESKTOP, NULL };

		for (int cnt=0; regStr[cnt] != NULL; cnt++) {
			if (reg.GetStr(regStr[cnt], buf, sizeof(buf))) {
				if (cnt == 0)
					RemoveSameLink(buf);
				::wsprintf(buf + strlen(buf), "\\%s", FASTCOPY_SHORTCUT);
				DeleteLink(buf);
			}
		}
		reg.CloseKey();
	}

// ���W�X�g������A�v���P�[�V���������폜
	char	setupDir[MAX_PATH] = "";

	::GetModuleFileName(NULL, setupDir, sizeof(setupDir));
	GetParentDir(setupDir, setupDir);
	BOOL	is_shext = FALSE;

	MakePath(buf, setupDir, CURRENT_SHEXTDLL);
	HMODULE		hShellExtDll = TLoadLibrary(buf);
	if (hShellExtDll) {
		BOOL (WINAPI *IsRegistDllProc)(void) = (BOOL (WINAPI *)(void))GetProcAddress(hShellExtDll, "IsRegistServer");
		HRESULT (WINAPI *UnRegistDllProc)(void) = (HRESULT (WINAPI *)(void))GetProcAddress(hShellExtDll, "DllUnregisterServer");

		if (IsRegistDllProc && UnRegistDllProc && (is_shext = IsRegistDllProc())) {
			UnRegistDllProc();
		}
		::FreeLibrary(hShellExtDll);
	}

// ���W�X�g������A���C���X�g�[�������폜
	if (reg.OpenKey(REGSTR_PATH_UNINSTALL)) {
		if (reg.OpenKey(FASTCOPY)) {
			if (reg.GetStr(REGSTR_VAL_UNINSTALLER_COMMANDLINE, setupDir, sizeof(setupDir)))
				GetParentDir(setupDir, setupDir);
			reg.CloseKey();
		}
		reg.DeleteKey(FASTCOPY);
		reg.CloseKey();
	}

// �I�����b�Z�[�W
	MessageBox(is_shext ? GetLoadStr(IDS_UNINSTSHEXTFIN) : GetLoadStr(IDS_UNINSTFIN));

// �C���X�g�[���f�B���N�g�����J��
	if (*setupDir)
		::ShellExecute(NULL, NULL, setupDir, 0, 0, SW_SHOW);

	::PostQuitMessage(0);
	return	TRUE;
}

/*
	�������e�����V���[�g�J�b�g���폜�i�X�^�[�g�A�b�v�ւ̏d���o�^�悯�j
*/
BOOL TInstDlg::RemoveSameLink(const char *dir, char *remove_path)
{
	char			path[MAX_PATH], dest[MAX_PATH], arg[MAX_PATH];
	HANDLE			fh;
	WIN32_FIND_DATA	data;
	BOOL			ret = FALSE;

	::wsprintf(path, "%s\\*.*", dir);
	if ((fh = ::FindFirstFile(path, &data)) == INVALID_HANDLE_VALUE)
		return	FALSE;

	do {
		::wsprintf(path, "%s\\%s", dir, data.cFileName);
		if (ReadLink(path, dest, arg) && *arg == 0) {
			int		dest_len = strlen(dest), fastcopy_len = strlen(FASTCOPY_EXE);
			if (dest_len > fastcopy_len && strncmpi(dest + dest_len - fastcopy_len, FASTCOPY_EXE, fastcopy_len) == 0) {
				ret = ::DeleteFile(path);
				if (remove_path != NULL)
					strcpy(remove_path, path);
			}
		}

	} while (::FindNextFile(fh, &data));

	::FindClose(fh);
	return	ret;
}

TInstSheet::TInstSheet(TWin *_parent, InstallCfg *_cfg) : TDlg(INSTALL_SHEET, _parent)
{
	cfg = _cfg;
}

void TInstSheet::GetData(void)
{
	if (resId == UNINSTALL_SHEET) {
	}
	else {
		cfg->programLink = IsDlgButtonChecked(PROGRAM_CHECK);
		cfg->desktopLink = IsDlgButtonChecked(DESKTOP_CHECK);
	}
}

void TInstSheet::PutData(void)
{
	if (resId == UNINSTALL_SHEET) {
	}
	else {
		CheckDlgButton(PROGRAM_CHECK, cfg->programLink);
		CheckDlgButton(DESKTOP_CHECK, cfg->desktopLink);
	}
}

void TInstSheet::Paste(void)
{
	if (hWnd) {
		if ((resId == UNINSTALL_SHEET) == (cfg->mode == UNINSTALL_MODE))
			return;
		GetData();
		Destroy();
	}
	resId = cfg->mode == UNINSTALL_MODE ? UNINSTALL_SHEET : INSTALL_SHEET;

	Create();
	PutData();
}

BOOL TInstSheet::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID)
	{
	case IDOK:	case IDCANCEL:
		{
			TWin	*top = parent;
			while (top->GetParent())
				top = top->GetParent();
			top->EvCommand(wNotifyCode, wID, hwndCtl);
		}
		return	TRUE;
	}
	return	FALSE;
}

BOOL TInstSheet::EvCreate(LPARAM lParam)
{
	Show();
	return	TRUE;
}

/*
	�f�B���N�g���_�C�A���O�p�ėp���[�`��
*/
void BrowseDirDlg(TWin *parentWin, UINT editCtl, char *title)
{ 
	IMalloc			*iMalloc = NULL;
	BROWSEINFO		brInfo;
	LPITEMIDLIST	pidlBrowse;
	char			fileBuf[MAX_PATH];

	parentWin->GetDlgItemText(editCtl, fileBuf, sizeof(fileBuf));
	if (!SUCCEEDED(SHGetMalloc(&iMalloc)))
		return;

	TBrowseDirDlg	dirDlg(fileBuf);
	brInfo.hwndOwner = parentWin->hWnd;
	brInfo.pidlRoot = 0;
	brInfo.pszDisplayName = fileBuf;
	brInfo.lpszTitle = title;
	brInfo.ulFlags = BIF_RETURNONLYFSDIRS;
	brInfo.lpfn = BrowseDirDlg_Proc;
	brInfo.lParam = (LPARAM)&dirDlg;
	brInfo.iImage = 0;

	do {
		if ((pidlBrowse = ::SHBrowseForFolder(&brInfo)) != NULL) {
			if (::SHGetPathFromIDList(pidlBrowse, fileBuf))
				::SetDlgItemText(parentWin->hWnd, editCtl, fileBuf);
			iMalloc->Free(pidlBrowse);
			break;
		}
	} while (dirDlg.IsDirty());

	iMalloc->Release();
}

/*
	BrowseDirDlg�p�R�[���o�b�N
*/
int CALLBACK BrowseDirDlg_Proc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM data)
{
	switch (uMsg) {
	case BFFM_INITIALIZED:
		((TBrowseDirDlg *)data)->CreateByWnd(hWnd);
		break;

	case BFFM_SELCHANGED:
		if (((TBrowseDirDlg *)data)->hWnd)
			((TBrowseDirDlg *)data)->SetFileBuf(lParam);
		break;
	}
	return 0;
}

/*
	BrowseDlg�p�T�u�N���X����
*/
BOOL TBrowseDirDlg::CreateByWnd(HWND _hWnd)
{
	BOOL	ret = TSubClass::CreateByWnd(_hWnd);
	dirtyFlg = FALSE;

// �f�B���N�g���ݒ�
	DWORD	attr = GetFileAttributes(fileBuf);
	if (attr == 0xffffffff || (attr & FILE_ATTRIBUTE_DIRECTORY) == 0)
		GetParentDir(fileBuf, fileBuf);
	SendMessage(BFFM_SETSELECTION, TRUE, (LPARAM)fileBuf);
	SetWindowText(FASTCOPY);

// �{�^���쐬
	RECT	tmp_rect;
	::GetWindowRect(GetDlgItem(IDOK), &tmp_rect);
	POINT	pt = { tmp_rect.left, tmp_rect.top };
	::ScreenToClient(hWnd, &pt);
	int		cx = (pt.x - 30) / 2, cy = tmp_rect.bottom - tmp_rect.top;

	::CreateWindow(BUTTON_CLASS, GetLoadStr(IDS_MKDIR), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, 10, pt.y, cx, cy, hWnd, (HMENU)MKDIR_BUTTON, TApp::GetInstance(), NULL);
	::CreateWindow(BUTTON_CLASS, GetLoadStr(IDS_RMDIR), WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON, 18 + cx, pt.y, cx, cy, hWnd, (HMENU)RMDIR_BUTTON, TApp::GetInstance(), NULL);

	HFONT	hDlgFont = (HFONT)SendDlgItemMessage(IDOK, WM_GETFONT, 0, 0L);
	if (hDlgFont) {
		SendDlgItemMessage(MKDIR_BUTTON, WM_SETFONT, (UINT)hDlgFont, 0L);
		SendDlgItemMessage(RMDIR_BUTTON, WM_SETFONT, (UINT)hDlgFont, 0L);
	}

	return	ret;
}

/*
	BrowseDlg�p WM_COMMAND ����
*/
BOOL TBrowseDirDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID) {
	case MKDIR_BUTTON:
		{
			char		dirBuf[MAX_PATH], path[MAX_PATH];
			TInputDlg	dlg(dirBuf, this);
			if (dlg.Exec() == FALSE)
				return	TRUE;

			MakePath(path, fileBuf, dirBuf);
			if (::CreateDirectory(path, NULL)) {
				strcpy(fileBuf, path);
				dirtyFlg = TRUE;
				PostMessage(WM_CLOSE, 0, 0);
			}
		}
		return	TRUE;

	case RMDIR_BUTTON:
		if (::RemoveDirectory(fileBuf)) {
			GetParentDir(fileBuf, fileBuf);
			dirtyFlg = TRUE;
			PostMessage(WM_CLOSE, 0, 0);
		}
		return	TRUE;
	}
	return	FALSE;
}

BOOL TBrowseDirDlg::SetFileBuf(LPARAM list)
{
	return	::SHGetPathFromIDList((LPITEMIDLIST)list, fileBuf);
}

/*
	��s����
*/
BOOL TInputDlg::EvCommand(WORD wNotifyCode, WORD wID, LPARAM hwndCtl)
{
	switch (wID) {
	case IDOK:
		GetDlgItemText(INPUT_EDIT, dirBuf, MAX_PATH);
		EndDialog(TRUE);
		return	TRUE;

	case IDCANCEL:
		EndDialog(FALSE);
		return	TRUE;
	}
	return	FALSE;
}

/*
	�e�f�B���N�g���擾�i�K���t���p�X�ł��邱�ƁBUNC�Ή��j
*/
BOOL GetParentDir(const char *srcfile, char *dir)
{
	char	path[MAX_PATH], *fname=NULL;

	if (::GetFullPathName(srcfile, sizeof(path), path, &fname) == 0 || fname == NULL)
		return	strcpy(dir, srcfile), FALSE;

	if (fname - path > 3 || path[1] != ':')
		*(fname - 1) = 0;
	else
		*fname = 0;		// C:\ �̏ꍇ

	strcpy(dir, path);
	return	TRUE;
}

/*
	�t�@�C���̕ۑ�����Ă���h���C�u����
*/
UINT GetDriveTypeEx(const char *file)
{
	if (file == NULL)
		return	GetDriveType(NULL);

	if (IsUncFile(file))
		return	DRIVE_REMOTE;

	char	buf[MAX_PATH];
	int		len = strlen(file), len2;

	strcpy(buf, file);
	do {
		len2 = len;
		GetParentDir(buf, buf);
		len = strlen(buf);
	} while (len != len2);

	return	GetDriveType(buf);
}

/*
	�啶���������𖳎����� strncmp
*/
int strncmpi(const char *str1, const char *str2, int num)
{
	for (int cnt=0; cnt < num; cnt++) {
		char	c1 = toupper(str1[cnt]), c2 = toupper(str2[cnt]);

		if (c1 == c2) {
			if (c1)
				continue;
			else
				return	0;
		}
		if (c1 > c2)
			return	1;
		else
			return	-1;
	}
	return	0;
}


/*
	�����N
	���炩���߁ACoInitialize(NULL); �����s���Ă�������
*/
BOOL SymLink(LPCSTR src, LPSTR dest, LPCSTR arg)
{
	IShellLink		*shellLink;
	IPersistFile	*persistFile;
	WCHAR			wbuf[MAX_PATH];
	BOOL			ret = FALSE;
	char			buf[MAX_PATH];

	if (SUCCEEDED(CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_IShellLink, (void **)&shellLink))) {
		shellLink->SetPath(src);
		shellLink->SetArguments(arg);
		GetParentDir(src, buf);
		shellLink->SetWorkingDirectory(buf);
		if (SUCCEEDED(shellLink->QueryInterface(IID_IPersistFile, (void **)&persistFile))) {
			MultiByteToWideChar(CP_ACP, 0, dest, -1, wbuf, MAX_PATH);
			if (SUCCEEDED(persistFile->Save(wbuf, TRUE))) {
				ret = TRUE;
				GetParentDir(dest, buf);
				::SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_PATH|SHCNF_FLUSH, buf, NULL);
			}
			persistFile->Release();
		}
		shellLink->Release();
	}
	return	ret;
}

/*
	�����N�̉���
	���炩���߁ACoInitialize(NULL); �����s���Ă�������
*/
BOOL ReadLink(LPCSTR src, LPSTR dest, LPSTR arg)
{
	IShellLink		*shellLink;
	IPersistFile	*persistFile;
	WCHAR			wbuf[MAX_PATH];
	BOOL			ret = FALSE;

	if (SUCCEEDED(CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_IShellLink, (void **)&shellLink))) {
		if (SUCCEEDED(shellLink->QueryInterface(IID_IPersistFile, (void **)&persistFile))) {
			::MultiByteToWideChar(CP_ACP, 0, src, -1, wbuf, MAX_PATH);
			if (SUCCEEDED(persistFile->Load(wbuf, STGM_READ))) {
				if (SUCCEEDED(shellLink->GetPath(dest, MAX_PATH, NULL, SLGP_SHORTPATH))) {
					shellLink->GetArguments(arg, MAX_PATH);
					ret = TRUE;
				}
			}
			persistFile->Release();
		}
		shellLink->Release();
	}
	return	ret;
}

/*
	�����N�t�@�C���폜
*/
BOOL DeleteLink(LPCSTR path)
{
	char	dir[MAX_PATH];

	if (::DeleteFile(path) != TRUE)
		return	FALSE;

	GetParentDir(path, dir);
	::SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_PATH|SHCNF_FLUSH, dir, NULL);

	return	TRUE;
}

