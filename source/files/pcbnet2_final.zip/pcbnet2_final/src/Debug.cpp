// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include "common.h"



EXPORT BOOL WINAPI netdebug(char *p1, int p2, int p3, int p4)
{
	*p1 = '\0';
	SOCKETINFO *si = (SOCKETINFO *)p2;
	if (! IsSocket(si))
		if (bStrict) return HSPERROR_INVALID_SOCKET; else return -1;

	char bl[2][6] = { "FALSE", "TRUE" };
	struct sockaddr_storage addr;
	int addrlen;
	DWORD dw;
	char s[128];
	int i;
	addrinfo *res;

	si->Lock();

	p1+=sprintf(p1, "SocketID: 0x%x\r\n", (unsigned int)si);
	p1+=sprintf(p1, "Type: %d\r\n", si->type);
	p1+=sprintf(p1, "Window Handle: 0x%x\r\n", (unsigned int)si->hWnd);
	p1+=sprintf(p1, "ThreadID: 0x%x\r\n", (unsigned int)si->threadID);
	p1+=sprintf(p1, "Thread Handle: 0x%x\r\n", (unsigned int)si->hThread);
	p1+=sprintf(p1, "AsyncWindow: 0x%x\r\n", (unsigned int)si->hWnd);
	p1+=sprintf(p1, "ErrorStatus: %d\r\n", si->err);
	p1+=sprintf(p1, "AsyncTaskFlag: 0x%08x\r\n", si->fAsyncTask);
	p1+=sprintf(p1, "User-definedValue: %u\r\n", (unsigned int)si->dwUser);
	p1+=sprintf(p1, "Closing: %s\r\n", bl[si->bClosing]);
	p1+=sprintf(p1, "UpTime: %u\r\n", GetTickCount()-si->stat.createTime);
	p1+=sprintf(p1, "ReceivedOctets: %d\r\n", si->stat.receivedOctets);
	p1+=sprintf(p1, "SentOctets: %d\r\n", si->stat.sentOctets);
	p1+=sprintf(p1, "PortMapping: %s\r\n", bl[si->map.bAvailable]);
	if (si->map.bAvailable) {
		p1+=sprintf(p1, "PortMappingErrorCode: %d\r\n", si->map.err);
		p1+=sprintf(p1, "PortMappingSocketType: %d\r\n", si->map.socktype);
		p1+=sprintf(p1, "PortMappingInternalAddress: %s:%d\r\n", inet_ntoa(si->map.inaddr.sin_addr), ntohs(si->map.inaddr.sin_port));
		p1+=sprintf(p1, "PortMappingExternalAddress: %s:%d\r\n", inet_ntoa(si->map.exaddr.sin_addr), ntohs(si->map.exaddr.sin_port));
		p1+=sprintf(p1, "PortMappingDescription: %s\r\n", si->map.description);
	}

	if (si->type & ST_TCP) {
		p1+=sprintf(p1, "Socket Descriptor: 0x%x\r\n", (unsigned int)si->soc[0]);
		addrlen = sizeof(addr);
		getsockname(si->soc[0], (sockaddr *)&addr, &addrlen);
		dw = sizeof(s);
		WSAAddressToString((sockaddr *)&addr, addrlen, NULL, s, &dw);
		p1+=sprintf(p1, "LocalAddress: %s\r\n", s);
		dw = sizeof(s);
		WSAAddressToString((sockaddr *)&si->addr, si->addrlen, NULL, s, &dw);
		p1+=sprintf(p1, "PeerAddress: %s\r\n", s);
		p1+=sprintf(p1, "HostName: %s\r\n", si->tcp.hostname);
		p1+=sprintf(p1, "Connected: %s\r\n", bl[si->tcp.bSendable]);
		p1+=sprintf(p1, "Blocking: %s\r\n", bl[si->tcp.bBlocking]);
		p1+=sprintf(p1, "Shutting: %s\r\n", bl[si->tcp.bShutting]);
		p1+=sprintf(p1, "Sending: %s\r\n", bl[si->tcp.bSending]);
		p1+=sprintf(p1, "ReadPending: %s\r\n", bl[si->tcp.bReadPending]);
		p1+=sprintf(p1, "BufferLen: %d\r\n", bl[si->tcp.iBufferLen]);
		p1+=sprintf(p1, "ReadBuf: %dbytes used\r\n", si->tcp.r->Size());
		p1+=sprintf(p1, "SendBuf: %dbytes used\r\n", si->tcp.s->Size());
		p1+=sprintf(p1, "AddressInfoPointer: %08x\r\n", si->tcp.res0);
	}
	if (si->type & ST_TCPLIS) {
		p1+=sprintf(p1, "tcplis.bListening: %s\r\n", bl[si->tcplis.bListening]);
		for(i=0; i<MAX_SOCKET&&si->soc[i]!=NULL; i++)  {
			p1+=sprintf(p1, "SocketDescriptor[%d]: 0x%x\r\n", i, (unsigned int)si->soc[i]);
			p1+=sprintf(p1, "Incoming[%d]: %s\r\n", i, bl[si->tcplis.bIncoming[i]]);
		}
	}
	if (si->type & ST_UDP) {
		for(i=0; i<MAX_SOCKET&&si->soc[i]!=NULL; i++)  {
			p1+=sprintf(p1, "SocketDescriptor[%d]: 0x%x\r\n", i, (unsigned int)si->soc[i]);
		}
		dw = sizeof(s);
		WSAAddressToString((sockaddr *)&si->addr, si->addrlen, NULL, s, &dw);
		p1+=sprintf(p1, "PeerAddress: %s\r\n", s);
		p1+=sprintf(p1, "HostName: %s\r\n", si->udp.hostname);
		p1+=sprintf(p1, "Bound: %s\r\n", bl[si->udp.bBound]);
		p1+=sprintf(p1, "Blocking: %s\r\n", bl[si->udp.bBlocking]);
		p1+=sprintf(p1, "Sendable: %s\r\n", bl[si->udp.bSendable]);
		p1+=sprintf(p1, "ReadPending: %s\r\n", bl[si->udp.bReadPending]);
		p1+=sprintf(p1, "BufferLen: %d\r\n", bl[si->udp.iBufferLen]);
		p1+=sprintf(p1, "ReadBuf: %d Packets %d bytes\r\n", si->udp.r->Count(), si->udp.r->Size());
		p1+=sprintf(p1, "SendBuf: %d Packets %d bytes\r\n", si->udp.s->Count(), si->udp.r->Size());
		dw = sizeof(s);
		WSAAddressToString((sockaddr *)&si->udp.fromaddr, si->udp.fromaddrlen, NULL, s, &dw);
		p1+=sprintf(p1, "LastFromAddress: %s\r\n", s);
	}
	if (si->type & ST_DNS) {
		p1+=sprintf(p1, "Reply: %s\r\n", bl[si->dns.bReply]);
		p1+=sprintf(p1, "Hostname: %s\r\n", si->dns.hostname);
		for(i=0, res=si->dns.res0; res!=NULL; i++, res=res->ai_next) {
			dw = sizeof(s);
			WSAAddressToString((sockaddr *)res->ai_addr, res->ai_addrlen, NULL, s, &dw);
			sprintf(p1, "HostInfo[%d].Family: %s\r\n", i, (int)res->ai_family);
			sprintf(p1, "HostInfo[%d].SockType: %s\r\n", i, (int)res->ai_socktype);
			sprintf(p1, "HostInfo[%d].Protocol: %s\r\n", i, (int)res->ai_protocol);
			sprintf(p1, "HostInfo[%d].Address: %s\r\n", i, s);
		}
	}
	if (si->type & ST_PING) {
		p1+=sprintf(p1, "HostName: %s\r\n", si->ping.hostname);
		p1+=sprintf(p1, "Result: %s\r\n", bl[si->ping.bResult]);
		p1+=sprintf(p1, "TimeOut: %d\r\n", si->ping.iTimeOut);
		p1+=sprintf(p1, "TTL: %d\r\n", si->ping.TTL);
		p1+=sprintf(p1, "ReplyCode: %d\r\n", (int)si->ping.replycode);
		p1+=sprintf(p1, "TripTime: %d\r\n", si->ping.iTripTime);
		if (getnameinfo((struct sockaddr *)&si->ping.fromaddr, si->ping.fromaddrlen, s, sizeof(s), NULL, 0, NI_NUMERICHOST) == 0) {
			p1+=sprintf(p1, "LastFromAddress: %s\r\n", s);
		}
	}

	si->Unlock();
	return 0;
}









