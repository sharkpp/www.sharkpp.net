<?php

// �G�N�X�|�[�g�R���g���[���N���X
class ExportController extends PluginController
{
	// Constructer
	public function __construct()
	{
		AuthUser::load();
		if ( ! AuthUser::isLoggedIn())
			redirect(get_url('login'));
		
		$this->setLayout('backend');
		$this->assignToLayout('sidebar', new View('../../../plugins/export/views/sidebar'));
	}

	// Plugin view main
	public function index()
	{
	//	  $this->browse();
		$this->display('export/views/index', array(
		//	  'dir'	  => $this->path,
		//	  'files' => $this->_getListFiles()
		));
	}

	// Import core
	private function export_core($controller_class)
	{
		include( dirname(__FILE__) . '/' . $controller_class . '.php' );
		$controller = new $controller_class;

		if( false === $controller->export() )
		{
			Flash::set('error', __("Can't export!"));
			redirect(get_url('plugin/export'));
		}
	}

	// Export to Frog eXtended RSS
	public function fxr()
	{
		$this->export_core('ExportFXR');
	}

} // end ConvertController class

