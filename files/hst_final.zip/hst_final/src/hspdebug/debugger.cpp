// Original code by TAKAHASHI Shuhei <pcb@pcbsoft.net>
// This code is licensed under NYSL ver. 0.9982.
// See LICENSE.txt for details.

#include <windows.h>
#include <process.h>
#include "hspdll.h"
#include "common.h"


PROCESS_INFORMATION pi;
HANDLE hDebugThread = NULL;
DWORD debugThreadId = 0;
int giDebugStat = 0;


UINT CALLBACK DebuggerThread(void *param);
EXPORT BOOL WINAPI DebugExec(BMSCR *bm, char *p1, int p2, int p3);
EXPORT BOOL WINAPI CloseDebugHandle(int p1, int p2, int p3, int p4);


UINT CALLBACK DebuggerThread(void *param)
{
	STARTUPINFO si;
	char *cmdline = (char *)param;
	BOOL bSuccess;
	MSG msg;
	DEBUG_EVENT de;

	memset(&si, 0, sizeof(si));
	memset(&pi, 0, sizeof(pi));
	si.cb = sizeof(si);
	bSuccess = CreateProcess(NULL, cmdline, NULL, NULL, FALSE, 
		DEBUG_PROCESS | NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi);
	if (! bSuccess) {
		giDebugStat = 2;
		delete [] cmdline;
		return 1;
	}
	giDebugStat = 1;

	while(1) {
		if (PeekMessage(&msg, (HWND)-1, 0, 0, PM_REMOVE)) {
			if (msg.message == WM_QUIT) break;
		}
		else if (WaitForDebugEvent(&de, 0)) {
			if (pi.dwProcessId == de.dwProcessId && 
					de.dwDebugEventCode == EXCEPTION_DEBUG_EVENT && 
					de.u.Exception.ExceptionRecord.ExceptionCode != EXCEPTION_BREAKPOINT) {
				WaitForSingleObject(hMutex, INFINITE);
				memcpy(&debuginfo->de, &de, sizeof(DEBUG_EVENT));
				debuginfo->bException = TRUE;
				ReleaseMutex(hMutex);
				ContinueDebugEvent(de.dwProcessId, de.dwThreadId, DBG_EXCEPTION_NOT_HANDLED);
			}
			else {
				ContinueDebugEvent(de.dwProcessId, de.dwThreadId, DBG_CONTINUE);
				if (pi.dwProcessId == de.dwProcessId && 
						de.dwDebugEventCode == EXIT_PROCESS_DEBUG_EVENT)
					break;
			}
		}
		else
			Sleep(10);
	}

	giDebugStat = -1;
	delete [] cmdline;
	return 0;
}


EXPORT BOOL WINAPI DebugExec(BMSCR *bm, char *p1, int p2, int p3)
{
	char *p;

	if (hDebugThread != NULL)
		return -2;

	p = new char[strlen(p1)+1];
	strcpy(p, p1);
	giDebugStat = 0;
	hDebugThread = (HANDLE)_beginthreadex(NULL, 0, DebuggerThread, p, 0, (unsigned int *)&debugThreadId);
	while(giDebugStat == 0)
		Sleep(1);

	if (giDebugStat == 2) {
		WaitForSingleObject(hDebugThread, INFINITE);
		CloseHandle(hDebugThread);
		hDebugThread = NULL;
		return -1;
	}
	return 0;
}



EXPORT BOOL WINAPI CloseDebugHandle(int p1, int p2, int p3, int p4)
{
	if (hDebugThread == NULL)
		return -1;

	if (WaitForSingleObject(hDebugThread, 0) == WAIT_TIMEOUT) {
		PostThreadMessage(debugThreadId, WM_QUIT, 0, 0);
		WaitForSingleObject(hDebugThread, INFINITE);
	}
	CloseHandle(hDebugThread);
	CloseHandle(pi.hThread);
	CloseHandle(pi.hProcess);
	hDebugThread = NULL;
	return 0;
}

